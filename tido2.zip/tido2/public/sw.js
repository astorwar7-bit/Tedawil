const CACHE_NAME = 'tadawul-ai-v3';

self.addEventListener('install', () => {
  // Don't use skipWaiting - let old SW finish gracefully
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) => Promise.all(
      names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n))
    ))
  );
  // Don't use clients.claim - let pages load normally
});

self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Only handle GET requests
  if (request.method !== 'GET') return;

  // Never intercept API calls
  if (request.url.includes('/api/')) return;

  // Never intercept navigation requests - let them go directly to the server
  if (request.mode === 'navigate') return;

  // Only cache static assets with cache-first strategy
  if (request.url.match(/\.(js|css|png|jpg|jpeg|svg|gif|ico|woff2?)$/)) {
    event.respondWith(
      caches.open(CACHE_NAME).then((cache) =>
        cache.match(request).then((cached) => {
          if (cached) return cached;
          return fetch(request).then((res) => {
            if (res.ok) cache.put(request, res.clone());
            return res;
          }).catch(() => new Response('Offline', { status: 503 }));
        })
      )
    );
  }
});
