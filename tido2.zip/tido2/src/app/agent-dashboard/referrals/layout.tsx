export default function AgentReferralsLayout({ children }: { children: React.ReactNode }) { return <>{children}</>; }
