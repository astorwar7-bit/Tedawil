'use client';
import { useEffect, useState } from 'react';
import { Users, Copy, DollarSign, User, CheckCircle, XCircle, Search, TrendingUp, Wallet, ArrowDownToLine, Gem, Filter, Clock } from 'lucide-react';
import { useToast } from '@/contexts/ToastContext';

interface Referral {
  id: string;
  username: string;
  email: string;
  fullName: string;
  balance: number;
  isActive: boolean;
  createdAt: string;
  totalDeposited: number;
  totalInvested: number;
  activeInvestmentsCount: number;
  depositCount: number;
}

interface AgentStats {
  totalCommissionEarned: number;
  referredUsersCount: number;
  activeReferrals: number;
  totalDepositsFromReferrals: number;
  totalInvestmentsFromReferrals: number;
}

export default function AgentReferralsPage() {
  const { showToast } = useToast();
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [stats, setStats] = useState<AgentStats>({ totalCommissionEarned: 0, referredUsersCount: 0, activeReferrals: 0, totalDepositsFromReferrals: 0, totalInvestmentsFromReferrals: 0 });
  const [referralCode, setReferralCode] = useState('');
  const [commissionRate, setCommissionRate] = useState(0);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const res = await fetch('/api/agents/dashboard');
        const data = await res.json();
        if (res.ok) {
          setReferrals(data.referrals || []);
          setStats(data.stats || {});
          setReferralCode(data.user.referralCode);
          setCommissionRate(data.user.commissionRate);
        }
      } catch {}
      setLoading(false);
    };
    fetchDashboard();
  }, []);

  const copyCode = () => {
    navigator.clipboard.writeText(referralCode);
    showToast('تم نسخ كود الإحالة');
  };

  const copyRefLink = () => {
    const link = `${window.location.origin}/register?ref=${referralCode}`;
    navigator.clipboard.writeText(link);
    showToast('تم نسخ رابط الإحالة');
  };

  const fmt = (n: number) => `$${n.toLocaleString('en', { minimumFractionDigits: 2 })}`;

  const filteredReferrals = referrals.filter(r => {
    const matchesSearch = !searchQuery || r.username.toLowerCase().includes(searchQuery.toLowerCase()) || r.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || (filterStatus === 'active' ? r.isActive : !r.isActive);
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>;
  }

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2ECC71]/20 to-[#FFD700]/20 flex items-center justify-center border border-[#2ECC71]/20">
          <Users size={18} className="text-[#2ECC71]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">الإحالات</h1>
          <p className="text-gray-500 text-xs mt-0.5">{referrals.length} مستخدم محال | عمولة {commissionRate}%</p>
        </div>
      </div>

      {/* Referral Code Banner */}
      <div className="glass-card p-5 featured-border">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0">
              <Copy size={22} className="text-[#FFD700]" />
            </div>
            <div>
              <h3 className="text-white font-bold">كود الإحالة الخاص بك</h3>
              <p className="text-gray-400 text-xs mt-0.5">شاركه مع عملائك | عمولة {commissionRate}% من كل إيداع</p>
              <p className="text-gray-600 text-[11px] mt-1 font-mono truncate max-w-[250px]" dir="ltr">{window.location.origin}/register?ref={referralCode}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <code className="text-[#FFD700] font-bold text-lg px-4 py-2 bg-[#FFD700]/5 rounded-xl border border-[#FFD700]/20" dir="ltr">{referralCode}</code>
            <button onClick={copyCode} className="btn-premium-gold px-3 py-2 rounded-xl text-xs font-bold">نسخ الكود</button>
            <button onClick={copyRefLink} className="bg-[#2ECC71]/10 text-[#2ECC71] border border-[#2ECC71]/20 px-3 py-2 rounded-xl text-xs font-bold hover:bg-[#2ECC71]/20 transition-all">نسخ الرابط</button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { label: 'إجمالي الإحالات', value: stats.referredUsersCount, icon: Users, color: '#FFD700' },
          { label: 'إحالات نشطة', value: stats.activeReferrals, icon: CheckCircle, color: '#2ECC71' },
          { label: 'إيداعاتهم', value: fmt(stats.totalDepositsFromReferrals), icon: Wallet, color: '#3498DB' },
          { label: 'استثماراتهم', value: fmt(stats.totalInvestmentsFromReferrals), icon: Gem, color: '#9B59B6' },
          { label: 'عمولاتي', value: fmt(stats.totalCommissionEarned), icon: TrendingUp, color: '#E67E22' },
        ].map((c, i) => (
          <div key={i} className="glass-card card-lift premium-shimmer p-3.5">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${c.color}15` }}>
                <c.icon size={14} style={{ color: c.color }} />
              </div>
              <span className="text-gray-400 text-[11px] leading-tight">{c.label}</span>
            </div>
            <p className="text-base font-bold text-white">{c.value}</p>
          </div>
        ))}
      </div>

      {/* Search & Filter */}
      <div className="bg-[#1A1F2E] rounded-xl p-3 border border-[#2A3040] flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input placeholder="ابحث بالاسم أو البريد..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-lg pr-9 pl-3 py-2 text-sm text-white focus:outline-none focus:border-[#FFD700]/50 transition-colors" dir="ltr" />
        </div>
        <div className="flex items-center gap-1 bg-[#12161F] rounded-lg p-1 border border-[#2A3040]">
          <Filter size={12} className="text-gray-500 mr-1" />
          {(['all', 'active', 'inactive'] as const).map(s => (
            <button key={s} onClick={() => setFilterStatus(s)} className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${filterStatus === s ? 'bg-[#FFD700]/10 text-[#FFD700]' : 'text-gray-500 hover:text-gray-300'}`}>
              {s === 'all' ? 'الكل' : s === 'active' ? 'نشط' : 'متوقف'}
            </button>
          ))}
        </div>
      </div>

      {/* Referrals List */}
      {filteredReferrals.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Users size={40} className="text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400 font-medium">{referrals.length === 0 ? 'لا توجد إحالات بعد' : 'لا توجد نتائج'}</p>
          <p className="text-gray-600 text-xs mt-1">{referrals.length === 0 ? 'شارك كود الإحالة لتبدأ في كسب العمولات' : 'جرّب تغيير البحث أو الفلتر'}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredReferrals.map(ref => (
            <div key={ref.id} className="glass-card p-4 hover:bg-[#1A1F2E]/80 transition-all">
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0 border border-[#2A3040]/50">
                  <User size={18} className="text-gray-300" />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-white font-bold text-sm truncate">{ref.username}</p>
                    {ref.isActive ? (
                      <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#2ECC71]/10 border border-[#2ECC71]/20">
                        <CheckCircle size={9} className="text-[#2ECC71]" />
                        <span className="text-[#2ECC71] text-[10px] font-medium">نشط</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-500/10 border border-red-500/20">
                        <XCircle size={9} className="text-red-400" />
                        <span className="text-red-400 text-[10px] font-medium">متوقف</span>
                      </span>
                    )}
                  </div>
                  <p className="text-gray-500 text-xs mb-2" dir="ltr">{ref.email}</p>

                  {/* Mini stats */}
                  <div className="grid grid-cols-4 gap-2">
                    <div className="bg-[#12161F] rounded-lg p-2 text-center">
                      <ArrowDownToLine size={11} className="text-[#2ECC71] mx-auto mb-0.5" />
                      <p className="text-[10px] text-gray-500">إيداعات</p>
                      <p className="text-white text-xs font-bold">{ref.depositCount}</p>
                    </div>
                    <div className="bg-[#12161F] rounded-lg p-2 text-center">
                      <DollarSign size={11} className="text-[#3498DB] mx-auto mb-0.5" />
                      <p className="text-[10px] text-gray-500">المودع</p>
                      <p className="text-[#2ECC71] text-xs font-bold">{fmt(ref.totalDeposited)}</p>
                    </div>
                    <div className="bg-[#12161F] rounded-lg p-2 text-center">
                      <Gem size={11} className="text-[#9B59B6] mx-auto mb-0.5" />
                      <p className="text-[10px] text-gray-500">مستثمر</p>
                      <p className="text-white text-xs font-bold">{ref.activeInvestmentsCount > 0 ? 'نعم' : 'لا'}</p>
                    </div>
                    <div className="bg-[#12161F] rounded-lg p-2 text-center">
                      <Wallet size={11} className="text-[#FFD700] mx-auto mb-0.5" />
                      <p className="text-[10px] text-gray-500">الرصيد</p>
                      <p className="text-white text-xs font-bold">{fmt(ref.balance)}</p>
                    </div>
                  </div>
                </div>

                {/* Date + Commission hint */}
                <div className="text-left shrink-0 hidden sm:block">
                  <p className="text-gray-600 text-[10px] flex items-center gap-1">
                    <Clock size={10} />
                    {new Date(ref.createdAt).toLocaleDateString('ar')}
                  </p>
                  {ref.totalDeposited > 0 && commissionRate > 0 && (
                    <div>
                      <p className="text-[#FFD700] text-xs font-bold mt-2">
                        +{fmt(ref.totalDeposited * commissionRate / 100)}
                      </p>
                      <p className={'text-gray-600 text-[10px]'}>{'عمولتي من إيداعاته'}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
