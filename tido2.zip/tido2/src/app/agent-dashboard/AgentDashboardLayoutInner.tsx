'use client';
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import AgentDashLayout from '@/components/AgentDashLayout';

export default function AgentDashboardLayoutInner({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.push('/');
    if (!loading && user && !user.isAgent && !user.isAdmin) router.push('/dashboard');
    if (!loading && user && user.isAdmin) router.push('/admin/dashboard');
  }, [user, loading, router]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#0A0F0D]"><div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>;
  if (!user) return null;

  return (
    <AgentDashLayout>
      {children}
    </AgentDashLayout>
  );
}
