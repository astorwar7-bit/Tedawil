'use client';
import { useEffect, useState } from 'react';
import { Bell, Check, Trash2 } from 'lucide-react';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
}

export default function AgentNotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = async () => {
    try {
      const res = await fetch('/api/notifications?limit=50');
      const data = await res.json();
      if (res.ok) setNotifications(data.notifications || []);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchNotifications(); }, []);

  const markAllRead = async () => {
    try {
      await fetch('/api/notifications/mark-all', { method: 'POST' });
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    } catch {}
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-[60vh]"><div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>;
  }

  const typeColors: Record<string, string> = {
    normal: 'bg-gray-500/10 text-gray-400',
    success: 'bg-[#2ECC71]/10 text-[#2ECC71]',
    alert: 'bg-red-500/10 text-red-400',
    urgent: 'bg-[#FFD700]/10 text-[#FFD700]',
    referral: 'bg-[#FFD700]/10 text-[#FFD700]',
    investment: 'bg-[#2ECC71]/10 text-[#2ECC71]',
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Bell size={22} className="text-[#FFD700]" />
          الإشعارات
        </h1>
        {notifications.some(n => !n.isRead) && (
          <button onClick={markAllRead} className="text-[#2ECC71] text-sm hover:text-[#2ECC71]/80 flex items-center gap-1">
            <Check size={14} /> تعيين الكل كمقروء
          </button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Bell size={40} className="text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">لا توجد إشعارات</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map(n => (
            <div key={n.id} className={`glass-card p-4 ${!n.isRead ? 'border-r-2 border-r-[#FFD700]' : ''}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className={`text-sm font-medium ${!n.isRead ? 'text-white' : 'text-gray-300'}`}>{n.title}</h3>
                    {n.type && <span className={`text-[10px] px-2 py-0.5 rounded-full ${typeColors[n.type] || typeColors.normal}`}>{n.type}</span>}
                  </div>
                  <p className="text-gray-400 text-xs leading-relaxed">{n.message}</p>
                  <p className="text-gray-600 text-[10px] mt-2">{new Date(n.createdAt).toLocaleString('ar')}</p>
                </div>
                {!n.isRead && <div className="w-2 h-2 rounded-full bg-[#FFD700] mt-2 shrink-0" />}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
