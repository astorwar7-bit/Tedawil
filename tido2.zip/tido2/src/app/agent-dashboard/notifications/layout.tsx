export default function AgentNotificationsLayout({ children }: { children: React.ReactNode }) { return <>{children}</>; }
