'use client';
import { AuthProvider } from '@/contexts/AuthContext';
import { ToastProvider } from '@/contexts/ToastContext';
import AgentDashboardLayoutInner from './AgentDashboardLayoutInner';

export default function AgentDashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <ToastProvider>
      <AuthProvider>
        <AgentDashboardLayoutInner>{children}</AgentDashboardLayoutInner>
      </AuthProvider>
    </ToastProvider>
  );
}
