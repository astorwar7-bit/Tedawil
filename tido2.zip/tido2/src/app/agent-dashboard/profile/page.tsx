'use client';
import { useState, useEffect } from 'react';
import { User, Mail, Phone, Calendar, Edit3, Save, X, Percent } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/contexts/ToastContext';

export default function AgentProfilePage() {
  const { user, refreshUser } = useAuth();
  const { showToast } = useToast();
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [dashboardInfo, setDashboardInfo] = useState<{ commissionRate: number; referralCode: string } | null>(null);

  useEffect(() => {
    if (user) {
      setFullName(user.fullName || '');
      setPhone(user.phone || '');
    }
  }, [user]);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const res = await fetch('/api/agents/dashboard');
        const data = await res.json();
        if (res.ok) setDashboardInfo({ commissionRate: data.user.commissionRate, referralCode: data.user.referralCode });
      } catch {}
    };
    fetchDashboard();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, phone }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error || 'حدث خطأ', 'error'); setSaving(false); return; }
      showToast('تم تحديث البيانات');
      setEditing(false);
      refreshUser();
    } catch { showToast('حدث خطأ', 'error'); }
    setSaving(false);
  };

  if (!user) return null;

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center border border-[#FFD700]/20">
          <User size={18} className="text-[#FFD700]" />
        </div>
        <h1 className="text-2xl font-bold text-white">الملف الشخصي</h1>
      </div>

      {/* Agent Badge */}
      <div className="glass-card p-5 featured-border">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-black text-2xl shadow-lg shadow-[#FFD700]/20">
            {user.username?.[0]?.toUpperCase()}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h2 className="text-white font-bold text-lg">{user.fullName || user.username}</h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FFD700]/10 text-[#FFD700] font-medium">وكيل</span>
            </div>
            <p className="text-gray-400 text-sm">@{user.username}</p>
            {dashboardInfo && (
              <div className="flex items-center gap-3 mt-1">
                <span className="text-[#FFD700] text-xs flex items-center gap-1"><Percent size={12} /> عمولة {dashboardInfo.commissionRate}%</span>
                <span className="text-gray-500 text-xs" dir="ltr">كود: {dashboardInfo.referralCode}</span>
              </div>
            )}
          </div>
          {!editing ? (
            <button onClick={() => setEditing(true)} className="p-2 rounded-xl hover:bg-[#2A3040] text-gray-400 hover:text-white transition-all">
              <Edit3 size={18} />
            </button>
          ) : (
            <div className="flex gap-1">
              <button onClick={handleSave} disabled={saving} className="p-2 rounded-xl bg-[#2ECC71]/10 text-[#2ECC71] hover:bg-[#2ECC71]/20 transition-all">
                {saving ? <div className="w-4 h-4 border-2 border-[#2ECC71]/30 border-t-[#2ECC71] rounded-full animate-spin" /> : <Save size={18} />}
              </button>
              <button onClick={() => setEditing(false)} className="p-2 rounded-xl hover:bg-[#2A3040] text-gray-400 hover:text-white transition-all">
                <X size={18} />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Mail size={14} className="text-[#3498DB]" />
            <span className="text-gray-400 text-xs">البريد الإلكتروني</span>
          </div>
          <p className="text-white text-sm" dir="ltr">{user.email}</p>
        </div>

        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Phone size={14} className="text-[#E67E22]" />
            <span className="text-gray-400 text-xs">رقم الهاتف</span>
          </div>
          {editing ? (
            <input value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-lg px-3 py-1.5 text-white text-sm" dir="ltr" />
          ) : (
            <p className="text-white text-sm" dir="ltr">{user.phone || 'غير محدد'}</p>
          )}
        </div>

        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Calendar size={14} className="text-[#2ECC71]" />
            <span className="text-gray-400 text-xs">تاريخ التسجيل</span>
          </div>
          <p className="text-white text-sm">{new Date(user.createdAt).toLocaleDateString('ar')}</p>
        </div>

        <div className="glass-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <User size={14} className="text-[#FFD700]" />
            <span className="text-gray-400 text-xs">الاسم الكامل</span>
          </div>
          {editing ? (
            <input value={fullName} onChange={e => setFullName(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-lg px-3 py-1.5 text-white text-sm" />
          ) : (
            <p className="text-white text-sm">{user.fullName || 'غير محدد'}</p>
          )}
        </div>
      </div>
    </div>
  );
}
