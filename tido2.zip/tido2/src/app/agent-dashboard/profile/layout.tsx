export default function AgentProfileLayout({ children }: { children: React.ReactNode }) { return <>{children}</>; }
