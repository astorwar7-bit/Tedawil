export default function AgentDepositsLayout({ children }: { children: React.ReactNode }) { return <>{children}</>; }
