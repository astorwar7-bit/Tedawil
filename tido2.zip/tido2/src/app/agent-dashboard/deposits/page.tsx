'use client';
import { useEffect, useState, useRef, useCallback } from 'react';
import {
  ArrowDownToLine, User, DollarSign, Search, Clock, CheckCircle,
  XCircle, AlertCircle, Send, Wallet, Mail, Calendar,
  TrendingUp, Package, BadgeCheck, X, Loader2, Building2,
} from 'lucide-react';
import { useToast } from '@/contexts/ToastContext';

interface SearchedClient {
  id: string;
  username: string;
  email: string;
  fullName: string;
  balance: number;
  isActive: boolean;
  createdAt: string;
  isMyReferral: boolean;
  totalDeposits: number;
  totalInvestments: number;
  activeInvestmentsCount: number;
}

interface AgentDeposit {
  id: string;
  amount: number;
  method: string;
  txHash: string;
  status: string;
  createdAt: string;
  user: { username: string; fullName: string; email: string };
}

export default function AgentDepositsPage() {
  const { showToast } = useToast();
  const [deposits, setDeposits] = useState<AgentDeposit[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchedClient[]>([]);
  const [searching, setSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Selected client
  const [selectedClient, setSelectedClient] = useState<SearchedClient | null>(null);

  // Form state
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('تحويل من الوكيل');
  const [txHash, setTxHash] = useState('');

  // Fetch deposits submitted by this agent
  const fetchDeposits = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/agents/deposits');
      const data = await res.json();
      if (res.ok) {
        setDeposits(data.deposits || []);
      }
    } catch { /* silent */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchDeposits(); }, [fetchDeposits]);

  // Debounced search
  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current);

    if (query.length < 2) {
      setSearchResults([]);
      setShowDropdown(false);
      setSearching(false);
      return;
    }

    setSearching(true);
    searchTimerRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/agents/search-client?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (res.ok) {
          setSearchResults(data.clients || []);
          setShowDropdown(data.clients?.length > 0);
        }
      } catch {
        setSearchResults([]);
      }
      setSearching(false);
    }, 400);
  }, []);

  // Close dropdown on outside click
  const searchRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const selectClient = (client: SearchedClient) => {
    setSelectedClient(client);
    setSearchQuery('');
    setSearchResults([]);
    setShowDropdown(false);
  };

  const clearClient = () => {
    setSelectedClient(null);
    setAmount('');
    setTxHash('');
  };

  const handleSubmit = async () => {
    if (!selectedClient) { showToast('يرجى اختيار العميل', 'error'); return; }
    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) { showToast('يرجى إدخال مبلغ صالح', 'error'); return; }

    setSubmitting(true);
    try {
      const res = await fetch('/api/agents/deposits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetUserId: selectedClient.id,
          amount: depositAmount,
          method,
          txHash,
        }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error || 'حدث خطأ', 'error'); setSubmitting(false); return; }
      showToast(data.message);
      setSelectedClient(null);
      setAmount('');
      setTxHash('');
      fetchDeposits();
    } catch { showToast('حدث خطأ في الاتصال', 'error'); }
    setSubmitting(false);
  };

  const fmt = (n: number) => `$${n.toLocaleString('en', { minimumFractionDigits: 2 })}`;

  // Stats
  const pendingCount = deposits.filter(d => d.status === 'pending').length;
  const approvedDeposits = deposits.filter(d => d.status === 'approved');
  const approvedCount = approvedDeposits.length;
  const approvedTotal = approvedDeposits.reduce((s, d) => s + d.amount, 0);
  const rejectedCount = deposits.filter(d => d.status === 'rejected').length;

  const statusConfig: Record<string, { icon: typeof CheckCircle; color: string; label: string; bg: string }> = {
    pending: { icon: Clock, color: '#E67E22', label: 'بانتظار الموافقة', bg: 'bg-[#E67E22]/10' },
    approved: { icon: CheckCircle, color: '#2ECC71', label: 'مقبول', bg: 'bg-[#2ECC71]/10' },
    rejected: { icon: XCircle, color: '#E74C3C', label: 'مرفوض', bg: 'bg-[#E74C3C]/10' },
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2ECC71]/20 to-[#3498DB]/20 flex items-center justify-center border border-[#2ECC71]/20">
            <ArrowDownToLine size={18} className="text-[#2ECC71]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">إيداع للعملاء</h1>
            <p className="text-gray-500 text-xs mt-0.5">إيداع في حسابات أي عميل على المنصة</p>
          </div>
        </div>
      </div>

      {/* Info Banner */}
      <div className="glass-card p-4 flex items-start gap-3 !bg-[#FFD700]/[0.03] !border-[#FFD700]/10" style={{ transform: 'none' }}>
        <div className="w-9 h-9 rounded-xl bg-[#FFD700]/10 flex items-center justify-center shrink-0 mt-0.5">
          <AlertCircle size={16} className="text-[#FFD700]" />
        </div>
        <div>
          <h3 className="text-white font-bold text-sm">كيف يعمل الإيداع عبر الوكيل؟</h3>
          <p className="text-gray-400 text-xs mt-1 leading-relaxed">
            ابحث عن أي عميل بالاسم أو البريد الإلكتروني، ثم أرسل طلب إيداع لحسابه. ستقوم الإدارة بمراجعة الطلب والموافقة عليه ليُضاف المبلغ إلى رصيد العميل.
          </p>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass-card card-lift p-3.5 text-center">
          <div className="w-9 h-9 mx-auto mb-2 rounded-xl bg-[#2ECC71]/10 flex items-center justify-center">
            <CheckCircle size={16} className="text-[#2ECC71]" />
          </div>
          <p className="text-lg font-bold text-[#2ECC71]">{approvedCount}</p>
          <p className="text-gray-500 text-[11px]">مقبول · {fmt(approvedTotal)}</p>
        </div>
        <div className="glass-card card-lift p-3.5 text-center">
          <div className="w-9 h-9 mx-auto mb-2 rounded-xl bg-[#E67E22]/10 flex items-center justify-center">
            <Clock size={16} className="text-[#E67E22]" />
          </div>
          <p className="text-lg font-bold text-[#E67E22]">{pendingCount}</p>
          <p className="text-gray-500 text-[11px]">بانتظار المراجعة</p>
        </div>
        <div className="glass-card card-lift p-3.5 text-center">
          <div className="w-9 h-9 mx-auto mb-2 rounded-xl bg-red-500/10 flex items-center justify-center">
            <XCircle size={16} className="text-red-400" />
          </div>
          <p className="text-lg font-bold text-red-400">{rejectedCount}</p>
          <p className="text-gray-500 text-[11px]">مرفوض</p>
        </div>
      </div>

      {/* New Deposit Section */}
      <div className="glass-card p-5" style={{ transform: 'none' }}>
        <div className="flex items-center gap-2 mb-4">
          <Send size={16} className="text-[#2ECC71]" />
          <h3 className="text-sm font-bold text-white">إيداع جديد</h3>
        </div>

        {!selectedClient ? (
          /* Search Client */
          <div className="space-y-4" ref={searchRef}>
            <div className="relative">
              <label className="text-gray-400 text-xs font-medium block mb-2">
                <User size={12} className="inline ml-1" />
                ابحث عن العميل
              </label>
              <div className="relative">
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  {searching ? (
                    <Loader2 size={14} className="text-[#FFD700] animate-spin" />
                  ) : (
                    <Search size={14} className="text-gray-400" />
                  )}
                </div>
                <input
                  value={searchQuery}
                  onChange={e => handleSearch(e.target.value)}
                  onFocus={() => searchResults.length > 0 && setShowDropdown(true)}
                  placeholder="ابحث باسم المستخدم أو البريد الإلكتروني..."
                  className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-3 text-white text-sm pr-10 focus:outline-none focus:border-[#FFD700]/50 transition-colors"
                  dir="ltr"
                />
              </div>

              {/* Search Results Dropdown */}
              {showDropdown && searchResults.length > 0 && (
                <div className="absolute top-full right-0 left-0 mt-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl overflow-hidden z-50 shadow-xl shadow-black/40 max-h-72 overflow-y-auto scrollbar-thin">
                  {searchResults.map(client => (
                    <button
                      key={client.id}
                      onClick={() => selectClient(client)}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#2A3040]/60 transition-colors text-right border-b border-[#2A3040]/30 last:border-b-0"
                    >
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0">
                        <User size={15} className="text-gray-300" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-white text-sm font-medium truncate">{client.username}</p>
                          {client.isMyReferral ? (
                            <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-[#2ECC71]/10 text-[#2ECC71] whitespace-nowrap">
                              إحالة منك
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-[#3498DB]/10 text-[#3498DB] whitespace-nowrap">
                              عميل جديد
                            </span>
                          )}
                        </div>
                        <p className="text-gray-500 text-xs truncate">{client.email}</p>
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-[#FFD700] text-xs font-bold">{fmt(client.balance)}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {searchQuery.length >= 2 && !searching && searchResults.length === 0 && (
              <p className="text-gray-500 text-xs text-center py-3">لم يتم العثور على عملاء مطابقين</p>
            )}
          </div>
        ) : (
          /* Selected Client Info + Deposit Form */
          <div className="space-y-4 animate-fadeIn">
            {/* Client Info Card */}
            <div className="bg-[#12161F] rounded-xl p-4 border border-[#2A3040] relative">
              <button
                onClick={clearClient}
                className="absolute top-3 left-3 w-7 h-7 rounded-lg bg-[#2A3040] hover:bg-[#3A4050] flex items-center justify-center transition-colors"
              >
                <X size={14} className="text-gray-400" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0 border border-[#FFD700]/10">
                  <User size={20} className="text-[#FFD700]" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-white font-bold text-base">{selectedClient.fullName || selectedClient.username}</h4>
                    {selectedClient.isMyReferral ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#2ECC71]/10 text-[#2ECC71] flex items-center gap-1">
                        <BadgeCheck size={10} />
                        عميل من إحالاتك
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#3498DB]/10 text-[#3498DB] flex items-center gap-1">
                        <User size={10} />
                        عميل جديد
                      </span>
                    )}
                  </div>
                  <p className="text-gray-400 text-xs mt-0.5" dir="ltr">{selectedClient.username} · {selectedClient.email}</p>
                </div>
              </div>

              {/* Client Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="bg-[#0D1117] rounded-lg p-2.5 text-center">
                  <Wallet size={13} className="text-[#FFD700] mx-auto mb-1" />
                  <p className="text-white font-bold text-sm" dir="ltr">{fmt(selectedClient.balance)}</p>
                  <p className="text-gray-500 text-[10px]">الرصيد الحالي</p>
                </div>
                <div className="bg-[#0D1117] rounded-lg p-2.5 text-center">
                  <TrendingUp size={13} className="text-[#2ECC71] mx-auto mb-1" />
                  <p className="text-white font-bold text-sm" dir="ltr">{fmt(selectedClient.totalDeposits)}</p>
                  <p className="text-gray-500 text-[10px]">إجمالي الإيداعات</p>
                </div>
                <div className="bg-[#0D1117] rounded-lg p-2.5 text-center">
                  <DollarSign size={13} className="text-[#3498DB] mx-auto mb-1" />
                  <p className="text-white font-bold text-sm" dir="ltr">{fmt(selectedClient.totalInvestments)}</p>
                  <p className="text-gray-500 text-[10px]">إجمالي الاستثمارات</p>
                </div>
                <div className="bg-[#0D1117] rounded-lg p-2.5 text-center">
                  <Package size={13} className="text-[#E67E22] mx-auto mb-1" />
                  <p className="text-white font-bold text-sm">{selectedClient.activeInvestmentsCount}</p>
                  <p className="text-gray-500 text-[10px]">استثمارات نشطة</p>
                </div>
              </div>

              {/* Registration date */}
              <div className="flex items-center gap-1.5 mt-3 text-gray-500 text-[11px]">
                <Calendar size={11} />
                <span>تاريخ التسجيل: {new Date(selectedClient.createdAt).toLocaleDateString('ar')}</span>
              </div>
            </div>

            {/* Deposit Form */}
            <div className="space-y-4">
              {/* Amount */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-2">
                  <DollarSign size={12} className="inline ml-1" />
                  مبلغ الإيداع
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#FFD700] font-bold text-lg">USD</span>
                  <input
                    type="number"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-4 text-white text-2xl font-bold text-center focus:outline-none focus:border-[#FFD700]/50 transition-colors"
                    dir="ltr"
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>

              {/* Method */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-2">
                  <Building2 size={12} className="inline ml-1" />
                  طريقة الإيداع
                </label>
                <select
                  value={method}
                  onChange={e => setMethod(e.target.value)}
                  className="select-premium"
                >
                  <option value="تحويل من الوكيل">تحويل من الوكيل</option>
                  <option value="تحويل بنكي">تحويل بنكي</option>
                  <option value="USDT (TRC20)">USDT (TRC20)</option>
                  <option value="Bitcoin">Bitcoin</option>
                  <option value="Ethereum">Ethereum</option>
                  <option value="آخرى">آخرى</option>
                </select>
              </div>

              {/* TX Hash */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-2">
                  <Search size={12} className="inline ml-1" />
                  رقم المعاملة / TX Hash <span className="text-gray-600">(اختياري)</span>
                </label>
                <input
                  value={txHash}
                  onChange={e => setTxHash(e.target.value)}
                  placeholder="أدخل رقم المعاملة إن وجد..."
                  className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors"
                  dir="ltr"
                />
              </div>

              {/* Preview Summary */}
              {selectedClient && amount && parseFloat(amount) > 0 && (
                <div className="bg-[#0D1117] rounded-xl p-4 border border-[#FFD700]/10 animate-fadeIn">
                  <div className="flex items-center gap-2 mb-3">
                    <DollarSign size={14} className="text-[#FFD700]" />
                    <span className="text-xs font-bold text-[#FFD700]">ملخص الإيداع</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">العميل</span>
                      <span className="text-white font-medium">{selectedClient.username}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">المبلغ</span>
                      <span className="text-[#2ECC71] font-bold text-sm">{fmt(parseFloat(amount))}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">طريقة الدفع</span>
                      <span className="text-white">{method}</span>
                    </div>
                    {txHash && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-500">رقم المعاملة</span>
                        <span className="text-gray-300 truncate max-w-[200px]" dir="ltr">{txHash}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                <button
                  onClick={handleSubmit}
                  disabled={submitting || !selectedClient || !amount || parseFloat(amount) <= 0}
                  className="flex-1 bg-gradient-to-l from-[#2ECC71] to-[#27AE60] text-white py-3.5 rounded-xl text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-[#2ECC71]/20 transition-all"
                >
                  {submitting ? (
                    <><Loader2 size={16} className="animate-spin" /> جاري الإرسال...</>
                  ) : (
                    <><Send size={14} /> إرسال طلب الإيداع</>
                  )}
                </button>
                <button
                  onClick={clearClient}
                  className="px-6 bg-[#2A3040] text-gray-300 py-3.5 rounded-xl text-sm hover:bg-[#3A4050] transition-colors"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Deposit History */}
      <div className="glass-card overflow-hidden" style={{ transform: 'none' }}>
        <div className="p-4 border-b border-[#2A3040]/50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet size={16} className="text-[#FFD700]" />
            <h3 className="text-sm font-bold text-white">سجل الإيداعات المرسلة</h3>
            <span className="text-gray-500 text-xs">({deposits.length})</span>
          </div>
        </div>
        {deposits.length === 0 ? (
          <div className="text-center py-12">
            <ArrowDownToLine size={40} className="text-gray-600 mx-auto mb-3" />
            <p className="text-gray-400">لم ترسل أي إيداعات بعد</p>
            <p className="text-gray-600 text-xs mt-1">ابحث عن عميل في الأعلى لإرسال إيداع</p>
          </div>
        ) : (
          <div className="max-h-96 overflow-y-auto scrollbar-thin">
            <div className="divide-y divide-[#2A3040]/50">
              {deposits.map(d => {
                const sc = statusConfig[d.status] || statusConfig.pending;
                const StatusIcon = sc.icon;
                return (
                  <div key={d.id} className="p-4 hover:bg-[#1A1F2E]/30 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${sc.bg}`}>
                        <StatusIcon size={16} style={{ color: sc.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                          <p className="text-white text-sm font-medium">{d.user?.username || 'عميل'}</p>
                          {d.user?.fullName && (
                            <span className="text-gray-500 text-xs">({d.user.fullName})</span>
                          )}
                          <span
                            className="px-2 py-0.5 rounded-full text-[10px] font-medium"
                            style={{ background: `${sc.color}15`, color: sc.color }}
                          >
                            {sc.label}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs flex-wrap">
                          <span className="text-gray-400 flex items-center gap-1">
                            <Clock size={10} />
                            {new Date(d.createdAt).toLocaleDateString('ar')}
                          </span>
                          <span className="text-gray-500 flex items-center gap-1">
                            <Building2 size={10} />
                            {d.method}
                          </span>
                        </div>
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-white font-bold text-sm">{fmt(d.amount)}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
