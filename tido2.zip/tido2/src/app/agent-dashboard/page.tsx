'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { DollarSign, Users, TrendingUp, Copy, User, CheckCircle, Clock, Percent, Wallet } from 'lucide-react';

interface AgentStats {
  totalCommissionEarned: number;
  referredUsersCount: number;
  activeReferrals: number;
  totalDepositsFromReferrals: number;
}

interface ReferralUser {
  id: string;
  username: string;
  email: string;
  fullName: string;
  balance: number;
  isActive: boolean;
  createdAt: string;
}

interface CommissionEntry {
  amount: number;
  details: string;
  createdAt: string;
}

export default function AgentDashboardPage() {
  const { showToast } = useToast();
  const [balance, setBalance] = useState(0);
  const [stats, setStats] = useState<AgentStats>({ totalCommissionEarned: 0, referredUsersCount: 0, activeReferrals: 0, totalDepositsFromReferrals: 0 });
  const [recentReferrals, setRecentReferrals] = useState<ReferralUser[]>([]);
  const [commissionHistory, setCommissionHistory] = useState<CommissionEntry[]>([]);
  const [referralCode, setReferralCode] = useState('');
  const [commissionRate, setCommissionRate] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const res = await fetch('/api/agents/dashboard');
        const data = await res.json();
        if (res.ok) {
          setBalance(data.user.balance);
          setStats(data.stats);
          setRecentReferrals(data.referrals || []);
          setCommissionHistory(data.commissionHistory || []);
          setReferralCode(data.user.referralCode);
          setCommissionRate(data.user.commissionRate);
        }
      } catch {}
      setLoading(false);
    };
    fetchDashboard();
  }, []);

  const copyCode = () => {
    navigator.clipboard.writeText(referralCode);
    showToast('تم نسخ كود الإحالة');
  };

  const fmt = (n: number) => `$${n.toLocaleString('en', { minimumFractionDigits: 2 })}`;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center border border-[#FFD700]/20">
          <TrendingUp size={18} className="text-[#FFD700]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">لوحة تحكم الوكيل</h1>
          <p className="text-gray-500 text-xs mt-0.5">مراقبة الإحالات والعمولات</p>
        </div>
      </div>

      {/* Agent Balance Banner */}
      <div className="glass-card p-5 featured-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center">
              <Wallet size={22} className="text-[#FFD700]" />
            </div>
            <div>
              <h3 className="text-gray-400 text-xs">رصيد محفظتك</h3>
              <p className="text-2xl font-bold text-white" dir="ltr">{fmt(balance)}</p>
            </div>
          </div>
          <div className="text-left">
            <p className="text-[#2ECC71] text-xs font-medium">عمولات متاحة للسحب</p>
            <p className="text-[#FFD700] text-lg font-bold" dir="ltr">{fmt(stats.totalCommissionEarned)}</p>
          </div>
        </div>
      </div>

      {/* Referral Code Banner */}
      <div className="glass-card p-5 featured-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center">
              <Copy size={20} className="text-[#FFD700]" />
            </div>
            <div>
              <h3 className="text-white font-bold text-sm">كود الإحالة الخاص بك</h3>
              <p className="text-gray-400 text-xs mt-0.5">شاركه مع الآخرين لتحصل على عمولة {commissionRate}% من كل إيداع</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <code className="text-[#FFD700] font-bold text-lg px-4 py-2 bg-[#FFD700]/5 rounded-xl border border-[#FFD700]/20" dir="ltr">
              {referralCode}
            </code>
            <button onClick={copyCode} className="btn-premium-gold px-3 py-2 rounded-xl text-sm font-bold">
              نسخ
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'إجمالي العمولات', value: fmt(stats.totalCommissionEarned), icon: DollarSign, color: '#FFD700' },
          { label: 'عدد الإحالات', value: stats.referredUsersCount.toString(), icon: Users, color: '#2ECC71' },
          { label: 'إحالات نشطة', value: stats.activeReferrals.toString(), icon: CheckCircle, color: '#3498DB' },
          { label: 'إيداعات الإحالات', value: fmt(stats.totalDepositsFromReferrals), icon: Wallet, color: '#E67E22' },
        ].map((c, i) => (
          <div key={i} className="glass-card card-lift premium-shimmer p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${c.color}15` }}>
                <c.icon size={16} style={{ color: c.color }} />
              </div>
              <span className="text-gray-400 text-xs leading-tight">{c.label}</span>
            </div>
            <p className="text-lg font-bold text-white">{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Recent Referrals */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <Users size={16} className="text-[#2ECC71]" />
            آخر الإحالات
          </h3>
          {recentReferrals.length === 0 ? (
            <div className="text-center py-8">
              <Users size={32} className="text-gray-600 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">لا توجد إحالات بعد</p>
              <p className="text-gray-600 text-xs mt-1">شارك كود الإحالة لتبدأ</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto scrollbar-thin">
              {recentReferrals.map(ref => (
                <div key={ref.id} className="flex items-center gap-3 p-3 rounded-xl bg-[#12161F] hover:bg-[#1A1F2E] transition-colors">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0">
                    <User size={14} className="text-gray-300" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium truncate">{ref.username}</p>
                    <p className="text-gray-500 text-xs truncate">{ref.email}</p>
                  </div>
                  <div className="text-left shrink-0">
                    <p className={`text-xs font-medium ${ref.isActive ? 'text-[#2ECC71]' : 'text-red-400'}`}>
                      {ref.isActive ? 'نشط' : 'غير نشط'}
                    </p>
                    <p className="text-gray-500 text-xs">{fmt(ref.balance)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Commission History */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <Percent size={16} className="text-[#FFD700]" />
            سجل العمولات
          </h3>
          {commissionHistory.length === 0 ? (
            <div className="text-center py-8">
              <DollarSign size={32} className="text-gray-600 mx-auto mb-3" />
              <p className="text-gray-500 text-sm">لا توجد عمولات بعد</p>
              <p className="text-gray-600 text-xs mt-1">ستظهر العمولات هنا عند إيداع الإحالات</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto scrollbar-thin">
              {commissionHistory.map((entry, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-xl bg-[#12161F] hover:bg-[#1A1F2E] transition-colors">
                  <div className="w-9 h-9 rounded-full bg-[#FFD700]/10 flex items-center justify-center shrink-0">
                    <DollarSign size={14} className="text-[#FFD700]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-xs font-medium truncate">{entry.details}</p>
                    <p className="text-gray-500 text-xs flex items-center gap-1">
                      <Clock size={10} />
                      {new Date(entry.createdAt).toLocaleDateString('ar')}
                    </p>
                  </div>
                  <span className="text-[#FFD700] font-bold text-sm shrink-0">+{fmt(entry.amount)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
