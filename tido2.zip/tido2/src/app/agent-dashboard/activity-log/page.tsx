'use client';
import { useEffect, useState } from 'react';
import { ArrowRightLeft, DollarSign, TrendingUp, CreditCard, Copy } from 'lucide-react';

interface ActivityEntry {
  id: string;
  action: string;
  details: string;
  amount: number;
  createdAt: string;
}

export default function AgentActivityLogPage() {
  const [activities, setActivities] = useState<ActivityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const limit = 20;

  useEffect(() => {
    const fetchActivities = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/activity-log?page=${page}&limit=${limit}`);
        const data = await res.json();
        if (res.ok) {
          setActivities(data.activities || []);
          setTotal(data.total || 0);
        }
      } catch {}
      setLoading(false);
    };
    fetchActivities();
  }, [page]);

  const fmt = (n: number) => `$${Math.abs(n).toLocaleString('en', { minimumFractionDigits: 2 })}`;

  const actionIcons: Record<string, typeof DollarSign> = {
    AGENT_COMMISSION: DollarSign,
    AGENT_CREATED: TrendingUp,
    REFERRAL_BONUS: TrendingUp,
    DEPOSIT_APPROVED: CreditCard,
  };

  const actionColors: Record<string, string> = {
    AGENT_COMMISSION: '#FFD700',
    AGENT_CREATED: '#2ECC71',
    REFERRAL_BONUS: '#2ECC71',
    DEPOSIT_APPROVED: '#3498DB',
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#3498DB]/20 to-[#2ECC71]/20 flex items-center justify-center border border-[#3498DB]/20">
          <ArrowRightLeft size={18} className="text-[#3498DB]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">سجل المعاملات</h1>
          <p className="text-gray-500 text-xs">{total} معاملة</p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center min-h-[40vh]"><div className="w-6 h-6 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>
      ) : activities.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <ArrowRightLeft size={40} className="text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">لا توجد معاملات</p>
        </div>
      ) : (
        <div className="space-y-2">
          {activities.map(a => {
            const Icon = actionIcons[a.action] || ArrowRightLeft;
            const color = actionColors[a.action] || '#8899AA';
            return (
              <div key={a.id} className="glass-card p-4 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: `${color}15` }}>
                  <Icon size={15} style={{ color }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">{a.details}</p>
                  <p className="text-gray-500 text-xs">{new Date(a.createdAt).toLocaleString('ar')}</p>
                </div>
                {a.amount !== 0 && (
                  <span className={`text-sm font-bold shrink-0 ${a.amount > 0 ? 'text-[#2ECC71]' : 'text-red-400'}`}>
                    {a.amount > 0 ? '+' : '-'}{fmt(a.amount)}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}

      {total > limit && (
        <div className="flex items-center justify-center gap-2 pt-4">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1.5 rounded-lg bg-[#2A3040] text-gray-300 text-sm disabled:opacity-50">السابق</button>
          <span className="text-gray-400 text-sm">{page} / {Math.ceil(total / limit)}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(total / limit)} className="px-3 py-1.5 rounded-lg bg-[#2A3040] text-gray-300 text-sm disabled:opacity-50">التالي</button>
        </div>
      )}
    </div>
  );
}
