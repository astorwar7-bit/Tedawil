export default function AgentActivityLogLayout({ children }: { children: React.ReactNode }) { return <>{children}</>; }
