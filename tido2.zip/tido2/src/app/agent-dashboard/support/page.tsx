'use client';
import { useState, useEffect } from 'react';
import { Headphones, Send, MessageSquare } from 'lucide-react';
import { useToast } from '@/contexts/ToastContext';

interface Ticket {
  id: string;
  subject: string;
  message: string;
  status: string;
  priority: string;
  createdAt: string;
  replies?: { message: string; isAdmin: boolean; createdAt: string }[];
}

export default function AgentSupportPage() {
  const { showToast } = useToast();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  const fetchTickets = async () => {
    try {
      const res = await fetch('/api/tickets?limit=50');
      const data = await res.json();
      if (res.ok) setTickets(data.tickets || []);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchTickets(); }, []);

  const handleSend = async () => {
    if (!subject.trim() || !message.trim()) { showToast('يرجى ملء جميع الحقول', 'error'); return; }
    setSending(true);
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, message, priority: 'medium', category: 'general' }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error || 'حدث خطأ', 'error'); setSending(false); return; }
      showToast('تم إرسال التذكرة');
      setSubject(''); setMessage(''); setShowForm(false);
      fetchTickets();
    } catch { showToast('حدث خطأ', 'error'); }
    setSending(false);
  };

  const statusColors: Record<string, string> = {
    open: 'text-[#2ECC71] bg-[#2ECC71]/10',
    closed: 'text-gray-400 bg-gray-400/10',
    pending: 'text-[#FFD700] bg-[#FFD700]/10',
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center border border-[#FFD700]/20">
            <Headphones size={18} className="text-[#FFD700]" />
          </div>
          <h1 className="text-2xl font-bold text-white">الدعم الفني</h1>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="btn-premium-gold px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2">
          <MessageSquare size={14} />
          {showForm ? 'إلغاء' : 'تذكرة جديدة'}
        </button>
      </div>

      {showForm && (
        <div className="glass-card p-5 space-y-3 animate-scaleIn">
          <input placeholder="الموضوع" value={subject} onChange={e => setSubject(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm" />
          <textarea placeholder="تفاصيل المشكلة..." value={message} onChange={e => setMessage(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm h-32 resize-none" />
          <button onClick={handleSend} disabled={sending} className="btn-premium-emerald px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 disabled:opacity-50">
            <Send size={14} />
            {sending ? 'جاري الإرسال...' : 'إرسال'}
          </button>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center min-h-[40vh]"><div className="w-6 h-6 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>
      ) : tickets.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <Headphones size={40} className="text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">لا توجد تذاكر</p>
        </div>
      ) : (
        <div className="space-y-2">
          {tickets.map(t => (
            <div key={t.id} className="glass-card p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white text-sm font-medium">{t.subject}</h3>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusColors[t.status] || statusColors.open}`}>{t.status === 'open' ? 'مفتوح' : t.status === 'closed' ? 'مغلق' : 'معلق'}</span>
              </div>
              <p className="text-gray-400 text-xs line-clamp-2">{t.message}</p>
              <p className="text-gray-600 text-[10px] mt-2">{new Date(t.createdAt).toLocaleString('ar')}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
