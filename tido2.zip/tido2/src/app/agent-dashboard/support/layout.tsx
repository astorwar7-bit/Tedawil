export default function AgentSupportLayout({ children }: { children: React.ReactNode }) { return <>{children}</>; }
