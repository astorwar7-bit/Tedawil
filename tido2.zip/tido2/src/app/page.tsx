'use client';
import { useState, useEffect } from 'react';
import { User, Lock, Eye, EyeOff, Shield, Zap, TrendingUp, Users, ChevronLeft, Fingerprint, Award, Globe, QrCode, Smartphone, MessageCircle } from 'lucide-react';
import Link from 'next/link';

function FloatingOrbs() {
  return (
    <div className="particles-container">
      <div className="absolute top-[8%] right-[12%] w-[280px] h-[280px] rounded-full bg-[#FFD700]/[0.03] blur-[80px] animate-glow-pulse" />
      <div className="absolute bottom-[12%] left-[8%] w-[220px] h-[220px] rounded-full bg-[#2ECC71]/[0.03] blur-[80px] animate-glow-pulse" style={{ animationDelay: '2s' }} />
      <div className="absolute top-[50%] left-[45%] w-[180px] h-[180px] rounded-full bg-[#3498DB]/[0.02] blur-[60px] animate-glow-pulse" style={{ animationDelay: '4s' }} />
      {[...Array(8)].map((_, i) => (
        <div key={i} className="particle" style={{
          left: `${8 + (i * 12)}%`, animationDelay: `${i * 0.9}s`, animationDuration: `${7 + (i * 0.5)}s`,
          background: ['#FFD700', '#2ECC71', '#3498DB'][i % 3], width: `${1.5 + (i % 2)}px`, height: `${1.5 + (i % 2)}px`,
        }} />
      ))}
    </div>
  );
}

function AnimatedLogo({ letter }: { letter: string }) {
  return (
    <div className="relative w-20 h-20 mx-auto">
      <div className="absolute inset-0 rounded-full border border-dashed border-[#FFD700]/15 logo-ring" />
      <div className="absolute inset-2.5 rounded-full border border-[#2ECC71]/10 logo-ring" style={{ animationDirection: 'reverse', animationDuration: '14s' }} />
      <div className="absolute inset-5 rounded-2xl bg-gradient-to-br from-[#FFD700] via-[#F0C040] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-black text-3xl shadow-lg shadow-[#FFD700]/30">
        {letter}
      </div>
    </div>
  );
}

export default function LoginPage() {
  const [form, setForm] = useState({ usernameOrEmail: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [settings, setSettings] = useState<{ platformName: string; platformNameEn: string }>({ platformName: 'تداول AI', platformNameEn: 'Tadawul AI' });

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => {
      if (d.platformNameEn) setSettings({ platformName: d.platformName || 'تداول AI', platformNameEn: d.platformNameEn });
    }).catch(() => {});
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'حدث خطأ أثناء تسجيل الدخول'); return; }
      if (data.token) localStorage.setItem('tedawilai_token', data.token);
      let target = '/dashboard';
      if (data.user?.isAdmin) target = '/admin/dashboard';
      else if (data.user?.isAgent) target = '/agent-dashboard';
      window.location.href = target;
    } catch { setError('تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً'); }
    finally { setLoading(false); }
  };

  const logoLetter = settings.platformNameEn ? settings.platformNameEn.charAt(0).toUpperCase() : 'T';

  return (
    <div className="min-h-[100dvh] flex bg-[#0A0F0D] relative overflow-hidden" dir="rtl">
      <FloatingOrbs />
      <div className="absolute inset-0 opacity-[0.015] pointer-events-none" style={{
        backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,215,0,0.5) 1px, transparent 0)`,
        backgroundSize: '40px 40px',
      }} />

      {/* Desktop right panel - branding */}
      <div className="hidden lg:flex lg:w-[50%] xl:w-[52%] relative flex-col items-center justify-center p-8 xl:p-14 overflow-hidden">
        <div className="relative z-10 max-w-lg w-full">
          <div className="text-center mb-10 animate-slide-up">
            <AnimatedLogo letter={logoLetter} />
            <h1 className="text-4xl xl:text-5xl font-black text-shimmer mt-6 mb-3 leading-tight tracking-tight" dir="ltr">
              {settings.platformNameEn}
            </h1>
            <p className="text-gray-500 text-base xl:text-lg">{settings.platformName}</p>
            <p className="text-gray-600 text-sm mt-1">منصتك الآمنة والموثوقة للاستثمار الرقمي</p>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-6 stagger-children">
            {[
              { icon: Shield, text: 'تشفير متقدم', desc: 'SSL + AES-256', color: '#FFD700' },
              { icon: TrendingUp, text: 'أرباح يومية مضمونة', desc: 'حتى 3.5% يومياً', color: '#2ECC71' },
              { icon: Award, text: 'تحليلات ذكية', desc: 'بيانات مباشرة', color: '#3498DB' },
              { icon: Users, text: 'دعم فني متواصل', desc: '24 ساعة / 7 أيام', color: '#E74C3C' },
            ].map((f, i) => (
              <div key={i} className="group relative p-4 rounded-2xl bg-white/[0.015] border border-white/[0.04] hover:border-white/[0.08] hover:bg-white/[0.03] transition-all duration-300">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 transition-transform duration-300 group-hover:scale-110" style={{ background: `${f.color}12` }}>
                    <f.icon size={18} style={{ color: f.color }} />
                  </div>
                  <div>
                    <p className="text-gray-200 text-sm font-medium mb-0.5">{f.text}</p>
                    <p className="text-gray-600 text-[11px]">{f.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-4 mb-6 animate-slide-up" style={{ animationDelay: '0.8s' }}>
            {[
              { icon: Shield, label: 'محمي SSL', color: '#2ECC71' },
              { icon: Lock, label: 'AES-256', color: '#FFD700' },
              { icon: Award, label: 'موثق', color: '#3498DB' },
              { icon: Globe, label: 'عالمي', color: '#9B59B6' },
            ].map(t => (
              <div key={t.label} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-white/[0.08] transition-colors">
                <t.icon size={11} style={{ color: `${t.color}80` }} />
                <span className="text-gray-600 text-[10px] font-medium">{t.label}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '1s' }}>
            <div className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/[0.02] border border-white/[0.05]">
              <div className="w-2 h-2 rounded-full bg-[#2ECC71] animate-pulse shadow-lg shadow-[#2ECC71]/50" />
              <span className="text-gray-500 text-xs">متصل الآن</span>
              <span className="text-[#2ECC71] font-bold text-sm">342</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/[0.02] border border-white/[0.05]">
              <Users size={14} className="text-[#FFD700]/60" />
              <span className="text-gray-500 text-xs">إجمالي المستثمرين</span>
              <span className="text-[#FFD700] font-bold text-sm">+5,000</span>
            </div>
          </div>
        </div>
      </div>

      {/* Left panel - login form */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8 relative z-10">
        <div className="lg:hidden absolute top-[-10%] right-[-20%] w-[300px] h-[300px] rounded-full bg-[#FFD700]/[0.03] blur-[80px] animate-glow-pulse" />
        <div className="lg:hidden absolute bottom-[-5%] left-[-15%] w-[250px] h-[250px] rounded-full bg-[#2ECC71]/[0.03] blur-[80px] animate-glow-pulse" style={{ animationDelay: '2s' }} />

        <div className="w-full max-w-[400px]">
          {/* Mobile logo */}
          <div className="lg:hidden text-center mb-8 animate-slide-up">
            <div className="relative w-16 h-16 mx-auto mb-3">
              <div className="absolute inset-0 rounded-full border border-dashed border-[#FFD700]/15 logo-ring" />
              <div className="absolute inset-3 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-black text-xl shadow-lg shadow-[#FFD700]/20">
                {logoLetter}
              </div>
            </div>
            <h1 className="text-2xl font-black text-shimmer" dir="ltr">{settings.platformNameEn}</h1>
            <p className="text-gray-500 text-sm mt-1">{settings.platformName}</p>
          </div>

          {/* Form card with animated gradient border */}
          <div className="animate-slide-up" style={{ animationDelay: '0.15s' }}>
            <div className="login-form-card">
              <form onSubmit={handleSubmit} className="relative z-10 rounded-2xl overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-[#141820] via-[#12161F] to-[#0F1318]" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#FFD700]/[0.015] to-transparent" />

                <div className="relative p-7 sm:p-8 space-y-5">
                  {/* Header */}
                  <div className="text-center mb-2">
                    <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-[#FFD700]/10 via-[#2ECC71]/5 to-[#FFD700]/10 border border-[#FFD700]/10 flex items-center justify-center">
                      <Fingerprint size={24} className="text-[#FFD700]" />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-1">مرحباً بعودتك</h2>
                    <p className="text-gray-500 text-sm">سجّل دخولك للوصول إلى حسابك</p>
                  </div>

                  {/* Error */}
                  {error && (
                    <div className="animate-scaleIn bg-red-500/[0.06] border border-red-500/15 rounded-xl p-3.5 flex items-center gap-2.5">
                      <div className="w-6 h-6 rounded-full bg-red-500/10 flex items-center justify-center shrink-0">
                        <div className="w-2 h-2 rounded-full bg-red-400" />
                      </div>
                      <span className="text-red-400 text-sm">{error}</span>
                    </div>
                  )}

                  {/* Username field */}
                  <div className="space-y-1.5">
                    <label className="text-gray-400 text-xs font-medium block">اسم المستخدم أو البريد الإلكتروني</label>
                    <div className="relative flex items-center">
                      <User size={18} className="absolute right-3.5 text-[#FFD700]/70 pointer-events-none" />
                      <input type="text" placeholder="أدخل اسم المستخدم أو البريد" value={form.usernameOrEmail} onChange={e => setForm({ ...form, usernameOrEmail: e.target.value })} required className="input-premium w-full !pr-11 !pl-3 h-12 text-[15px] placeholder:text-gray-600" style={{ textAlign: 'start' }} />
                    </div>
                  </div>

                  {/* Password field */}
                  <div className="space-y-1.5">
                    <label className="text-gray-400 text-xs font-medium block">كلمة المرور</label>
                    <div className="relative flex items-center">
                      <Lock size={18} className="absolute right-3.5 text-[#2ECC71]/70 pointer-events-none" />
                      <input type={showPass ? 'text' : 'password'} placeholder="أدخل كلمة المرور" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required className="input-premium w-full !pr-11 !pl-11 h-12 text-[15px] placeholder:text-gray-600" style={{ textAlign: 'start' }} />
                      <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-2.5 text-gray-500 hover:text-gray-300 transition-colors" tabIndex={-1}>
                        {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>

                  {/* Forgot password */}
                  <div className="flex justify-start">
                    <Link href="/forgot-password" className="text-xs text-gray-500 hover:text-[#FFD700] transition-colors">نسيت كلمة المرور؟</Link>
                  </div>

                  {/* Login button */}
                  <button type="submit" disabled={loading} className="btn-premium-gold h-[3.2rem] text-[15px] mt-2 flex items-center justify-center gap-2.5 disabled:opacity-60 disabled:cursor-not-allowed">
                    {loading ? (
                      <><div className="w-5 h-5 border-2 border-[#0A0F0D]/30 border-t-[#0A0F0D] rounded-full animate-spin" /><span className="font-semibold">جاري تسجيل الدخول...</span></>
                    ) : (
                      <><Zap size={18} /><span className="font-semibold">تسجيل الدخول</span></>
                    )}
                  </button>

                  {/* Quick login section */}
                  <div className="flex items-center gap-3 py-1">
                    <div className="flex-1 gradient-divider" />
                    <span className="text-gray-600 text-[11px]">تسجيل دخول سريع</span>
                    <div className="flex-1 gradient-divider" />
                  </div>

                  {/* Social/quick login placeholders */}
                  <div className="grid grid-cols-3 gap-2">
                    <button type="button" className="flex flex-col items-center gap-1.5 py-3 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-white/[0.08] hover:bg-white/[0.04] transition-all group">
                      <QrCode size={18} className="text-gray-400 group-hover:text-[#FFD700] transition-colors" />
                      <span className="text-gray-500 text-[10px]">مسح QR</span>
                    </button>
                    <button type="button" className="flex flex-col items-center gap-1.5 py-3 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-white/[0.08] hover:bg-white/[0.04] transition-all group">
                      <Smartphone size={18} className="text-gray-400 group-hover:text-[#2ECC71] transition-colors" />
                      <span className="text-gray-500 text-[10px]">الإيميل</span>
                    </button>
                    <button type="button" className="flex flex-col items-center gap-1.5 py-3 rounded-xl bg-white/[0.02] border border-white/[0.04] hover:border-white/[0.08] hover:bg-white/[0.04] transition-all group">
                      <MessageCircle size={18} className="text-gray-400 group-hover:text-[#3498DB] transition-colors" />
                      <span className="text-gray-500 text-[10px]">المراسلة</span>
                    </button>
                  </div>

                  {/* Register link */}
                  <Link href="/register" className="flex items-center justify-center gap-2 py-3 rounded-xl text-sm text-gray-400 hover:text-[#FFD700] hover:bg-[#FFD700]/[0.04] transition-all duration-300 group">
                    <span>ليس لديك حساب؟</span>
                    <span className="font-semibold text-[#FFD700] group-hover:underline">إنشاء حساب جديد</span>
                    <ChevronLeft size={14} className="text-[#FFD700]/60 group-hover:text-[#FFD700] group-hover:-translate-x-0.5 transition-all" />
                  </Link>
                </div>
              </form>
            </div>
          </div>

          {/* Trust indicators */}
          <div className="flex items-center justify-center gap-4 mt-8 animate-slide-up" style={{ animationDelay: '0.4s' }}>
            {[
              { color: '#2ECC71', label: 'اتصال آمن' },
              { color: '#FFD700', label: 'تشفير 256-بت' },
              { color: '#3498DB', label: 'حماية DDoS' },
            ].map(t => (
              <div key={t.label} className="flex items-center gap-1.5">
                <div className="w-1 h-1 rounded-full" style={{ background: `${t.color}60` }} />
                <span className="text-gray-600 text-[11px]">{t.label}</span>
              </div>
            ))}
          </div>


        </div>
      </div>
    </div>
  );
}
