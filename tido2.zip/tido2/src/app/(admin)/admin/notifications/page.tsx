'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Send, Search, X, User } from 'lucide-react';

interface UserResult {
  id: string;
  username: string;
  email: string;
  fullName: string;
}

export default function AdminNotificationsPage() {
  const { showToast } = useToast();
  const [form, setForm] = useState({ target: 'all', targetUserId: '', title: '', message: '', type: 'normal' });
  const [sent, setSent] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserResult | null>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  const searchUsers = useCallback(async (query: string) => {
    if (query.length < 2) { setSearchResults([]); setShowDropdown(false); return; }
    setSearching(true);
    try {
      const res = await fetch(`/api/admin/users?search=${encodeURIComponent(query)}&limit=10`);
      const data = await res.json();
      if (res.ok) {
        setSearchResults(data.users || []);
        setShowDropdown(true);
      }
    } catch { /* silent fail */ }
    setSearching(false);
  }, []);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchUsers(searchQuery), 400);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [searchQuery, searchUsers]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setShowDropdown(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const selectUser = (u: UserResult) => {
    setSelectedUser(u);
    setForm({ ...form, targetUserId: u.id });
    setSearchQuery(u.username);
    setShowDropdown(false);
  };

  const clearUser = () => {
    setSelectedUser(null);
    setForm({ ...form, targetUserId: '' });
    setSearchQuery('');
  };

  const send = async () => {
    if (!form.title || !form.message) { showToast('العنوان والنص مطلوبان', 'error'); return; }
    if (form.target === 'user' && !form.targetUserId) { showToast('يرجى تحديد المستخدم', 'error'); return; }
    const res = await fetch('/api/admin/notifications', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const data = await res.json();
    if (!res.ok) { showToast(data.error, 'error'); return; }
    showToast(data.message);
    setForm({ target: 'all', targetUserId: '', title: '', message: '', type: 'normal' });
    setSelectedUser(null);
    setSearchQuery('');
    setSent(true); setTimeout(() => setSent(false), 3000);
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <h1 className="text-2xl font-bold text-white">الإشعارات الجماعية</h1>
      <div className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040] space-y-3">
        <div className="flex gap-3">
          <label className="flex items-center gap-2 text-sm"><input type="radio" name="target" value="all" checked={form.target === 'all'} onChange={() => setForm({...form, target: 'all'})} className="accent-[#FFD700]" /> جميع المستخدمين</label>
          <label className="flex items-center gap-2 text-sm"><input type="radio" name="target" value="user" checked={form.target === 'user'} onChange={() => setForm({...form, target: 'user'})} className="accent-[#FFD700]" /> مستخدم محدد</label>
        </div>
        {form.target === 'user' && (
          <div className="relative" ref={searchRef}>
            <div className="relative">
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                {selectedUser ? (
                  <div className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center">
                    <User size={14} className="text-[#2ECC71]" />
                  </div>
                ) : (
                  <div className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center">
                    <Search size={14} className="text-[#FFD700]/70" />
                  </div>
                )}
              </div>
              <input
                placeholder="اسم المستخدم أو البريد الإلكتروني"
                value={selectedUser ? `${selectedUser.username} (${selectedUser.email})` : searchQuery}
                onChange={e => { if (selectedUser) { clearUser(); return; } setSearchQuery(e.target.value); }}
                onFocus={() => { if (!selectedUser && searchQuery.length >= 2) setShowDropdown(true); }}
                className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm pr-11"
                dir="ltr"
              />
              {selectedUser && (
                <button onClick={clearUser} className="absolute left-3 top-1/2 -translate-y-1/2 w-7 h-7 rounded-lg flex items-center justify-center text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all">
                  <X size={14} />
                </button>
              )}
              {searching && (
                <div className="absolute left-3 top-1/2 -translate-y-1/2">
                  <div className="w-4 h-4 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </div>
            {showDropdown && searchResults.length > 0 && (
              <div className="absolute top-full right-0 left-0 mt-1 bg-[#1A1F2E] border border-[#2A3040] rounded-xl overflow-hidden z-50 shadow-xl shadow-black/30 max-h-64 overflow-y-auto scrollbar-thin">
                {searchResults.map(u => (
                  <button
                    key={u.id}
                    onClick={() => selectUser(u)}
                    className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#2A3040]/50 transition-colors text-right"
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0">
                      <User size={14} className="text-gray-300" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm font-medium truncate">{u.username}</p>
                      <p className="text-gray-500 text-xs truncate">{u.email}</p>
                    </div>
                    {u.fullName && (
                      <p className="text-gray-400 text-xs shrink-0">{u.fullName}</p>
                    )}
                  </button>
                ))}
              </div>
            )}
            {showDropdown && searchQuery.length >= 2 && !searching && searchResults.length === 0 && (
              <div className="absolute top-full right-0 left-0 mt-1 bg-[#1A1F2E] border border-[#2A3040] rounded-xl p-4 z-50">
                <p className="text-gray-500 text-sm text-center">لم يتم العثور على مستخدمين</p>
              </div>
            )}
          </div>
        )}
        <input placeholder="عنوان الإشعار" value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm" />
        <textarea placeholder="نص الإشعار" value={form.message} onChange={e => setForm({...form, message: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm h-28 resize-none" />
        <div className="flex gap-3">
          <select value={form.type} onChange={e => setForm({...form, type: e.target.value})} className="bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm"><option value="normal">عادي</option><option value="alert">تنبيه</option><option value="urgent">عاجل</option></select>
          <button onClick={send} className="bg-[#2ECC71] text-white px-6 py-2 rounded-xl text-sm font-bold flex items-center gap-1"><Send size={14} /> إرسال الآن</button>
        </div>
        {sent && <p className="text-[#2ECC71] text-sm">تم الإرسال بنجاح</p>}
      </div>
    </div>
  );
}
