'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';

export default function AdminReferralsPage() {
  const { showToast } = useToast();
  const [rate, setRate] = useState(5);
  const [stats, setStats] = useState({ referralBonusRate: 5, totalReferralProfits: 0, referralUsersCount: 0 });

  useEffect(() => { fetch('/api/admin/referrals').then(r => r.json()).then(d => { setRate(d.referralBonusRate); setStats(d); }); }, []);

  const save = async () => {
    const res = await fetch('/api/admin/referrals', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ referralBonusRate: rate }) });
    if (!res.ok) { const d = await res.json(); showToast(d.error, 'error'); return; }
    showToast('تم تحديث نسبة الإحالات');
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <h1 className="text-2xl font-bold text-white">إدارة الإحالات</h1>
      <div className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040] space-y-4">
        <div><label className="text-gray-400 text-sm block mb-1">نسبة مكافأة الدعوة (%)</label><input type="number" min="0" max="30" step="0.5" value={rate} onChange={e => setRate(parseFloat(e.target.value))} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm max-w-xs" dir="ltr" /></div>
        <p className="text-gray-400 text-sm">المستخدم الداعي يحصل على <span className="text-[#FFD700] font-bold">{rate}%</span> من أرباح المدعو اليومية</p>
        <button onClick={save} className="bg-[#2ECC71] text-white px-6 py-2.5 rounded-xl text-sm font-bold">حفظ التغييرات</button>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[#1A1F2E] rounded-xl p-4 border border-[#2A3040]"><p className="text-gray-400 text-xs">إجمالي أرباح الإحالات</p><p className="text-xl font-bold text-[#FFD700]">${stats.totalReferralProfits.toFixed(2)}</p></div>
        <div className="bg-[#1A1F2E] rounded-xl p-4 border border-[#2A3040]"><p className="text-gray-400 text-xs">مستخدمين حصلوا على أرباح إحالات</p><p className="text-xl font-bold text-white">{stats.referralUsersCount}</p></div>
      </div>
    </div>
  );
}
