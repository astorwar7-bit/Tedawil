'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Plus, Trash2, Edit2 } from 'lucide-react';

interface AdRow { id: string; type: string; title: string; content: string; link: string; imageUrl: string; priority: number; isActive: boolean; startDate: string; endDate: string | null; }

export default function AdminAdsPage() {
  const { showToast } = useToast();
  const [ads, setAds] = useState<AdRow[]>([]);
  const [modal, setModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ type: 'text', title: '', content: '', link: '', imageUrl: '', startDate: new Date().toISOString().split('T')[0], endDate: '', priority: 0, isActive: true });

  const fetchAds = () => fetch('/api/admin/ads').then(r => r.json()).then(d => setAds(d.ads || []));
  useEffect(() => { fetchAds(); }, []);

  const save = async () => {
    const url = editId ? '/api/admin/ads' : '/api/admin/ads';
    const method = editId ? 'PUT' : 'POST';
    const body = editId ? { ...form, id: editId } : form;
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) { showToast(data.error, 'error'); return; }
    showToast(data.message); setModal(false); setEditId(null); setForm({ type: 'text', title: '', content: '', link: '', imageUrl: '', startDate: new Date().toISOString().split('T')[0], endDate: '', priority: 0, isActive: true }); fetchAds();
  };

  const del = async (id: string) => {
    await fetch(`/api/admin/ads?id=${id}`, { method: 'DELETE' });
    showToast('تم حذف الإعلان'); fetchAds();
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">إدارة الإعلانات</h1>
        <button onClick={() => { setModal(true); setEditId(null); }} className="bg-[#2ECC71] hover:bg-[#25A25A] text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-1"><Plus size={16} /> إضافة إعلان</button>
      </div>
      <div className="space-y-2">
        {ads.map(ad => (
          <div key={ad.id} className="bg-[#1A1F2E] rounded-xl p-4 border border-[#2A3040] flex items-center justify-between">
            <div className="flex-1"><h3 className="text-white text-sm font-medium">{ad.title}</h3><p className="text-gray-500 text-xs">{ad.type} - أولوية: {ad.priority} - {ad.isActive ? 'نشط' : 'غير نشط'}</p></div>
            <div className="flex gap-1">
              <button onClick={() => { setEditId(ad.id); setForm({ type: ad.type, title: ad.title, content: ad.content, link: ad.link, imageUrl: ad.imageUrl, startDate: ad.startDate.split('T')[0], endDate: ad.endDate?.split('T')[0] || '', priority: ad.priority, isActive: ad.isActive }); setModal(true); }} className="p-2 hover:bg-[#2A3040] rounded-lg"><Edit2 size={14} className="text-blue-400" /></button>
              <button onClick={() => del(ad.id)} className="p-2 hover:bg-[#2A3040] rounded-lg"><Trash2 size={14} className="text-red-400" /></button>
            </div>
          </div>
        ))}
      </div>
      {modal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setModal(false)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-md border border-[#2A3040] max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-bold mb-4">{editId ? 'تعديل إعلان' : 'إضافة إعلان'}</h3>
            <div className="space-y-3">
              <select value={form.type} onChange={e => setForm({...form, type: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm"><option value="text">نصي</option><option value="image">صورة</option></select>
              <input placeholder="العنوان" value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm" />
              {form.type === 'image' ? <input placeholder="رابط الصورة" value={form.imageUrl} onChange={e => setForm({...form, imageUrl: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm" dir="ltr" /> : <textarea placeholder="المحتوى" value={form.content} onChange={e => setForm({...form, content: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm h-20 resize-none" />}
              <input placeholder="رابط (اختياري)" value={form.link} onChange={e => setForm({...form, link: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm" dir="ltr" />
              <div className="grid grid-cols-2 gap-2">
                <div><label className="text-gray-400 text-xs">تاريخ البداية</label><input type="date" value={form.startDate} onChange={e => setForm({...form, startDate: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm" /></div>
                <div><label className="text-gray-400 text-xs">تاريخ النهاية</label><input type="date" value={form.endDate} onChange={e => setForm({...form, endDate: e.target.value})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm" /></div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div><label className="text-gray-400 text-xs">الأولوية</label><input type="number" value={form.priority} onChange={e => setForm({...form, priority: parseInt(e.target.value)})} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm" dir="ltr" /></div>
                <div className="flex items-end gap-2"><label className="flex items-center gap-2 text-sm text-gray-300"><input type="checkbox" checked={form.isActive} onChange={e => setForm({...form, isActive: e.target.checked})} className="accent-[#2ECC71]" /> نشط</label></div>
              </div>
              <button onClick={save} className="w-full bg-[#2ECC71] text-white py-2.5 rounded-xl text-sm font-bold">حفظ</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
