'use client';
import { useEffect, useState, useRef } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Users, DollarSign, TrendingUp, Clock, CheckCircle, BarChart3, Coins, Loader2, AlertTriangle, Calendar, Bot, PieChart as PieChartIcon } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';

function AnimatedAdminValue({ value }: { value: string | number }) {
  const rafRef = useRef<number>(0);
  const [displayed, setDisplayed] = useState('...');

  useEffect(() => {
    const num = typeof value === 'number' ? value : parseFloat(String(value).replace(/[$,]/g, ''));
    const isFormatted = typeof value === 'string' && value.includes('$');
    const isComplex = typeof value === 'string' && value.includes('(');

    if (isNaN(num) || num === 0 || isComplex) {
      const timer = setTimeout(() => setDisplayed(String(value)), 50);
      return () => clearTimeout(timer);
    }

    const duration = 1000;
    const startTime = Date.now();
    const step = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = num * eased;
      if (isFormatted) {
        setDisplayed(`$${Math.floor(current).toLocaleString('en', { minimumFractionDigits: 2 })}`);
      } else {
        setDisplayed(Math.floor(current).toLocaleString('en'));
      }
      if (progress < 1) rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);

    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [value]);

  return <>{displayed}</>;
}

interface DistributionResult {
  totalDistributed: number;
  investorsCount: number;
  referralBonuses: number;
  message: string;
}

const PIE_COLORS = ['#FFD700', '#2ECC71', '#3498DB', '#E67E22', '#9B59B6', '#E74C3C', '#1ABC9C', '#F39C12'];

export default function AdminDashboard() {
  const { showToast } = useToast();
  const [stats, setStats] = useState({
    totalUsers: 0, newToday: 0, totalDeposits: 0, totalProfits: 0,
    pendingWithdrawals: 0, pendingWithdrawalAmount: 0, completedWithdrawals: 0,
    totalAgents: 0, activeInvestments: 0, totalInvestments: 0,
    totalAgentCommission: 0, thisMonthDeposits: 0, planDistribution: [] as { name: string; color: string; count: number }[],
  });
  const [chartData, setChartData] = useState<{ date: string; deposits: number; withdrawals: number }[]>([]);
  const [distributing, setDistributing] = useState(false);
  const [confirmDistribute, setConfirmDistribute] = useState(false);
  const [distributionResult, setDistributionResult] = useState<DistributionResult | null>(null);
  const [lastDistribution, setLastDistribution] = useState<string | null>(null);

  const updateStats = (data: Record<string, unknown>) => {
    setStats(prev => ({
      totalUsers: (data.totalUsers as number) ?? prev.totalUsers,
      newToday: (data.newToday as number) ?? prev.newToday,
      totalDeposits: (data.totalDeposits as number) ?? prev.totalDeposits,
      totalProfits: (data.totalProfits as number) ?? prev.totalProfits,
      pendingWithdrawals: (data.pendingWithdrawals as number) ?? prev.pendingWithdrawals,
      pendingWithdrawalAmount: (data.pendingWithdrawalAmount as number) ?? prev.pendingWithdrawalAmount,
      completedWithdrawals: (data.completedWithdrawals as number) ?? prev.completedWithdrawals,
      totalAgents: (data.totalAgents as number) ?? prev.totalAgents,
      activeInvestments: (data.activeInvestments as number) ?? prev.activeInvestments,
      totalInvestments: (data.totalInvestments as number) ?? prev.totalInvestments,
      totalAgentCommission: (data.totalAgentCommission as number) ?? prev.totalAgentCommission,
      thisMonthDeposits: (data.thisMonthDeposits as number) ?? prev.thisMonthDeposits,
      planDistribution: Array.isArray(data.planDistribution) ? data.planDistribution as typeof prev.planDistribution : prev.planDistribution,
    }));
    if (Array.isArray(data.chartData)) setChartData(data.chartData as typeof chartData);
  };

  useEffect(() => {
    fetch('/api/admin/dashboard')
      .then(r => r.json())
      .then(data => {
        if (data && typeof data === 'object') updateStats(data);
      })
      .catch(err => console.error('Admin dashboard fetch error:', err));

    fetch('/api/admin/activity-log?actionType=DISTRIBUTE_PROFITS&limit=1')
      .then(r => r.json())
      .then(data => {
        if (data?.logs && Array.isArray(data.logs) && data.logs.length > 0) setLastDistribution(data.logs[0].createdAt);
      })
      .catch(() => {});
  }, []);

  const handleDistribute = async () => {
    setDistributing(true);
    setConfirmDistribute(false);
    try {
      const res = await fetch('/api/admin/distribute-profits', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        setDistributionResult(data);
        showToast(data.message, 'success');
        setLastDistribution(new Date().toISOString());
        fetch('/api/admin/dashboard').then(r => r.json()).then(d => { if (d && typeof d === 'object') updateStats(d); });
      } else {
        showToast(data.error || 'حدث خطأ أثناء التوزيع', 'error');
      }
    } catch { showToast('حدث خطأ أثناء التوزيع', 'error'); }
    finally { setDistributing(false); }
  };

  const fmt = (n: number) => `$${n.toLocaleString('en', { minimumFractionDigits: 2 })}`;

  const cards = [
    { label: 'إجمالي المستخدمين', value: stats.totalUsers, icon: Users, color: '#FFD700' },
    { label: 'المستخدمين الجدد اليوم', value: stats.newToday, icon: Users, color: '#2ECC71' },
    { label: 'إجمالي الإيداعات', value: fmt(stats.totalDeposits), icon: DollarSign, color: '#3498DB' },
    { label: 'إيرادات الشهر', value: fmt(stats.thisMonthDeposits), icon: DollarSign, color: '#FFD700' },
    { label: 'إجمالي الأرباح الموزعة', value: fmt(stats.totalProfits), icon: TrendingUp, color: '#2ECC71' },
    { label: 'السحوبات المعلقة', value: `${stats.pendingWithdrawals} (${fmt(stats.pendingWithdrawalAmount)})`, icon: Clock, color: '#E67E22' },
    { label: 'السحوبات المكتملة', value: fmt(stats.completedWithdrawals), icon: CheckCircle, color: '#2ECC71' },
    { label: 'الوكلاء', value: stats.totalAgents, icon: Users, color: '#9B59B6' },
    { label: 'استثمارات نشطة', value: stats.activeInvestments, icon: TrendingUp, color: '#1ABC9C' },
    { label: 'إجمالي الاستثمارات', value: stats.totalInvestments, icon: BarChart3, color: '#3498DB' },
    { label: 'عمولات الوكلاء', value: fmt(stats.totalAgentCommission), icon: Coins, color: '#FFD700' },
    { label: 'السحوبات المكتملة', value: fmt(stats.completedWithdrawals), icon: CheckCircle, color: '#2ECC71' },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Profit Distribution Section */}
      <div className="glass-card p-5 featured-border">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center border border-[#FFD700]/20">
              <Coins size={22} className="text-[#FFD700]" />
            </div>
            <div>
              <h2 className="text-white font-bold">توزيع الأرباح اليومية</h2>
              <p className="text-gray-400 text-xs mt-0.5">توزيع الأرباح على جميع الاستثمارات النشطة</p>
              {lastDistribution && (
                <div className="flex items-center gap-1 mt-1 text-gray-500 text-xs">
                  <Calendar size={12} />
                  آخر توزيع: {new Date(lastDistribution).toLocaleString('ar')}
                </div>
              )}
            </div>
          </div>
          <button onClick={() => setConfirmDistribute(true)} disabled={distributing} className="btn-premium-gold px-6 py-3 rounded-xl text-sm font-bold flex items-center gap-2 disabled:opacity-50">
            {distributing ? <Loader2 size={16} className="animate-spin" /> : <Coins size={16} />}
            {distributing ? 'جاري التوزيع...' : 'توزيع أرباح اليوم'}
          </button>
        </div>
        {distributionResult && (
          <div className="mt-4 bg-[#2ECC71]/5 border border-[#2ECC71]/20 rounded-xl p-4 animate-fadeIn">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-[#2ECC71] text-lg font-bold">{fmt(distributionResult.totalDistributed)}</p>
                <p className="text-gray-400 text-xs">إجمالي الموزع</p>
              </div>
              <div className="text-center">
                <p className="text-[#FFD700] text-lg font-bold">{distributionResult.investorsCount}</p>
                <p className="text-gray-400 text-xs">عدد المستثمرين</p>
              </div>
              <div className="text-center">
                <p className="text-[#3498DB] text-lg font-bold">{fmt(distributionResult.referralBonuses)}</p>
                <p className="text-gray-400 text-xs">مكافآت الإحالات</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {confirmDistribute && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setConfirmDistribute(false)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-sm border border-[#2A3040]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 flex items-center justify-center"><AlertTriangle size={18} className="text-[#FFD700]" /></div>
              <div>
                <h3 className="text-white font-bold text-sm">تأكيد توزيع الأرباح</h3>
                <p className="text-gray-400 text-xs mt-0.5">سيتم توزيع الأرباح على جميع الاستثمارات النشطة</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm mb-5">سيتم حساب الأرباح اليومية لجميع الاستثمارات النشطة وإضافتها إلى أرصدة المستثمرين.</p>
            <div className="flex gap-2">
              <button onClick={handleDistribute} className="flex-1 btn-premium-gold py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2"><Coins size={14} /> تأكيد التوزيع</button>
              <button onClick={() => setConfirmDistribute(false)} className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm hover:bg-[#3A4050]">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      <h1 className="text-2xl font-bold text-white flex items-center gap-2">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center border border-[#FFD700]/20">
          <TrendingUp size={18} className="text-[#FFD700]" />
        </div>
        لوحة تحكم الأدمن
      </h1>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {cards.map((c, i) => (
          <div key={i} className="glass-card card-lift premium-shimmer p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${c.color}15` }}>
                <c.icon size={16} style={{ color: c.color }} />
              </div>
              <span className="text-gray-400 text-xs leading-tight">{c.label}</span>
            </div>
            <p className="text-lg font-bold text-white"><AnimatedAdminValue value={c.value} /></p>
          </div>
        ))}
      </div>

      {/* Charts: 2-column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Deposits/Withdrawals Bar Chart */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <BarChart3 size={16} className="text-[#2ECC71]" />
            الإيداعات والسحوبات - آخر 30 يوم
          </h3>
          <div className="h-72">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2A3040" />
                  <XAxis dataKey="date" stroke="#8899AA" fontSize={12} />
                  <YAxis stroke="#8899AA" fontSize={12} />
                  <Tooltip contentStyle={{ background: '#1A1F2E', border: '1px solid #2A3040', borderRadius: '12px', color: '#fff', boxShadow: '0 12px 40px rgba(0,0,0,0.4)' }} />
                  <Legend />
                  <Bar dataKey="deposits" fill="#2ECC71" name="الإيداعات" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="withdrawals" fill="#E74C3C" name="السحوبات" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500 text-sm">لا توجد بيانات للعرض</div>
            )}
          </div>
        </div>

        {/* Deposits Trend Area Chart */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <TrendingUp size={16} className="text-[#FFD700]" />
            اتجاه الإيداعات - آخر 30 يوم
          </h3>
          <div className="h-72">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="depositGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2ECC71" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#2ECC71" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2A3040" />
                  <XAxis dataKey="date" stroke="#8899AA" fontSize={12} />
                  <YAxis stroke="#8899AA" fontSize={12} />
                  <Tooltip contentStyle={{ background: '#1A1F2E', border: '1px solid #2A3040', borderRadius: '12px', color: '#fff', boxShadow: '0 12px 40px rgba(0,0,0,0.4)' }} />
                  <Area type="monotone" dataKey="deposits" stroke="#2ECC71" fill="url(#depositGradient)" strokeWidth={2} name="الإيداعات" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500 text-sm">لا توجد بيانات للعرض</div>
            )}
          </div>
        </div>
      </div>

      {/* Plan Distribution Pie Chart */}
      {stats.planDistribution.length > 0 && (
        <div className="glass-card p-5">
          <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <PieChartIcon size={16} className="text-[#3498DB]" />
            توزيع خطط الاستثمار
          </h3>
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-64 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stats.planDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={100}
                    paddingAngle={3}
                    dataKey="count"
                    nameKey="name"
                  >
                    {stats.planDistribution.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: '#1A1F2E', border: '1px solid #2A3040', borderRadius: '12px', color: '#fff' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-2">
              {stats.planDistribution.map((plan, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full shrink-0" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                  <span className="text-gray-300 text-sm flex-1">{plan.name}</span>
                  <span className="text-white font-bold text-sm">{plan.count}</span>
                  <span className="text-gray-500 text-xs">مستخدم</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
