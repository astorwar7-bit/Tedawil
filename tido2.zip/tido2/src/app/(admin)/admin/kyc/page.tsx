'use client';

import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/contexts/ToastContext';
import {
  Shield,
  Clock,
  CheckCircle,
  XCircle,
  Search,
  Check,
  X,
  Loader2,
  ChevronLeft,
  ChevronRight,
  Eye,
  User,
  Mail,
  Image as ImageIcon,
  Camera,
  CreditCard,
  X as CloseIcon,
} from 'lucide-react';

interface KYCSubmission {
  id: string;
  userId: string;
  username: string;
  fullName: string;
  email: string;
  idFront: string;
  idBack: string;
  selfie: string;
  status: string;
  rejectReason: string;
  createdAt: string;
  updatedAt: string;
}

interface Stats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
}

export default function AdminKYCPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [submissions, setSubmissions] = useState<KYCSubmission[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, pending: 0, approved: 0, rejected: 0 });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // View modal
  const [viewModal, setViewModal] = useState<KYCSubmission | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [showRejectInput, setShowRejectInput] = useState(false);

  const fetchSubmissions = useCallback(async (p: number = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('page', String(p));
      params.set('limit', '20');
      if (filter !== 'all') params.set('status', filter);
      if (search) params.set('search', search);

      const res = await fetch(`/api/admin/kyc?${params.toString()}`);
      const data = await res.json();
      setSubmissions(data.submissions || []);
      setStats(data.stats || { total: 0, pending: 0, approved: 0, rejected: 0 });
      setTotalPages(data.pages || 1);
    } catch (err) {
      console.error('Failed to fetch KYC submissions:', err);
    }
    setLoading(false);
  }, [filter, search]);

  useEffect(() => {
    if (user) {
      setPage(1);
      fetchSubmissions(1);
    }
  }, [user, filter]);

  useEffect(() => {
    if (user) fetchSubmissions(page);
  }, [page]);

  const handleSearch = () => {
    setPage(1);
    fetchSubmissions(1);
  };

  const handleApprove = async (id: string) => {
    setActionLoading(id);
    try {
      const res = await fetch(`/api/admin/kyc/${id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'approve' }),
      });
      if (res.ok) {
        showToast('تم قبول طلب التحقق بنجاح', 'success');
        setViewModal(null);
        fetchSubmissions(page);
      } else {
        const data = await res.json();
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء المعالجة', 'error');
    }
    setActionLoading(null);
  };

  const handleReject = async (id: string) => {
    if (!rejectReason.trim()) {
      showToast('يرجى إدخال سبب الرفض', 'error');
      return;
    }
    setActionLoading(id);
    try {
      const res = await fetch(`/api/admin/kyc/${id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reject', reason: rejectReason }),
      });
      if (res.ok) {
        showToast('تم رفض طلب التحقق', 'success');
        setViewModal(null);
        setShowRejectInput(false);
        setRejectReason('');
        fetchSubmissions(page);
      } else {
        const data = await res.json();
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء المعالجة', 'error');
    }
    setActionLoading(null);
  };

  const statusColors: Record<string, string> = {
    pending: '#FFD700',
    verified: '#2ECC71',
    rejected: '#EF4444',
  };

  const statusLabels: Record<string, string> = {
    pending: 'قيد المراجعة',
    verified: 'موافق عليه',
    rejected: 'مرفوض',
  };

  const statCards = [
    { label: 'إجمالي الطلبات', value: stats.total, icon: Shield, color: '#FFD700', bg: 'rgba(255,215,0,0.1)' },
    { label: 'قيد المراجعة', value: stats.pending, icon: Clock, color: '#FFD700', bg: 'rgba(255,215,0,0.1)' },
    { label: 'موافق عليه', value: stats.approved, icon: CheckCircle, color: '#2ECC71', bg: 'rgba(46,204,113,0.1)' },
    { label: 'مرفوض', value: stats.rejected, icon: XCircle, color: '#EF4444', bg: 'rgba(239,68,68,0.1)' },
  ];

  const openViewModal = (sub: KYCSubmission) => {
    setViewModal(sub);
    setShowRejectInput(false);
    setRejectReason('');
  };

  if (!user) return null;

  return (
    <div className="space-y-5 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 flex items-center justify-center">
          <Shield size={20} className="text-[#FFD700]" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">مراجعة التحقق من الهوية (KYC)</h1>
          <p className="text-gray-500 text-xs">مراجعة وادارة طلبات التحقق من هوية المستخدمين</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {statCards.map((s, i) => (
          <div key={i} className="glass-card card-lift p-4">
            <div className="flex items-center gap-2 mb-2">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ background: s.bg }}
              >
                <s.icon size={16} style={{ color: s.color }} />
              </div>
              <span className="text-gray-400 text-xs">{s.label}</span>
            </div>
            <p className="text-2xl font-bold text-white">{s.value}</p>
          </div>
        ))}
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
          <input
            placeholder="بحث بالاسم أو البريد الإلكتروني..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            className="input-premium pr-10"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {[
            { key: 'all', label: 'الكل' },
            { key: 'pending', label: 'قيد المراجعة' },
            { key: 'verified', label: 'موافق عليه' },
            { key: 'rejected', label: 'مرفوض' },
          ].map(f => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
                filter === f.key
                  ? 'bg-[#FFD700]/15 text-[#FFD700] border border-[#FFD700]/30'
                  : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-[#3A4050]'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Desktop Table */}
      <div className="glass-card overflow-hidden hidden md:block">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2A3040]">
                <th className="text-right p-3 text-gray-400 font-medium text-xs">المستخدم</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">البريد الإلكتروني</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">الحالة</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">تاريخ التقديم</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">إجراء</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={5} className="text-center py-12">
                    <Loader2 className="animate-spin text-[#FFD700] mx-auto" size={24} />
                  </td>
                </tr>
              ) : submissions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 text-gray-500">
                    <Shield size={40} className="mx-auto mb-3 opacity-30" />
                    لا توجد طلبات تحقق
                  </td>
                </tr>
              ) : (
                submissions.map(s => (
                  <tr key={s.id} className="border-b border-[#2A3040]/50 hover:bg-[#2A3040]/20 transition-colors">
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                          {(s.fullName || s.username).charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="text-white text-xs font-medium">{s.fullName || s.username}</p>
                          <p className="text-gray-500 text-[10px]">@{s.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-3 text-gray-400 text-xs" dir="ltr">{s.email}</td>
                    <td className="p-3">
                      <span
                        className="px-2.5 py-1 rounded-lg text-[11px] font-medium"
                        style={{
                          background: `${statusColors[s.status]}15`,
                          color: statusColors[s.status],
                        }}
                      >
                        {statusLabels[s.status] || s.status}
                      </span>
                    </td>
                    <td className="p-3 text-gray-500 text-xs">{new Date(s.createdAt).toLocaleDateString('ar')}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openViewModal(s)}
                          className="p-1.5 rounded-lg bg-[#FFD700]/10 text-[#FFD700] hover:bg-[#FFD700]/20 transition-colors"
                          title="عرض المستندات"
                        >
                          <Eye size={14} />
                        </button>
                        {s.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleApprove(s.id)}
                              disabled={!!actionLoading}
                              className="p-1.5 rounded-lg bg-[#2ECC71]/10 text-[#2ECC71] hover:bg-[#2ECC71]/20 transition-colors disabled:opacity-50"
                              title="موافقة"
                            >
                              {actionLoading === s.id ? (
                                <Loader2 size={14} className="animate-spin" />
                              ) : (
                                <Check size={14} />
                              )}
                            </button>
                            <button
                              onClick={() => openViewModal(s)}
                              className="p-1.5 rounded-lg bg-[#EF4444]/10 text-[#EF4444] hover:bg-[#EF4444]/20 transition-colors"
                              title="رفض"
                            >
                              <X size={14} />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-[#2A3040]">
            <span className="text-gray-500 text-xs">صفحة {page} من {totalPages}</span>
            <div className="flex gap-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg bg-[#1A1F2E] text-gray-400 hover:text-white border border-[#2A3040] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight size={16} />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg bg-[#1A1F2E] text-gray-400 hover:text-white border border-[#2A3040] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden space-y-3">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="glass-card p-4 skeleton-premium rounded-2xl">
                <div className="h-20" />
              </div>
            ))}
          </div>
        ) : submissions.length === 0 ? (
          <div className="glass-card p-8 text-center">
            <Shield size={40} className="mx-auto mb-3 text-gray-600" />
            <p className="text-gray-500 text-sm">لا توجد طلبات تحقق</p>
          </div>
        ) : (
          submissions.map(s => (
            <div key={s.id} className="glass-card p-4 card-lift">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                    {(s.fullName || s.username).charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-white text-sm font-bold">{s.fullName || s.username}</p>
                    <p className="text-gray-500 text-xs">@{s.username}</p>
                    <p className="text-gray-600 text-[10px] mt-0.5" dir="ltr">{s.email}</p>
                  </div>
                </div>
                <span
                  className="px-2.5 py-1 rounded-lg text-[11px] font-medium flex-shrink-0"
                  style={{
                    background: `${statusColors[s.status]}15`,
                    color: statusColors[s.status],
                  }}
                >
                  {statusLabels[s.status] || s.status}
                </span>
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-[#2A3040]/50">
                <span className="text-gray-500 text-xs">
                  {new Date(s.createdAt).toLocaleDateString('ar')}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openViewModal(s)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FFD700]/10 text-[#FFD700] text-xs font-medium hover:bg-[#FFD700]/20 transition-colors"
                  >
                    <Eye size={13} />
                    عرض
                  </button>
                  {s.status === 'pending' && (
                    <>
                      <button
                        onClick={() => handleApprove(s.id)}
                        disabled={!!actionLoading}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2ECC71]/10 text-[#2ECC71] text-xs font-medium hover:bg-[#2ECC71]/20 transition-colors disabled:opacity-50"
                      >
                        {actionLoading === s.id ? (
                          <Loader2 size={13} className="animate-spin" />
                        ) : (
                          <Check size={13} />
                        )}
                        موافقة
                      </button>
                      <button
                        onClick={() => openViewModal(s)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#EF4444]/10 text-[#EF4444] text-xs font-medium hover:bg-[#EF4444]/20 transition-colors"
                      >
                        <X size={13} />
                        رفض
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))
        )}

        {/* Mobile Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-1">
            <span className="text-gray-500 text-xs">صفحة {page} من {totalPages}</span>
            <div className="flex gap-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg bg-[#1A1F2E] text-gray-400 border border-[#2A3040] disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronRight size={16} />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg bg-[#1A1F2E] text-gray-400 border border-[#2A3040] disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* View / Detail Modal */}
      {viewModal && (
        <div
          className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
          onClick={() => {
            setViewModal(null);
            setShowRejectInput(false);
            setRejectReason('');
          }}
        >
          <div
            className="bg-[#12161F] rounded-2xl border border-[#2A3040] w-full max-w-lg max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b border-[#2A3040] sticky top-0 bg-[#12161F] z-10 rounded-t-2xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-white font-bold">
                  {(viewModal.fullName || viewModal.username).charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-white font-bold text-sm">{viewModal.fullName || viewModal.username}</h3>
                  <p className="text-gray-500 text-xs">@{viewModal.username}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className="px-2.5 py-1 rounded-lg text-[11px] font-medium"
                  style={{
                    background: `${statusColors[viewModal.status]}15`,
                    color: statusColors[viewModal.status],
                  }}
                >
                  {statusLabels[viewModal.status] || viewModal.status}
                </span>
                <button
                  onClick={() => {
                    setViewModal(null);
                    setShowRejectInput(false);
                    setRejectReason('');
                  }}
                  className="p-1.5 rounded-lg hover:bg-[#2A3040] text-gray-500 hover:text-white transition-colors"
                >
                  <CloseIcon size={16} />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-4 space-y-4">
              {/* User Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#1A1F2E] border border-[#2A3040]/50">
                  <User size={16} className="text-[#FFD700] flex-shrink-0" />
                  <div>
                    <p className="text-gray-500 text-[10px]">الاسم الكامل</p>
                    <p className="text-white text-xs font-medium">{viewModal.fullName || '-'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2.5 p-3 rounded-xl bg-[#1A1F2E] border border-[#2A3040]/50">
                  <Mail size={16} className="text-[#FFD700] flex-shrink-0" />
                  <div>
                    <p className="text-gray-500 text-[10px]">البريد الإلكتروني</p>
                    <p className="text-white text-xs font-medium" dir="ltr">{viewModal.email}</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-[#1A1F2E] border border-[#2A3040]/50">
                  <p className="text-gray-500 text-[10px]">تاريخ التقديم</p>
                  <p className="text-white text-xs font-medium">{new Date(viewModal.createdAt).toLocaleDateString('ar')}</p>
                </div>
                <div className="p-3 rounded-xl bg-[#1A1F2E] border border-[#2A3040]/50">
                  <p className="text-gray-500 text-[10px]">آخر تحديث</p>
                  <p className="text-white text-xs font-medium">{new Date(viewModal.updatedAt).toLocaleDateString('ar')}</p>
                </div>
              </div>

              {/* Rejection reason (if previously rejected) */}
              {viewModal.rejectReason && viewModal.status === 'rejected' && (
                <div className="p-3 rounded-xl bg-[#EF4444]/5 border border-[#EF4444]/20">
                  <p className="text-[#EF4444] text-[10px] font-medium mb-1">سبب الرفض السابق</p>
                  <p className="text-gray-300 text-xs">{viewModal.rejectReason}</p>
                </div>
              )}

              {/* Uploaded Documents */}
              <div>
                <h4 className="text-white text-sm font-bold mb-3 flex items-center gap-2">
                  <Camera size={15} className="text-[#FFD700]" />
                  المستندات المرفوعة
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* ID Front */}
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-gray-400 text-[11px]">
                      <CreditCard size={12} className="text-[#FFD700]" />
                      الوجه الأمامي
                    </div>
                    <div className="relative aspect-[3/2] rounded-xl overflow-hidden bg-[#1A1F2E] border border-[#2A3040]">
                      {viewModal.idFront ? (
                        <img
                          src={viewModal.idFront}
                          alt="الوجه الأمامي"
                          className="w-full h-full object-cover"
                          onClick={() => window.open(viewModal.idFront, '_blank')}
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-gray-600">
                          <ImageIcon size={24} />
                          <span className="text-[10px] mt-1">غير متوفر</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* ID Back */}
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-gray-400 text-[11px]">
                      <CreditCard size={12} className="text-[#2ECC71]" />
                      الوجه الخلفي
                    </div>
                    <div className="relative aspect-[3/2] rounded-xl overflow-hidden bg-[#1A1F2E] border border-[#2A3040]">
                      {viewModal.idBack ? (
                        <img
                          src={viewModal.idBack}
                          alt="الوجه الخلفي"
                          className="w-full h-full object-cover"
                          onClick={() => window.open(viewModal.idBack, '_blank')}
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-gray-600">
                          <ImageIcon size={24} />
                          <span className="text-[10px] mt-1">غير متوفر</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Selfie */}
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-1.5 text-gray-400 text-[11px]">
                      <Camera size={12} className="text-[#FFD700]" />
                      صورة شخصية
                    </div>
                    <div className="relative aspect-[3/2] rounded-xl overflow-hidden bg-[#1A1F2E] border border-[#2A3040]">
                      {viewModal.selfie ? (
                        <img
                          src={viewModal.selfie}
                          alt="صورة شخصية"
                          className="w-full h-full object-cover"
                          onClick={() => window.open(viewModal.selfie, '_blank')}
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-gray-600">
                          <ImageIcon size={24} />
                          <span className="text-[10px] mt-1">غير متوفر</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Reject Reason Input */}
              {viewModal.status === 'pending' && showRejectInput && (
                <div className="space-y-2 animate-fadeIn">
                  <label className="text-gray-400 text-xs">سبب الرفض *</label>
                  <textarea
                    value={rejectReason}
                    onChange={e => setRejectReason(e.target.value)}
                    placeholder="أدخل سبب رفض طلب التحقق..."
                    rows={3}
                    className="input-premium resize-none"
                  />
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleReject(viewModal.id)}
                      disabled={!!actionLoading || !rejectReason.trim()}
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold text-white bg-[#EF4444] hover:bg-[#EF4444]/80 transition-colors disabled:opacity-50"
                    >
                      {actionLoading === viewModal.id ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : (
                        <X size={14} />
                      )}
                      تأكيد الرفض
                    </button>
                    <button
                      onClick={() => {
                        setShowRejectInput(false);
                        setRejectReason('');
                      }}
                      className="px-4 py-2.5 rounded-xl text-sm bg-[#2A3040] text-gray-300 hover:bg-[#3A4050] transition-colors"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              )}

              {/* Action Buttons (only for pending) */}
              {viewModal.status === 'pending' && !showRejectInput && (
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => handleApprove(viewModal.id)}
                    disabled={!!actionLoading}
                    className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold text-white bg-[#2ECC71] hover:bg-[#2ECC71]/80 transition-colors disabled:opacity-50"
                  >
                    {actionLoading === viewModal.id ? (
                      <Loader2 size={16} className="animate-spin" />
                    ) : (
                      <Check size={16} />
                    )}
                    موافقة
                  </button>
                  <button
                    onClick={() => setShowRejectInput(true)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold text-white bg-[#EF4444] hover:bg-[#EF4444]/80 transition-colors"
                  >
                    <X size={16} />
                    رفض
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
