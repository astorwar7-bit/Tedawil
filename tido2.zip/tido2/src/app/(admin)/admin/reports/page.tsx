'use client';
import { useState } from 'react';
import { Download, FileJson, FileSpreadsheet } from 'lucide-react';

function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob(['\uFEFF' + content], { type: mimeType }); // BOM for Arabic CSV
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function jsonToCsv(data: Record<string, unknown>[], filename: string) {
  if (!data || data.length === 0) return;
  const headers = Object.keys(data[0]);
  const rows = data.map(row =>
    headers.map(h => {
      const val = String(row[h] ?? '');
      // Escape commas and quotes in CSV
      if (val.includes(',') || val.includes('"') || val.includes('\n')) {
        return `"${val.replace(/"/g, '""')}"`;
      }
      return val;
    }).join(',')
  );
  const csv = [headers.join(','), ...rows].join('\n');
  downloadFile(csv, `${filename}.csv`, 'text/csv;charset=utf-8');
}

export default function AdminReportsPage() {
  const [loading, setLoading] = useState('');

  const downloadReport = async (type: string, label: string) => {
    setLoading(type);
    try {
      const res = await fetch(`/api/admin/reports?type=${type}`);
      const data = await res.json();
      const jsonData = data.data || [];

      if (jsonData.length === 0) {
        setLoading('');
        return;
      }

      // Download JSON
      const jsonBlob = new Blob([JSON.stringify(jsonData, null, 2)], { type: 'application/json' });
      const jsonUrl = URL.createObjectURL(jsonBlob);
      const a = document.createElement('a');
      a.href = jsonUrl; a.download = `${label}.json`; a.click();
      URL.revokeObjectURL(jsonUrl);

      // Download CSV
      jsonToCsv(jsonData, label);
    } catch {}
    setLoading('');
  };

  const reports = [
    { type: 'users', label: 'تقرير المستخدمين' },
    { type: 'transactions', label: 'تقرير المعاملات' },
    { type: 'withdrawals', label: 'تقرير السحوبات' },
    { type: 'referralProfits', label: 'تقرير أرباح الإحالات' },
  ];

  return (
    <div className="space-y-4 animate-fadeIn">
      <h1 className="text-2xl font-bold text-white">التقارير</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reports.map(r => (
          <div key={r.type} className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040]">
            <div className="flex items-center justify-between mb-3">
              <div><h3 className="text-white font-medium">{r.label}</h3><p className="text-gray-500 text-xs">تحميل كملف JSON و CSV</p></div>
              {loading === r.type && <div className="animate-spin w-5 h-5 border-2 border-[#FFD700] border-t-transparent rounded-full" />}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => downloadReport(r.type, r.label)}
                disabled={loading === r.type}
                className="flex-1 bg-[#FFD700] hover:bg-[#B8960F] text-[#0A0F0D] px-4 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <Download size={14} />
                تحميل JSON
              </button>
              <button
                onClick={() => {
                  setLoading(r.type + '_csv');
                  fetch(`/api/admin/reports?type=${r.type}`)
                    .then(res => res.json())
                    .then(data => {
                      jsonToCsv(data.data || [], r.label);
                      setLoading('');
                    })
                    .catch(() => setLoading(''));
                }}
                disabled={loading === r.type}
                className="flex-1 bg-[#2ECC71]/10 hover:bg-[#2ECC71]/20 text-[#2ECC71] px-4 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <FileSpreadsheet size={14} />
                تحميل CSV
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
