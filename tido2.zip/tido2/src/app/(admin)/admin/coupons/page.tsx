'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Plus, Trash2, Edit2, Tag, Percent, DollarSign, Users, Clock, CheckCircle, XCircle, Search, ToggleLeft, ToggleRight, Copy, Filter, TrendingUp, AlertTriangle } from 'lucide-react';

interface CouponRow {
  id: string;
  code: string;
  discount: number;
  type: string;
  maxUses: number;
  maxUsesPerUser: number;
  minInvestment: number;
  usedCount: number;
  expiresAt: string | null;
  isActive: boolean;
  createdAt: string;
  _count?: { usages: number; investments: number };
}

export default function AdminCouponsPage() {
  const { showToast } = useToast();
  const [coupons, setCoupons] = useState<CouponRow[]>([]);
  const [modal, setModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'percentage' | 'fixed'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [form, setForm] = useState({
    code: '',
    discount: 10,
    type: 'percentage' as 'percentage' | 'fixed',
    maxUses: 100,
    maxUsesPerUser: 1,
    minInvestment: 0,
    expiresAt: '',
    isActive: true,
  });

  const fetchCoupons = () => fetch('/api/admin/coupons').then(r => r.json()).then(d => setCoupons(d.coupons || []));
  useEffect(() => { fetchCoupons(); }, []);

  const resetForm = () => {
    setForm({ code: '', discount: 10, type: 'percentage', maxUses: 100, maxUsesPerUser: 1, minInvestment: 0, expiresAt: '', isActive: true });
    setEditId(null);
  };

  const save = async () => {
    const body = editId ? { ...form, id: editId } : form;
    const res = await fetch('/api/admin/coupons', {
      method: editId ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) { showToast(data.error, 'error'); return; }
    showToast(data.message);
    setModal(false);
    resetForm();
    fetchCoupons();
  };

  const del = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الكوبون؟')) return;
    await fetch(`/api/admin/coupons?id=${id}`, { method: 'DELETE' });
    showToast('تم حذف الكوبون');
    fetchCoupons();
  };

  const toggleActive = async (coupon: CouponRow) => {
    const res = await fetch('/api/admin/coupons', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: coupon.id, isActive: !coupon.isActive }),
    });
    if (res.ok) {
      showToast(!coupon.isActive ? 'تم تفعيل الكوبون' : 'تم تعطيل الكوبون');
      fetchCoupons();
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    showToast(`تم نسخ الكوبون: ${code}`);
  };

  const openEdit = (c: CouponRow) => {
    setEditId(c.id);
    setForm({
      code: c.code,
      discount: c.discount,
      type: (c.type || 'percentage') as 'percentage' | 'fixed',
      maxUses: c.maxUses,
      maxUsesPerUser: c.maxUsesPerUser || 1,
      minInvestment: c.minInvestment || 0,
      expiresAt: c.expiresAt?.split('T')[0] || '',
      isActive: c.isActive,
    });
    setModal(true);
  };

  // Filter coupons
  const filteredCoupons = coupons.filter(c => {
    const matchesSearch = !searchQuery || c.code.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || c.type === filterType;
    const matchesStatus = filterStatus === 'all' || (filterStatus === 'active' ? c.isActive : !c.isActive);
    return matchesSearch && matchesType && matchesStatus;
  });

  const totalDiscountGiven = coupons.reduce((acc, c) => {
    if (c._count?.investments) return acc + c._count.investments * c.discount;
    return acc;
  }, 0);

  const expiredCount = coupons.filter(c => c.expiresAt && new Date(c.expiresAt) < new Date()).length;
  const almostExpiredCount = coupons.filter(c => {
    if (!c.expiresAt) return false;
    const daysLeft = (new Date(c.expiresAt).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24);
    return daysLeft > 0 && daysLeft <= 3;
  }).length;

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Tag size={22} className="text-[#FFD700]" />
            إدارة الكوبونات
          </h1>
          <p className="text-xs text-gray-500 mt-1">إنشاء وإدارة كوبونات الخصم للمستخدمين</p>
        </div>
        <button onClick={() => { resetForm(); setModal(true); }} className="bg-gradient-to-l from-[#2ECC71] to-[#27AE60] text-white px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 hover:shadow-lg hover:shadow-[#2ECC71]/20 transition-all">
          <Plus size={16} /> إنشاء كوبون جديد
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="glass-card p-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#FFD700]/10 flex items-center justify-center">
              <Tag size={16} className="text-[#FFD700]" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500">إجمالي</p>
              <p className="text-lg font-bold text-white">{coupons.length}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#2ECC71]/10 flex items-center justify-center">
              <CheckCircle size={16} className="text-[#2ECC71]" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500">نشط</p>
              <p className="text-lg font-bold text-[#2ECC71]">{coupons.filter(c => c.isActive).length}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-500/10 flex items-center justify-center">
              <XCircle size={16} className="text-red-400" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500">غير نشط</p>
              <p className="text-lg font-bold text-red-400">{coupons.filter(c => !c.isActive).length}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <Percent size={16} className="text-purple-400" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500">نسبة مئوية</p>
              <p className="text-lg font-bold text-white">{coupons.filter(c => c.type === 'percentage').length}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <DollarSign size={16} className="text-blue-400" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500">مبلغ ثابت</p>
              <p className="text-lg font-bold text-white">{coupons.filter(c => c.type === 'fixed').length}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500/10 flex items-center justify-center">
              <AlertTriangle size={16} className="text-orange-400" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500">منتهي/قريب</p>
              <p className="text-lg font-bold text-orange-400">{expiredCount + almostExpiredCount}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-[#1A1F2E] rounded-xl p-3 border border-[#2A3040] flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            placeholder="ابحث بالكود..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value.toUpperCase())}
            className="w-full bg-[#12161F] border border-[#2A3040] rounded-lg pr-9 pl-3 py-2 text-sm text-white focus:outline-none focus:border-[#FFD700]/50 transition-colors"
            dir="ltr"
          />
        </div>
        <div className="flex gap-2">
          <div className="flex items-center gap-1 bg-[#12161F] rounded-lg p-1 border border-[#2A3040]">
            <Filter size={12} className="text-gray-500 mr-1" />
            {(['all', 'percentage', 'fixed'] as const).map(t => (
              <button key={t} onClick={() => setFilterType(t)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${filterType === t ? 'bg-[#FFD700]/10 text-[#FFD700]' : 'text-gray-500 hover:text-gray-300'}`}>
                {t === 'all' ? 'الكل' : t === 'percentage' ? 'نسبة' : 'ثابت'}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-1 bg-[#12161F] rounded-lg p-1 border border-[#2A3040]">
            {(['all', 'active', 'inactive'] as const).map(s => (
              <button key={s} onClick={() => setFilterStatus(s)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${filterStatus === s ? 'bg-[#2ECC71]/10 text-[#2ECC71]' : 'text-gray-500 hover:text-gray-300'}`}>
                {s === 'all' ? 'الكل' : s === 'active' ? 'نشط' : 'متوقف'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Coupons Table */}
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#2A3040] bg-[#12161F]/50">
              <th className="text-right p-3 text-gray-400 text-xs font-medium">الكود</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">النوع</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">الخصم</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">الحد لكل مستخدم</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">الاستخدام</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">الحد الأدنى</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">الانتهاء</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">الحالة</th>
              <th className="text-right p-3 text-gray-400 text-xs font-medium">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {filteredCoupons.map(c => {
              const usage = c.maxUses > 0 ? Math.round((c.usedCount / c.maxUses) * 100) : 0;
              const isExpired = c.expiresAt && new Date(c.expiresAt) < new Date();
              const isAlmostExpired = c.expiresAt && !isExpired && ((new Date(c.expiresAt).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) <= 3;
              return (
                <tr key={c.id} className="border-b border-[#2A3040]/50 hover:bg-white/[0.01] transition-colors">
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[#FFD700] font-bold text-xs font-mono" dir="ltr">{c.code}</span>
                      <button onClick={() => copyCode(c.code)} className="text-gray-600 hover:text-[#FFD700] transition-colors" title="نسخ">
                        <Copy size={12} />
                      </button>
                    </div>
                  </td>
                  <td className="p-3">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-[11px] ${c.type === 'fixed' ? 'bg-blue-500/10 text-blue-400' : 'bg-purple-500/10 text-purple-400'}`}>
                      {c.type === 'fixed' ? <DollarSign size={10} /> : <Percent size={10} />}
                      {c.type === 'fixed' ? 'مبلغ ثابت' : 'نسبة مئوية'}
                    </span>
                  </td>
                  <td className="p-3 text-white font-medium text-xs">
                    {c.type === 'fixed' ? `$${c.discount}` : `${c.discount}%`}
                  </td>
                  <td className="p-3 text-gray-300 text-xs">{c.maxUsesPerUser || 1}</td>
                  <td className="p-3">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-300 text-[11px]">{c.usedCount}/{c.maxUses}</span>
                        <div className="w-14 h-1.5 bg-[#12161F] rounded-full overflow-hidden">
                          <div className={`h-full rounded-full transition-all ${usage >= 90 ? 'bg-red-400' : usage >= 60 ? 'bg-yellow-400' : 'bg-[#2ECC71]'}`} style={{ width: `${Math.min(usage, 100)}%` }} />
                        </div>
                      </div>
                      <span className="text-[10px] text-gray-600">{usage}% مستخدم</span>
                    </div>
                  </td>
                  <td className="p-3 text-gray-300 text-xs">{c.minInvestment > 0 ? `$${c.minInvestment.toLocaleString()}` : '-'}</td>
                  <td className="p-3 text-xs">
                    {c.expiresAt ? (
                      <div className={`flex items-center gap-1 ${isExpired ? 'text-red-400' : isAlmostExpired ? 'text-orange-400' : 'text-gray-300'}`}>
                        <Clock size={10} />
                        {new Date(c.expiresAt).toLocaleDateString('ar')}
                        {isExpired && <span className="text-[9px] bg-red-500/10 px-1.5 py-0.5 rounded-full text-red-400">منتهي</span>}
                        {isAlmostExpired && <span className="text-[9px] bg-orange-500/10 px-1.5 py-0.5 rounded-full text-orange-400">قريب</span>}
                      </div>
                    ) : <span className="text-gray-600">بدون انتهاء</span>}
                  </td>
                  <td className="p-3">
                    <button onClick={() => toggleActive(c)} className="flex items-center gap-1.5 transition-all" title={c.isActive ? 'تعطيل' : 'تفعيل'}>
                      {c.isActive ? (
                        <ToggleRight size={24} className="text-[#2ECC71]" />
                      ) : (
                        <ToggleLeft size={24} className="text-gray-600" />
                      )}
                    </button>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(c)} className="p-1.5 hover:bg-[#2A3040] rounded-lg transition-colors" title="تعديل">
                        <Edit2 size={14} className="text-blue-400" />
                      </button>
                      <button onClick={() => del(c.id)} className="p-1.5 hover:bg-red-500/10 rounded-lg transition-colors" title="حذف">
                        <Trash2 size={14} className="text-red-400" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filteredCoupons.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <Tag size={40} className="mx-auto mb-3 opacity-20" />
            <p className="text-sm font-medium">لا توجد كوبونات</p>
            <p className="text-xs mt-1 text-gray-600">أنشئ كوبون جديد للبدء</p>
          </div>
        )}
      </div>

      {/* Create/Edit Modal */}
      {modal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setModal(false)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-md border border-[#2A3040] animate-fadeIn max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-bold mb-5 text-lg flex items-center gap-2">
              <Tag size={18} className="text-[#FFD700]" />
              {editId ? 'تعديل' : 'إنشاء'} كوبون
            </h3>
            <div className="space-y-4">
              {/* Code */}
              <div>
                <label className="text-gray-400 text-xs mb-1.5 block font-medium">كود الكوبون</label>
                <div className="relative">
                  <input placeholder="مثال: WELCOME2024" value={form.code} onChange={e => setForm({ ...form, code: e.target.value.toUpperCase() })}
                    className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors font-mono tracking-wider"
                    dir="ltr" disabled={!!editId} />
                  {!editId && (
                    <button type="button" onClick={() => setForm({...form, code: Math.random().toString(36).substring(2, 8).toUpperCase()})}
                      className="absolute left-2 top-1/2 -translate-y-1/2 px-2 py-1 text-[10px] text-[#FFD700] bg-[#FFD700]/10 rounded-lg hover:bg-[#FFD700]/20 transition-colors">
                      عشوائي
                    </button>
                  )}
                </div>
              </div>

              {/* Type Selector */}
              <div>
                <label className="text-gray-400 text-xs mb-1.5 block font-medium">نوع الخصم</label>
                <div className="grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => setForm({ ...form, type: 'percentage' })}
                    className={`flex items-center justify-center gap-2 px-3 py-3 rounded-xl text-sm font-medium border transition-all ${form.type === 'percentage' ? 'bg-purple-500/10 border-purple-500/40 text-purple-400' : 'bg-[#12161F] border-[#2A3040] text-gray-400 hover:border-gray-500'}`}>
                    <Percent size={16} />
                    <div className="text-right">
                      <p className="text-xs">نسبة مئوية</p>
                      <p className="text-[10px] text-gray-500">% من المبلغ</p>
                    </div>
                  </button>
                  <button type="button" onClick={() => setForm({ ...form, type: 'fixed' })}
                    className={`flex items-center justify-center gap-2 px-3 py-3 rounded-xl text-sm font-medium border transition-all ${form.type === 'fixed' ? 'bg-blue-500/10 border-blue-500/40 text-blue-400' : 'bg-[#12161F] border-[#2A3040] text-gray-400 hover:border-gray-500'}`}>
                    <DollarSign size={16} />
                    <div className="text-right">
                      <p className="text-xs">مبلغ ثابت</p>
                      <p className="text-[10px] text-gray-500">$ من المبلغ</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Discount + Max Uses + Per User */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-gray-400 text-xs mb-1 block">
                    {form.type === 'fixed' ? 'الخصم ($)' : 'الخصم (%)'}
                  </label>
                  <input type="number" value={form.discount} onChange={e => setForm({ ...form, discount: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors"
                    dir="ltr" min={0} max={form.type === 'percentage' ? 100 : undefined} step={form.type === 'fixed' ? 1 : 0.1} />
                </div>
                <div>
                  <label className="text-gray-400 text-xs mb-1 block">الحد الأقصى</label>
                  <input type="number" value={form.maxUses} onChange={e => setForm({ ...form, maxUses: parseInt(e.target.value) || 0 })}
                    className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors"
                    dir="ltr" min={1} />
                </div>
                <div>
                  <label className="text-gray-400 text-xs mb-1 block">لكل مستخدم</label>
                  <input type="number" value={form.maxUsesPerUser} onChange={e => setForm({ ...form, maxUsesPerUser: parseInt(e.target.value) || 0 })}
                    className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors"
                    dir="ltr" min={0} />
                  <p className="text-[9px] text-gray-600 mt-0.5">0 = بلا حد</p>
                </div>
              </div>

              {/* Min Investment */}
              <div>
                <label className="text-gray-400 text-xs mb-1 block">الحد الأدنى للاستثمار لاستخدام الكوبون ($)</label>
                <input type="number" value={form.minInvestment} onChange={e => setForm({ ...form, minInvestment: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors"
                  dir="ltr" min={0} />
                <p className="text-[10px] text-gray-600 mt-0.5">0 = بدون حد أدنى</p>
              </div>

              {/* Preview */}
              {form.discount > 0 && (
                <div className="bg-[#0D1117] rounded-xl p-3.5 border border-[#2A3040]/50">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp size={13} className="text-[#FFD700]" />
                    <span className="text-xs font-bold text-[#FFD700]">معاينة الخصم</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    {[
                      { label: 'استثمار $500', value: form.type === 'fixed' ? Math.max(0, 500 - form.discount) : (500 - (500 * form.discount / 100)) },
                      { label: 'استثمار $1,000', value: form.type === 'fixed' ? Math.max(0, 1000 - form.discount) : (1000 - (1000 * form.discount / 100)) },
                      { label: 'استثمار $5,000', value: form.type === 'fixed' ? Math.max(0, 5000 - form.discount) : (5000 - (5000 * form.discount / 100)) },
                    ].map((item, i) => (
                      <div key={i} className="bg-[#1A1F2E] rounded-lg p-2 text-center">
                        <p className="text-[9px] text-gray-500 mb-0.5">{item.label}</p>
                        <p className="text-xs font-bold text-[#2ECC71]">${Math.round(item.value * 100) / 100}</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-gray-500">
                    <span>حد لكل مستخدم: <b className="text-white">{form.maxUsesPerUser > 0 ? form.maxUsesPerUser + ' مرة' : 'بلا حد'}</b></span>
                    <span>|</span>
                    <span>إجمالي: <b className="text-white">{form.maxUses}</b></span>
                    {form.minInvestment > 0 && <><span>|</span><span>حد أدنى: <b className="text-white">${form.minInvestment}</b></span></>}
                  </div>
                </div>
              )}

              {/* Expires At */}
              <div>
                <label className="text-gray-400 text-xs mb-1 block">تاريخ الانتهاء (اختياري)</label>
                <input type="date" value={form.expiresAt} onChange={e => setForm({ ...form, expiresAt: e.target.value })}
                  className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-3 py-2 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors" />
              </div>

              {/* Active */}
              <label className="flex items-center gap-2.5 text-sm text-gray-300 cursor-pointer p-2.5 rounded-xl bg-[#12161F] border border-[#2A3040] hover:border-[#2A3040] transition-all">
                <input type="checkbox" checked={form.isActive} onChange={e => setForm({ ...form, isActive: e.target.checked })} className="accent-[#2ECC71] w-4 h-4" />
                <CheckCircle size={16} className={form.isActive ? 'text-[#2ECC71]' : 'text-gray-600'} />
                <span>كوبون نشط</span>
              </label>

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                <button onClick={save} className="flex-1 bg-gradient-to-l from-[#2ECC71] to-[#27AE60] text-white py-2.5 rounded-xl text-sm font-bold hover:shadow-lg hover:shadow-[#2ECC71]/20 transition-all">
                  {editId ? 'تحديث' : 'إنشاء'}
                </button>
                <button onClick={() => setModal(false)} className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm font-medium hover:bg-[#2A3040]/80 transition-colors">
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
