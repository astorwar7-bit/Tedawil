'use client';
import { useEffect, useState } from 'react';
import { Search, Ban, CheckCircle, Trash2, Eye, DollarSign, User, Mail, Phone, Calendar } from 'lucide-react';
import { useToast } from '@/contexts/ToastContext';

interface UserRow { id: string; username: string; fullName: string; email: string; phone: string; balance: number; isActive: boolean; createdAt: string; }

const avatarColors = ['#FFD700','#2ECC71','#3498DB','#E74C3C','#9B59B6','#E67E22','#1ABC9C','#F39C12'];
function getAvatarColor(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return avatarColors[Math.abs(hash) % avatarColors.length];
}
function getInitials(name: string) {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) return parts[0][0] + parts[1][0];
  return parts[0].substring(0, 2);
}
function formatDate(dateStr: string) {
  try { return new Date(dateStr).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric' }); } catch { return dateStr; }
}

export default function AdminUsersPage() {
  const { showToast } = useToast();
  const [users, setUsers] = useState<UserRow[]>([]);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [balanceModal, setBalanceModal] = useState<string | null>(null);
  const [balanceForm, setBalanceForm] = useState({ amount: '', reason: '' });
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const fetchUsers = () => {
    fetch(`/api/admin/users?page=${page}&limit=10&search=${search}`).then(r => r.json()).then(d => { setUsers(d.users || []); setTotal(d.total || 0); });
  };

  useEffect(() => { fetchUsers(); }, [page, search]);

  const toggleActive = async (userId: string) => {
    await fetch('/api/admin/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, action: 'toggleActive' }) });
    showToast('تم تحديث حالة الحساب');
    fetchUsers();
  };

  const updateBalance = async () => {
    if (!balanceModal || !balanceForm.amount || !balanceForm.reason) { showToast('يرجى إدخال جميع البيانات', 'error'); return; }
    await fetch('/api/admin/users', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: balanceModal, action: 'updateBalance', balance: parseFloat(balanceForm.amount), reason: balanceForm.reason }) });
    showToast('تم تحديث الرصيد');
    setBalanceModal(null); setBalanceForm({ amount: '', reason: '' }); fetchUsers();
  };

  const deleteUser = async (userId: string) => {
    await fetch(`/api/admin/users?userId=${userId}`, { method: 'DELETE' });
    showToast('تم حذف المستخدم');
    setConfirmDelete(null); fetchUsers();
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">إدارة المستخدمين</h1>
        <span className="text-sm text-gray-500">{total} مستخدم</span>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
        <input placeholder="بحث بالاسم، الإيميل، الهاتف..." value={search} onChange={e => { setSearch(e.target.value); setPage(1); }} className="input-premium w-full !pr-10 !pl-4 h-11 text-sm" />
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {users.map(u => {
          const color = getAvatarColor(u.fullName);
          const initials = getInitials(u.fullName);
          return (
            <div key={u.id} className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] p-4 hover:border-[#3A4050] transition-colors">
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div className="w-11 h-11 rounded-xl flex items-center justify-center text-sm font-bold shrink-0" style={{ background: `${color}15`, color: color, border: `1px solid ${color}25` }}>
                  {initials}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white font-semibold text-sm truncate">{u.fullName}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium shrink-0 ${u.isActive ? 'bg-[#2ECC71]/10 text-[#2ECC71]' : 'bg-red-500/10 text-red-400'}`}>
                      {u.isActive ? 'نشط' : 'موقوف'}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs">
                      <User size={12} className="text-gray-600 shrink-0" />
                      <span className="text-gray-400 truncate">@{u.username}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <Mail size={12} className="text-gray-600 shrink-0" />
                      <span className="text-gray-500 truncate">{u.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <Phone size={12} className="text-gray-600 shrink-0" />
                      <span className="text-gray-500" dir="ltr">{u.phone || '-'}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <Calendar size={12} className="text-gray-600 shrink-0" />
                      <span className="text-gray-500">{formatDate(u.createdAt)}</span>
                    </div>
                  </div>
                </div>

                {/* Balance + Actions */}
                <div className="flex flex-col items-end gap-2 shrink-0">
                  <div className="text-[#FFD700] font-bold text-sm">${u.balance.toFixed(2)}</div>
                  <div className="flex gap-1">
                    <a href={`/admin/users/${u.id}`} className="p-1.5 hover:bg-[#2A3040] rounded-lg transition-colors" title="عرض التفاصيل"><Eye size={14} className="text-blue-400" /></a>
                    <button onClick={() => setBalanceModal(u.id)} className="p-1.5 hover:bg-[#2A3040] rounded-lg transition-colors" title="تعديل الرصيد"><DollarSign size={14} className="text-[#FFD700]" /></button>
                    <button onClick={() => toggleActive(u.id)} className="p-1.5 hover:bg-[#2A3040] rounded-lg transition-colors" title={u.isActive ? 'إيقاف' : 'تفعيل'}>{u.isActive ? <Ban size={14} className="text-red-400" /> : <CheckCircle size={14} className="text-[#2ECC71]" />}</button>
                    <button onClick={() => setConfirmDelete(u.id)} className="p-1.5 hover:bg-[#2A3040] rounded-lg transition-colors" title="حذف"><Trash2 size={14} className="text-red-400" /></button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {users.length === 0 && (
        <div className="text-center py-12 text-gray-500">لا يوجد مستخدمين</div>
      )}

      {total > 10 && (
        <div className="flex justify-center gap-2">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 hover:border-[#3A4050] disabled:opacity-40">السابق</button>
          <span className="px-4 py-2 text-gray-400 text-xs flex items-center">صفحة {page} من {Math.ceil(total / 10)}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(total / 10)} className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 hover:border-[#3A4050] disabled:opacity-40">التالي</button>
        </div>
      )}

      {/* Balance Modal */}
      {balanceModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setBalanceModal(null)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-sm border border-[#2A3040]" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-bold mb-4">تعديل الرصيد</h3>
            <div className="space-y-3">
              <input type="number" placeholder="المبلغ (موجب للإضافة، سالب للخصم)" value={balanceForm.amount} onChange={e => setBalanceForm({...balanceForm, amount: e.target.value})} className="input-premium w-full h-11 text-sm" dir="ltr" />
              <input placeholder="السبب" value={balanceForm.reason} onChange={e => setBalanceForm({...balanceForm, reason: e.target.value})} className="input-premium w-full h-11 text-sm" />
              <div className="flex gap-2 pt-1">
                <button onClick={updateBalance} className="flex-1 bg-[#2ECC71] text-white py-2.5 rounded-xl text-sm font-bold hover:opacity-90 transition-opacity">تأكيد</button>
                <button onClick={() => setBalanceModal(null)} className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm hover:bg-[#3A4050] transition-colors">إلغاء</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {confirmDelete && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setConfirmDelete(null)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-sm border border-[#2A3040]" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-bold mb-2">تأكيد الحذف</h3>
            <p className="text-gray-400 text-sm mb-4">سيتم حذف المستخدم وجميع بياناته نهائياً. هذا الإجراء لا يمكن التراجع عنه.</p>
            <div className="flex gap-2">
              <button onClick={() => deleteUser(confirmDelete)} className="flex-1 bg-red-500 text-white py-2.5 rounded-xl text-sm font-bold hover:opacity-90 transition-opacity">حذف</button>
              <button onClick={() => setConfirmDelete(null)} className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm hover:bg-[#3A4050] transition-colors">إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
