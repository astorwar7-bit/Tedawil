'use client';
import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';

export default function AdminUserDetail() {
  const { id } = useParams();
  const [data, setData] = useState<Record<string, unknown> | null>(null);

  useEffect(() => {
    if (id) fetch(`/api/admin/users/${id}`).then(r => r.json()).then(setData);
  }, [id]);

  if (!data) return <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>;
  const u = data.user as Record<string, unknown>;
  const investments = (data.investments || []) as Record<string, unknown>[];
  const profits = (data.profits || []) as Record<string, unknown>[];
  const withdrawals = (data.withdrawals || []) as Record<string, unknown>[];

  return (
    <div className="space-y-4 animate-fadeIn">
      <a href="/admin/users" className="text-[#FFD700] text-sm hover:underline">← العودة للمستخدمين</a>
      <h1 className="text-2xl font-bold text-white">تفاصيل المستخدم</h1>
      <div className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040] grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
        {Object.entries({ 'اسم المستخدم': u.username, 'الاسم': u.fullName, 'الإيميل': u.email, 'الهاتف': u.phone, 'الرصيد': `$${Number(u.balance || 0).toFixed(2)}`, 'الحالة': u.isActive ? 'نشط' : 'موقوف', 'تاريخ التسجيل': new Date(u.createdAt as string).toLocaleDateString('ar') }).map(([k, v]) => (
          <div key={k}><span className="text-gray-400 block text-xs">{k}</span><span className="text-white font-medium">{String(v || '-')}</span></div>
        ))}
      </div>
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] p-4"><h3 className="text-white font-medium mb-2">الاستثمارات ({investments.length})</h3>
        {investments.length === 0 ? <p className="text-gray-500 text-sm">لا توجد</p> : investments.map((inv, i) => <div key={i} className="text-xs text-gray-300 py-1">${Number(inv.amount).toFixed(2)} - {inv.dailyRate}% - {new Date(inv.startDate as string).toLocaleDateString('ar')}</div>)}
      </div>
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] p-4"><h3 className="text-white font-medium mb-2">الأرباح ({profits.length})</h3>
        {profits.length === 0 ? <p className="text-gray-500 text-sm">لا توجد</p> : profits.slice(0, 20).map((p, i) => <div key={i} className="text-xs text-gray-300 py-0.5">${Number(p.amount).toFixed(2)} - {String(p.type)} - {new Date(p.date as string).toLocaleDateString('ar')}</div>)}
      </div>
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] p-4"><h3 className="text-white font-medium mb-2">السحوبات ({withdrawals.length})</h3>
        {withdrawals.length === 0 ? <p className="text-gray-500 text-sm">لا توجد</p> : withdrawals.map((w, i) => <div key={i} className="text-xs text-gray-300 py-0.5">${Number(w.amount).toFixed(2)} - {String(w.status)} - {new Date(w.createdAt as string).toLocaleDateString('ar')}</div>)}
      </div>
    </div>
  );
}
