'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { CheckSquare, Square, Loader2, AlertTriangle } from 'lucide-react';

interface WithdrawalRow { id: string; amount: number; walletAddress: string; status: string; rejectReason: string; createdAt: string; user: { username: string; fullName: string }; }

export default function AdminWithdrawalsPage() {
  const { showToast } = useToast();
  const [tab, setTab] = useState('pending');
  const [withdrawals, setWithdrawals] = useState<WithdrawalRow[]>([]);
  const [rejectModal, setRejectModal] = useState<string | null>(null);
  const [bulkRejectModal, setBulkRejectModal] = useState(false);
  const [reason, setReason] = useState('');
  const [bulkReason, setBulkReason] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkLoading, setBulkLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    fetch(`/api/admin/withdrawals?status=${tab === 'all' ? '' : tab}`).then(r => r.json()).then(d => setWithdrawals(d.withdrawals || []));
    setSelectedIds(new Set());
  }, [tab]);

  const handleAction = async (id: string, action: string, rejectReason?: string) => {
    setActionLoading(id);
    await fetch('/api/admin/withdrawals', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ withdrawalId: id, action, rejectReason }) });
    showToast(action === 'approve' ? 'تم الموافقة' : 'تم الرفض');
    setRejectModal(null); setReason('');
    fetch(`/api/admin/withdrawals?status=${tab === 'all' ? '' : tab}`).then(r => r.json()).then(d => setWithdrawals(d.withdrawals || []));
    setActionLoading(null);
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    const pendingIds = withdrawals.filter(w => w.status === 'pending').map(w => w.id);
    if (selectedIds.size === pendingIds.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(pendingIds));
    }
  };

  const pendingCount = withdrawals.filter(w => w.status === 'pending').length;
  const allPendingSelected = pendingCount > 0 && selectedIds.size === pendingCount;

  const handleBulkApprove = async () => {
    if (selectedIds.size === 0) return;
    setBulkLoading(true);
    try {
      const res = await fetch('/api/admin/withdrawals/bulk', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ withdrawalIds: Array.from(selectedIds), action: 'approve' }),
      });
      const data = await res.json();
      if (res.ok) {
        showToast(data.message || 'تمت الموافقة الجماعية', 'success');
        setSelectedIds(new Set());
        fetch(`/api/admin/withdrawals?status=${tab === 'all' ? '' : tab}`).then(r => r.json()).then(d => setWithdrawals(d.withdrawals || []));
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء المعالجة', 'error');
    }
    setBulkLoading(false);
  };

  const handleBulkReject = async () => {
    if (selectedIds.size === 0 || !bulkReason) return;
    setBulkLoading(true);
    try {
      const res = await fetch('/api/admin/withdrawals/bulk', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ withdrawalIds: Array.from(selectedIds), action: 'reject', rejectReason: bulkReason }),
      });
      const data = await res.json();
      if (res.ok) {
        showToast(data.message || 'تم الرفض الجماعي', 'success');
        setSelectedIds(new Set());
        setBulkRejectModal(false);
        setBulkReason('');
        fetch(`/api/admin/withdrawals?status=${tab === 'all' ? '' : tab}`).then(r => r.json()).then(d => setWithdrawals(d.withdrawals || []));
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ أثناء المعالجة', 'error');
    }
    setBulkLoading(false);
  };

  const statusBadge = (s: string) => {
    const m: Record<string, string> = { pending: 'bg-yellow-500/10 text-yellow-400', approved: 'bg-[#2ECC71]/10 text-[#2ECC71]', rejected: 'bg-red-500/10 text-red-400' };
    const l: Record<string, string> = { pending: 'معلق', approved: 'موافق', rejected: 'مرفوض' };
    return <span className={`px-3 py-1 rounded-full text-xs font-medium ${m[s]}`}>{l[s]}</span>;
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <h1 className="text-2xl font-bold text-white">طلبات السحب</h1>

      {/* Bulk action bar */}
      {tab === 'pending' && selectedIds.size > 0 && (
        <div className="bg-[#FFD700]/5 border border-[#FFD700]/20 rounded-xl p-3 flex items-center justify-between animate-fadeIn">
          <span className="text-[#FFD700] text-sm font-medium">
            تم تحديد {selectedIds.size} طلب
          </span>
          <div className="flex gap-2">
            <button
              onClick={handleBulkApprove}
              disabled={bulkLoading}
              className="px-4 py-2 bg-[#2ECC71] text-white rounded-xl text-xs font-bold hover:bg-[#2ECC71]/80 transition-colors disabled:opacity-50 flex items-center gap-1"
            >
              {bulkLoading ? <Loader2 size={14} className="animate-spin" /> : null}
              موافقة جماعية
            </button>
            <button
              onClick={() => setBulkRejectModal(true)}
              disabled={bulkLoading}
              className="px-4 py-2 bg-[#EF4444] text-white rounded-xl text-xs font-bold hover:bg-[#EF4444]/80 transition-colors disabled:opacity-50 flex items-center gap-1"
            >
              {bulkLoading ? <Loader2 size={14} className="animate-spin" /> : null}
              رفض جماعي
            </button>
          </div>
        </div>
      )}

      <div className="flex gap-2">
        {['pending', 'approved', 'rejected'].map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-xl text-xs font-medium ${tab === t ? 'bg-[#FFD700] text-[#0A0F0D]' : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040]'}`}>
            {t === 'pending' ? 'معلقة' : t === 'approved' ? 'موافق عليها' : 'مرفوضة'}
          </button>
        ))}
      </div>
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-[#2A3040]">
            {tab === 'pending' && (
              <th className="p-3 w-10">
                <button onClick={toggleSelectAll} className="text-gray-400 hover:text-[#FFD700] transition-colors">
                  {allPendingSelected ? <CheckSquare size={16} className="text-[#FFD700]" /> : <Square size={16} />}
                </button>
              </th>
            )}
            <th className="text-right p-3 text-gray-400">المستخدم</th><th className="text-right p-3 text-gray-400">المبلغ</th><th className="text-right p-3 text-gray-400">المحفظة</th><th className="text-right p-3 text-gray-400">التاريخ</th><th className="text-right p-3 text-gray-400">الحالة</th><th className="text-right p-3 text-gray-400">إجراءات</th>
          </tr></thead>
          <tbody>
            {withdrawals.length === 0 ? <tr><td colSpan={7} className="text-center py-8 text-gray-500">لا توجد طلبات</td></tr> :
            withdrawals.map(w => (
              <tr key={w.id} className={`border-b border-[#2A3040]/50 ${selectedIds.has(w.id) ? 'bg-[#FFD700]/5' : ''}`}>
                {tab === 'pending' && (
                  <td className="p-3">
                    {w.status === 'pending' ? (
                      <button onClick={() => toggleSelect(w.id)} className="text-gray-400 hover:text-[#FFD700] transition-colors">
                        {selectedIds.has(w.id) ? <CheckSquare size={16} className="text-[#FFD700]" /> : <Square size={16} />}
                      </button>
                    ) : null}
                  </td>
                )}
                <td className="p-3 text-white text-xs">{w.user?.fullName || w.user?.username}</td>
                <td className="p-3 text-[#FFD700] font-medium">${w.amount.toFixed(2)}</td>
                <td className="p-3 text-gray-400 text-xs max-w-[100px] truncate">{w.walletAddress}</td>
                <td className="p-3 text-gray-300 text-xs">{new Date(w.createdAt).toLocaleDateString('ar')}</td>
                <td className="p-3">{statusBadge(w.status)}</td>
                <td className="p-3">
                  {w.status === 'pending' && (
                    <div className="flex gap-1">
                      <button onClick={() => handleAction(w.id, 'approve')} disabled={actionLoading === w.id} className="px-3 py-1 bg-[#2ECC71]/10 text-[#2ECC71] rounded-lg text-xs hover:bg-[#2ECC71]/20 disabled:opacity-50">
                        {actionLoading === w.id ? <Loader2 size={12} className="animate-spin" /> : 'موافقة'}
                      </button>
                      <button onClick={() => setRejectModal(w.id)} className="px-3 py-1 bg-red-500/10 text-red-400 rounded-lg text-xs hover:bg-red-500/20">رفض</button>
                    </div>
                  )}
                  {w.rejectReason && <p className="text-red-400 text-xs mt-1">{w.rejectReason}</p>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Single Reject Modal */}
      {rejectModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setRejectModal(null)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-sm border border-[#2A3040]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#EF4444]/10 flex items-center justify-center">
                <AlertTriangle size={18} className="text-[#EF4444]" />
              </div>
              <h3 className="text-white font-bold text-sm">سبب الرفض</h3>
            </div>
            <textarea placeholder="أدخل سبب الرفض..." value={reason} onChange={e => setReason(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none h-24 resize-none" />
            <div className="flex gap-2 mt-3">
              <button onClick={() => handleAction(rejectModal, 'reject', reason)} className="flex-1 bg-red-500 text-white py-2.5 rounded-xl text-sm font-bold">تأكيد الرفض</button>
              <button onClick={() => setRejectModal(null)} className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Reject Modal */}
      {bulkRejectModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setBulkRejectModal(false)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-sm border border-[#2A3040]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-[#EF4444]/10 flex items-center justify-center">
                <AlertTriangle size={18} className="text-[#EF4444]" />
              </div>
              <div>
                <h3 className="text-white font-bold text-sm">رفض جماعي</h3>
                <p className="text-gray-400 text-xs mt-0.5">رفض {selectedIds.size} طلب سحب</p>
              </div>
            </div>
            <textarea placeholder="أدخل سبب الرفض..." value={bulkReason} onChange={e => setBulkReason(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none h-24 resize-none" />
            <div className="flex gap-2 mt-3">
              <button onClick={handleBulkReject} disabled={!bulkReason || bulkLoading} className="flex-1 bg-red-500 text-white py-2.5 rounded-xl text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2">
                {bulkLoading ? <Loader2 size={14} className="animate-spin" /> : null}
                تأكيد الرفض الجماعي
              </button>
              <button onClick={() => { setBulkRejectModal(false); setBulkReason(''); }} className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
