'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import {
  Bot,
  Plus,
  Edit3,
  Trash2,
  ToggleLeft,
  ToggleRight,
  Shield,
  AlertTriangle,
  TrendingUp,
  Search,
  RefreshCw,
  Users,
  Zap,
  Save,
  X,
  ChevronDown,
} from 'lucide-react';

// ──────────────────────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────────────────────
interface TradingBot {
  id: string;
  name: string;
  description: string;
  strategy: string;
  dailyReturn: number;
  riskLevel: string;
  minBalance: number;
  icon: string;
  color: string;
  isActive: boolean;
  sortOrder: number;
  subscribers: number;
  activeSubscribers: number;
}

// ──────────────────────────────────────────────────────────────
// Constants
// ──────────────────────────────────────────────────────────────
const RISK_LEVELS = ['منخفض', 'متوسط', 'عالي', 'عالي جداً'];

const RISK_COLORS: Record<string, { bg: string; text: string; border: string; icon: string }> = {
  'منخفض': { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/30', icon: 'text-emerald-400' },
  'متوسط': { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/30', icon: 'text-amber-400' },
  'عالي': { bg: 'bg-orange-500/10', text: 'text-orange-400', border: 'border-orange-500/30', icon: 'text-orange-400' },
  'عالي جداً': { bg: 'bg-red-500/10', text: 'text-red-400', border: 'border-red-500/30', icon: 'text-red-400' },
};

const ICON_OPTIONS = [
  'Bot', 'Zap', 'TrendingUp', 'Shield', 'Brain', 'Cpu',
  'BarChart3', 'Rocket', 'Target', 'Sparkles',
];

const COLOR_OPTIONS = [
  '#FFD700', '#2ECC71', '#3B82F6', '#8B5CF6', '#EC4899',
  '#F97316', '#06B6D4', '#EF4444', '#10B981', '#6366F1',
];

const emptyBot: Omit<TradingBot, 'id' | 'subscribers' | 'activeSubscribers'> = {
  name: '',
  description: '',
  strategy: '',
  dailyReturn: 0,
  riskLevel: 'متوسط',
  minBalance: 0,
  icon: 'Bot',
  color: '#FFD700',
  isActive: true,
  sortOrder: 0,
};

// ──────────────────────────────────────────────────────────────
// Icon renderer helper
// ──────────────────────────────────────────────────────────────
function renderIcon(name: string, size = 20, className = '') {
  const props = { size, className };
  switch (name) {
    case 'Bot': return <Bot {...props} />;
    case 'Zap': return <Zap {...props} />;
    case 'TrendingUp': return <TrendingUp {...props} />;
    case 'Shield': return <Shield {...props} />;
    case 'AlertTriangle': return <AlertTriangle {...props} />;
    case 'Users': return <Users {...props} />;
    default: return <Bot {...props} />;
  }
}

// ──────────────────────────────────────────────────────────────
// Component
// ──────────────────────────────────────────────────────────────
export default function AdminTradingBotsPage() {
  const { showToast } = useToast();

  // ── State ───────────────────────────────────────────────────
  const [bots, setBots] = useState<TradingBot[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingBot, setEditingBot] = useState<TradingBot | null>(null);
  const [form, setForm] = useState(emptyBot);
  const [deleteConfirm, setDeleteConfirm] = useState<TradingBot | null>(null);

  // ── Fetch bots ──────────────────────────────────────────────
  const fetchBots = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/admin/trading-bots');
      const data = await res.json();
      if (res.ok) {
        setBots(data.bots || []);
      } else {
        showToast(data.error || 'حدث خطأ أثناء جلب البوتات', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBots();
  }, []);

  // ── Search filter ───────────────────────────────────────────
  const filteredBots = bots.filter(
    (bot) =>
      bot.name.includes(searchQuery) ||
      bot.description.includes(searchQuery) ||
      bot.strategy.includes(searchQuery)
  );

  // ── Stats ───────────────────────────────────────────────────
  const totalBots = bots.length;
  const activeBots = bots.filter((b) => b.isActive).length;
  const totalSubscribers = bots.reduce((sum, b) => sum + b.subscribers, 0);
  const avgReturn =
    bots.length > 0
      ? (bots.reduce((sum, b) => sum + b.dailyReturn, 0) / bots.length).toFixed(1)
      : '0.0';

  // ── Open create form ───────────────────────────────────────
  const openCreateForm = () => {
    setForm(emptyBot);
    setEditingBot(null);
    setShowForm(true);
  };

  // ── Open edit form ──────────────────────────────────────────
  const openEditForm = (bot: TradingBot) => {
    setForm({
      name: bot.name,
      description: bot.description,
      strategy: bot.strategy,
      dailyReturn: bot.dailyReturn,
      riskLevel: bot.riskLevel,
      minBalance: bot.minBalance,
      icon: bot.icon,
      color: bot.color,
      isActive: bot.isActive,
      sortOrder: bot.sortOrder,
    });
    setEditingBot(bot);
    setShowForm(true);
  };

  // ── Handle save (create or update) ──────────────────────────
  const handleSave = async () => {
    if (!form.name.trim()) {
      showToast('اسم البوت مطلوب', 'error');
      return;
    }
    if (!form.strategy.trim()) {
      showToast('اسم الاستراتيجية مطلوب', 'error');
      return;
    }
    if (form.dailyReturn < 0 || form.dailyReturn > 100) {
      showToast('العائد اليومي يجب أن يكون بين 0 و 100', 'error');
      return;
    }
    if (form.minBalance < 0) {
      showToast('الحد الأدنى للرصيد يجب أن يكون صفر أو أكثر', 'error');
      return;
    }

    try {
      setSaving(true);
      const isEditing = !!editingBot;
      const url = isEditing
        ? `/api/admin/trading-bots/${editingBot.id}`
        : '/api/admin/trading-bots';
      const method = isEditing ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'حدث خطأ أثناء الحفظ', 'error');
        return;
      }

      showToast(data.message || (isEditing ? 'تم تحديث البوت بنجاح' : 'تم إنشاء البوت بنجاح'));
      setShowForm(false);
      setEditingBot(null);
      setForm(emptyBot);
      fetchBots();
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
    } finally {
      setSaving(false);
    }
  };

  // ── Toggle bot status ───────────────────────────────────────
  const toggleBotStatus = async (bot: TradingBot) => {
    try {
      const res = await fetch(`/api/admin/trading-bots/${bot.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !bot.isActive }),
      });
      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'حدث خطأ', 'error');
        return;
      }

      showToast(data.message || (bot.isActive ? 'تم تعطيل البوت' : 'تم تفعيل البوت'));
      fetchBots();
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
    }
  };

  // ── Delete bot ──────────────────────────────────────────────
  const deleteBot = async () => {
    if (!deleteConfirm) return;
    try {
      const res = await fetch(`/api/admin/trading-bots/${deleteConfirm.id}`, {
        method: 'DELETE',
      });
      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'حدث خطأ أثناء الحذف', 'error');
        setDeleteConfirm(null);
        return;
      }

      showToast(data.message || 'تم حذف البوت بنجاح');
      setDeleteConfirm(null);
      fetchBots();
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
      setDeleteConfirm(null);
    }
  };

  // ────────────────────────────────────────────────────────────
  // Render
  // ────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* ── Header ───────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center">
            <Bot size={20} className="text-[#FFD700]" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">إدارة بوتات التداول</h1>
            <p className="text-gray-400 text-xs mt-0.5">{bots.length} بوت تداول</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={fetchBots}
            className="p-2.5 rounded-xl text-gray-400 hover:text-white hover:bg-[#1A1F2E] transition-all border border-[#2A3040]"
            title="تحديث القائمة"
          >
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={openCreateForm}
            className="btn-premium-gold px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2"
          >
            <Plus size={16} />
            إضافة بوت جديد
          </button>
        </div>
      </div>

      {/* ── Stats Cards ──────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Bots */}
        <div className="glass-card rounded-2xl p-4 sm:p-5 card-lift">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 flex items-center justify-center">
              <Bot size={18} className="text-[#FFD700]" />
            </div>
            <span className="text-[10px] text-gray-500 font-medium bg-[#12161F] px-2 py-1 rounded-full">
              إجمالي
            </span>
          </div>
          <p className="text-white text-2xl font-bold neon-gold">{totalBots}</p>
          <p className="text-gray-400 text-xs mt-1">إجمالي البوتات</p>
        </div>

        {/* Active Bots */}
        <div className="glass-card rounded-2xl p-4 sm:p-5 card-lift">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Zap size={18} className="text-emerald-400" />
            </div>
            <span className="text-[10px] text-gray-500 font-medium bg-[#12161F] px-2 py-1 rounded-full">
              نشط
            </span>
          </div>
          <p className="text-white text-2xl font-bold neon-emerald">{activeBots}</p>
          <p className="text-gray-400 text-xs mt-1">بوتات نشطة</p>
        </div>

        {/* Total Subscribers */}
        <div className="glass-card rounded-2xl p-4 sm:p-5 card-lift">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Users size={18} className="text-blue-400" />
            </div>
            <span className="text-[10px] text-gray-500 font-medium bg-[#12161F] px-2 py-1 rounded-full">
              مستخدمين
            </span>
          </div>
          <p className="text-white text-2xl font-bold" style={{ color: '#3B82F6' }}>
            {totalSubscribers.toLocaleString('ar-EG')}
          </p>
          <p className="text-gray-400 text-xs mt-1">إجمالي المشتركين</p>
        </div>

        {/* Average Daily Return */}
        <div className="glass-card rounded-2xl p-4 sm:p-5 card-lift">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <TrendingUp size={18} className="text-purple-400" />
            </div>
            <span className="text-[10px] text-gray-500 font-medium bg-[#12161F] px-2 py-1 rounded-full">
              متوسط
            </span>
          </div>
          <p className="text-white text-2xl font-bold" style={{ color: '#8B5CF6' }}>
            {avgReturn}%
          </p>
          <p className="text-gray-400 text-xs mt-1">متوسط العائد اليومي</p>
        </div>
      </div>

      {/* ── Search ───────────────────────────────────────────── */}
      <div className="relative">
        <Search
          size={16}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none"
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث بالاسم، الوصف أو الاستراتيجية..."
          className="input-premium w-full pr-10 pl-4"
          dir="rtl"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors"
          >
            <X size={14} />
          </button>
        )}
      </div>

      {/* ── Loading Skeleton ─────────────────────────────────── */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="skeleton-card rounded-2xl overflow-hidden">
              <div className="h-1.5 w-full bg-[#2A3040]" />
              <div className="p-5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[#2A3040] animate-pulse" />
                  <div className="space-y-2 flex-1">
                    <div className="h-4 bg-[#2A3040] rounded animate-pulse w-3/4" />
                    <div className="h-3 bg-[#2A3040] rounded animate-pulse w-1/2" />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="h-3 bg-[#2A3040] rounded animate-pulse" />
                  <div className="h-3 bg-[#2A3040] rounded animate-pulse w-2/3" />
                </div>
                <div className="flex gap-2">
                  <div className="h-3 bg-[#2A3040] rounded animate-pulse w-1/4" />
                  <div className="h-3 bg-[#2A3040] rounded animate-pulse w-1/4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── Empty State ──────────────────────────────────────── */}
      {!loading && bots.length === 0 && (
        <div className="glass-card rounded-2xl p-12 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#2A3040]/50 flex items-center justify-center">
            <Bot size={32} className="text-gray-500" />
          </div>
          <h3 className="text-white font-bold text-lg mb-2">لا توجد بوتات تداول</h3>
          <p className="text-gray-400 text-sm mb-6">ابدأ بإضافة أول بوت تداول للمنصة</p>
          <button
            onClick={openCreateForm}
            className="btn-premium-gold px-6 py-2.5 rounded-xl text-sm font-bold inline-flex items-center gap-2"
          >
            <Plus size={16} />
            إضافة بوت جديد
          </button>
        </div>
      )}

      {/* ── No Search Results ────────────────────────────────── */}
      {!loading && bots.length > 0 && filteredBots.length === 0 && (
        <div className="glass-card rounded-2xl p-12 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#2A3040]/50 flex items-center justify-center">
            <Search size={32} className="text-gray-500" />
          </div>
          <h3 className="text-white font-bold text-lg mb-2">لا توجد نتائج</h3>
          <p className="text-gray-400 text-sm">
            لا توجد بوتات تطابق &quot;{searchQuery}&quot;
          </p>
        </div>
      )}

      {/* ── Bots Grid ────────────────────────────────────────── */}
      {!loading && filteredBots.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredBots.map((bot) => {
            const risk = RISK_COLORS[bot.riskLevel] || RISK_COLORS['متوسط'];
            return (
              <div
                key={bot.id}
                className={`glass-card card-lift rounded-2xl overflow-hidden transition-all duration-300 ${
                  !bot.isActive ? 'opacity-60' : ''
                }`}
              >
                {/* Top Color Strip */}
                <div
                  className="h-1.5 w-full"
                  style={{
                    background: `linear-gradient(to left, ${bot.color}, ${bot.color}88)`,
                  }}
                />

                <div className="p-5">
                  {/* Bot Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center"
                        style={{
                          backgroundColor: `${bot.color}15`,
                          border: `1px solid ${bot.color}30`,
                          color: bot.color,
                        }}
                      >
                        {renderIcon(bot.icon, 22)}
                      </div>
                      <div>
                        <h3 className="text-white font-bold text-base">{bot.name}</h3>
                        <p className="text-gray-400 text-xs" style={{ color: bot.color }}>
                          {bot.strategy}
                        </p>
                      </div>
                    </div>

                    {/* Status Toggle */}
                    <button
                      onClick={() => toggleBotStatus(bot)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus:outline-none ${
                        bot.isActive ? 'bg-[#2ECC71]' : 'bg-[#2A3040]'
                      }`}
                      aria-label={bot.isActive ? 'تعطيل البوت' : 'تفعيل البوت'}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                          bot.isActive ? '-translate-x-6' : '-translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  {/* Bot Details */}
                  <div className="space-y-2.5 mb-4">
                    {/* Description */}
                    {bot.description && (
                      <p className="text-gray-500 text-xs leading-relaxed line-clamp-2">
                        {bot.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400 flex items-center gap-1.5">
                        <TrendingUp size={14} style={{ color: bot.color }} />
                        العائد اليومي
                      </span>
                      <span className="font-bold" style={{ color: bot.color }}>
                        {bot.dailyReturn}%
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400 flex items-center gap-1.5">
                        <Shield size={14} className={risk.icon} />
                        مستوى المخاطر
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${risk.bg} ${risk.text} border ${risk.border}`}
                      >
                        {bot.riskLevel}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400 flex items-center gap-1.5">
                        <span className="text-xs">$</span>
                        الحد الأدنى للرصيد
                      </span>
                      <span className="text-white font-medium">
                        ${bot.minBalance.toLocaleString('en-US')}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-400 flex items-center gap-1.5">
                        <Users size={14} className="text-[#FFD700]" />
                        المشتركين
                      </span>
                      <span className="text-white font-bold">
                        {bot.activeSubscribers}/{bot.subscribers}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 border-t border-[#2A3040] pt-3">
                    <button
                      onClick={() => openEditForm(bot)}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium text-[#FFD700] hover:bg-[#FFD700]/10 transition-all border border-[#FFD700]/20"
                    >
                      <Edit3 size={14} />
                      تعديل
                    </button>
                    <button
                      onClick={() => setDeleteConfirm(bot)}
                      className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 transition-all border border-red-500/20"
                    >
                      <Trash2 size={14} />
                      حذف
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ──────────────────────────────────────────────────────── */}
      {/* Create / Edit Modal                                     */}
      {/* ──────────────────────────────────────────────────────── */}
      {showForm && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowForm(false)}
          />

          {/* Modal Content */}
          <div
            className="relative w-full max-w-lg glass-card p-6 animate-fadeIn border border-[#2A3040] max-h-[90vh] overflow-y-auto scrollbar-thin"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-white font-bold text-lg flex items-center gap-2">
                <Bot size={20} className="text-[#FFD700]" />
                {editingBot ? 'تعديل بوت التداول' : 'إضافة بوت جديد'}
              </h3>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-[#1A1F2E]"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-4">
              {/* Bot Name */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">
                  اسم البوت <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="مثال: بوت التداول الذهبي"
                  className="input-premium w-full"
                  dir="rtl"
                />
              </div>

              {/* Description */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">
                  الوصف <span className="text-gray-600">(اختياري)</span>
                </label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="وصف مختصر عن البوت وأداءه..."
                  rows={2}
                  className="input-premium w-full resize-none"
                  dir="rtl"
                />
              </div>

              {/* Strategy */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">
                  الاستراتيجية <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={form.strategy}
                  onChange={(e) => setForm({ ...form, strategy: e.target.value })}
                  placeholder="مثال: تداول بالذكاء الاصطناعي"
                  className="input-premium w-full"
                  dir="rtl"
                />
              </div>

              {/* Daily Return & Min Balance */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">
                    العائد اليومي (%) <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={form.dailyReturn}
                    onChange={(e) =>
                      setForm({ ...form, dailyReturn: parseFloat(e.target.value) || 0 })
                    }
                    className="input-premium w-full"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">
                    الحد الأدنى للرصيد ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={form.minBalance}
                    onChange={(e) =>
                      setForm({ ...form, minBalance: parseFloat(e.target.value) || 0 })
                    }
                    className="input-premium w-full"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* Risk Level */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">
                  مستوى المخاطر
                </label>
                <div className="relative">
                  <select
                    value={form.riskLevel}
                    onChange={(e) => setForm({ ...form, riskLevel: e.target.value })}
                    className="input-premium w-full appearance-none cursor-pointer pr-4 pl-10"
                    dir="rtl"
                  >
                    {RISK_LEVELS.map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={16}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none"
                  />
                </div>
              </div>

              {/* Icon Selection */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">الأيقونة</label>
                <div className="flex flex-wrap gap-2">
                  {ICON_OPTIONS.map((iconName) => (
                    <button
                      key={iconName}
                      type="button"
                      onClick={() => setForm({ ...form, icon: iconName })}
                      className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                        form.icon === iconName
                          ? 'bg-[#FFD700]/20 border-2 border-[#FFD700] scale-110 text-[#FFD700]'
                          : 'bg-[#12161F] border border-[#2A3040] text-gray-400 hover:border-[#FFD700]/50'
                      }`}
                    >
                      {renderIcon(iconName, 18)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Selection */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">اللون</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {COLOR_OPTIONS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setForm({ ...form, color: c })}
                      className={`w-8 h-8 rounded-lg transition-all ${
                        form.color === c
                          ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1A1F2E] scale-110'
                          : ''
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={form.color}
                    onChange={(e) => setForm({ ...form, color: e.target.value })}
                    className="w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent"
                  />
                  <input
                    type="text"
                    value={form.color}
                    onChange={(e) => setForm({ ...form, color: e.target.value })}
                    placeholder="#FFD700"
                    className="input-premium flex-1"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* Sort Order & Active */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">
                    ترتيب العرض
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={form.sortOrder}
                    onChange={(e) =>
                      setForm({ ...form, sortOrder: parseInt(e.target.value) || 0 })
                    }
                    className="input-premium w-full"
                    dir="ltr"
                  />
                </div>
                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2.5 cursor-pointer py-2.5">
                    <span
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 ${
                        form.isActive ? 'bg-[#2ECC71]' : 'bg-[#2A3040]'
                      }`}
                      onClick={() => setForm({ ...form, isActive: !form.isActive })}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                          form.isActive ? '-translate-x-6' : '-translate-x-1'
                        }`}
                      />
                    </span>
                    <span className="text-gray-300 text-sm">نشط</span>
                  </label>
                </div>
              </div>

              {/* Monthly Return Preview */}
              <div className="bg-[#12161F] rounded-xl p-4 border border-[#2A3040]">
                <p className="text-gray-400 text-xs mb-3 font-medium">معاينة الأرباح المتوقعة</p>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-gray-500 text-[10px] mb-1">يومي (100$)</p>
                    <p className="text-white text-sm font-bold">
                      ${(100 * form.dailyReturn) / 100}$
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[10px] mb-1">شهري (100$)</p>
                    <p className="text-emerald-400 text-sm font-bold">
                      ${((100 * form.dailyReturn) / 100 * 30).toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[10px] mb-1">سنوي (100$)</p>
                    <p className="text-[#FFD700] text-sm font-bold">
                      ${((100 * form.dailyReturn) / 100 * 365).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="btn-premium-gold flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {saving ? (
                    <RefreshCw size={16} className="animate-spin" />
                  ) : editingBot ? (
                    <Save size={16} />
                  ) : (
                    <Plus size={16} />
                  )}
                  {saving
                    ? 'جاري الحفظ...'
                    : editingBot
                      ? 'حفظ التعديلات'
                      : 'إضافة البوت'}
                </button>
                <button
                  onClick={() => setShowForm(false)}
                  className="flex-1 py-3 rounded-xl text-sm font-medium text-gray-400 hover:text-white hover:bg-[#1A1F2E] transition-all border border-[#2A3040]"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ──────────────────────────────────────────────────────── */}
      {/* Delete Confirmation Dialog                              */}
      {/* ──────────────────────────────────────────────────────── */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center p-4">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setDeleteConfirm(null)}
          />

          {/* Dialog Content */}
          <div
            className="relative w-full max-w-sm glass-card p-6 animate-fadeIn border border-red-500/20"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Warning Icon */}
            <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-red-500/10 flex items-center justify-center">
              <AlertTriangle size={28} className="text-red-400" />
            </div>

            <h3 className="text-white font-bold text-lg text-center mb-2">حذف بوت التداول</h3>
            <p className="text-gray-400 text-sm text-center mb-6 leading-relaxed">
              هل أنت متأكد من حذف بوت &quot;
              <span className="text-white font-medium">{deleteConfirm.name}</span>
              &quot؛؟ لا يمكن التراجع عن هذا الإجراء.
            </p>

            <div className="flex gap-3">
              <button
                onClick={deleteBot}
                className="flex-1 py-2.5 rounded-xl text-sm font-bold bg-red-500 text-white hover:bg-red-600 transition-all flex items-center justify-center gap-2"
              >
                <Trash2 size={14} />
                نعم، حذف البوت
              </button>
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:text-white hover:bg-[#1A1F2E] transition-all border border-[#2A3040]"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
