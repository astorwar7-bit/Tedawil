'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Users, Search, Plus, Edit3, Trash2, X, User, DollarSign, TrendingUp, Check, Percent, Copy, Shield, Wallet, ArrowDownToLine, ArrowUpFromLine, AlertTriangle } from 'lucide-react';

interface Agent {
  id: string;
  username: string;
  email: string;
  fullName: string;
  balance: number;
  commissionRate: number;
  referralCode: string;
  createdAt: string;
  referredUsersCount: number;
  activeReferrals: number;
  totalCommissionEarned: number;
  totalDepositsFromReferrals: number;
}

export default function AdminAgentsPage() {
  const { showToast } = useToast();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ id: string; username: string; email: string; fullName: string }[]>([]);
  const [searching, setSearching] = useState(false);
  const [selectedUser, setSelectedUser] = useState<{ id: string; username: string; email: string } | null>(null);
  const [commissionRate, setCommissionRate] = useState('5');
  const [editRate, setEditRate] = useState('');
  const [saving, setSaving] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  // Balance modal state
  const [balanceModal, setBalanceModal] = useState(false);
  const [balanceAgent, setBalanceAgent] = useState<Agent | null>(null);
  const [balanceAction, setBalanceAction] = useState<'deposit' | 'withdraw'>('deposit');
  const [balanceAmount, setBalanceAmount] = useState('');
  const [balanceNote, setBalanceNote] = useState('');

  const fetchAgents = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/agents');
      const data = await res.json();
      if (res.ok) setAgents(data.agents || []);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchAgents(); }, []);

  const searchUsers = useCallback(async (query: string) => {
    if (query.length < 2) { setSearchResults([]); return; }
    setSearching(true);
    try {
      const res = await fetch(`/api/admin/users?search=${encodeURIComponent(query)}&limit=10`);
      const data = await res.json();
      if (res.ok) {
        setSearchResults((data.users || []).filter((u: { isAdmin: boolean; isAgent: boolean }) => !u.isAdmin && !u.isAgent));
      }
    } catch {}
    setSearching(false);
  }, []);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => searchUsers(searchQuery), 400);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [searchQuery, searchUsers]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setSearchResults([]);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleAddAgent = async () => {
    if (!selectedUser) { showToast('يرجى اختيار المستخدم', 'error'); return; }
    const rate = parseFloat(commissionRate);
    if (isNaN(rate) || rate < 0 || rate > 50) { showToast('نسبة العمولة غير صالحة', 'error'); return; }

    setSaving(true);
    try {
      const res = await fetch('/api/admin/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: selectedUser.id, commissionRate: rate }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error || 'حدث خطأ', 'error'); setSaving(false); return; }
      showToast(data.message);
      setShowAddModal(false);
      setSelectedUser(null);
      setSearchQuery('');
      setCommissionRate('5');
      fetchAgents();
    } catch { showToast('حدث خطأ', 'error'); }
    setSaving(false);
  };

  const handleUpdateRate = async (agentId: string) => {
    const rate = parseFloat(editRate);
    if (isNaN(rate) || rate < 0 || rate > 50) { showToast('نسبة العمولة غير صالحة', 'error'); return; }

    setSaving(true);
    try {
      const res = await fetch('/api/admin/agents', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId, commissionRate: rate }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error || 'حدث خطأ', 'error'); setSaving(false); return; }
      showToast(data.message);
      setEditingAgent(null);
      setEditRate('');
      fetchAgents();
    } catch { showToast('حدث خطأ', 'error'); }
    setSaving(false);
  };

  const handleDeactivate = async (agentId: string, username: string) => {
    if (!confirm(`هل أنت متأكد من إلغاء وكالة ${username}؟`)) return;
    setSaving(true);
    try {
      const res = await fetch('/api/admin/agents', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agentId, deactivate: true }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error || 'حدث خطأ', 'error'); setSaving(false); return; }
      showToast(data.message);
      fetchAgents();
    } catch { showToast('حدث خطأ', 'error'); }
    setSaving(false);
  };

  const openBalanceModal = (agent: Agent, action: 'deposit' | 'withdraw') => {
    setBalanceAgent(agent);
    setBalanceAction(action);
    setBalanceAmount('');
    setBalanceNote('');
    setBalanceModal(true);
  };

  const handleBalanceAction = async () => {
    if (!balanceAgent) return;
    const amount = parseFloat(balanceAmount);
    if (isNaN(amount) || amount <= 0) { showToast('يرجى إدخال مبلغ صالح', 'error'); return; }

    if (balanceAction === 'withdraw' && amount > balanceAgent.balance) {
      showToast(`رصيد الوكيل غير كافي (الرصيد: $${balanceAgent.balance.toFixed(2)})`, 'error');
      return;
    }

    setSaving(true);
    try {
      const res = await fetch('/api/admin/agents', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: balanceAgent.id,
          balanceAction: balanceAction,
          balanceAmount: amount,
          balanceNote: balanceNote,
        }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error || 'حدث خطأ', 'error'); setSaving(false); return; }
      showToast(data.message);
      setBalanceModal(false);
      fetchAgents();
    } catch { showToast('حدث خطأ', 'error'); }
    setSaving(false);
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    showToast('تم نسخ كود الإحالة');
  };

  const fmt = (n: number) => `$${n.toLocaleString('en', { minimumFractionDigits: 2 })}`;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center border border-[#FFD700]/20">
            <Users size={18} className="text-[#FFD700]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">إدارة الوكلاء</h1>
            <p className="text-gray-500 text-xs mt-0.5">{agents.length} وكيل نشط</p>
          </div>
        </div>
        <button onClick={() => setShowAddModal(true)} className="btn-premium-gold px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2">
          <Plus size={16} />
          إضافة وكيل
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { label: 'إجمالي الوكلاء', value: agents.length, icon: Users, color: '#FFD700' },
          { label: 'إجمالي أرصدة الوكلاء', value: fmt(agents.reduce((s, a) => s + a.balance, 0)), icon: Wallet, color: '#2ECC71' },
          { label: 'إجمالي العمولات المدفوعة', value: fmt(agents.reduce((s, a) => s + a.totalCommissionEarned, 0)), icon: DollarSign, color: '#3498DB' },
          { label: 'إجمالي الإحالات', value: agents.reduce((s, a) => s + a.referredUsersCount, 0), icon: TrendingUp, color: '#E67E22' },
          { label: 'إحالات نشطة', value: agents.reduce((s, a) => s + a.activeReferrals, 0), icon: Check, color: '#9B59B6' },
        ].map((c, i) => (
          <div key={i} className="glass-card card-lift premium-shimmer p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${c.color}15` }}>
                <c.icon size={15} style={{ color: c.color }} />
              </div>
              <span className="text-gray-400 text-xs leading-tight">{c.label}</span>
            </div>
            <p className="text-lg font-bold text-white">{c.value}</p>
          </div>
        ))}
      </div>

      {/* Agents Table */}
      {agents.length === 0 ? (
        <div className="glass-card p-12 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#FFD700]/10 flex items-center justify-center">
            <Shield size={28} className="text-[#FFD700]/50" />
          </div>
          <h3 className="text-white font-medium mb-1">لا يوجد وكلاء بعد</h3>
          <p className="text-gray-500 text-sm">أضف وكيلاً جديدًا للبدء</p>
        </div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#2A3040] bg-[#12161F]/30">
                  <th className="text-right p-4 text-gray-400 font-medium text-xs">الوكيل</th>
                  <th className="text-right p-4 text-gray-400 font-medium text-xs">الرصيد</th>
                  <th className="text-right p-4 text-gray-400 font-medium text-xs">نسبة العمولة</th>
                  <th className="text-right p-4 text-gray-400 font-medium text-xs hidden md:table-cell">الإحالات</th>
                  <th className="text-right p-4 text-gray-400 font-medium text-xs hidden lg:table-cell">إيداعات الإحالات</th>
                  <th className="text-right p-4 text-gray-400 font-medium text-xs hidden lg:table-cell">العمولات</th>
                  <th className="text-right p-4 text-gray-400 font-medium text-xs">المحفظة</th>
                  <th className="text-right p-4 text-gray-400 font-medium text-xs">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {agents.map(agent => (
                  <tr key={agent.id} className="border-b border-[#2A3040]/50 hover:bg-[#1A1F2E]/50 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0">
                          <User size={15} className="text-gray-300" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-white font-medium truncate">{agent.username}</p>
                          <p className="text-gray-500 text-xs truncate">{agent.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-[#2ECC71] font-bold text-sm">{fmt(agent.balance)}</span>
                    </td>
                    <td className="p-4">
                      {editingAgent?.id === agent.id ? (
                        <div className="flex items-center gap-2">
                          <input type="number" value={editRate} onChange={e => setEditRate(e.target.value)} className="w-16 bg-[#12161F] border border-[#2A3040] rounded-lg px-2 py-1 text-white text-xs text-center" min="0" max="50" step="0.5" />
                          <span className="text-gray-400 text-xs">%</span>
                          <button onClick={() => handleUpdateRate(agent.id)} className="text-[#2ECC71] hover:text-[#2ECC71]/80"><Check size={14} /></button>
                          <button onClick={() => { setEditingAgent(null); setEditRate(''); }} className="text-gray-400 hover:text-white"><X size={14} /></button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <Percent size={13} className="text-[#FFD700]" />
                          <span className="text-[#FFD700] font-bold">{agent.commissionRate}%</span>
                        </div>
                      )}
                    </td>
                    <td className="p-4 hidden md:table-cell">
                      <div>
                        <p className="text-white font-medium">{agent.referredUsersCount}</p>
                        <p className="text-gray-500 text-xs">{agent.activeReferrals} نشط</p>
                      </div>
                    </td>
                    <td className="p-4 hidden lg:table-cell">
                      <span className="text-[#2ECC71] font-medium">{fmt(agent.totalDepositsFromReferrals)}</span>
                    </td>
                    <td className="p-4 hidden lg:table-cell">
                      <span className="text-[#FFD700] font-medium">{fmt(agent.totalCommissionEarned)}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-1">
                        <button onClick={() => openBalanceModal(agent, 'deposit')} className="p-2 rounded-lg hover:bg-[#2ECC71]/10 text-[#2ECC71] transition-all" title="شحن رصيد">
                          <ArrowDownToLine size={15} />
                        </button>
                        <button onClick={() => openBalanceModal(agent, 'withdraw')} className="p-2 rounded-lg hover:bg-red-500/10 text-red-400 transition-all" title="سحب رصيد">
                          <ArrowUpFromLine size={15} />
                        </button>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-1">
                        <button onClick={() => copyCode(agent.referralCode)} className="p-2 rounded-lg hover:bg-[#2A3040] text-gray-400 hover:text-white transition-all" title="نسخ كود الإحالة">
                          <Copy size={14} />
                        </button>
                        <button onClick={() => { setEditingAgent(agent); setEditRate(String(agent.commissionRate)); }} className="p-2 rounded-lg hover:bg-[#FFD700]/10 text-gray-400 hover:text-[#FFD700] transition-all" title="تعديل العمولة">
                          <Edit3 size={14} />
                        </button>
                        <button onClick={() => handleDeactivate(agent.id, agent.username)} className="p-2 rounded-lg hover:bg-red-500/10 text-gray-400 hover:text-red-400 transition-all" title="إلغاء الوكالة">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===== Add Agent Modal ===== */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setShowAddModal(false)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-md border border-[#2A3040] animate-scaleIn" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-white font-bold text-lg">إضافة وكيل جديد</h3>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-white p-1"><X size={18} /></button>
            </div>
            <div className="space-y-4">
              <div className="relative" ref={searchRef}>
                <label className="text-gray-400 text-xs font-medium mr-1 block mb-1.5">اختر المستخدم</label>
                <div className="relative">
                  <div className="absolute right-3 top-1/2 -translate-y-1/2"><Search size={14} className="text-gray-400" /></div>
                  <input placeholder="ابحث بالاسم أو البريد الإلكتروني..." value={selectedUser ? `${selectedUser.username} (${selectedUser.email})` : searchQuery} onChange={e => { if (selectedUser) { setSelectedUser(null); setSearchQuery(''); return; } setSearchQuery(e.target.value); }} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm pr-10" dir="ltr" />
                  {selectedUser && <button onClick={() => { setSelectedUser(null); setSearchQuery(''); }} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-400"><X size={14} /></button>}
                </div>
                {searchResults.length > 0 && !selectedUser && (
                  <div className="absolute top-full right-0 left-0 mt-1 bg-[#1A1F2E] border border-[#2A3040] rounded-xl overflow-hidden z-50 shadow-xl shadow-black/30 max-h-48 overflow-y-auto scrollbar-thin">
                    {searchResults.map(u => (
                      <button key={u.id} onClick={() => { setSelectedUser({ id: u.id, username: u.username, email: u.email }); setSearchResults([]); }} className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#2A3040]/50 transition-colors text-right">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center shrink-0"><User size={13} className="text-gray-300" /></div>
                        <div className="min-w-0">
                          <p className="text-white text-sm font-medium truncate">{u.username}</p>
                          <p className="text-gray-500 text-xs truncate">{u.email}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <label className="text-gray-400 text-xs font-medium mr-1 block mb-1.5">نسبة العمولة (%)</label>
                <div className="relative">
                  <input type="number" value={commissionRate} onChange={e => setCommissionRate(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm" min="0" max="50" step="0.5" />
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">%</span>
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={handleAddAgent} disabled={saving || !selectedUser} className="flex-1 btn-premium-gold py-2.5 rounded-xl text-sm font-bold disabled:opacity-50">{saving ? 'جاري الحفظ...' : 'تعيين كوكيل'}</button>
                <button onClick={() => setShowAddModal(false)} className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm hover:bg-[#3A4050]">إلغاء</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Balance Modal (Deposit/Withdraw) ===== */}
      {balanceModal && balanceAgent && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setBalanceModal(false)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-sm border border-[#2A3040] animate-scaleIn" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-white font-bold text-lg">
                {balanceAction === 'deposit' ? '💰 شحن رصيد' : '💸 سحب رصيد'}
              </h3>
              <button onClick={() => setBalanceModal(false)} className="text-gray-400 hover:text-white p-1"><X size={18} /></button>
            </div>

            {/* Agent Info */}
            <div className="bg-[#12161F] rounded-xl p-3.5 mb-5 border border-[#2A3040]/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 flex items-center justify-center">
                  <User size={16} className="text-gray-300" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{balanceAgent.username}</p>
                  <p className="text-gray-500 text-xs">{balanceAgent.email}</p>
                </div>
                <div className="text-left">
                  <p className="text-gray-500 text-[10px]">الرصيد الحالي</p>
                  <p className="text-[#2ECC71] font-bold text-sm">{fmt(balanceAgent.balance)}</p>
                </div>
              </div>
            </div>

            {/* Action Type Tabs */}
            <div className="flex gap-2 mb-5">
              <button onClick={() => setBalanceAction('deposit')} className={`flex-1 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${balanceAction === 'deposit' ? 'bg-[#2ECC71]/15 text-[#2ECC71] border border-[#2ECC71]/30' : 'bg-[#12161F] text-gray-400 border border-[#2A3040]'}`}>
                <ArrowDownToLine size={16} /> شحن
              </button>
              <button onClick={() => setBalanceAction('withdraw')} className={`flex-1 py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all ${balanceAction === 'withdraw' ? 'bg-red-500/15 text-red-400 border border-red-500/30' : 'bg-[#12161F] text-gray-400 border border-[#2A3040]'}`}>
                <ArrowUpFromLine size={16} /> سحب
              </button>
            </div>

            <div className="space-y-4">
              {/* Amount */}
              <div>
                <label className="text-gray-400 text-xs font-medium mr-1 block mb-1.5">المبلغ ($)</label>
                <input type="number" value={balanceAmount} onChange={e => setBalanceAmount(e.target.value)} placeholder="0.00" className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-3 text-white text-lg font-bold text-center focus:outline-none focus:border-[#FFD700]/50 transition-colors" dir="ltr" min="0" step="0.01" />
              </div>

              {/* Note */}
              <div>
                <label className="text-gray-400 text-xs font-medium mr-1 block mb-1.5">ملاحظة (اختياري)</label>
                <input value={balanceNote} onChange={e => setBalanceNote(e.target.value)} placeholder="سبب الشحن أو السحب..." className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-[#FFD700]/50 transition-colors" />
              </div>

              {/* Warning for withdraw */}
              {balanceAction === 'withdraw' && balanceAmount && parseFloat(balanceAmount) > balanceAgent.balance && (
                <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-xl p-3">
                  <AlertTriangle size={14} className="text-red-400 shrink-0" />
                  <span className="text-red-400 text-xs">المبلغ أكبر من رصيد الوكيل الحالي</span>
                </div>
              )}

              {/* Preview */}
              {balanceAmount && parseFloat(balanceAmount) > 0 && parseFloat(balanceAmount) <= balanceAgent.balance && (
                <div className="bg-[#0D1117] rounded-xl p-3 border border-[#2A3040]/50">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400 text-xs">الرصيد بعد العملية</span>
                    <span className={`font-bold text-sm ${balanceAction === 'deposit' ? 'text-[#2ECC71]' : 'text-red-400'}`}>
                      {fmt(balanceAction === 'deposit' ? balanceAgent.balance + parseFloat(balanceAmount) : balanceAgent.balance - parseFloat(balanceAmount))}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-1">
                <button onClick={handleBalanceAction} disabled={saving || !balanceAmount || parseFloat(balanceAmount) <= 0} className={`flex-1 py-3 rounded-xl text-sm font-bold disabled:opacity-50 flex items-center justify-center gap-2 transition-all ${balanceAction === 'deposit' ? 'bg-gradient-to-l from-[#2ECC71] to-[#27AE60] hover:shadow-lg hover:shadow-[#2ECC71]/20' : 'bg-gradient-to-l from-red-500 to-red-600 hover:shadow-lg hover:shadow-red-500/20'} text-white`}>
                  {saving ? 'جاري المعالجة...' : balanceAction === 'deposit' ? `شحن ${fmt(parseFloat(balanceAmount) || 0)}` : `سحب ${fmt(parseFloat(balanceAmount) || 0)}`}
                </button>
                <button onClick={() => setBalanceModal(false)} className="flex-1 bg-[#2A3040] text-gray-300 py-3 rounded-xl text-sm hover:bg-[#3A4050] transition-colors">إلغاء</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
