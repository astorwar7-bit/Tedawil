export default function AdminAgentsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
