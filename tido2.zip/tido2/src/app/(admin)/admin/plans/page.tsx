'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import ConfirmDialog from '@/components/ConfirmDialog';
import { Plus, Trash2, Edit2, Users, TrendingUp, Clock, DollarSign, Gem, Loader2 } from 'lucide-react';

interface Plan {
  id: string;
  name: string;
  nameEn: string;
  minAmount: number;
  maxAmount: number;
  dailyRate: number;
  duration: number;
  icon: string;
  color: string;
  isActive: boolean;
  sortOrder: number;
  description: string | null;
  createdAt: string;
  _count?: { investments: number };
}

const emptyForm = {
  name: '',
  nameEn: '',
  minAmount: 100,
  maxAmount: 50000,
  dailyRate: 1.5,
  duration: 30,
  icon: '🥉',
  color: '#FFD700',
  isActive: true,
  sortOrder: 0,
  description: '',
};

const emojiOptions = ['🥉', '🥈', '🥇', '💎', '🏆', '🚀', '⭐', '👑', '🔥', '💰', '📈', '🎯', '🌟', '💎', '🪙'];

const colorOptions = [
  '#CD7F32', '#C0C0C0', '#FFD700', '#B9F2FF', '#2ECC71',
  '#E74C3C', '#9B59B6', '#3498DB', '#F39C12', '#1ABC9C',
  '#E91E63', '#00BCD4', '#FF9800', '#8BC34A',
];

export default function AdminPlansPage() {
  const { showToast } = useToast();
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [modal, setModal] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleteName, setDeleteName] = useState('');

  const fetchPlans = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/admin/plans');
      const data = await res.json();
      if (res.ok) {
        setPlans(data.plans || []);
      } else {
        showToast(data.error || 'حدث خطأ أثناء جلب الخطط', 'error');
      }
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlans();
  }, []);

  const openCreateModal = () => {
    setEditId(null);
    setForm(emptyForm);
    setModal(true);
  };

  const openEditModal = (plan: Plan) => {
    setEditId(plan.id);
    setForm({
      name: plan.name,
      nameEn: plan.nameEn,
      minAmount: plan.minAmount,
      maxAmount: plan.maxAmount,
      dailyRate: plan.dailyRate,
      duration: plan.duration,
      icon: plan.icon,
      color: plan.color,
      isActive: plan.isActive,
      sortOrder: plan.sortOrder,
      description: plan.description || '',
    });
    setModal(true);
  };

  const handleSave = async () => {
    if (!form.name.trim() || !form.nameEn.trim()) {
      showToast('اسم الخطة والاسم الإنجليزي مطلوبان', 'error');
      return;
    }
    if (form.minAmount < 0 || form.maxAmount < 0) {
      showToast('المبالغ يجب أن تكون موجبة', 'error');
      return;
    }
    if (form.dailyRate <= 0 || form.dailyRate > 100) {
      showToast('النسبة اليومية يجب أن تكون بين 0 و 100', 'error');
      return;
    }
    if (form.duration < 1) {
      showToast('المدة يجب أن تكون يوم واحد على الأقل', 'error');
      return;
    }

    try {
      setSaving(true);
      const url = editId ? `/api/admin/plans/${editId}` : '/api/admin/plans';
      const method = editId ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'حدث خطأ', 'error');
        return;
      }

      showToast(data.message);
      setModal(false);
      setEditId(null);
      setForm(emptyForm);
      fetchPlans();
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/admin/plans/${deleteId}`, { method: 'DELETE' });
      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'حدث خطأ', 'error');
        setDeleteId(null);
        return;
      }

      showToast(data.message);
      setDeleteId(null);
      fetchPlans();
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
      setDeleteId(null);
    }
  };

  const handleToggle = async (plan: Plan) => {
    try {
      const res = await fetch(`/api/admin/plans/${plan.id}`, { method: 'PATCH' });
      const data = await res.json();

      if (!res.ok) {
        showToast(data.error || 'حدث خطأ', 'error');
        return;
      }

      showToast(data.message);
      fetchPlans();
    } catch {
      showToast('خطأ في الاتصال بالخادم', 'error');
    }
  };

  const formatCurrency = (amount: number) => {
    if (amount === 0) return '∞';
    return '$' + amount.toLocaleString('en-US');
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center">
            <Gem size={20} className="text-[#FFD700]" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">إدارة خطط الاستثمار</h1>
            <p className="text-gray-400 text-xs mt-0.5">{plans.length} خطة استثمار</p>
          </div>
        </div>
        <button
          onClick={openCreateModal}
          className="btn-premium-emerald px-5 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2"
        >
          <Plus size={16} />
          إضافة خطة جديدة
        </button>
      </div>

      {/* Loading Skeleton */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="glass-card p-6 rounded-2xl animate-pulse">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-[#2A3040]" />
                <div className="space-y-2 flex-1">
                  <div className="h-4 bg-[#2A3040] rounded w-3/4" />
                  <div className="h-3 bg-[#2A3040] rounded w-1/2" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-3 bg-[#2A3040] rounded" />
                <div className="h-3 bg-[#2A3040] rounded w-2/3" />
                <div className="h-3 bg-[#2A3040] rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && plans.length === 0 && (
        <div className="glass-card rounded-2xl p-12 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#2A3040]/50 flex items-center justify-center">
            <Gem size={32} className="text-gray-500" />
          </div>
          <h3 className="text-white font-bold text-lg mb-2">لا توجد خطط استثمار</h3>
          <p className="text-gray-400 text-sm mb-6">ابدأ بإضافة أول خطة استثمار للمنصة</p>
          <button
            onClick={openCreateModal}
            className="btn-premium-emerald px-6 py-2.5 rounded-xl text-sm font-bold inline-flex items-center gap-2"
          >
            <Plus size={16} />
            إضافة خطة جديدة
          </button>
        </div>
      )}

      {/* Plans Grid */}
      {!loading && plans.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`glass-card card-lift rounded-2xl overflow-hidden transition-all duration-300 ${
                !plan.isActive ? 'opacity-60' : ''
              }`}
            >
              {/* Card Top Color Strip */}
              <div
                className="h-1.5 w-full"
                style={{ background: `linear-gradient(to left, ${plan.color}, ${plan.color}88)` }}
              />

              <div className="p-5">
                {/* Plan Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                      style={{ backgroundColor: `${plan.color}15`, border: `1px solid ${plan.color}30` }}
                    >
                      {plan.icon}
                    </div>
                    <div>
                      <h3 className="text-white font-bold text-base">{plan.name}</h3>
                      <p className="text-gray-400 text-xs" style={{ color: plan.color }}>
                        {plan.nameEn}
                      </p>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <button
                    onClick={() => handleToggle(plan)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus:outline-none ${
                      plan.isActive ? 'bg-[#2ECC71]' : 'bg-[#2A3040]'
                    }`}
                    aria-label={plan.isActive ? 'تعطيل الخطة' : 'تفعيل الخطة'}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                        plan.isActive ? '-translate-x-6' : '-translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Plan Details */}
                <div className="space-y-2.5 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-1.5">
                      <DollarSign size={14} className="text-[#2ECC71]" />
                      الحد الأدنى
                    </span>
                    <span className="text-white font-medium">{formatCurrency(plan.minAmount)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-1.5">
                      <DollarSign size={14} className="text-[#FFD700]" />
                      الحد الأقصى
                    </span>
                    <span className="text-white font-medium">{formatCurrency(plan.maxAmount)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-1.5">
                      <TrendingUp size={14} className="text-[#2ECC71]" />
                      النسبة اليومية
                    </span>
                    <span className="font-bold" style={{ color: plan.color }}>
                      {plan.dailyRate}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-1.5">
                      <Clock size={14} className="text-gray-400" />
                      المدة
                    </span>
                    <span className="text-white font-medium">{plan.duration} يوم</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-1.5">
                      <Users size={14} className="text-[#FFD700]" />
                      استثمارات نشطة
                    </span>
                    <span className="text-white font-bold">{plan._count?.investments || 0}</span>
                  </div>
                </div>

                {/* Description */}
                {plan.description && (
                  <p className="text-gray-500 text-xs leading-relaxed mb-4 line-clamp-2 border-t border-[#2A3040] pt-3">
                    {plan.description}
                  </p>
                )}

                {/* Actions */}
                <div className="flex gap-2 border-t border-[#2A3040] pt-3">
                  <button
                    onClick={() => openEditModal(plan)}
                    className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium text-[#FFD700] hover:bg-[#FFD700]/10 transition-all border border-[#FFD700]/20"
                  >
                    <Edit2 size={14} />
                    تعديل
                  </button>
                  <button
                    onClick={() => {
                      setDeleteId(plan.id);
                      setDeleteName(plan.name);
                    }}
                    className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 transition-all border border-red-500/20"
                  >
                    <Trash2 size={14} />
                    حذف
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Modal */}
      {modal && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setModal(false)} />
          <div
            className="relative w-full max-w-lg glass-card p-6 animate-scaleIn border border-[#2A3040] max-h-[90vh] overflow-y-auto scrollbar-thin"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-white font-bold text-lg flex items-center gap-2">
                <Gem size={20} className="text-[#FFD700]" />
                {editId ? 'تعديل خطة الاستثمار' : 'إضافة خطة جديدة'}
              </h3>
              <button
                onClick={() => setModal(false)}
                className="text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-[#1A1F2E]"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {/* Arabic Name */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">اسم الخطة (عربي) *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="مثال: الخطة الذهبية"
                  className="input-premium w-full"
                  dir="rtl"
                />
              </div>

              {/* English Name */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">اسم الخطة (إنجليزي) *</label>
                <input
                  type="text"
                  value={form.nameEn}
                  onChange={(e) => setForm({ ...form, nameEn: e.target.value })}
                  placeholder="e.g. Gold Plan"
                  className="input-premium w-full"
                  dir="ltr"
                />
              </div>

              {/* Min/Max Amount */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">الحد الأدنى ($) *</label>
                  <input
                    type="number"
                    min="0"
                    value={form.minAmount}
                    onChange={(e) => setForm({ ...form, minAmount: parseFloat(e.target.value) || 0 })}
                    className="input-premium w-full"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">الحد الأقصى ($) *</label>
                  <input
                    type="number"
                    min="0"
                    value={form.maxAmount}
                    onChange={(e) => setForm({ ...form, maxAmount: parseFloat(e.target.value) || 0 })}
                    className="input-premium w-full"
                    dir="ltr"
                    placeholder="0 = بدون حد"
                  />
                </div>
              </div>

              {/* Daily Rate & Duration */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">النسبة اليومية (%) *</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={form.dailyRate}
                    onChange={(e) => setForm({ ...form, dailyRate: parseFloat(e.target.value) || 0 })}
                    className="input-premium w-full"
                    dir="ltr"
                  />
                </div>
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">المدة (أيام) *</label>
                  <input
                    type="number"
                    min="1"
                    value={form.duration}
                    onChange={(e) => setForm({ ...form, duration: parseInt(e.target.value) || 0 })}
                    className="input-premium w-full"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* Icon Selection */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">الأيقونة *</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {emojiOptions.map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setForm({ ...form, icon: emoji })}
                      className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl transition-all ${
                        form.icon === emoji
                          ? 'bg-[#FFD700]/20 border-2 border-[#FFD700] scale-110'
                          : 'bg-[#12161F] border border-[#2A3040] hover:border-[#FFD700]/50'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={form.icon}
                  onChange={(e) => setForm({ ...form, icon: e.target.value })}
                  placeholder="أو أدخل أيقونة مخصصة"
                  className="input-premium w-full"
                  dir="ltr"
                />
              </div>

              {/* Color Selection */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">اللون *</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {colorOptions.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setForm({ ...form, color: c })}
                      className={`w-8 h-8 rounded-lg transition-all ${
                        form.color === c ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1A1F2E] scale-110' : ''
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={form.color}
                    onChange={(e) => setForm({ ...form, color: e.target.value })}
                    className="w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent"
                  />
                  <input
                    type="text"
                    value={form.color}
                    onChange={(e) => setForm({ ...form, color: e.target.value })}
                    placeholder="#FFD700"
                    className="input-premium flex-1"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-gray-400 text-xs font-medium block mb-1.5">الوصف (اختياري)</label>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="وصف مختصر للخطة..."
                  rows={3}
                  className="input-premium w-full resize-none"
                  dir="rtl"
                />
              </div>

              {/* Sort Order & Active */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 text-xs font-medium block mb-1.5">ترتيب العرض</label>
                  <input
                    type="number"
                    min="0"
                    value={form.sortOrder}
                    onChange={(e) => setForm({ ...form, sortOrder: parseInt(e.target.value) || 0 })}
                    className="input-premium w-full"
                    dir="ltr"
                  />
                </div>
                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2.5 cursor-pointer py-2.5">
                    <span className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 ${form.isActive ? 'bg-[#2ECC71]' : 'bg-[#2A3040]'}`}>
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                          form.isActive ? '-translate-x-6' : '-translate-x-1'
                        }`}
                      />
                    </span>
                    <span className="text-gray-300 text-sm">نشطة</span>
                  </label>
                </div>
              </div>

              {/* Profit Preview */}
              <div className="bg-[#12161F] rounded-xl p-4 border border-[#2A3040]">
                <p className="text-gray-400 text-xs mb-2 font-medium">معاينة الأرباح المتوقعة</p>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-gray-500 text-[10px]">أقل استثمار</p>
                    <p className="text-white text-sm font-bold">
                      ${(form.minAmount * form.dailyRate / 100).toFixed(2)}/يوم
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[10px]">إجمالي (أقل)</p>
                    <p className="text-[#2ECC71] text-sm font-bold">
                      ${(form.minAmount * form.dailyRate / 100 * form.duration).toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-[10px]">إجمالي (أعلى)</p>
                    <p className="text-[#FFD700] text-sm font-bold">
                      {form.maxAmount > 0
                        ? `$${(form.maxAmount * form.dailyRate / 100 * form.duration).toFixed(2)}`
                        : '∞'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="btn-premium-emerald flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {saving ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : editId ? (
                    <Edit2 size={16} />
                  ) : (
                    <Plus size={16} />
                  )}
                  {saving ? 'جاري الحفظ...' : editId ? 'حفظ التعديلات' : 'إضافة الخطة'}
                </button>
                <button
                  onClick={() => setModal(false)}
                  className="flex-1 py-3 rounded-xl text-sm font-medium text-gray-400 hover:text-white hover:bg-[#1A1F2E] transition-all border border-[#2A3040]"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmDialog
        open={!!deleteId}
        title="حذف خطة الاستثمار"
        message={`هل أنت متأكد من حذف خطة "${deleteName}"؟ لا يمكن التراجع عن هذا الإجراء. إذا كانت الخطة تحتوي على استثمارات نشطة، فلن يتم حذفها.`}
        confirmText="حذف الخطة"
        cancelText="إلغاء"
        onConfirm={handleDelete}
        onCancel={() => setDeleteId(null)}
        variant="danger"
      />
    </div>
  );
}
