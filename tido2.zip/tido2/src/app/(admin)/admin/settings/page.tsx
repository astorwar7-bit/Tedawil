'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Save, Globe, Type, DollarSign, Percent, Gift, Wallet } from 'lucide-react';

export default function AdminSettingsPage() {
  const { showToast } = useToast();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    platformName: '',
    platformNameEn: '',
    platformDesc: '',
    mainWalletAddress: '',
    minDeposit: 100,
    minWithdraw: 10,
    referralBonusRate: 5,
    referralLevel2Rate: 2,
    referralFixedBonus: 5,
    monthlyCommissionCap: 0,
    minDailyRate: 1.2,
    maxDailyRate: 1.7,
    welcomeBonus: 10,
  });

  useEffect(() => {
    fetch('/api/admin/settings').then(r => r.json()).then(d => {
      if (d.settings) setForm({ ...form, ...d.settings });
    });
  }, []);

  const save = async () => {
    setSaving(true);
    const res = await fetch('/api/admin/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const data = await res.json();
    if (!res.ok) { showToast(data.error, 'error'); setSaving(false); return; }
    showToast('تم حفظ الإعدادات بنجاح');
    setSaving(false);
  };

  const inputClass = "w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:border-[#FFD700] focus:outline-none transition-colors";
  const labelClass = "text-gray-400 text-xs mb-1.5 block font-medium";

  return (
    <div className="space-y-6 animate-fadeIn max-w-2xl">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700]/10 to-[#2ECC71]/10 flex items-center justify-center border border-[#FFD700]/10">
          <Globe size={18} className="text-[#FFD700]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">الإعدادات العامة</h1>
          <p className="text-gray-500 text-xs">إدارة إعدادات المنصة والعرض</p>
        </div>
      </div>

      {/* Platform Branding */}
      <div className="bg-[#1A1F2E] rounded-2xl p-5 border border-[#2A3040] space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2A3040] pb-2">
          <Type size={14} className="text-[#FFD700]" />
          هوية المنصة
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className={labelClass}>اسم المنصة (عربي)</label>
            <input value={form.platformName} onChange={e => setForm({...form, platformName: e.target.value})} className={inputClass} placeholder="تداول AI" />
          </div>
          <div>
            <label className={labelClass}>اسم المنصة (إنجليزي) - يظهر في واجهة الدخول</label>
            <input value={form.platformNameEn} onChange={e => setForm({...form, platformNameEn: e.target.value})} className={inputClass} placeholder="Tadawul AI" dir="ltr" />
            <p className="text-[10px] text-gray-600 mt-1">هذا الاسم يظهر في صفحات الدخول والتسجيل</p>
          </div>
        </div>
        <div>
          <label className={labelClass}>وصف المنصة</label>
          <textarea value={form.platformDesc} onChange={e => setForm({...form, platformDesc: e.target.value})} className={`${inputClass} h-20 resize-none`} placeholder="منصة استثمار رقمية متكاملة" />
        </div>

        {/* Live Preview */}
        <div className="bg-[#0A0F0D] rounded-xl p-4 border border-[#2A3040]/50">
          <p className="text-[10px] text-gray-600 mb-2">معاينة مباشرة:</p>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-black text-lg">T</div>
            <div>
              <p className="text-lg font-black text-white" dir="ltr">{form.platformNameEn || 'Tadawul AI'}</p>
              <p className="text-xs text-gray-500">{form.platformName || 'تداول AI'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Financial Settings */}
      <div className="bg-[#1A1F2E] rounded-2xl p-5 border border-[#2A3040] space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-[#2A3040] pb-2">
          <DollarSign size={14} className="text-[#2ECC71]" />
          الإعدادات المالية
        </h2>
        <div>
          <label className={labelClass}>عنوان محفظة USDT الرئيسي</label>
          <input value={form.mainWalletAddress} onChange={e => setForm({...form, mainWalletAddress: e.target.value})} className={inputClass} dir="ltr" placeholder="0x..." />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelClass}>الحد الأدنى للإيداع ($)</label>
            <div className="relative">
              <DollarSign size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600" />
              <input type="number" value={form.minDeposit} onChange={e => setForm({...form, minDeposit: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
          </div>
          <div>
            <label className={labelClass}>الحد الأدنى للسحب ($)</label>
            <div className="relative">
              <DollarSign size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600" />
              <input type="number" value={form.minWithdraw} onChange={e => setForm({...form, minWithdraw: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelClass}>النسبة اليومية الدنيا (%)</label>
            <div className="relative">
              <Percent size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600" />
              <input type="number" step="0.1" value={form.minDailyRate} onChange={e => setForm({...form, minDailyRate: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
          </div>
          <div>
            <label className={labelClass}>النسبة اليومية العليا (%)</label>
            <div className="relative">
              <Percent size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600" />
              <input type="number" step="0.1" value={form.maxDailyRate} onChange={e => setForm({...form, maxDailyRate: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelClass}>مكافأة التسجيل ($)</label>
            <div className="relative">
              <Gift size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#FFD700]" />
              <input type="number" step="0.1" value={form.welcomeBonus} onChange={e => setForm({...form, welcomeBonus: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
          </div>
          <div>
            <label className={labelClass}>نسبة مكافأة الدعوة (%)</label>
            <div className="relative">
              <Wallet size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#2ECC71]" />
              <input type="number" step="0.1" value={form.referralBonusRate} onChange={e => setForm({...form, referralBonusRate: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
            <p className="text-[10px] text-gray-600 mt-1">نسبة من أرباح المستخدم المحال يومياً</p>
          </div>
        </div>
        <div>
          <label className={labelClass}>مكافأة إحالة ثابتة ($)</label>
          <div className="relative">
            <Gift size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#FFD700]" />
            <input type="number" step="0.1" value={form.referralFixedBonus} onChange={e => setForm({...form, referralFixedBonus: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
          </div>
          <p className="text-[10px] text-gray-600 mt-1">مبلغ يُضاف فوراً لرصيد الراعي عند تسجيل شخص بكوده</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelClass}>نسبة مكافأة المستوى الثاني (%)</label>
            <div className="relative">
              <Percent size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#3498DB]" />
              <input type="number" step="0.1" value={form.referralLevel2Rate} onChange={e => setForm({...form, referralLevel2Rate: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
            <p className="text-[10px] text-gray-600 mt-1">نسبة يحصل عليها مُحيل المُحيل</p>
          </div>
          <div>
            <label className={labelClass}>الحد الأقصى للعمولة الشهرية ($)</label>
            <div className="relative">
              <DollarSign size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#E67E22]" />
              <input type="number" step="1" value={form.monthlyCommissionCap} onChange={e => setForm({...form, monthlyCommissionCap: parseFloat(e.target.value)})} className={`${inputClass} pr-9`} dir="ltr" />
            </div>
            <p className="text-[10px] text-gray-600 mt-1">0 = بدون سقف</p>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <button onClick={save} disabled={saving} className="w-full bg-gradient-to-l from-[#2ECC71] to-[#27AE60] text-white py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-[#2ECC71]/20 transition-all disabled:opacity-60">
        <Save size={16} />
        {saving ? 'جاري الحفظ...' : 'حفظ جميع التغييرات'}
      </button>
    </div>
  );
}
