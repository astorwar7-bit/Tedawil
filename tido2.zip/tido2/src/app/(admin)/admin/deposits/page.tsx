'use client';

import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/contexts/ToastContext';
import { DollarSign, Clock, CheckCircle, XCircle, Search, Check, X, Loader2, ChevronLeft, ChevronRight, AlertTriangle } from 'lucide-react';

interface Deposit {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  paymentMethod: string;
  transactionHash: string;
  screenshotUrl: string;
  status: string;
  createdAt: string;
}

interface Stats {
  total: number;
  pending: number;
  approved: number;
  rejected: number;
  pendingAmount: number;
}

export default function AdminDepositsPage() {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, pending: 0, approved: 0, rejected: 0, pendingAmount: 0 });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [confirmModal, setConfirmModal] = useState<{ id: string; action: 'approve' | 'reject'; amount: number; userName: string } | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchDeposits = useCallback(async (p: number = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('page', String(p));
      params.set('limit', '20');
      if (filter !== 'all') params.set('status', filter);
      if (search) params.set('search', search);

      const res = await fetch(`/api/admin/deposits?${params.toString()}`);
      const data = await res.json();
      setDeposits(data.deposits || []);
      setStats(data.stats || { total: 0, pending: 0, approved: 0, rejected: 0, pendingAmount: 0 });
      setTotalPages(data.pages || 1);
    } catch (err) {
      console.error('Failed to fetch deposits:', err);
    }
    setLoading(false);
  }, [filter, search]);

  useEffect(() => {
    if (user) {
      setPage(1);
      fetchDeposits(1);
    }
  }, [user, filter]);

  useEffect(() => {
    if (user) fetchDeposits(page);
  }, [page]);

  const handleSearch = () => {
    setPage(1);
    fetchDeposits(1);
  };

  const handleAction = async () => {
    if (!confirmModal) return;
    setActionLoading(confirmModal.id);
    try {
      const res = await fetch('/api/admin/deposits', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ depositId: confirmModal.id, action: confirmModal.action }),
      });
      if (res.ok) {
        showToast(confirmModal.action === 'approve' ? 'تم قبول الإيداع بنجاح' : 'تم رفض الإيداع', 'success');
        setConfirmModal(null);
        fetchDeposits(page);
      } else {
        const data = await res.json();
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch (err) {
      showToast('حدث خطأ أثناء المعالجة', 'error');
    }
    setActionLoading(null);
  };

  const statusColors: Record<string, string> = {
    pending: '#FFD700',
    approved: '#2ECC71',
    rejected: '#EF4444',
  };
  const statusLabels: Record<string, string> = {
    pending: 'معلق',
    approved: 'موافق عليه',
    rejected: 'مرفوض',
  };
  const methodLabels: Record<string, string> = {
    USDT_TRC20: 'USDT TRC20',
    USDT_ERC20: 'USDT ERC20',
    BANK: 'تحويل بنكي',
  };

  const statCards = [
    { label: 'إجمالي الإيداعات', value: `$${stats.total.toFixed(2)}`, icon: DollarSign, color: '#FFD700', bg: 'rgba(255,215,0,0.1)' },
    { label: 'قيد المراجعة', value: `${stats.pending} ($${stats.pendingAmount.toFixed(2)})`, icon: Clock, color: '#FFD700', bg: 'rgba(255,215,0,0.1)' },
    { label: 'تمت الموافقة', value: stats.approved, icon: CheckCircle, color: '#2ECC71', bg: 'rgba(46,204,113,0.1)' },
    { label: 'مرفوضة', value: stats.rejected, icon: XCircle, color: '#EF4444', bg: 'rgba(239,68,68,0.1)' },
  ];

  if (!user) return null;

  return (
    <div className="space-y-5 animate-fadeIn">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 flex items-center justify-center">
          <DollarSign size={20} className="text-[#FFD700]" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">إدارة الإيداعات</h1>
          <p className="text-gray-500 text-xs">مراجعة وإدارة طلبات الإيداع</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {statCards.map((s, i) => (
          <div key={i} className="glass-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <s.icon size={16} style={{ color: s.color }} />
              <span className="text-gray-400 text-xs">{s.label}</span>
            </div>
            <p className="text-lg font-bold text-white">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
          <input
            placeholder="بحث بالاسم المستخدم..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            className="input-premium pr-10"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {['all', 'pending', 'approved', 'rejected'].map(s => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
                filter === s ? 'bg-[#FFD700]/15 text-[#FFD700] border border-[#FFD700]/30' : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-[#3A4050]'
              }`}
            >
              {s === 'all' ? 'الكل' : statusLabels[s] || s}
            </button>
          ))}
        </div>
      </div>

      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#2A3040]">
                <th className="text-right p-3 text-gray-400 font-medium text-xs">المستخدم</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">المبلغ</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">الطريقة</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">TX Hash</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">الحالة</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">التاريخ</th>
                <th className="text-right p-3 text-gray-400 font-medium text-xs">إجراء</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={7} className="text-center py-12"><Loader2 className="animate-spin text-[#FFD700] mx-auto" size={24} /></td></tr>
              ) : deposits.length === 0 ? (
                <tr><td colSpan={7} className="text-center py-12 text-gray-500">لا توجد إيداعات</td></tr>
              ) : (
                deposits.map(d => (
                  <tr key={d.id} className="border-b border-[#2A3040]/50 hover:bg-[#2A3040]/20 transition-colors">
                    <td className="p-3 text-white text-xs font-medium">{d.userName || '-'}</td>
                    <td className="p-3 text-[#FFD700] font-bold text-xs" dir="ltr">${d.amount.toFixed(2)}</td>
                    <td className="p-3 text-gray-400 text-xs">{methodLabels[d.paymentMethod] || d.paymentMethod}</td>
                    <td className="p-3 text-gray-400 text-xs" dir="ltr">{d.transactionHash ? `${d.transactionHash.slice(0, 8)}...` : '-'}</td>
                    <td className="p-3">
                      <span className="badge" style={{ background: `${statusColors[d.status]}15`, color: statusColors[d.status] }}>
                        {statusLabels[d.status] || d.status}
                      </span>
                    </td>
                    <td className="p-3 text-gray-500 text-xs">{new Date(d.createdAt).toLocaleDateString('ar')}</td>
                    <td className="p-3">
                      {d.status === 'pending' && (
                        <div className="flex gap-1">
                          <button
                            onClick={() => setConfirmModal({ id: d.id, action: 'approve', amount: d.amount, userName: d.userName })}
                            className="p-1.5 rounded-lg bg-[#2ECC71]/10 text-[#2ECC71] hover:bg-[#2ECC71]/20 transition-colors"
                            title="موافقة"
                          >
                            <Check size={14} />
                          </button>
                          <button
                            onClick={() => setConfirmModal({ id: d.id, action: 'reject', amount: d.amount, userName: d.userName })}
                            className="p-1.5 rounded-lg bg-[#EF4444]/10 text-[#EF4444] hover:bg-[#EF4444]/20 transition-colors"
                            title="رفض"
                          >
                            <X size={14} />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-[#2A3040]">
            <span className="text-gray-500 text-xs">صفحة {page} من {totalPages}</span>
            <div className="flex gap-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg bg-[#1A1F2E] text-gray-400 hover:text-white border border-[#2A3040] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight size={16} />
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-2 rounded-lg bg-[#1A1F2E] text-gray-400 hover:text-white border border-[#2A3040] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Confirmation Modal */}
      {confirmModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setConfirmModal(null)}>
          <div className="bg-[#1A1F2E] rounded-2xl p-6 w-full max-w-sm border border-[#2A3040]" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${confirmModal.action === 'approve' ? 'bg-[#2ECC71]/10' : 'bg-[#EF4444]/10'}`}>
                <AlertTriangle size={18} className={confirmModal.action === 'approve' ? 'text-[#2ECC71]' : 'text-[#EF4444]'} />
              </div>
              <div>
                <h3 className="text-white font-bold text-sm">
                  {confirmModal.action === 'approve' ? 'تأكيد قبول الإيداع' : 'تأكيد رفض الإيداع'}
                </h3>
                <p className="text-gray-400 text-xs mt-0.5">
                  {confirmModal.userName} — ${confirmModal.amount.toFixed(2)}
                </p>
              </div>
            </div>
            <p className="text-gray-300 text-sm mb-5">
              {confirmModal.action === 'approve'
                ? 'سيتم إضافة المبلغ إلى رصيد المستخدم وإرسال إشعار بذلك.'
                : 'سيتم رفض الإيداع وإرسال إشعار للمستخدم.'}
            </p>
            <div className="flex gap-2">
              <button
                onClick={handleAction}
                disabled={!!actionLoading}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-colors disabled:opacity-50 flex items-center justify-center gap-2 ${
                  confirmModal.action === 'approve' ? 'bg-[#2ECC71] hover:bg-[#2ECC71]/80' : 'bg-[#EF4444] hover:bg-[#EF4444]/80'
                }`}
              >
                {actionLoading ? <Loader2 size={14} className="animate-spin" /> : null}
                {confirmModal.action === 'approve' ? 'تأكيد القبول' : 'تأكيد الرفض'}
              </button>
              <button
                onClick={() => setConfirmModal(null)}
                className="flex-1 bg-[#2A3040] text-gray-300 py-2.5 rounded-xl text-sm hover:bg-[#3A4050] transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
