import AdminDashLayout from '@/components/AdminDashLayout';

export default function Layout({ children }: { children: React.ReactNode }) {
  return <AdminDashLayout>{children}</AdminDashLayout>;
}
