'use client';
import { useEffect, useState } from 'react';

interface LogRow { id: string; adminName: string; actionType: string; details: string; ipAddress: string; createdAt: string; }

export default function AdminActivityLogPage() {
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [page, setPage] = useState(1);
  const [actionType, setActionType] = useState('');

  useEffect(() => {
    fetch(`/api/admin/activity-log?page=${page}&limit=20&actionType=${actionType}`).then(r => r.json()).then(d => setLogs(d.logs || []));
  }, [page, actionType]);

  const actionTypes = ['APPLY_RATE', 'TOGGLE_USER', 'UPDATE_BALANCE', 'DELETE_USER', 'APPROVE_WITHDRAWAL', 'REJECT_WITHDRAWAL', 'CREATE_AD', 'UPDATE_AD', 'DELETE_AD', 'CREATE_COUPON', 'UPDATE_COUPON', 'DELETE_COUPON', 'SEND_NOTIFICATION', 'UPDATE_REFERRAL', 'UPDATE_SETTINGS'];

  return (
    <div className="space-y-4 animate-fadeIn">
      <h1 className="text-2xl font-bold text-white">سجل العمليات</h1>
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => { setActionType(''); setPage(1); }} className={`px-3 py-1.5 rounded-xl text-xs ${!actionType ? 'bg-[#FFD700] text-[#0A0F0D]' : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040]'}`}>الكل</button>
        {actionTypes.map(t => (
          <button key={t} onClick={() => { setActionType(t); setPage(1); }} className={`px-3 py-1.5 rounded-xl text-xs ${actionType === t ? 'bg-[#FFD700] text-[#0A0F0D]' : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040]'}`}>{t.replace(/_/g, ' ')}</button>
        ))}
      </div>
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-[#2A3040]">
            <th className="text-right p-3 text-gray-400">التاريخ</th><th className="text-right p-3 text-gray-400">الأدمن</th><th className="text-right p-3 text-gray-400">العملية</th><th className="text-right p-3 text-gray-400">التفاصيل</th>
          </tr></thead>
          <tbody>
            {logs.length === 0 ? <tr><td colSpan={4} className="text-center py-8 text-gray-500">لا توجد سجلات</td></tr> :
            logs.map(l => (
              <tr key={l.id} className="border-b border-[#2A3040]/50 hover:bg-[#2A3040]/30">
                <td className="p-3 text-gray-300 text-xs">{new Date(l.createdAt).toLocaleString('ar')}</td>
                <td className="p-3 text-white text-xs">{l.adminName}</td>
                <td className="p-3"><span className="px-2 py-1 bg-[#2A3040] rounded-lg text-xs text-[#FFD700]">{l.actionType.replace(/_/g, ' ')}</span></td>
                <td className="p-3 text-gray-400 text-xs max-w-[300px] truncate">{l.details}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="flex justify-center gap-2"><button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300">السابق</button><span className="px-3 py-2 text-gray-400 text-xs">صفحة {page}</span><button onClick={() => setPage(p => p + 1)} className="px-3 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300">التالي</button></div>
    </div>
  );
}
