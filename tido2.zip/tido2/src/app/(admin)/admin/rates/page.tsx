'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';

export default function AdminRatesPage() {
  const { showToast } = useToast();
  const [minRate, setMinRate] = useState('1.2');
  const [maxRate, setMaxRate] = useState('1.7');
  const [logs, setLogs] = useState<{ rate: number; affectedCount: number; appliedBy: string; createdAt: string }[]>([]);

  useEffect(() => {
    fetch('/api/admin/rates').then(r => r.json()).then(d => {
      setMinRate(String(d.settings?.minDailyRate || 1.2));
      setMaxRate(String(d.settings?.maxDailyRate || 1.7));
      setLogs(d.logs || []);
    });
  }, []);

  const applyRate = async () => {
    try {
      const res = await fetch('/api/admin/rates', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'apply', minDailyRate: parseFloat(minRate), maxDailyRate: parseFloat(maxRate) }) });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      fetch('/api/admin/rates').then(r => r.json()).then(d => setLogs(d.logs || []));
    } catch { showToast('حدث خطأ', 'error'); }
  };

  const simulate = async () => {
    try {
      const res = await fetch('/api/admin/rates', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'simulate', minDailyRate: parseFloat(minRate), maxDailyRate: parseFloat(maxRate) }) });
      const data = await res.json();
      showToast(`محاكاة: نسبة ${data.simulatedRate}% - إجمالي التوزيع: $${data.totalDistribution?.toFixed(2)} - مستثمرين: ${data.affectedCount}`, 'info');
    } catch { showToast('حدث خطأ', 'error'); }
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      <h1 className="text-2xl font-bold text-white">إدارة النسب</h1>
      <div className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040] space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div><label className="text-gray-400 text-sm block mb-1">الحد الأدنى (%)</label><input type="number" step="0.1" min="0.5" max="5" value={minRate} onChange={e => setMinRate(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:border-[#FFD700] focus:outline-none" dir="ltr" /></div>
          <div><label className="text-gray-400 text-sm block mb-1">الحد الأقصى (%)</label><input type="number" step="0.1" min="0.5" max="5" value={maxRate} onChange={e => setMaxRate(e.target.value)} className="w-full bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-2.5 text-white text-sm focus:border-[#FFD700] focus:outline-none" dir="ltr" /></div>
        </div>
        <div className="flex gap-3">
          <button onClick={applyRate} className="bg-[#2ECC71] hover:bg-[#25A25A] text-white font-bold px-6 py-2.5 rounded-xl text-sm">تطبيق نسبة اليوم</button>
          <button onClick={simulate} className="bg-[#2A3040] hover:bg-[#3A4050] text-gray-300 font-medium px-6 py-2.5 rounded-xl text-sm">محاكاة التوزيع</button>
        </div>
      </div>
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-[#2A3040]">
            <th className="text-right p-3 text-gray-400">التاريخ</th><th className="text-right p-3 text-gray-400">النسبة</th><th className="text-right p-3 text-gray-400">المستثمرين</th><th className="text-right p-3 text-gray-400">بواسطة</th>
          </tr></thead>
          <tbody>
            {logs.length === 0 ? <tr><td colSpan={4} className="text-center py-8 text-gray-500">لا توجد سجلات</td></tr> :
            logs.map(l => (
              <tr key={l.createdAt} className="border-b border-[#2A3040]/50"><td className="p-3 text-gray-300">{new Date(l.createdAt).toLocaleString('ar')}</td><td className="p-3 text-[#FFD700] font-bold">{l.rate}%</td><td className="p-3 text-white">{l.affectedCount}</td><td className="p-3 text-gray-300">{l.appliedBy}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
