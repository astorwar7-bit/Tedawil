'use client';
import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/contexts/ToastContext';
import {
  Search, Filter, Loader2, ChevronLeft, Headphones, AlertTriangle, Eye,
} from 'lucide-react';

/* ─── types ─── */
interface TicketRow {
  id: string;
  subject: string;
  message: string;
  status: string;
  priority: string;
  category: string;
  createdAt: string;
  updatedAt: string;
  user: { username: string; fullName: string };
  replies: { message: string; createdAt: string; isAdmin: boolean }[];
}

/* ─── labels & colors ─── */
const statusLabels: Record<string, string> = {
  open: 'مفتوحة', in_progress: 'قيد المراجعة', resolved: 'تم الحل', closed: 'مغلقة',
};
const statusColors: Record<string, string> = {
  open: 'bg-[#2ECC71]/15 text-[#2ECC71] border-[#2ECC71]/30',
  in_progress: 'bg-[#3498DB]/15 text-[#3498DB] border-[#3498DB]/30',
  resolved: 'bg-[#FFD700]/15 text-[#FFD700] border-[#FFD700]/30',
  closed: 'bg-[#8899AA]/15 text-[#8899AA] border-[#8899AA]/30',
};
const priorityLabels: Record<string, string> = {
  low: 'منخفضة', medium: 'متوسطة', high: 'عالية', urgent: 'عاجلة',
};
const priorityColors: Record<string, string> = {
  urgent: 'bg-[#EF4444]/15 text-[#EF4444] border-[#EF4444]/30',
  high: 'bg-[#FF8C00]/15 text-[#FF8C00] border-[#FF8C00]/30',
  medium: 'bg-[#3498DB]/15 text-[#3498DB] border-[#3498DB]/30',
  low: 'bg-[#8899AA]/15 text-[#8899AA] border-[#8899AA]/30',
};
const categoryLabels: Record<string, string> = {
  general: 'عام', deposit: 'الإيداع', withdrawal: 'السحب',
  investment: 'الاستثمار', technical: 'تقني', other: 'أخرى',
};

export default function AdminSupportPage() {
  const { showToast } = useToast();
  const router = useRouter();
  const [tickets, setTickets] = useState<TicketRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [openCount, setOpenCount] = useState(0);
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  const fetchTickets = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter) params.set('status', statusFilter);
      if (priorityFilter) params.set('priority', priorityFilter);
      if (categoryFilter) params.set('category', categoryFilter);
      const res = await fetch(`/api/admin/tickets?${params.toString()}`);
      const data = await res.json();
      if (data.success) {
        setTickets(data.data.tickets || []);
        setOpenCount(data.data.openCount || 0);
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
    setLoading(false);
  }, [statusFilter, priorityFilter, categoryFilter, showToast]);

  useEffect(() => { fetchTickets(); }, [fetchTickets]);

  return (
    <div className="animate-fadeIn space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          تذاكر الدعم
          {openCount > 0 && (
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#EF4444] text-white animate-pulse">
              {openCount} مفتوحة
            </span>
          )}
        </h1>
      </div>

      {/* filters */}
      <div className="glass-card rounded-xl p-4 flex flex-wrap gap-3">
        <div className="flex items-center gap-2 text-gray-400 text-xs">
          <Filter size={14} />
          تصفية:
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="input-premium rounded-lg px-3 py-1.5 text-xs text-white min-w-[120px]"
        >
          <option value="">كل الحالات</option>
          <option value="open">مفتوحة</option>
          <option value="in_progress">قيد المراجعة</option>
          <option value="resolved">تم الحل</option>
          <option value="closed">مغلقة</option>
        </select>
        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
          className="input-premium rounded-lg px-3 py-1.5 text-xs text-white min-w-[120px]"
        >
          <option value="">كل الأولويات</option>
          <option value="urgent">عاجلة</option>
          <option value="high">عالية</option>
          <option value="medium">متوسطة</option>
          <option value="low">منخفضة</option>
        </select>
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="input-premium rounded-lg px-3 py-1.5 text-xs text-white min-w-[120px]"
        >
          <option value="">كل التصنيفات</option>
          <option value="general">عام</option>
          <option value="deposit">الإيداع</option>
          <option value="withdrawal">السحب</option>
          <option value="investment">الاستثمار</option>
          <option value="technical">تقني</option>
          <option value="other">أخرى</option>
        </select>
      </div>

      {/* tickets table */}
      <div className="glass-card rounded-xl border border-[#2A3040] overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 size={32} className="animate-spin text-[#FFD700]" />
          </div>
        ) : tickets.length === 0 ? (
          <div className="text-center py-16">
            <Headphones size={48} className="mx-auto mb-3 text-gray-600" />
            <p className="text-gray-400 text-sm">لا توجد تذاكر</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#2A3040] bg-[#12161F]/50">
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">#</th>
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">المستخدم</th>
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">الموضوع</th>
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">التصنيف</th>
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">الأولوية</th>
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">الحالة</th>
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">التاريخ</th>
                  <th className="text-right p-3 text-gray-400 font-medium text-xs">إجراء</th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((t) => (
                  <tr
                    key={t.id}
                    className="border-b border-[#2A3040]/50 hover:bg-[#2A3040]/30 transition-colors"
                  >
                    <td className="p-3 text-gray-500 text-xs font-mono">{t.id.slice(-6)}</td>
                    <td className="p-3 text-white text-xs">
                      {t.user?.fullName || t.user?.username}
                    </td>
                    <td className="p-3 text-gray-300 text-xs max-w-[200px] truncate">
                      {t.subject}
                    </td>
                    <td className="p-3">
                      <span className="text-gray-400 text-xs">{categoryLabels[t.category] || t.category}</span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${priorityColors[t.priority]}`}>
                        {priorityLabels[t.priority]}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${statusColors[t.status]}`}>
                        {statusLabels[t.status]}
                      </span>
                    </td>
                    <td className="p-3 text-gray-400 text-xs whitespace-nowrap">
                      {new Date(t.createdAt).toLocaleDateString('ar')}
                    </td>
                    <td className="p-3">
                      <button
                        onClick={() => router.push(`/admin/support/${t.id}`)}
                        className="p-1.5 rounded-lg bg-[#FFD700]/10 text-[#FFD700] hover:bg-[#FFD700]/20 transition-colors"
                      >
                        <Eye size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
