'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useToast } from '@/contexts/ToastContext';
import {
  ChevronRight, Send, Loader2, User, Mail, Phone, Clock, CheckCircle2,
  Headphones, AlertCircle, MessageSquare,
} from 'lucide-react';

/* ─── types ─── */
interface TicketReply {
  id: string;
  message: string;
  isAdmin: boolean;
  createdAt: string;
  user: { username: string; fullName: string };
}

interface TicketDetail {
  id: string;
  subject: string;
  message: string;
  status: string;
  priority: string;
  category: string;
  createdAt: string;
  updatedAt: string;
  user: { username: string; fullName: string; email: string; phone: string };
  replies: TicketReply[];
}

/* ─── labels & colors ─── */
const statusLabels: Record<string, string> = {
  open: 'مفتوحة', in_progress: 'قيد المراجعة', resolved: 'تم الحل', closed: 'مغلقة',
};
const statusColors: Record<string, string> = {
  open: 'bg-[#2ECC71]/15 text-[#2ECC71] border-[#2ECC71]/30',
  in_progress: 'bg-[#3498DB]/15 text-[#3498DB] border-[#3498DB]/30',
  resolved: 'bg-[#FFD700]/15 text-[#FFD700] border-[#FFD700]/30',
  closed: 'bg-[#8899AA]/15 text-[#8899AA] border-[#8899AA]/30',
};
const priorityLabels: Record<string, string> = {
  low: 'منخفضة', medium: 'متوسطة', high: 'عالية', urgent: 'عاجلة',
};
const priorityColors: Record<string, string> = {
  urgent: 'bg-[#EF4444]/15 text-[#EF4444] border-[#EF4444]/30',
  high: 'bg-[#FF8C00]/15 text-[#FF8C00] border-[#FF8C00]/30',
  medium: 'bg-[#3498DB]/15 text-[#3498DB] border-[#3498DB]/30',
  low: 'bg-[#8899AA]/15 text-[#8899AA] border-[#8899AA]/30',
};
const categoryLabels: Record<string, string> = {
  general: 'عام', deposit: 'الإيداع', withdrawal: 'السحب',
  investment: 'الاستثمار', technical: 'تقني', other: 'أخرى',
};

export default function AdminTicketDetailPage() {
  const { showToast } = useToast();
  const router = useRouter();
  const params = useParams();
  const ticketId = params.id as string;

  const [ticket, setTicket] = useState<TicketDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [replyText, setReplyText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [changingStatus, setChangingStatus] = useState(false);

  const fetchTicket = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/tickets/${ticketId}`);
      const data = await res.json();
      if (data.success) {
        setTicket(data.data.ticket);
      } else {
        showToast(data.error || 'التذكرة غير موجودة', 'error');
        router.push('/admin/support');
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
    setLoading(false);
  };

  useEffect(() => { fetchTicket(); }, [ticketId]);

  const changeStatus = async (newStatus: string) => {
    if (!ticket || ticket.status === newStatus) return;
    setChangingStatus(true);
    try {
      const res = await fetch(`/api/admin/tickets/${ticketId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        showToast(`تم تغيير الحالة إلى ${statusLabels[newStatus]}`, 'success');
        fetchTicket();
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
    setChangingStatus(false);
  };

  const submitReply = async () => {
    if (!replyText.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/admin/tickets/${ticketId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: replyText }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم إرسال الرد', 'success');
        setReplyText('');
        fetchTicket();
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 size={32} className="animate-spin text-[#FFD700]" />
      </div>
    );
  }

  if (!ticket) return null;

  return (
    <div className="animate-fadeIn space-y-4">
      {/* header */}
      <div className="flex items-center gap-3 flex-wrap">
        <button
          onClick={() => router.push('/admin/support')}
          className="p-2 rounded-xl bg-[#1A1F2E] border border-[#2A3040] text-gray-400 hover:text-white transition-colors"
        >
          <ChevronRight size={20} />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-bold text-white truncate">
            <span className="text-gray-500 text-sm font-mono ml-2">#{ticket.id.slice(-6)}</span>
            {ticket.subject}
          </h1>
          <div className="flex flex-wrap items-center gap-2 mt-1">
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColors[ticket.status]}`}>
              {statusLabels[ticket.status]}
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${priorityColors[ticket.priority]}`}>
              {priorityLabels[ticket.priority]}
            </span>
            <span className="text-xs text-gray-500">
              {categoryLabels[ticket.category] || ticket.category}
            </span>
            <span className="text-xs text-gray-500 flex items-center gap-1">
              <Clock size={12} />
              {new Date(ticket.createdAt).toLocaleString('ar')}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* main content */}
        <div className="lg:col-span-2 space-y-4">
          {/* original message */}
          <div className="glass-card rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare size={16} className="text-[#2ECC71]" />
              <span className="text-sm font-medium text-[#2ECC71]">رسالة المستخدم</span>
              <span className="text-xs text-gray-500 mr-auto">
                {new Date(ticket.createdAt).toLocaleString('ar')}
              </span>
            </div>
            <p className="text-gray-300 text-sm whitespace-pre-wrap leading-relaxed">{ticket.message}</p>
          </div>

          {/* conversation */}
          <div className="space-y-3 max-h-[45vh] overflow-y-auto scrollbar-thin">
            {ticket.replies.length === 0 && (
              <div className="text-center py-6 text-gray-500">
                <Headphones size={36} className="mx-auto mb-2 opacity-30" />
                <p className="text-sm">لا توجد ردود بعد</p>
              </div>
            )}
            {ticket.replies.map((reply) => (
              <div
                key={reply.id}
                className={`p-4 rounded-xl ${
                  reply.isAdmin
                    ? 'bg-[#12161F] border border-[#FFD700]/20 ml-4'
                    : 'bg-[#1A1F2E] border border-[#2A3040] mr-4'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                    reply.isAdmin
                      ? 'bg-[#FFD700]/20 text-[#FFD700]'
                      : 'bg-[#2ECC71]/20 text-[#2ECC71]'
                  }`}>
                    {reply.isAdmin ? 'م' : 'أ'}
                  </div>
                  <span className={`text-sm font-medium ${reply.isAdmin ? 'text-[#FFD700]' : 'text-[#2ECC71]'}`}>
                    {reply.isAdmin ? 'فريق الدعم' : (reply.user?.fullName || reply.user?.username)}
                  </span>
                  {reply.isAdmin && <CheckCircle2 size={14} className="text-[#FFD700]" />}
                  <span className="text-xs text-gray-500 mr-auto">
                    {new Date(reply.createdAt).toLocaleString('ar')}
                  </span>
                </div>
                <p className="text-gray-300 text-sm whitespace-pre-wrap leading-relaxed">{reply.message}</p>
              </div>
            ))}
          </div>

          {/* reply form */}
          {ticket.status !== 'closed' && (
            <div className="glass-card p-4 rounded-xl">
              <label className="text-gray-400 text-xs mb-2 block">رد المشرف</label>
              <div className="flex gap-2">
                <textarea
                  placeholder="اكتب ردك هنا..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  className="flex-1 input-premium rounded-xl px-4 py-3 text-white text-sm resize-none h-16"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      submitReply();
                    }
                  }}
                />
                <button
                  onClick={submitReply}
                  disabled={submitting || !replyText.trim()}
                  className="px-4 btn-premium-gold rounded-xl transition-colors disabled:opacity-50 self-end h-16"
                >
                  {submitting ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* sidebar */}
        <div className="space-y-4">
          {/* status control */}
          <div className="glass-card rounded-xl p-4 space-y-3">
            <h3 className="text-white font-medium text-sm">تغيير الحالة</h3>
            <div className="space-y-1.5">
              {(['open', 'in_progress', 'resolved', 'closed'] as const).map((s) => (
                <button
                  key={s}
                  onClick={() => changeStatus(s)}
                  disabled={changingStatus || ticket.status === s}
                  className={`w-full px-3 py-2 rounded-lg text-xs font-medium transition-all flex items-center gap-2 ${
                    ticket.status === s
                      ? statusColors[s]
                      : 'bg-[#12161F] text-gray-400 border border-[#2A3040] hover:border-[#FFD700]/40 hover:text-white'
                  } disabled:opacity-60`}
                >
                  {ticket.status === s && <CheckCircle2 size={12} />}
                  {statusLabels[s]}
                </button>
              ))}
            </div>
          </div>

          {/* user info */}
          <div className="glass-card rounded-xl p-4 space-y-3">
            <h3 className="text-white font-medium text-sm flex items-center gap-2">
              <User size={14} />
              معلومات المستخدم
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2 text-gray-400">
                <User size={12} className="text-gray-500" />
                <span>{ticket.user?.fullName || ticket.user?.username}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Headphones size={12} className="text-gray-500" />
                <span className="font-mono">@{ticket.user?.username}</span>
              </div>
              {ticket.user?.email && (
                <div className="flex items-center gap-2 text-gray-400">
                  <Mail size={12} className="text-gray-500" />
                  <span className="font-mono">{ticket.user.email}</span>
                </div>
              )}
              {ticket.user?.phone && (
                <div className="flex items-center gap-2 text-gray-400">
                  <Phone size={12} className="text-gray-500" />
                  <span dir="ltr">{ticket.user.phone}</span>
                </div>
              )}
            </div>
          </div>

          {/* ticket info */}
          <div className="glass-card rounded-xl p-4 space-y-3">
            <h3 className="text-white font-medium text-sm">معلومات التذكرة</h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-500">التصنيف</span>
                <span className="text-gray-300">{categoryLabels[ticket.category] || ticket.category}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">الأولوية</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${priorityColors[ticket.priority]}`}>
                  {priorityLabels[ticket.priority]}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">تاريخ الإنشاء</span>
                <span className="text-gray-300">{new Date(ticket.createdAt).toLocaleDateString('ar')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">آخر تحديث</span>
                <span className="text-gray-300">{new Date(ticket.updatedAt).toLocaleDateString('ar')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">عدد الردود</span>
                <span className="text-gray-300">{ticket.replies.length}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
