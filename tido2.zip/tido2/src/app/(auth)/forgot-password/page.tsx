'use client';
import { useState, useRef, useEffect } from 'react';
import { User, Lock, Eye, EyeOff, KeyRound, ArrowRight, CheckCircle, ShieldCheck, ShieldAlert, Loader2 } from 'lucide-react';
import Link from 'next/link';

function getPasswordStrength(password: string) {
  let score = 0;
  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  return score;
}

const strengthLabels = ['', 'ضعيفة', 'متوسطة', 'جيدة', 'قوية جداً'];
const strengthColors = ['', '#EF4444', '#E67E22', '#FFD700', '#2ECC71'];

function FloatingOrbs() {
  return (
    <div className="particles-container">
      <div className="absolute top-[8%] right-[12%] w-[280px] h-[280px] rounded-full bg-[#FFD700]/[0.03] blur-[80px] animate-glow-pulse" />
      <div className="absolute bottom-[12%] left-[8%] w-[220px] h-[220px] rounded-full bg-[#2ECC71]/[0.03] blur-[80px] animate-glow-pulse" style={{ animationDelay: '2s' }} />
      <div className="absolute top-[45%] left-[35%] w-[180px] h-[180px] rounded-full bg-[#3498DB]/[0.02] blur-[60px] animate-glow-pulse" style={{ animationDelay: '4s' }} />
      {[...Array(8)].map((_, i) => (
        <div
          key={i}
          className="particle"
          style={{
            left: `${10 + (i * 11)}%`,
            animationDelay: `${i * 1}s`,
            animationDuration: `${8 + (i * 0.7)}s`,
            background: ['#FFD700', '#2ECC71', '#3498DB', '#FFD700', '#2ECC71', '#9B59B6', '#FFD700', '#2ECC71'][i],
            width: `${1.5 + (i % 2)}px`,
            height: `${1.5 + (i % 2)}px`,
          }}
        />
      ))}
    </div>
  );
}

function AnimatedLogo() {
  return (
    <div className="relative w-20 h-20 mx-auto">
      <div className="absolute inset-0 rounded-full border border-dashed border-[#FFD700]/20 logo-ring" />
      <div className="absolute inset-2 rounded-full border border-[#2ECC71]/15 logo-ring" style={{ animationDirection: 'reverse', animationDuration: '14s' }} />
      <div className="absolute inset-4 rounded-full bg-gradient-to-br from-[#FFD700]/10 to-[#2ECC71]/10 animate-breathe" />
      <div className="absolute inset-5 rounded-2xl bg-gradient-to-br from-[#FFD700] via-[#F0C040] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-black text-3xl shadow-lg shadow-[#FFD700]/30">
        T
      </div>
    </div>
  );
}

function StepIndicator({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex items-center gap-2 justify-center mb-2">
      {Array.from({ length: total }, (_, i) => i + 1).map((step) => (
        <div key={step} className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
              current > step
                ? 'bg-gradient-to-br from-[#FFD700] to-[#2ECC71] text-[#0A0F0D]'
                : current === step
                ? 'bg-[#FFD700]/15 text-[#FFD700] border border-[#FFD700]/30'
                : 'bg-[#1A1F2E] text-gray-600 border border-[#2A3040]'
            }`}
          >
            {current > step ? <CheckCircle size={14} /> : step}
          </div>
          {step < total && (
            <div
              className={`w-10 h-[2px] rounded-full transition-all duration-500 ${
                current > step ? 'bg-gradient-to-l from-[#FFD700] to-[#2ECC71]' : 'bg-[#2A3040]'
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
}

function PinInput({ value, onChange, error }: { value: string; onChange: (v: string) => void; error?: string }) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 4);
    onChange(raw);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !value) {
      // Nothing to do for single input
    }
  };

  return (
    <div className="space-y-2">
      <label className="text-gray-400 text-xs font-medium mr-1 block">رمز PIN المكون من 4 أرقام</label>
      <div className="relative">
        <div className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-[#FFD700]/[0.06] flex items-center justify-center">
          <KeyRound size={16} className="text-[#FFD700]/70" />
        </div>
        <input
          ref={inputRef}
          type="password"
          inputMode="numeric"
          maxLength={4}
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          placeholder="• • • •"
          autoFocus
          className={`input-premium pr-12 h-[3.2rem] text-center text-2xl tracking-[0.5em] font-bold placeholder:text-gray-700 placeholder:tracking-[0.3em] placeholder:font-normal ${
            error ? 'border-red-500/50 focus:border-red-500 focus:shadow-[0_0_0_3px_rgba(239,68,68,0.1)]' : ''
          }`}
        />
      </div>
      {error && (
        <div className="flex items-center gap-1.5 mr-1 animate-fadeIn">
          <ShieldAlert size={13} className="text-red-400" />
          <span className="text-red-400 text-[11px]">{error}</span>
        </div>
      )}
      {/* PIN dots visual */}
      <div className="flex justify-center gap-3 mt-1">
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={`w-3 h-3 rounded-full transition-all duration-200 ${
              i < value.length
                ? 'bg-[#FFD700] shadow-[0_0_8px_rgba(255,215,0,0.4)] scale-110'
                : 'bg-[#2A3040] border border-[#3A4050]'
            }`}
          />
        ))}
      </div>
    </div>
  );
}

export default function ForgotPasswordPage() {
  const [step, setStep] = useState(1);
  const [username, setUsername] = useState('');
  const [hasPin, setHasPin] = useState(false);
  const [pin, setPin] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [pinError, setPinError] = useState('');
  const [needsSupport, setNeedsSupport] = useState(false);
  const [success, setSuccess] = useState(false);
  const [focusedField, setFocusedField] = useState('');
  const formRef = useRef<HTMLFormElement>(null);

  const passwordStrength = getPasswordStrength(newPassword);

  // Step 1: Check username
  const handleUsernameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'حدث خطأ أثناء التحقق');
        return;
      }
      setHasPin(data.hasPin);
      if (!data.hasPin) {
        setNeedsSupport(true);
      }
      setStep(2);
    } catch {
      setError('تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً');
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Submit PIN + new password
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pin || pin.length !== 4) {
      setPinError('يرجى إدخال رمز PIN المكون من 4 أرقام');
      return;
    }
    if (newPassword.length < 8) {
      setError('كلمة السر يجب أن تكون 8 أحرف على الأقل');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('كلمتا السر غير متطابقتين');
      return;
    }
    setError('');
    setPinError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: username.trim(),
          pin,
          newPassword,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.needsSupport) {
          setNeedsSupport(true);
          setStep(3);
          return;
        }
        if (res.status === 401) {
          setPinError(data.error || 'رمز PIN غير صحيح');
          return;
        }
        setError(data.error || 'حدث خطأ أثناء إعادة تعيين كلمة السر');
        return;
      }
      setSuccess(true);
      setStep(3);
    } catch {
      setError('تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً');
    } finally {
      setLoading(false);
    }
  };

  // Calculate total steps
  const totalSteps = hasPin ? 3 : 2;

  return (
    <div className="min-h-[100dvh] flex bg-[#0A0F0D] relative overflow-hidden">
      <FloatingOrbs />
      {/* Mesh grid */}
      <div
        className="absolute inset-0 opacity-[0.015] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,215,0,0.5) 1px, transparent 0)`,
          backgroundSize: '40px 40px',
        }}
      />

      <div className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8 relative z-10">
        {/* Mobile background orbs */}
        <div className="lg:hidden absolute top-[-10%] right-[-20%] w-[300px] h-[300px] rounded-full bg-[#FFD700]/[0.03] blur-[80px] animate-glow-pulse" />
        <div className="lg:hidden absolute bottom-[-5%] left-[-15%] w-[250px] h-[250px] rounded-full bg-[#2ECC71]/[0.03] blur-[80px] animate-glow-pulse" style={{ animationDelay: '2s' }} />

        <div className="w-full max-w-[420px]">
          {/* Mobile Logo */}
          <div className="lg:hidden text-center mb-8 animate-slide-up">
            <div className="relative w-16 h-16 mx-auto mb-3">
              <div className="absolute inset-0 rounded-full border border-dashed border-[#FFD700]/20 logo-ring" />
              <div className="absolute inset-2 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-black text-xl shadow-lg shadow-[#FFD700]/20">
                T
              </div>
            </div>
            <h1 className="text-3xl font-bold gradient-text-animated">تداولاي</h1>
            <p className="text-gray-500 text-sm mt-1">منصتك الآمنة للاستثمار الرقمي</p>
          </div>

          {/* Form Card */}
          <div className="relative animate-slide-up" style={{ animationDelay: '0.15s' }}>
            {/* Card glow */}
            <div className="absolute -inset-[2px] bg-gradient-to-br from-[#FFD700]/15 via-[#2ECC71]/5 to-[#3498DB]/10 rounded-[1.15rem] blur-xl opacity-50" />

            <div className="relative z-10 rounded-2xl overflow-hidden">
              {/* Card inner gradient bg */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#141820] via-[#12161F] to-[#0F1318]" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#FFD700]/[0.02] to-transparent" />

              <div className="relative p-7 sm:p-9 space-y-5">
                {/* Header */}
                <div className="text-center mb-1">
                  {success ? (
                    <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-[#2ECC71]/10 border border-[#2ECC71]/15 flex items-center justify-center">
                      <ShieldCheck size={28} className="text-[#2ECC71]" />
                    </div>
                  ) : needsSupport && !hasPin ? (
                    <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-orange-500/10 border border-orange-500/15 flex items-center justify-center">
                      <ShieldAlert size={28} className="text-orange-400" />
                    </div>
                  ) : (
                    <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-[#FFD700]/10 via-[#2ECC71]/5 to-[#FFD700]/10 border border-[#FFD700]/10 flex items-center justify-center">
                      <KeyRound size={24} className="text-[#FFD700]" />
                    </div>
                  )}
                  <h2 className="text-2xl font-bold text-white mb-1">
                    {success ? 'تم تغيير كلمة السر!' : 'نسيت كلمة السر؟'}
                  </h2>
                  <p className="text-gray-500 text-sm">
                    {success
                      ? 'تم تحديث كلمة السر بنجاح، يمكنك الآن تسجيل الدخول'
                      : needsSupport && !hasPin
                      ? 'لا يوجد رمز PIN مُعَدّ لحسابك'
                      : 'أدخل بياناتك لإعادة تعيين كلمة السر'}
                  </p>
                </div>

                {/* Error */}
                {error && (
                  <div className="animate-scaleIn bg-red-500/[0.06] border border-red-500/15 rounded-xl p-3.5 flex items-center gap-2.5">
                    <div className="w-6 h-6 rounded-full bg-red-500/10 flex items-center justify-center shrink-0">
                      <div className="w-2 h-2 rounded-full bg-red-400" />
                    </div>
                    <span className="text-red-400 text-sm">{error}</span>
                  </div>
                )}

                {/* Support message */}
                {needsSupport && !hasPin && !success && (
                  <div className="bg-orange-500/[0.06] border border-orange-500/15 rounded-xl p-4 space-y-2">
                    <p className="text-orange-300 text-sm">
                      لم تقم بإعداد رمز PIN لحماية حسابك. لا يمكننا إعادة تعيين كلمة السر تلقائياً.
                    </p>
                    <p className="text-gray-400 text-xs">
                      يرجى التواصل مع الدعم الفني عبر صفحة الدعم في حسابك أو البريد الإلكتروني الرسمي.
                    </p>
                  </div>
                )}

                {/* Success state */}
                {success ? (
                  <div className="space-y-4">
                    <div className="bg-[#2ECC71]/[0.06] border border-[#2ECC71]/15 rounded-xl p-4">
                      <div className="flex items-center gap-2.5 mb-2">
                        <CheckCircle size={18} className="text-[#2ECC71]" />
                        <span className="text-[#2ECC71] font-semibold text-sm">تم بنجاح</span>
                      </div>
                      <p className="text-gray-400 text-xs">
                        تم تحديث كلمة السر الخاصة بحسابك. يرجى تسجيل الدخول باستخدام كلمة السر الجديدة.
                      </p>
                    </div>
                    <Link
                      href="/"
                      className="btn-premium-gold h-[3.2rem] text-[15px] flex items-center justify-center gap-2.5 w-full"
                    >
                      <ArrowRight size={18} />
                      <span className="font-semibold">العودة لتسجيل الدخول</span>
                    </Link>
                  </div>
                ) : needsSupport ? (
                  <Link
                    href="/"
                    className="btn-premium-gold h-[3.2rem] text-[15px] flex items-center justify-center gap-2.5 w-full"
                  >
                    <ArrowRight size={18} />
                    <span className="font-semibold">العودة لتسجيل الدخول</span>
                  </Link>
                ) : (
                  <>
                    {/* Step indicator */}
                    <StepIndicator current={step} total={totalSteps} />

                    {/* Step 1: Username */}
                    {step === 1 && (
                      <form onSubmit={handleUsernameSubmit} className="space-y-5 animate-fadeIn">
                        <div className="space-y-1.5">
                          <label className="text-gray-400 text-xs font-medium mr-1 block">
                            اسم المستخدم أو البريد الإلكتروني
                          </label>
                          <div className={`relative group transition-all duration-300 ${focusedField === 'username' ? 'scale-[1.01]' : ''}`}>
                            <div
                              className="absolute right-3.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-[#FFD700]/[0.06] flex items-center justify-center transition-colors duration-300"
                              style={focusedField === 'username' ? { background: 'rgba(255,215,0,0.12)' } : {}}
                            >
                              <User size={16} className="text-[#FFD700]/70" />
                            </div>
                            <input
                              type="text"
                              placeholder="أدخل اسم المستخدم أو البريد"
                              value={username}
                              onChange={(e) => setUsername(e.target.value)}
                              onFocus={() => setFocusedField('username')}
                              onBlur={() => setFocusedField('')}
                              required
                              autoFocus
                              className="input-premium pr-12 h-[3rem] text-[15px] placeholder:text-gray-600"
                              autoComplete="username"
                            />
                          </div>
                        </div>
                        <button
                          type="submit"
                          disabled={loading || !username.trim()}
                          className="btn-premium-gold h-[3.2rem] text-[15px] flex items-center justify-center gap-2.5 disabled:opacity-60 disabled:cursor-not-allowed w-full"
                        >
                          {loading ? (
                            <>
                              <div className="w-5 h-5 border-2 border-[#0A0F0D]/30 border-t-[#0A0F0D] rounded-full animate-spin" />
                              <span className="font-semibold">جاري التحقق...</span>
                            </>
                          ) : (
                            <>
                              <span className="font-semibold">التحقق</span>
                              <ArrowRight size={18} />
                            </>
                          )}
                        </button>
                      </form>
                    )}

                    {/* Step 2: PIN + New Password */}
                    {step === 2 && hasPin && (
                      <form onSubmit={handleResetSubmit} className="space-y-4 animate-fadeIn">
                        {/* PIN Input */}
                        <PinInput value={pin} onChange={(v) => { setPin(v); setPinError(''); }} error={pinError} />

                        {/* New Password */}
                        <div className="space-y-1.5">
                          <label className="text-gray-400 text-xs font-medium mr-1 block">كلمة السر الجديدة</label>
                          <div className={`relative group transition-all duration-300 ${focusedField === 'newPass' ? 'scale-[1.01]' : ''}`}>
                            <div
                              className="absolute right-3.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-[#2ECC71]/[0.06] flex items-center justify-center transition-colors duration-300"
                              style={focusedField === 'newPass' ? { background: 'rgba(46,204,113,0.12)' } : {}}
                            >
                              <Lock size={16} className="text-[#2ECC71]/70" />
                            </div>
                            <input
                              type={showPass ? 'text' : 'password'}
                              placeholder="8 أحرف على الأقل، حرف كبير ورقم"
                              value={newPassword}
                              onChange={(e) => setNewPassword(e.target.value)}
                              onFocus={() => setFocusedField('newPass')}
                              onBlur={() => setFocusedField('')}
                              required
                              className="input-premium pr-12 pl-12 h-[3rem] text-[15px] placeholder:text-gray-600"
                              autoComplete="new-password"
                            />
                            <button
                              type="button"
                              onClick={() => setShowPass(!showPass)}
                              className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg flex items-center justify-center text-gray-500 hover:text-gray-300 hover:bg-white/[0.04] transition-all"
                              tabIndex={-1}
                            >
                              {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                            </button>
                          </div>
                          {/* Password strength */}
                          {newPassword.length > 0 && (
                            <div className="mt-2 space-y-1.5">
                              <div className="flex gap-1.5">
                                {[...Array(4)].map((_, i) => (
                                  <div
                                    key={i}
                                    className="h-1 flex-1 rounded-full transition-all duration-400"
                                    style={{
                                      background: i < passwordStrength ? strengthColors[passwordStrength] : '#2A3040',
                                      boxShadow: i < passwordStrength ? `0 0 8px ${strengthColors[passwordStrength]}30` : 'none',
                                    }}
                                  />
                                ))}
                              </div>
                              <p className="text-[11px]" style={{ color: strengthColors[passwordStrength] || '#6B7280' }}>
                                {strengthLabels[passwordStrength]}
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Confirm Password */}
                        <div className="space-y-1.5">
                          <label className="text-gray-400 text-xs font-medium mr-1 block">تأكيد كلمة السر الجديدة</label>
                          <div className={`relative group transition-all duration-300 ${focusedField === 'confirmPass' ? 'scale-[1.01]' : ''}`}>
                            <div
                              className="absolute right-3.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-[#9B59B6]/[0.06] flex items-center justify-center transition-colors duration-300"
                              style={focusedField === 'confirmPass' ? { background: 'rgba(155,89,182,0.12)' } : {}}
                            >
                              <Lock size={16} className="text-[#9B59B6]/70" />
                            </div>
                            <input
                              type={showPass ? 'text' : 'password'}
                              placeholder="أعد كتابة كلمة السر الجديدة"
                              value={confirmPassword}
                              onChange={(e) => setConfirmPassword(e.target.value)}
                              onFocus={() => setFocusedField('confirmPass')}
                              onBlur={() => setFocusedField('')}
                              required
                              className={`input-premium pr-12 h-[3rem] text-[15px] placeholder:text-gray-600 ${
                                confirmPassword && newPassword === confirmPassword ? 'border-[#2ECC71]/30' : ''
                              }`}
                              autoComplete="new-password"
                            />
                            {confirmPassword && newPassword === confirmPassword && (
                              <CheckCircle size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#2ECC71]" />
                            )}
                          </div>
                        </div>

                        <button
                          type="submit"
                          disabled={loading || !pin || pin.length !== 4 || !newPassword || !confirmPassword}
                          className="btn-premium-gold h-[3.2rem] text-[15px] flex items-center justify-center gap-2.5 disabled:opacity-60 disabled:cursor-not-allowed w-full mt-2"
                        >
                          {loading ? (
                            <>
                              <div className="w-5 h-5 border-2 border-[#0A0F0D]/30 border-t-[#0A0F0D] rounded-full animate-spin" />
                              <span className="font-semibold">جاري التحديث...</span>
                            </>
                          ) : (
                            <>
                              <KeyRound size={18} />
                              <span className="font-semibold">تحديث كلمة السر</span>
                            </>
                          )}
                        </button>
                      </form>
                    )}
                  </>
                )}

                {/* Divider */}
                {!success && (
                  <div className="flex items-center gap-3 py-1">
                    <div className="flex-1 gradient-divider" />
                    <span className="text-gray-600 text-[11px]">أو</span>
                    <div className="flex-1 gradient-divider" />
                  </div>
                )}

                {/* Back to login */}
                <Link
                  href="/"
                  className="flex items-center justify-center gap-2 py-3 rounded-xl text-sm text-gray-400 hover:text-[#FFD700] hover:bg-[#FFD700]/[0.04] transition-all duration-300 group"
                >
                  <ArrowRight size={14} className="text-[#FFD700]/60 group-hover:text-[#FFD700] group-hover:-translate-x-0.5 transition-all" />
                  <span>العودة لتسجيل الدخول</span>
                </Link>
              </div>
            </div>
          </div>

          {/* Bottom Trust Indicators */}
          <div className="flex items-center justify-center gap-4 mt-8 animate-slide-up" style={{ animationDelay: '0.4s' }}>
            {[
              { color: '#2ECC71', label: 'اتصال آمن' },
              { color: '#FFD700', label: 'تشفير 256-bit' },
              { color: '#3498DB', label: 'حماية متقدمة' },
            ].map((t) => (
              <div key={t.label} className="flex items-center gap-1.5">
                <div className="w-1 h-1 rounded-full" style={{ background: `${t.color}60` }} />
                <span className="text-gray-600 text-[11px]">{t.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
