'use client';

import { Shield, ArrowRight } from 'lucide-react';
import Link from 'next/link';

export default function TermsPage() {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-[#0A0F0D]" dir="rtl">
      {/* Background effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[5%] right-[10%] w-[300px] h-[300px] rounded-full bg-[#FFD700]/[0.03] blur-[80px] animate-glow-pulse" />
        <div className="absolute bottom-[10%] left-[10%] w-[250px] h-[250px] rounded-full bg-[#2ECC71]/[0.03] blur-[80px] animate-glow-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex items-start justify-center px-4 py-8 sm:py-12">
        <div className="w-full max-w-2xl animate-fadeIn">
          {/* Header */}
          <div className="text-center mb-8 animate-slide-up">
            <div className="relative w-16 h-16 mx-auto mb-4">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#FFD700]/15 to-[#FFD700]/5 border border-[#FFD700]/15 flex items-center justify-center">
                <Shield size={28} className="text-[#FFD700]" />
              </div>
              <div className="absolute -inset-1 rounded-2xl bg-[#FFD700]/5 blur-xl" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold gradient-text-animated mb-2">شروط الاستخدام</h1>
            <p className="text-gray-500 text-sm">آخر تحديث: أبريل ٢٠٢٦</p>
          </div>

          {/* Content Card */}
          <div className="glass-card p-6 sm:p-8 space-y-8">
            {/* 1. مقدمة */}
            <section className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">١</span>
                مقدمة
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  مرحباً بك في منصة تداولاي للاستثمار الذكي. تحكم شروط الاستخدام هذه ("الشروط") وصولك واستخدامك لمنصة تداولاي والخدمات المرتبطة بها، بما في ذلك الموقع الإلكتروني والتطبيقات وجميع الخدمات المقدمة عبر المنصة. باستخدامك للمنصة فإنك توافق صراحةً على الالتزام بهذه الشروط والأحكام.
                </p>
                <p>
                  تُعدّ هذه الشروط اتفاقية قانونية ملزمة بينك وبين تداولاي. يرجى قراءتها بعناية تامة قبل البدء في استخدام المنصة. إذا كنت لا توافق على أي من هذه الشروط، فيجب عليك التوقف عن استخدام المنصة فوراً. نحتفظ بالحق في تعديل هذه الشروط في أي وقت وسنقوم بإشعارك بأي تغييرات جوهرية.
                </p>
                <p>
                  تهدف منصة تداولاي إلى توفير بيئة استثمارية آمنة وشفافة للمستخدمين في مختلف أنحاء العالم العربي والعالم. نسعى لتحقيق أعلى معايير الجودة والأمان في جميع خدماتنا المقدمة، مع الالتزام الكامل بالأنظمة والقوانين المعمول بها.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 2. شروط التسجيل */}
            <section className="animate-slide-up" style={{ animationDelay: '0.15s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">٢</span>
                شروط التسجيل
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  يجب أن يكون عمرك ١٨ عاماً أو أكثر لتتمكن من التسجيل في المنصة واستخدام خدماتها. يُلزمك تقديم بيانات صحيحة ودقيقة وكاملة عند إنشاء حسابك، بما في ذلك الاسم الحقيقي وعنوان البريد الإلكتروني ورقم الهاتف. أي معلومات مضللة أو غير صحيحة قد تؤدي إلى تعليق أو إلغاء حسابك.
                </p>
                <p>
                  أنت المسؤول الوحيد عن الحفاظ على سرية بيانات حسابك وكلمة المرور الخاصة بك. لا يجوز لك مشاركة بيانات الدخول مع أي طرف ثالث أو السماح لأي شخص آخر باستخدام حسابك. يجب عليك إخطارنا فوراً في حال اشتباهك بأي استخدام غير مصرح به لحسابك أو أي اختراق أمني.
                </p>
                <p>
                  يُحظر على كل مستخدم إنشاء أكثر من حساب واحد على المنصة. في حال اكتشاف وجود حسابات متعددة لنفس المستخدم، نحتفظ بالحق في تعليق أو إغلاق جميع الحسابات المرتبطة دون إنذار مسبق، مع احتمال مصادرة الأرباح المستحقة.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 3. قواعد الاستثمار */}
            <section className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center text-[#2ECC71] text-xs font-bold">٣</span>
                قواعد الاستثمار
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  تخضع جميع عمليات الاستثمار على المنصة للشروط والأحكام الخاصة بكل خطة استثمارية. تختلف معدلات العائد اليومي والحد الأدنى والأقصى للاستثمار حسب نوع الخطة المختارة. يجب عليك مراجعة تفاصيل كل خطة بعناية قبل اتخاذ قرار الاستثمار، والنظر في مدى تحملك للمخاطر المالية.
                </p>
                <p>
                  يُحقق الاستثمار عائداً يومياً وفقاً للنسبة المحددة في خطة الاستثمار المختارة. يتم احتساب الأرباح بشكل يومي وإضافتها إلى رصيدك المتاح. تُستمر عملية احتساب الأرباح طوال مدة الخطة الاستثمارية المحددة. يرجى الملاحظة أن جميع الأرباح المعلنة تقريبية وقد تتأثر بعوامل السوق المختلفة.
                </p>
                <p>
                  لا تضمن تداولاي أي عائد محدد أو مضمون من الاستثمار. الاستثمار ينطوي دائماً على درجة من المخاطر، وقد لا تسترد المبلغ المستثمر بالكامل. ننصحك بشدة بعدم استثمار أموال لا يمكنك تحمل خسارتها والبحث عن المشورة المالية المتخصصة قبل اتخاذ أي قرارات استثمارية.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 4. الإيداع والسحب */}
            <section className="animate-slide-up" style={{ animationDelay: '0.25s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">٤</span>
                الإيداع والسحب
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  تدعم المنصة عدة طرق للإيداع والسحب تشمل العملات الرقمية (USDT عبر شبكات TRC20 و ERC20) والتحويل المصرفي. يتم معالجة طلبات الإيداع خلال فترة زمنية محددة بعد التحقق من المعاملة. قد تختلف مدة المعالجة حسب طريقة الدفع المختارة وشبكة البلوكتشين المستخدمة.
                </p>
                <p>
                  يُشترط استكمال عملية التحقق من الهوية (KYC) قبل السماح بعمليات السحب. يتم معالجة طلبات السحب خلال مدة تتراوح بين ٢٤ إلى ٧٢ ساعة عمل بعد الموافقة عليها. يحق للمنصة رفض أي طلب سحب في حال وجود شكوك حول مصدر الأموال أو مخالفة لشروط الاستخدام.
                </p>
                <p>
                  تحتفظ تداولاي بالحق في فرض رسوم معالجة على عمليات الإيداع والسحب وفقاً للجدول المعتمد. يتم إفصاح جميع الرسوم المطبقة بوضوح قبل تأكيد أي عملية مالية. قد تخضع عمليات السحب الكبيرة لعملية مراجعة إضافية لأغراض الأمان والامتثال.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 5. مسؤولية المستخدم */}
            <section className="animate-slide-up" style={{ animationDelay: '0.3s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center text-[#2ECC71] text-xs font-bold">٥</span>
                مسؤولية المستخدم
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  تتحمل مسؤولية كاملة عن جميع الأنشطة التي تتم من خلال حسابك على المنصة. يشمل ذلك جميع عمليات الاستثمار والإيداع والسحب وأي تفاعلات أخرى مع المنصة. لا تتحمل تداولاي أي مسؤولية عن الخسائر الناتجة عن أخطاء المستخدم أو إهماله أو عدم التزامه بهذه الشروط.
                </p>
                <p>
                  يُمنع منعاً باتاً استخدام المنصة لأي أغراض غير قانونية أو الاحتيالية، بما في ذلك غسل الأموال وتمويل الإرهاب والتهرب الضريبي. تلتزم تداولاي بالقوانين واللوائح المالية الدولية وتتعاون مع الجهات الرقابية المختصة في حال وجود أي اشتباه.
                </p>
                <p>
                  يُحظر على المستخدم محاولة التلاعب بالمنصة أو استغلال الثغرات الأمنية أو استخدام برامج آلية غير مصرح بها. في حال اكتشاف أي سلوك مخالف، نحتفظ بالحق في اتخاذ الإجراءات اللازمة بما في ذلك تعليق الحساب نهائياً وملاحقة المستخدم قانونياً.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 6. حماية الحساب */}
            <section className="animate-slide-up" style={{ animationDelay: '0.35s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">٦</span>
                حماية الحساب
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  تتخذ تداولاي جميع التدابير الأمنية اللازمة لحماية بياناتك وأموالك، بما في ذلك تشفير البيانات بتقنية AES-256 وبروتوكولات الأمان المتقدمة. نستخدم أنظمة مراقبة مستمرة للكشف عن أي نشاط مشبوه والتصدي له فوراً.
                </p>
                <p>
                  يُنصح المستخدمون بشدة بتفعيل المصادقة الثنائية (2FA) وتعيين رمز PIN إضافي لتعزيز أمان حساباتهم. كما يجب استخدام كلمات مرور قوية وفريدة وتغييرها بشكل دوري. لن يطلب منك ممثلو تداولاي أبداً كلمة مرورك أو رمز PIN الخاص بك.
                </p>
                <p>
                  في حال فقدانك للوصول إلى حسابك أو اشتباهك بوجود اختراق، يجب عليك التواصل مع فريق الدعم الفني فوراً عبر البريد الإلكتروني أو نموذج الدعم في المنصة. سنتخذ جميع الإجراءات اللازمة لاستعادة أمان حسابك في أسرع وقت ممكن.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 7. الإنهاء والتعليق */}
            <section className="animate-slide-up" style={{ animationDelay: '0.4s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center text-[#2ECC71] text-xs font-bold">٧</span>
                الإنهاء والتعليق
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  يحق لك إغلاق حسابك في أي وقت عن طريق التواصل مع فريق الدعم الفني. في حال إغلاق الحساب برغبتك، يجب عليك سحب جميع الأرصدة المتاحة قبل تقديم طلب الإغلاق. لن نتمكن من استعادة حسابك بعد اكتمال عملية الإغلاق النهائي.
                </p>
                <p>
                  تحتفظ تداولاي بالحق في تعليق أو إلغاء حسابك دون إنذار مسبق في الحالات التالية: مخالفة شروط الاستخدام، النشاط المشبوه، تقديم معلومات مضللة، المشاركة في أنشطة غير قانونية، أو أي سلوك يضر بالمنصة أو بمستخدميها الآخرين.
                </p>
                <p>
                  في حال تعليق الحساب، قد يتم تجميد جميع الأرصدة والعمليات الجارية حتى يتم الانتهاء من عملية المراجعة. إذا تم تأكيد المخالفة، قد لا يتم السماح بسحب الأرصدة المتبقية. يحق للمستخدم المتضرر الطعن في قرار التعليق خلال ٣٠ يوماً من تاريخ الإخطار.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 8. القوانين المطبقة */}
            <section className="animate-slide-up" style={{ animationDelay: '0.45s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">٨</span>
                القوانين المطبقة
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  تخضع هذه الشروط والأحكام وتُفسّر وفقاً للقوانين المعمول بها. في حال نشوء أي نزاع يتعلق بهذه الشروط أو استخدام المنصة، يتم حله بالطرق الودية أولاً. في حال تعذر التوصل إلى حل ودي، يُحال النزاع إلى المحاكم المختصة.
                </p>
                <p>
                  تلتزم تداولاي بالامتثال لجميع القوانين واللوائح المالية الدولية والمحلية المعمول بها في الولايات القضائية التي تعمل فيها. يشمل ذلك قوانين مكافحة غسل الأموال (AML) ومعرفة العميل (KYC) وقوانين حماية البيانات الشخصية.
                </p>
                <p>
                  إذا تبين أن أي حكم من أحكام هذه الشروط غير صالح أو غير قابل للتنفيذ بموجب القانون المعمول به، فإن ذلك لا يؤثر على صلاحية وقابلية تنفيذ الأحكام الأخرى. تظل الشروط المتبقية سارية المفعول بالكامل. نعمل باستمرار على تحديث شروطنا لتتوافق مع أحدث المتطلبات القانونية.
                </p>
              </div>
            </section>
          </div>

          {/* Back Link */}
          <div className="text-center mt-8 animate-slide-up" style={{ animationDelay: '0.5s' }}>
            <Link
              href="/register"
              className="inline-flex items-center gap-2 text-gray-400 hover:text-[#FFD700] transition-colors text-sm"
            >
              <ArrowRight size={16} />
              العودة
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
