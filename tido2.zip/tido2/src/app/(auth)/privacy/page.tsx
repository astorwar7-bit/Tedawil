'use client';

import { Lock, ArrowRight } from 'lucide-react';
import Link from 'next/link';

export default function PrivacyPage() {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-[#0A0F0D]" dir="rtl">
      {/* Background effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[8%] left-[10%] w-[280px] h-[280px] rounded-full bg-[#2ECC71]/[0.03] blur-[80px] animate-glow-pulse" />
        <div className="absolute bottom-[12%] right-[8%] w-[220px] h-[220px] rounded-full bg-[#FFD700]/[0.03] blur-[80px] animate-glow-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex items-start justify-center px-4 py-8 sm:py-12">
        <div className="w-full max-w-2xl animate-fadeIn">
          {/* Header */}
          <div className="text-center mb-8 animate-slide-up">
            <div className="relative w-16 h-16 mx-auto mb-4">
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-[#2ECC71]/15 to-[#2ECC71]/5 border border-[#2ECC71]/15 flex items-center justify-center">
                <Lock size={28} className="text-[#2ECC71]" />
              </div>
              <div className="absolute -inset-1 rounded-2xl bg-[#2ECC71]/5 blur-xl" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold gradient-text-animated mb-2">سياسة الخصوصية</h1>
            <p className="text-gray-500 text-sm">آخر تحديث: أبريل ٢٠٢٦</p>
          </div>

          {/* Content Card */}
          <div className="glass-card p-6 sm:p-8 space-y-8">
            {/* 1. جمع البيانات */}
            <section className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center text-[#2ECC71] text-xs font-bold">١</span>
                جمع البيانات
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  نقوم بجمع البيانات الشخصية التي تقدمها لنا طوعاً عند التسجيل في المنصة، وتشمل: الاسم الحقيقي واسم المستخدم وعنوان البريد الإلكتروني ورقم الهاتف وكلمة المرور المشفرة. كما نقوم بجمع بيانات إضافية عند إكمال عملية التحقق من الهوية (KYC) مثل صورة الهوية الشخصية وصورة شخصية.
                </p>
                <p>
                  نجمع تلقائياً بعض البيانات الفنية عند استخدامك للمنصة، بما في ذلك: عنوان بروتوكول الإنترنت (IP)، نوع المتصفح ونظام التشغيل، صفحات التصفح والتفاعلات، الأوقات والتواريخ للزيارات، ومعرفات الأجهزة المستخدمة. تُستخدم هذه البيانات لتحسين أداء المنصة وتوفير تجربة استخدام أفضل.
                </p>
                <p>
                  فيما يتعلق بالبيانات المالية، نقوم بتسجيل جميع عمليات الإيداع والسحب والاستثمار والأرباح المرتبطة بحسابك. تُحفظ هذه البيانات بأمان تام لأغراض المحاسبة والامتثال التنظيمي وضمان دقة المعاملات المالية التي تتم عبر المنصة.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 2. استخدام البيانات */}
            <section className="animate-slide-up" style={{ animationDelay: '0.15s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">٢</span>
                استخدام البيانات
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  نستخدم بياناتك الشخصية لتوفير وتحسين خدمات المنصة، بما يشمل: إنشاء وإدارة حسابك الاستثماري، معالجة العمليات المالية والإيداعات والسحوبات، احتساب وتوزيع الأرباح اليومية، التواصل معك بخصوص حسابك وتحديثات الخدمة، وتقديم الدعم الفني عند الحاجة.
                </p>
                <p>
                  قد نستخدم بياناتك لتحليل أنماط الاستخدام وتحسين تجربة المستخدم بشكل عام. يشمل ذلك تحسين واجهة المنصة وتطوير ميزات جديدة وتخصيص المحتوى العروض الاستثمارية بناءً على اهتماماتك. لا نبيع بياناتك الشخصية لأطراف ثالثة تحت أي ظرف من الظروف.
                </p>
                <p>
                  نستخدم البيانات المجمّعة بشكل مجهول الهوية لأغراض إحصائية وتحليلية، مثل إعداد تقارير الأداء وفهم اتجاهات الاستخدام العام. لا يمكن من خلال هذه البيانات المجهولة التعرف على هويتك الشخصية أو ربطها بحسابك المحدد على المنصة.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 3. مشاركة البيانات */}
            <section className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center text-[#2ECC71] text-xs font-bold">٣</span>
                مشاركة البيانات
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  لا نقوم بمشاركة بياناتك الشخصية مع أطراف ثالثة إلا في الحالات الاستثنائية التالية: بموافقتك الصريحة، أو استجابةً لأمر قضائي أو طلب رسمي من جهة حكومية مختصة، أو لحماية حقوق المنصة ومستخدميها، أو في حال الضرورة لتنفيذ عمليات مالية عبر مزودي خدمات الدفع المعتمدين.
                </p>
                <p>
                  قد نتعاون مع مزودي خدمات موثوقين لمساعدتنا في تشغيل المنصة وتقديم الخدمات لك، مثل مزودي خدمات الاستضافة ومعالجة الدفع والتحقق من الهوية. يلتزم هؤلاء المزودون باتفاقيات سرية صارمة ولا يُسمح لهم باستخدام بياناتك إلا لأغراض تقديم الخدمات المطلوبة.
                </p>
                <p>
                  في حال وقوع اندماج أو استحواذ أو بيع أصول تتعلق بالمنصة، قد يتم نقل بياناتك الشخصية إلى الكيان الجديد. سنقوم بإشعارك بأي تغيير جوهري في ملكية البيانات عبر البريد الإلكتروني أو إشعار واضح على المنصة قبل نفاذ أي نقل فعلي.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 4. حماية البيانات */}
            <section className="animate-slide-up" style={{ animationDelay: '0.25s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">٤</span>
                حماية البيانات
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  نولي أهمية قصوى لحماية بياناتك الشخصية والمالية. نطبق أعلى معايير الأمان التقنية المتاحة، بما في ذلك تشفير AES-256 لجميع البيانات الحساسة، وبروتوكولات نقل آمنة (SSL/TLS) لجميع الاتصالات، وجدران حماية متقدمة وأنظمة كشف التسلل لمنع الوصول غير المصرح به.
                </p>
                <p>
                  نقوم بإجراء عمليات تدقيق أمني دورية وفحوصات اختراق منتظمة للتأكد من فعالية إجراءات الحماية المطبقة. كما نحتفظ بنسخ احتياطية مشفرة ومؤمّنة لجميع البيانات في مواقع جغرافية متعددة لضمان استمرارية الخدمة وحماية البيانات من أي فقدان محتمل.
                </p>
                <p>
                  يقتصر الوصول إلى بياناتك الشخصية على الموظفين المصرح لهم فقط وبالقدر الضروري لأداء مهامهم. يخضع جميع الموظفين لاتفاقيات سرية صارمة ويتلقون تدريباً دورياً على أفضل ممارسات حماية البيانات وأمن المعلومات المتقدمة.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 5. ملفات تعريف الارتباط */}
            <section className="animate-slide-up" style={{ animationDelay: '0.3s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center text-[#2ECC71] text-xs font-bold">٥</span>
                ملفات تعريف الارتباط
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  نستخدم ملفات تعريف الارتباط (Cookies) وتقنيات مشابهة لتحسين تجربتك على المنصة. تُستخدم ملفات تعريف الارتباط الأساسية لضمان عمل المنصة بشكل صحيح، مثل الحفاظ على جلسة تسجيل الدخول وتذكر تفضيلاتك اللغوية وإعدادات العرض.
                </p>
                <p>
                  نستخدم أيضاً ملفات تعريف الارتباط التحليلية لفهم كيفية تفاعلك مع المنصة. تساعدنا هذه البيانات في تحسين أداء المنصة وتحديد المجالات التي تحتاج إلى تطوير. يمكنك التحكم في إعدادات ملفات تعريف الارتباط من خلال إعدادات المتصفح الخاص بك.
                </p>
                <p>
                  نستخدم ملفات تعريف الارتباط الوظيفية لتزويدك بميزات محسّنة مثل تذكر تفاصيل تسجيل الدخول الأخيرة وتوفير محتوى مخصص. لا نستخدم ملفات تعريف الارتباط الإعلانية أو التتبعية التي تنتمي لأطراف ثالثة. يمكنك حذف جميع ملفات تعريف الارتباط المخزنة في أي وقت.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 6. حقوق المستخدم */}
            <section className="animate-slide-up" style={{ animationDelay: '0.35s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center text-[#FFD700] text-xs font-bold">٦</span>
                حقوق المستخدم
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  يحق لك الوصول إلى بياناتك الشخصية المخزنة لدينا في أي وقت. يمكنك طلب نسخة من جميع بياناتك عبر التواصل مع فريق الدعم الفني أو من خلال إعدادات الحساب. نلتزم بتقديم البيانات المطلوبة في غضون فترة زمنية معقولة وفقاً للأنظمة المعمول بها.
                </p>
                <p>
                  يحق لك طلب تصحيح أي بيانات شخصية غير دقيقة أو غير مكتملة مخزنة في حسابك. كما يحق لك طلب حذف بياناتك الشخصية مع مراعاة أن بعض البيانات قد يتعين الاحتفاظ بها لأغراض قانونية وتنظيمية، مثل سجلات المعاملات المالية المطلوبة لفترات محددة.
                </p>
                <p>
                  يحق لك الاعتراض على معالجة بياناتك الشخصية أو طلب تقييد هذه المعالجة في ظروف معينة. كما يحق لك سحب موافقتك على جمع ومعالجة بياناتك في أي وقت. لممارسة أي من هذه الحقوق، يرجى التواصل معنا عبر البريد الإلكتروني المخصص لشؤون الخصوصية المذكور في قسم التواصل أدناه.
                </p>
              </div>
            </section>

            <div className="h-px bg-gradient-to-l from-transparent via-[#2A3040] to-transparent" />

            {/* 7. التواصل */}
            <section className="animate-slide-up" style={{ animationDelay: '0.4s' }}>
              <h2 className="text-lg font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center text-[#2ECC71] text-xs font-bold">٧</span>
                التواصل
              </h2>
              <div className="space-y-3 text-gray-400 text-sm leading-[1.9]">
                <p>
                  نرحب بجميع استفساراتك ومقترحاتك حول سياسة الخصوصية أو أي مسألة تتعلق ببياناتك الشخصية. يمكنك التواصل مع فريق الخصوصية لدينا عبر البريد الإلكتروني privacy@tedawilai.com وسنقوم بالرد عليك في غضون ٤٨ ساعة عمل كحد أقصى.
                </p>
                <p>
                  كما يمكنك التواصل معنا عبر نموذج الدعم الفني المتاح على المنصة أو من خلال قسم تذاكر الدعم. نحرص على التعامل مع جميع الشكاوى والاستفسارات المتعلقة بالخصوصية بسرية تامة واهتمام بالغ، وسنقدم لك تحديثات منتظمة حول حالة طلبك حتى حله نهائياً.
                </p>
                <p>
                  نحتفظ بالحق في تحديث سياسة الخصوصية هذه بشكل دوري لتتوافق مع التطورات التقنية والقانونية. في حال إجراء تغييرات جوهرية، سنقوم بإشعارك عبر البريد الإلكتروني أو إشعار واضح على المنصة قبل نفاذ التغييرات. يُنصح بمراجعة هذه السياسة بشكل دوري للبقاء على اطلاع بأي تحديثات.
                </p>
              </div>
            </section>
          </div>

          {/* Back Link */}
          <div className="text-center mt-8 animate-slide-up" style={{ animationDelay: '0.5s' }}>
            <Link
              href="/register"
              className="inline-flex items-center gap-2 text-gray-400 hover:text-[#FFD700] transition-colors text-sm"
            >
              <ArrowRight size={16} />
              العودة
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
