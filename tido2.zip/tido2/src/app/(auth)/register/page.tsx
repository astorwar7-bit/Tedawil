'use client';
import { useState, useEffect, useCallback } from 'react';
import { User, Lock, Eye, EyeOff, Mail, Phone, UserPlus, CheckCircle, XCircle, Shield, TrendingUp, ChevronLeft, Check, Globe, Award, Sparkles } from 'lucide-react';
import Link from 'next/link';

const countries = [
  {code:'SA',name:'السعودية',dial:'+966'},{code:'AE',name:'الإمارات',dial:'+971'},{code:'KW',name:'الكويت',dial:'+965'},
  {code:'QA',name:'قطر',dial:'+974'},{code:'BH',name:'البحرين',dial:'+973'},{code:'OM',name:'عمان',dial:'+968'},
  {code:'IQ',name:'العراق',dial:'+964'},{code:'JO',name:'الأردن',dial:'+962'},{code:'LB',name:'لبنان',dial:'+961'},
  {code:'SY',name:'سوريا',dial:'+963'},{code:'PS',name:'فلسطين',dial:'+970'},{code:'EG',name:'مصر',dial:'+20'},
  {code:'MA',name:'المغرب',dial:'+212'},{code:'DZ',name:'الجزائر',dial:'+213'},{code:'TN',name:'تونس',dial:'+216'},
  {code:'LY',name:'ليبيا',dial:'+218'},{code:'SD',name:'السودان',dial:'+249'},{code:'YE',name:'اليمن',dial:'+967'},
  {code:'TR',name:'تركيا',dial:'+90'},{code:'US',name:'أمريكا',dial:'+1'},{code:'GB',name:'بريطانيا',dial:'+44'},
  {code:'DE',name:'ألمانيا',dial:'+49'},{code:'FR',name:'فرنسا',dial:'+33'},{code:'MY',name:'ماليزيا',dial:'+60'},
  {code:'ID',name:'إندونيسيا',dial:'+62'},{code:'IN',name:'الهند',dial:'+91'},{code:'PK',name:'باكستان',dial:'+92'},
  {code:'BD',name:'بنجلاديش',dial:'+880'},{code:'CN',name:'الصين',dial:'+86'},{code:'JP',name:'اليابان',dial:'+81'},
  {code:'KR',name:'كوريا',dial:'+82'},{code:'RU',name:'روسيا',dial:'+7'},{code:'BR',name:'البرازيل',dial:'+55'},
  {code:'CA',name:'كندا',dial:'+1'},{code:'AU',name:'أستراليا',dial:'+61'},{code:'NG',name:'نيجيريا',dial:'+234'},
];

function getPasswordStrength(password: string) {
  let score = 0;
  if (password.length >= 8) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  return score;
}

const strengthLabels = ['ضعيف', 'مقبول', 'جيد', 'قوي جداً'];
const strengthColors = ['', '#EF4444', '#E67E22', '#FFD700', '#2ECC71'];

function FloatingOrbs() {
  return (
    <div className="particles-container">
      <div className="absolute top-[10%] right-[10%] w-[200px] h-[200px] rounded-full bg-[#2ECC71]/[0.04] blur-[60px] animate-glow-pulse" />
      <div className="absolute bottom-[15%] left-[15%] w-[180px] h-[180px] rounded-full bg-[#FFD700]/[0.03] blur-[60px] animate-glow-pulse" style={{ animationDelay: '2s' }} />
      {[...Array(6)].map((_, i) => (
        <div key={i} className="particle" style={{
          left: `${10 + (i * 15)}%`, animationDelay: `${i * 1.3}s`, animationDuration: `${8 + i}s`,
          background: ['#FFD700', '#2ECC71', '#3498DB'][i % 3], width: '2px', height: '2px',
        }} />
      ))}
    </div>
  );
}

function AnimatedStat({ value, label, icon: Icon, suffix, prefix }: { value: number; label: string; icon: typeof User; suffix?: string; prefix?: string }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let current = 0;
    const step = Math.ceil(value / 50);
    const timer = setInterval(() => { current += step; if (current >= value) { current = value; clearInterval(timer); } setCount(current); }, 25);
    return () => clearInterval(timer);
  }, [value]);

  return (
    <div className="text-center p-3 rounded-2xl bg-white/[0.02] border border-white/[0.04]">
      <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-[#FFD700]/10 flex items-center justify-center">
        <Icon size={18} className="text-[#FFD700]" />
      </div>
      <p className="text-xl font-bold text-white number-glow">{prefix}{count.toLocaleString('en')}{suffix}</p>
      <p className="text-gray-500 text-[11px] mt-0.5">{label}</p>
    </div>
  );
}

// Step indicators
const steps = [
  { id: 1, label: 'المعلومات الشخصية', icon: User },
  { id: 2, label: 'الأمان', icon: Lock },
  { id: 3, label: 'الإحالة', icon: UserPlus },
];

export default function RegisterPage() {
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [referralStatus, setReferralStatus] = useState<{ valid: boolean; username?: string } | null>(null);
  const [dialCode, setDialCode] = useState('+966');
  const [settings, setSettings] = useState<{ platformName: string; platformNameEn: string }>({ platformName: 'تداول AI', platformNameEn: 'Tadawul AI' });
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [currentStep, setCurrentStep] = useState(1);
  const [touchedSteps, setTouchedSteps] = useState<Set<number>>(new Set([1]));
  const [form, setForm] = useState({
    fullName: '', username: '', email: '', phone: '', password: '', confirmPassword: '', referralCode: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const passwordStrength = getPasswordStrength(form.password);
  const logoLetter = settings.platformNameEn ? settings.platformNameEn.charAt(0).toUpperCase() : 'T';

  // Determine step validity
  const step1Valid = form.fullName.trim().length > 0 && /^[a-zA-Z0-9]{3,}$/.test(form.username) && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email);
  const step2Valid = form.password.length >= 8 && /[A-Z]/.test(form.password) && /[0-9]/.test(form.password) && form.password === form.confirmPassword;
  const step3Valid = true; // referral is optional

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => {
      if (d.platformNameEn) setSettings({ platformName: d.platformName || 'تداول AI', platformNameEn: d.platformNameEn });
    }).catch(() => {});

    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) setForm(prev => ({ ...prev, referralCode: ref }));
  }, []);

  const checkReferral = useCallback(async (code: string) => {
    if (code.length < 3) { setReferralStatus(null); return; }
    try { const res = await fetch(`/api/auth/check-referral?code=${code}`); const data = await res.json(); setReferralStatus(data); }
    catch { setReferralStatus({ valid: false }); }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => { if (form.referralCode) checkReferral(form.referralCode); }, 1000);
    return () => clearTimeout(timer);
  }, [form.referralCode, checkReferral]);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.fullName.trim()) e.fullName = 'الاسم الكامل مطلوب';
    if (!/^[a-zA-Z0-9]{3,}$/.test(form.username)) e.username = 'أحرف إنجليزية وأرقام فقط، 3 أحرف كحد أدنى';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'بريد إلكتروني غير صالح';
    if (!form.phone.trim()) e.phone = 'رقم الهاتف مطلوب';
    if (form.password.length < 8 || !/[A-Z]/.test(form.password) || !/[0-9]/.test(form.password)) e.password = '8 أحرف كحد أدنى، حرف كبير ورقم';
    if (form.password !== form.confirmPassword) e.confirmPassword = 'كلمتا المرور غير متطابقتين';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: form.fullName, username: form.username, email: form.email,
          phone: `${dialCode}${form.phone}`, password: form.password,
          referralCode: form.referralCode || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'حدث خطأ أثناء التسجيل'); setLoading(false); return; }
      if (data.token) localStorage.setItem('tedawilai_token', data.token);
      setSuccess(true);
      setTimeout(() => { window.location.href = '/dashboard'; }, 1500);
    } catch { setError('تعذر الاتصال بالخادم'); }
    finally { setLoading(false); }
  };

  const fieldComplete = (field: string) => form[field as keyof typeof form]?.length > 0;
  const fieldError = (field: string) => errors[field];

  // Check if all fields are valid for animated checkmark
  const allValid = step1Valid && step2Valid;

  // Success state
  if (success) {
    return (
      <div className="min-h-[100dvh] flex bg-[#0A0F0D] relative overflow-hidden" dir="rtl">
        <FloatingOrbs />
        <div className="flex-1 flex items-center justify-center p-4 relative z-10">
          <div className="w-full max-w-[400px] text-center animate-scaleIn">
            <div className="glass-card p-8 sm:p-10">
              <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-[#2ECC71] to-[#FFD700] flex items-center justify-center text-[#0A0F0D] font-black text-3xl shadow-lg shadow-[#2ECC71]/30">
                <Check size={40} />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">تم إنشاء حسابك بنجاح!</h2>
              <p className="text-gray-400 text-sm mb-6">مرحباً بك في {settings.platformName}. جارٍ تحويلك للوحة التحكم...</p>
              <div className="w-full bg-[#2A3040] rounded-full h-1.5 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-[#2ECC71] to-[#FFD700] rounded-full animate-slide-up" style={{ width: '100%', animation: 'progress-glow 1.5s ease-in-out' }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] flex bg-[#0A0F0D]" dir="rtl">
      {/* Desktop right panel */}
      <div className="hidden lg:flex lg:w-[45%] relative flex-col items-center justify-center overflow-hidden p-8">
        <FloatingOrbs />
        <div className="relative z-10 max-w-sm w-full">
          <div className="text-center mb-8 animate-slide-up">
            <div className="relative w-20 h-20 mx-auto mb-4">
              <div className="absolute inset-0 rounded-full border border-dashed border-[#2ECC71]/25 logo-ring" />
              <div className="absolute inset-1.5 rounded-full border border-[#FFD700]/15 logo-ring" style={{ animationDirection: 'reverse', animationDuration: '12s' }} />
              <div className="absolute inset-3 rounded-2xl bg-gradient-to-br from-[#2ECC71] via-[#4ADE80] to-[#FFD700] flex items-center justify-center text-[#0A0F0D] font-black text-2xl shadow-lg shadow-[#2ECC71]/25 animate-breathe">
                {logoLetter}
              </div>
            </div>
            <h1 className="text-3xl font-black text-shimmer mb-2" dir="ltr">{settings.platformNameEn}</h1>
            <p className="text-gray-500 text-sm">{settings.platformName}</p>
            <p className="text-gray-600 text-xs mt-1">منصة الاستثمار الذكية والموثوقة</p>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-8 stagger-children">
            <AnimatedStat value={5000} label="مستخدم نشط" icon={UserPlus} prefix="+" />
            <AnimatedStat value={2000000} label="أرباح ($)" icon={TrendingUp} prefix="$" />
          </div>

          <div className="flex items-center justify-center gap-3 mt-4 animate-slide-up" style={{ animationDelay: '0.8s' }}>
            {[
              { icon: Shield, label: 'مشفّر', color: '#2ECC71' },
              { icon: Award, label: 'موثق', color: '#FFD700' },
              { icon: Globe, label: 'عالمي', color: '#3498DB' },
            ].map(t => (
              <div key={t.label} className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                <t.icon size={11} style={{ color: `${t.color}60` }} />
                <span className="text-gray-600 text-[10px] font-medium">{t.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Left panel - form */}
      <div className="w-full lg:w-[55%] flex items-center justify-center p-4 py-6 relative min-h-[100dvh]">
        <div className="lg:hidden absolute top-[-5%] right-[-10%] w-[250px] h-[250px] rounded-full bg-[#2ECC71]/[0.03] blur-[60px] animate-glow-pulse" />
        <div className="lg:hidden absolute bottom-[5%] left-[-10%] w-[200px] h-[200px] rounded-full bg-[#FFD700]/[0.03] blur-[60px] animate-glow-pulse" style={{ animationDelay: '2s' }} />

        <div className="w-full max-w-[420px] relative z-10">
          {/* Mobile logo */}
          <div className="lg:hidden text-center mb-6 animate-slide-up">
            <div className="relative w-14 h-14 mx-auto mb-2">
              <div className="absolute inset-0 rounded-full border border-dashed border-[#2ECC71]/20 logo-ring" />
              <div className="absolute inset-1.5 rounded-xl bg-gradient-to-br from-[#2ECC71] to-[#FFD700] flex items-center justify-center text-[#0A0F0D] font-black text-xl shadow-lg shadow-[#2ECC71]/20">
                {logoLetter}
              </div>
            </div>
            <h1 className="text-2xl font-black text-shimmer" dir="ltr">{settings.platformNameEn}</h1>
            <p className="text-gray-500 text-sm mt-1">{settings.platformName}</p>
          </div>

          {/* Form card */}
          <div className="relative animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <div className="absolute -inset-[1px] bg-gradient-to-br from-[#2ECC71]/15 via-[#FFD700]/5 to-[#3498DB]/10 rounded-[1.1rem] blur-xl opacity-40" />

            <form onSubmit={handleSubmit} className="relative z-10 rounded-2xl overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-[#141820] via-[#12161F] to-[#0F1318]" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#2ECC71]/[0.015] to-transparent" />

              <div className="relative p-6 sm:p-7 space-y-4 max-h-[85dvh] overflow-y-auto scrollbar-thin">
                {/* Desktop title */}
                <div className="hidden lg:block text-center mb-2">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-2xl bg-gradient-to-br from-[#2ECC71]/10 to-[#FFD700]/10 border border-[#2ECC71]/10 flex items-center justify-center">
                    <Sparkles size={22} className="text-[#2ECC71]" />
                  </div>
                  <h2 className="text-xl font-bold text-white">إنشاء حساب جديد</h2>
                  <p className="text-gray-500 text-sm mt-1">أدخل بياناتك لبدء الاستثمار</p>
                </div>

                {/* Step Indicators */}
                <div className="flex items-center justify-center gap-2 pt-2 pb-1">
                  {steps.map((step, i) => {
                    const isActive = step.id === currentStep;
                    const isCompleted = step.id < currentStep;
                    const stepValid = step.id === 1 ? step1Valid : step.id === 2 ? step2Valid : step3Valid;
                    return (
                      <div key={step.id} className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => { setCurrentStep(step.id); setTouchedSteps(prev => new Set([...prev, step.id])); }}
                          className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                            isCompleted
                              ? 'bg-gradient-to-br from-[#2ECC71] to-[#FFD700] text-[#0A0F0D]'
                              : isActive
                                ? 'bg-[#FFD700]/15 text-[#FFD700] border-2 border-[#FFD700]/30'
                                : 'bg-[#2A3040] text-gray-500'
                          }`}
                        >
                          {isCompleted ? (
                            <Check size={14} className="step-check-animated" />
                          ) : (
                            step.id
                          )}
                        </button>
                        <span className={`text-[10px] font-medium hidden sm:inline transition-colors ${isActive ? 'text-white' : isCompleted ? 'text-[#2ECC71]' : 'text-gray-600'}`}>
                          {step.label}
                        </span>
                        {i < steps.length - 1 && (
                          <div className={`w-8 h-0.5 rounded-full mx-1 transition-colors ${isCompleted ? 'bg-[#2ECC71]' : 'bg-[#2A3040]'}`} />
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Animated checkmark when all fields are valid */}
                {allValid && (
                  <div className="flex items-center justify-center animate-scaleIn">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#2ECC71]/10 border border-[#2ECC71]/20">
                      <CheckCircle size={14} className="text-[#2ECC71]" />
                      <span className="text-[#2ECC71] text-xs font-medium">جميع الحقول صحيحة ✨</span>
                    </div>
                  </div>
                )}

                {/* Error */}
                {error && (
                  <div className="animate-scaleIn bg-red-500/[0.06] border border-red-500/15 rounded-xl p-3.5 flex items-center gap-2.5">
                    <div className="w-6 h-6 rounded-full bg-red-500/10 flex items-center justify-center shrink-0">
                      <div className="w-2 h-2 rounded-full bg-red-400" />
                    </div>
                    <span className="text-red-400 text-sm">{error}</span>
                  </div>
                )}

                {/* Step 1: Personal Info */}
                {(currentStep === 1 || currentStep > 1) && (
                  <div className={`space-y-3.5 ${currentStep === 1 ? '' : 'opacity-60 pointer-events-none max-h-0 overflow-hidden -mt-3.5'} transition-all duration-300`}>
                    <div className="space-y-1">
                      <label className="text-gray-400 text-xs font-medium block">الاسم الكامل</label>
                      <div className="relative flex items-center">
                        <User size={16} className="absolute right-3 text-[#FFD700]/70 pointer-events-none" />
                        <input placeholder="مثال: أحمد محمد" value={form.fullName} onChange={e => setForm({...form, fullName: e.target.value})}
                          className={`input-premium w-full !pr-10 h-11 text-[14px] ${fieldError('fullName') ? 'border-red-500/50' : ''} ${fieldComplete('fullName') && !fieldError('fullName') ? 'border-[#2ECC71]/30' : ''}`} style={{ textAlign: 'start' }} />
                      </div>
                      {fieldError('fullName') && <p className="text-red-400 text-[11px] animate-fadeIn">{errors.fullName}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-gray-400 text-xs font-medium block">اسم المستخدم</label>
                      <div className="relative flex items-center">
                        <UserPlus size={16} className="absolute right-3 text-[#2ECC71]/70 pointer-events-none" />
                        <input placeholder="أحرف إنجليزية وأرقام فقط" value={form.username} onChange={e => setForm({...form, username: e.target.value})} dir="ltr"
                          className={`input-premium w-full !pr-10 !pl-8 h-11 text-[14px] ${fieldError('username') ? 'border-red-500/50' : ''} ${fieldComplete('username') && !fieldError('username') ? 'border-[#2ECC71]/30' : ''}`} />
                        {fieldComplete('username') && !fieldError('username') && (
                          <CheckCircle size={16} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#2ECC71]" />
                        )}
                      </div>
                      {fieldError('username') && <p className="text-red-400 text-[11px] animate-fadeIn">{errors.username}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-gray-400 text-xs font-medium block">البريد الإلكتروني</label>
                      <div className="relative flex items-center">
                        <Mail size={16} className="absolute right-3 text-[#3498DB]/70 pointer-events-none" />
                        <input type="email" placeholder="example@email.com" value={form.email} onChange={e => setForm({...form, email: e.target.value})} dir="ltr"
                          className={`input-premium w-full !pr-10 !pl-8 h-11 text-[14px] ${fieldError('email') ? 'border-red-500/50' : ''} ${fieldComplete('email') && !fieldError('email') ? 'border-[#2ECC71]/30' : ''}`} />
                        {fieldComplete('email') && !fieldError('email') && (
                          <CheckCircle size={16} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#2ECC71]" />
                        )}
                      </div>
                      {fieldError('email') && <p className="text-red-400 text-[11px] animate-fadeIn">{errors.email}</p>}
                    </div>

                    {/* Next step button for step 1 */}
                    {currentStep === 1 && (
                      <button type="button" onClick={() => { if (step1Valid) { setCurrentStep(2); setTouchedSteps(prev => new Set([...prev, 2])); } }} disabled={!step1Valid} className="btn-premium-gold h-[3rem] text-[14px] disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                        التالي <ChevronLeft size={16} />
                      </button>
                    )}
                  </div>
                )}

                {/* Step 2: Security */}
                {currentStep >= 2 && (
                  <div className={`space-y-3.5 ${currentStep === 2 ? '' : 'opacity-60 pointer-events-none max-h-0 overflow-hidden -mt-3.5'} transition-all duration-300`}>
                    <div className="space-y-1">
                      <label className="text-gray-400 text-xs font-medium block">رقم الهاتف</label>
                      <div className="flex items-stretch gap-0">
                        <div className="relative flex items-center shrink-0">
                          <Phone size={14} className="absolute right-2.5 text-[#E67E22]/70 pointer-events-none z-10" />
                          <select value={dialCode} onChange={e => setDialCode(e.target.value)}
                            className="h-11 rounded-r-[0.875rem] rounded-l-none !pr-9 pl-3 text-[13px] font-medium cursor-pointer border border-[#2A3040] border-l-0 bg-[rgba(18,22,31,0.8)] text-white outline-none transition-all duration-300 focus:border-[#FFD700] focus:z-10"
                            style={{ background: 'rgba(18,22,31,0.8)', minWidth: '5.5rem' }} dir="ltr">
                            {countries.map(c => <option key={c.code} value={c.dial}>{c.dial}</option>)}
                          </select>
                        </div>
                        <div className="relative flex-1">
                          <input placeholder="5XXXXXXXX" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} dir="ltr"
                            className={`w-full h-11 rounded-l-[0.875rem] rounded-r-none border border-[#2A3040] bg-[rgba(18,22,31,0.8)] text-white text-[15px] tracking-wide px-4 outline-none transition-all duration-300 focus:border-[#FFD700] focus:shadow-[0_0_0_3px_rgba(255,215,0,0.1)] ${fieldError('phone') ? 'border-red-500/50' : ''}`} />
                        </div>
                      </div>
                      {fieldError('phone') && <p className="text-red-400 text-[11px] animate-fadeIn">{errors.phone}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-gray-400 text-xs font-medium block">كلمة المرور</label>
                      <div className="relative flex items-center">
                        <Lock size={16} className="absolute right-3 text-[#9B59B6]/70 pointer-events-none" />
                        <input type={showPass ? 'text' : 'password'} placeholder="8 أحرف، حرف كبير ورقم" value={form.password} onChange={e => setForm({...form, password: e.target.value})} dir="ltr"
                          className={`input-premium w-full !pr-10 !pl-10 h-11 text-[14px] ${fieldError('password') ? 'border-red-500/50' : ''}`} />
                        <button type="button" onClick={() => setShowPass(!showPass)} className="absolute left-2.5 text-gray-500 hover:text-gray-300 transition-colors">
                          {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                      {form.password.length > 0 && (
                        <div className="mt-2 space-y-1.5">
                          <div className="flex gap-1.5">
                            {[...Array(4)].map((_, i) => (
                              <div key={i} className="h-1 flex-1 rounded-full transition-all duration-400" style={{
                                background: i < passwordStrength ? strengthColors[passwordStrength] : '#2A3040',
                                boxShadow: i < passwordStrength ? `0 0 8px ${strengthColors[passwordStrength]}30` : 'none',
                              }} />
                            ))}
                          </div>
                          <p className="text-[11px]" style={{ color: strengthColors[passwordStrength] || '#6B7280' }}>{strengthLabels[passwordStrength]}</p>
                        </div>
                      )}
                      {fieldError('password') && <p className="text-red-400 text-[11px] animate-fadeIn">{errors.password}</p>}
                    </div>

                    <div className="space-y-1">
                      <label className="text-gray-400 text-xs font-medium block">تأكيد كلمة المرور</label>
                      <div className="relative flex items-center">
                        <Lock size={16} className="absolute right-3 text-[#9B59B6]/70 pointer-events-none" />
                        <input type="password" placeholder="أعد إدخال كلمة المرور" value={form.confirmPassword} onChange={e => setForm({...form, confirmPassword: e.target.value})} dir="ltr"
                          className={`input-premium w-full !pr-10 !pl-8 h-11 text-[14px] ${fieldError('confirmPassword') ? 'border-red-500/50' : ''} ${form.confirmPassword && form.password === form.confirmPassword ? 'border-[#2ECC71]/30' : ''}`} />
                        {form.confirmPassword && form.password === form.confirmPassword && (
                          <CheckCircle size={16} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#2ECC71]" />
                        )}
                      </div>
                      {fieldError('confirmPassword') && <p className="text-red-400 text-[11px] animate-fadeIn">{errors.confirmPassword}</p>}
                    </div>

                    {/* Step 2 nav buttons */}
                    {currentStep === 2 && (
                      <div className="flex gap-2">
                        <button type="button" onClick={() => setCurrentStep(1)} className="flex-1 bg-[#2A3040] text-gray-300 h-[3rem] rounded-xl text-sm hover:bg-[#3A4050]">
                          السابق
                        </button>
                        <button type="button" onClick={() => { setCurrentStep(3); setTouchedSteps(prev => new Set([...prev, 3])); }} className="flex-1 btn-premium-gold h-[3rem] text-[14px] flex items-center justify-center gap-2">
                          التالي <ChevronLeft size={16} />
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Step 3: Referral */}
                {currentStep >= 3 && (
                  <div className={`space-y-3.5 ${currentStep === 3 ? '' : 'opacity-60 pointer-events-none max-h-0 overflow-hidden -mt-3.5'} transition-all duration-300`}>
                    <div className="space-y-1">
                      <label className="text-gray-400 text-xs font-medium block">كود الدعوة <span className="text-gray-600">(اختياري)</span></label>
                      <div className="relative flex items-center">
                        <UserPlus size={16} className="absolute right-3 text-[#FFD700]/70 pointer-events-none" />
                        <input placeholder="أدخل كود الدعوة" value={form.referralCode} onChange={e => setForm({...form, referralCode: e.target.value})} dir="ltr"
                          className="input-premium w-full !pr-10 h-11 text-[14px]" />
                        {referralStatus && referralStatus.valid && (
                          <div className="flex items-center gap-1 mt-1.5 mr-1 animate-fadeIn">
                            <CheckCircle size={13} className="text-[#2ECC71]" />
                            <span className="text-[#2ECC71] text-[11px] font-medium">مُوثّق: {referralStatus.username}</span>
                          </div>
                        )}
                        {referralStatus && !referralStatus.valid && (
                          <div className="flex items-center gap-1 mt-1.5 mr-1 animate-fadeIn">
                            <XCircle size={13} className="text-red-400" />
                            <span className="text-red-400 text-[11px]">كود غير صالح</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Terms */}
                    <p className="text-gray-600 text-[11px] leading-relaxed text-center">
                      بالتسجيل، أنت توافق على{' '}
                      <Link href="/terms" className="text-gray-400 hover:text-[#FFD700] transition-colors">شروط الخدمة</Link>
                      {' '}و{' '}
                      <Link href="/privacy" className="text-gray-400 hover:text-[#FFD700] transition-colors">سياسة الخصوصية</Link>
                    </p>

                    {/* Submit button */}
                    <button type="submit" disabled={loading} className="btn-premium-emerald h-[3.1rem] text-[15px] mt-1 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                      {loading ? (
                        <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> جاري إنشاء الحساب...</>
                      ) : (
                        <><UserPlus size={18} /> إنشاء حساب</>
                      )}
                    </button>

                    {/* Back to step 2 */}
                    {currentStep === 3 && (
                      <button type="button" onClick={() => setCurrentStep(2)} className="w-full bg-[#2A3040] text-gray-300 h-[3rem] rounded-xl text-sm hover:bg-[#3A4050]">
                        السابق
                      </button>
                    )}
                  </div>
                )}

                {/* Login link */}
                <div className="flex items-center justify-center gap-2 pt-1">
                  <span className="text-gray-500 text-sm">لديك حساب بالفعل؟</span>
                  <Link href="/" className="text-[#FFD700] hover:text-[#FFD700]/80 font-semibold text-sm transition-colors inline-flex items-center gap-1">
                    تسجيل الدخول
                    <ChevronLeft size={14} />
                  </Link>
                </div>
              </div>
            </form>
          </div>

          {/* Trust indicators */}
          <div className="flex items-center justify-center gap-4 mt-6 animate-slide-up" style={{ animationDelay: '0.3s' }}>
            {[
              { color: '#2ECC71', label: 'اتصال آمن' },
              { color: '#FFD700', label: 'تشفير 256-بت' },
              { color: '#3498DB', label: 'حماية DDoS' },
            ].map(t => (
              <div key={t.label} className="flex items-center gap-1.5">
                <div className="w-1 h-1 rounded-full" style={{ background: `${t.color}60` }} />
                <span className="text-gray-600 text-[11px]">{t.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
