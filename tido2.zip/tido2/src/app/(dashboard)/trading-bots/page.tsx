'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Bot, Zap, Shield, TrendingUp, DollarSign, AlertTriangle, CheckCircle, Users, Info, Star, MessageSquarePlus, ChevronDown, ChevronUp, Trash2, Send } from 'lucide-react';

interface MarketBot {
  id: string;
  name: string;
  botName: string;
  strategy: string;
  description: string;
  dailyReturn: number;
  riskLevel: string;
  minBalance: number;
  icon: string;
  color: string;
  subscribers: number;
  isSubscribed: boolean;
}

interface ActiveBot {
  id: string;
  botId: string;
  botName: string;
  strategy: string;
  dailyReturn: number;
  profit: number;
  riskLevel: string;
  minBalance: number;
  isActive: boolean;
  createdAt: string;
}

export default function TradingBotsPage() {
  const { showToast } = useToast();
  const [tab, setTab] = useState<'marketplace' | 'active'>('marketplace');
  const [bots, setBots] = useState<MarketBot[]>([]);
  const [activeBots, setActiveBots] = useState<ActiveBot[]>([]);
  const [totalProfit, setTotalProfit] = useState(0);
  const [maxSubs] = useState(3);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [showDetails, setShowDetails] = useState<string | null>(null);
  const [botReviews, setBotReviews] = useState<Record<string, { avgRating: number; total: number }>>({});
  const [expandedReview, setExpandedReview] = useState<string | null>(null);
  const [reviewList, setReviewList] = useState<Record<string, { id: string; rating: number; comment: string; createdAt: string; userId: string; user: { id: string; username: string; fullName: string; avatar: string } }[]>>({});
  const [reviewFormOpen, setReviewFormOpen] = useState<string | null>(null);
  const [newRating, setNewRating] = useState(0);
  const [newComment, setNewComment] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [currentUserId, setCurrentUserId] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/trading-bots?tab=${tab}`);
      const data = await res.json();
      if (tab === 'active') {
        setActiveBots(data.activeBots || []);
        setTotalProfit(data.totalProfit || 0);
      } else {
        setBots(data.bots || []);
        setActiveBots(data.activeBots || []);
        // Fetch review summaries for bots
        const botIds = (data.bots || []).map((b: MarketBot) => b.id);
        for (const botId of botIds) {
          fetchBotReviewSummary(botId);
        }
      }
    } catch { showToast('حدث خطأ أثناء التحميل', 'error'); }
    setLoading(false);
  };

  const fetchBotReviewSummary = async (botId: string) => {
    try {
      const res = await fetch(`/api/reviews?botId=${botId}&limit=1`);
      const data = await res.json();
      setBotReviews(prev => ({
        ...prev,
        [botId]: { avgRating: data.avgRating || 0, total: data.total || 0 },
      }));
    } catch { /* ignore */ }
  };

  const fetchBotReviews = async (botId: string) => {
    try {
      const res = await fetch(`/api/reviews?botId=${botId}&limit=10`);
      const data = await res.json();
      setReviewList(prev => ({ ...prev, [botId]: data.reviews || [] }));
      setBotReviews(prev => ({
        ...prev,
        [botId]: { avgRating: data.avgRating || 0, total: data.total || 0 },
      }));
    } catch { showToast('حدث خطأ أثناء تحميل التقييمات', 'error'); }
  };

  const fetchCurrentUser = async () => {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const data = await res.json();
        setCurrentUserId(data.user?.id || '');
      }
    } catch { /* not logged in */ }
  };

  useEffect(() => { fetchCurrentUser(); }, []);

  useEffect(() => { fetchData(); }, [tab]);

  const toggleSubscription = async (botId: string, isSubscribed: boolean) => {
    setActionLoading(botId);
    try {
      const res = await fetch('/api/trading-bots', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('tedawilai_token')}` },
        body: JSON.stringify({ action: isSubscribed ? 'unsubscribe' : 'subscribe', botId }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      fetchData();
    } catch { showToast('حدث خطأ', 'error'); }
    setActionLoading(null);
  };

  const submitBotReview = async (botId: string) => {
    if (newRating === 0) { showToast('يرجى اختيار التقييم', 'error'); return; }
    setSubmittingReview(true);
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('tedawilai_token')}` },
        body: JSON.stringify({ rating: newRating, comment: newComment, botId }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); setSubmittingReview(false); return; }
      showToast(data.message || 'تم إضافة التقييم بنجاح');
      setNewRating(0);
      setNewComment('');
      setReviewFormOpen(null);
      fetchBotReviews(botId);
    } catch { showToast('حدث خطأ', 'error'); }
    setSubmittingReview(false);
  };

  const deleteBotReview = async (reviewId: string, botId: string) => {
    try {
      const res = await fetch(`/api/reviews/${reviewId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${localStorage.getItem('tedawilai_token')}` },
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message || 'تم حذف التقييم');
      fetchBotReviews(botId);
    } catch { showToast('حدث خطأ', 'error'); }
  };

  const renderStars = (rating: number, size: number = 12) => (
    <div className="flex items-center gap-px">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star key={s} size={size} className={s <= Math.round(rating) ? 'fill-[#FFD700] text-[#FFD700]' : 'fill-[#2A3040] text-[#2A3040]'} />
      ))}
    </div>
  );

  const formatDate = (dateStr: string) => {
    const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24));
    if (diff === 0) return 'اليوم';
    if (diff === 1) return 'أمس';
    if (diff < 7) return `منذ ${diff} أيام`;
    if (diff < 30) return `منذ ${Math.floor(diff / 7)} أسابيع`;
    return `منذ ${Math.floor(diff / 30)} أشهر`;
  };

  const riskBadge = (risk: string) => {
    const colors: Record<string, string> = {
      'منخفض': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
      'متوسط': 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
      'عالي': 'bg-orange-500/10 text-orange-400 border-orange-500/20',
      'عالي جداً': 'bg-red-500/10 text-red-400 border-red-500/20',
    };
    return <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${colors[risk] || ''}`}>{risk}</span>;
  };

  const riskIcon = (risk: string) => {
    if (risk.includes('منخفض')) return <Shield size={14} className="text-emerald-400" />;
    if (risk.includes('متوسط')) return <AlertTriangle size={14} className="text-yellow-400" />;
    return <AlertTriangle size={14} className="text-red-400" />;
  };

  const tabs = [
    { id: 'marketplace' as const, label: 'المتجر', icon: Bot },
    { id: 'active' as const, label: 'النشط', icon: Zap },
  ];

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">بوتات التداول</h1>
        <div className="flex items-center gap-1 text-xs text-gray-400">
          <Bot size={14} className="text-[#FFD700]" />
          <span>{activeBots.length}/{maxSubs} نشط</span>
        </div>
      </div>

      <div className="flex gap-2">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium transition-all ${
              tab === t.id ? 'bg-[#2ECC71] text-white neon-emerald' : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-[#2ECC71]'
            }`}>
            <t.icon size={14} />
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'active' && (
        <div className="grid grid-cols-2 gap-3">
          <div className="glass-card p-4 text-center">
            <DollarSign size={20} className="text-[#2ECC71] mx-auto mb-1" />
            <p className="text-xl font-bold text-[#2ECC71]">${totalProfit.toFixed(2)}</p>
            <p className="text-gray-400 text-xs mt-1">إجمالي الأرباح</p>
          </div>
          <div className="glass-card p-4 text-center">
            <Bot size={20} className="text-[#FFD700] mx-auto mb-1" />
            <p className="text-xl font-bold text-[#FFD700]">{activeBots.length}</p>
            <p className="text-gray-400 text-xs mt-1">بوتات نشطة</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {loading ? (
          <div className="col-span-full space-y-4">
            {[1, 2, 3].map(i => <div key={i} className="skeleton-card" />)}
          </div>
        ) : tab === 'active' && activeBots.length === 0 ? (
          <div className="col-span-2 text-center py-12">
            <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#1A1F2E] border border-[#2A3040] flex items-center justify-center">
              <Bot size={28} className="text-gray-600" />
            </div>
            <p className="text-gray-400 font-medium mb-1">لا توجد بوتات نشطة</p>
            <p className="text-gray-500 text-sm">اشترك في بوت من المتجر وابدأ التداول الآلي</p>
          </div>
        ) : tab === 'marketplace' && bots.length === 0 ? (
          <div className="col-span-2 text-center py-12">
            <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#1A1F2E] border border-[#2A3040] flex items-center justify-center">
              <Bot size={28} className="text-gray-600" />
            </div>
            <p className="text-gray-400 font-medium mb-1">لا توجد بوتات متاحة حالياً</p>
            <p className="text-gray-500 text-sm">عُد لاحقاً للاطلاع على البوتات الجديدة</p>
          </div>
        ) : (
          (tab === 'active' ? activeBots : bots).map((bot: MarketBot | ActiveBot) => {
            const isSub = 'isSubscribed' in bot ? bot.isSubscribed : true;
            const b = bot as MarketBot & ActiveBot;
            const botColor = (b as MarketBot).color || '#FFD700';
            return (
              <div key={b.id} className={`glass-card p-4 card-lift ${isSub ? 'featured-border' : ''}`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${botColor}20` }}>
                      <Bot size={20} style={{ color: botColor }} />
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm">{b.botName || b.name}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        {riskIcon(b.riskLevel)}
                        {riskBadge(b.riskLevel)}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {'subscribers' in b && b.subscribers > 0 && (
                      <span className="flex items-center gap-1 text-[10px] text-gray-500 ml-1">
                        <Users size={10} />{b.subscribers}
                      </span>
                    )}
                    {isSub && <CheckCircle size={18} className="text-[#2ECC71]" />}
                  </div>
                </div>

                <p className="text-gray-400 text-xs mb-3 leading-relaxed line-clamp-2">{b.strategy}</p>

                {'description' in b && (b as MarketBot).description && (
                  <div className="mb-3">
                    {showDetails === b.id ? (
                      <div className="bg-[#12161F] rounded-lg p-3 text-gray-400 text-xs leading-relaxed">
                        <p>{(b as MarketBot).description}</p>
                        <button onClick={() => setShowDetails(null)} className="text-[#2ECC71] text-[10px] mt-1 hover:underline">إخفاء التفاصيل</button>
                      </div>
                    ) : (
                      <button onClick={() => setShowDetails(b.id)} className="flex items-center gap-1 text-[#2ECC71] text-[10px] hover:underline">
                        <Info size={10} />عرض التفاصيل
                      </button>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="bg-[#12161F] rounded-lg p-2 text-center">
                    <TrendingUp size={14} className="text-[#2ECC71] mx-auto mb-0.5" />
                    <p className="text-white font-bold text-sm">{b.dailyReturn}%</p>
                    <p className="text-gray-500 text-[10px]">عائد يومي</p>
                  </div>
                  <div className="bg-[#12161F] rounded-lg p-2 text-center">
                    <DollarSign size={14} className="text-[#FFD700] mx-auto mb-0.5" />
                    <p className="text-white font-bold text-sm">${b.minBalance}</p>
                    <p className="text-gray-500 text-[10px]">حد أدنى</p>
                  </div>
                </div>

                {'profit' in b && b.profit > 0 && (
                  <div className="bg-[#2ECC71]/5 rounded-lg p-2 mb-3 text-center">
                    <p className="text-[#2ECC71] font-bold text-xs">ربح: ${b.profit.toFixed(2)}</p>
                  </div>
                )}

                <button
                  onClick={() => toggleSubscription(b.botId || b.id, isSub)}
                  disabled={actionLoading === (b.botId || b.id) || (!isSub && activeBots.length >= maxSubs)}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all disabled:opacity-50 ${
                    isSub ? 'bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20' : 'btn-premium-gold'
                  }`}>
                  {actionLoading === (b.botId || b.id) ? '...' : isSub ? 'إلغاء الاشتراك' : 'اشتراك'}
                </button>

                {/* Bot Reviews - marketplace only */}
                {tab === 'marketplace' && 'isSubscribed' in b && (
                  <div className="border-t border-[#2A3040]/50 mt-3 pt-3">
                    <button
                      onClick={() => {
                        if (expandedReview === b.id) {
                          setExpandedReview(null);
                        } else {
                          setExpandedReview(b.id);
                          fetchBotReviews(b.id);
                        }
                      }}
                      className="w-full flex items-center justify-between py-1.5 group"
                    >
                      <div className="flex items-center gap-2">
                        <MessageSquarePlus size={12} className="text-[#FFD700]" />
                        <span className="text-[10px] text-gray-400">التقييمات</span>
                        {(botReviews[b.id]?.total ?? 0) > 0 && (
                          <div className="flex items-center gap-1">
                            {renderStars(botReviews[b.id].avgRating, 10)}
                            <span className="text-[9px] text-gray-500">
                              {botReviews[b.id].avgRating} ({botReviews[b.id].total})
                            </span>
                          </div>
                        )}
                      </div>
                      {expandedReview === b.id
                        ? <ChevronUp size={12} className="text-gray-500" />
                        : <ChevronDown size={12} className="text-gray-500" />
                      }
                    </button>

                    {expandedReview === b.id && (
                      <div className="animate-fadeIn space-y-2 mt-2">
                        {currentUserId && reviewFormOpen !== b.id && (
                          <button
                            onClick={() => setReviewFormOpen(b.id)}
                            className="w-full py-2 rounded-lg bg-[#1A1F2E] border border-[#2A3040] hover:border-[#FFD700]/30 text-[10px] text-gray-400 hover:text-[#FFD700] transition-all flex items-center justify-center gap-1.5"
                          >
                            <MessageSquarePlus size={11} />
                            أضف تقييمك
                          </button>
                        )}

                        {reviewFormOpen === b.id && (
                          <div className="glass-card p-2.5 space-y-2 animate-fadeIn">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold text-white">أضف تقييمك</span>
                              <button onClick={() => { setReviewFormOpen(null); setNewRating(0); setNewComment(''); }} className="text-gray-500 hover:text-gray-300 text-[10px]">إلغاء</button>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] text-gray-400">التقييم:</span>
                              <div className="flex items-center gap-px">
                                {[1,2,3,4,5].map((s) => (
                                  <button key={s} type="button" onClick={() => setNewRating(s)} className="cursor-pointer hover:scale-110 transition-transform">
                                    <Star size={15} className={s <= newRating ? 'fill-[#FFD700] text-[#FFD700]' : 'fill-[#2A3040] text-[#2A3040]'} />
                                  </button>
                                ))}
                              </div>
                            </div>
                            <textarea
                              value={newComment}
                              onChange={(e) => setNewComment(e.target.value)}
                              placeholder="شاركنا رأيك..."
                              className="w-full bg-[#12161F] border border-[#2A3040] rounded-lg px-2.5 py-1.5 text-[10px] text-white placeholder-gray-600 focus:outline-none focus:border-[#FFD700]/50 resize-none"
                              rows={2}
                            />
                            <button
                              onClick={() => submitBotReview(b.id)}
                              disabled={submittingReview || newRating === 0}
                              className="btn-ripple px-3 py-1.5 rounded-lg text-[10px] font-bold flex items-center gap-1.5 transition-all disabled:opacity-50 bg-[#FFD700]/10 border border-[#FFD700]/30 text-[#FFD700] hover:bg-[#FFD700]/20"
                            >
                              {submittingReview ? <div className="w-3 h-3 border-2 border-[#FFD700]/30 border-t-[#FFD700] rounded-full animate-spin" /> : <Send size={10} />}
                              إرسال
                            </button>
                          </div>
                        )}

                        {(reviewList[b.id] || []).length === 0 ? (
                          <div className="text-center py-3">
                            <MessageSquarePlus size={18} className="text-gray-600 mx-auto mb-1" />
                            <p className="text-[10px] text-gray-500">لا توجد تقييمات بعد</p>
                          </div>
                        ) : (
                          <div className="space-y-1.5 max-h-48 overflow-y-auto custom-scrollbar">
                            {(reviewList[b.id] || []).map((review) => (
                              <div key={review.id} className="bg-[#12161F] rounded-lg p-2.5 border border-[#2A3040]/50">
                                <div className="flex items-center justify-between mb-1">
                                  <div className="flex items-center gap-1.5">
                                    <div className="w-5 h-5 rounded-full bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[8px] font-bold text-[#0A0F0D]">
                                      {review.user.fullName?.charAt(0) || review.user.username.charAt(0)}
                                    </div>
                                    <span className="text-[10px] text-white font-medium">
                                      {review.user.fullName || review.user.username}
                                    </span>
                                    <span className="text-[8px] text-gray-600">{formatDate(review.createdAt)}</span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    {renderStars(review.rating, 9)}
                                    {review.userId === currentUserId && (
                                      <button onClick={() => deleteBotReview(review.id, b.id)} className="text-gray-600 hover:text-red-400 transition-colors mr-0.5">
                                        <Trash2 size={9} />
                                      </button>
                                    )}
                                  </div>
                                </div>
                                {review.comment && <p className="text-[10px] text-gray-400 leading-relaxed">{review.comment}</p>}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
