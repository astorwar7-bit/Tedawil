'use client';
import { useEffect, useState, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import {
  DollarSign, AlertTriangle, ShieldCheck, ShieldX, Download,
  ArrowDownToLine, Wallet, TrendingUp, ArrowLeftRight,
  Check, ChevronDown, Loader2, CircleDot, Zap, Info,
  Minus, Plus, X
} from 'lucide-react';
import ConfirmDialog from '@/components/ConfirmDialog';
import { useToast } from '@/contexts/ToastContext';

interface Withdrawal {
  id: string;
  amount: number;
  walletAddress: string;
  status: string;
  rejectReason: string;
  createdAt: string;
}

interface WithdrawalSettings {
  minWithdraw: number;
  maxWithdraw: number;
  withdrawalFee: number;
}

const QUICK_AMOUNTS = [10, 50, 100, 500];

// Animated count-up hook
function useCountUp(target: number, duration: number = 1200, enabled: boolean = true) {
  const [value, setValue] = useState(0);
  const startRef = useRef<number | null>(null);
  const frameRef = useRef<number>(0);

  const animate = useCallback((timestamp: number) => {
    if (!startRef.current) startRef.current = timestamp;
    const elapsed = timestamp - startRef.current;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    setValue(eased * target);
    if (progress < 1) {
      frameRef.current = requestAnimationFrame(animate);
    }
  }, [target, duration]);

  useEffect(() => {
    if (!enabled) { setValue(0); return; }
    startRef.current = null;
    frameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameRef.current);
  }, [animate, enabled]);

  return value;
}

// Status Timeline Component
function StatusTimeline({ status, rejectReason }: { status: string; rejectReason?: string }) {
  const steps = [
    { key: 'pending', label: 'تم التقديم', icon: CircleDot },
    { key: 'processing', label: 'قيد المعالجة', icon: Loader2 },
    { key: 'approved', label: 'تم التحويل', icon: Check },
  ];

  const isRejected = status === 'rejected';
  const statusOrder: Record<string, number> = {
    pending: 0, processing: 1, approved: 2, rejected: -1,
  };
  const currentIdx = statusOrder[status] ?? 0;

  return (
    <div className="space-y-1">
      <div className="flex items-center gap-1 py-2">
        {steps.map((step, idx) => {
          const isCompleted = currentIdx >= idx + 1;
          const isActive = currentIdx === idx && status !== 'rejected';
          const isRejected = status === 'rejected';
          const Icon = step.icon;
          const isLast = idx === steps.length - 1;

          return (
            <div key={step.key} className="flex items-center">
              <div className="flex flex-col items-center gap-1">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-500 ${
                    isCompleted
                      ? 'bg-[#2ECC71]/20 border border-[#2ECC71]/50'
                      : isActive
                      ? 'bg-[#FFD700]/20 border border-[#FFD700]/50 animate-breathe'
                      : isRejected && step.key === 'approved'
                      ? 'bg-red-500/20 border border-red-500/50'
                      : 'bg-[#12161F] border border-[#2A3040]'
                  }`}
                >
                  {isActive && status === 'processing' ? (
                    <Loader2 size={14} className="text-[#FFD700] animate-spin" />
                  ) : (
                    <Icon
                      size={14}
                      className={
                        isCompleted
                          ? 'text-[#2ECC71]'
                          : isActive
                          ? 'text-[#FFD700]'
                          : isRejected && step.key === 'approved'
                          ? 'text-red-400'
                          : 'text-gray-600'
                      }
                    />
                  )}
                </div>
                <span
                  className={`text-[10px] whitespace-nowrap ${
                    isCompleted
                      ? 'text-[#2ECC71]'
                      : isActive
                      ? 'text-[#FFD700]'
                      : 'text-gray-600'
                  }`}
                >
                  {isRejected && step.key === 'approved' ? 'مرفوض' : step.label}
                </span>
              </div>
              {!isLast && (
                <div
                  className={`w-8 sm:w-10 h-0.5 mx-1 mt-[-16px] transition-all duration-500 ${
                    isCompleted ? 'bg-[#2ECC71]/50' : 'bg-[#2A3040]'
                  }`}
                />
              )}
            </div>
          );
        })}
      </div>
      {isRejected && rejectReason && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-2 mt-1">
          <p className="text-red-400 text-[11px]">
            <span className="font-medium">سبب الرفض: </span>
            {rejectReason}
          </p>
        </div>
      )}
    </div>
  );
}

export default function WithdrawalsPage() {
  const router = useRouter();
  const { showToast } = useToast();
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [available, setAvailable] = useState(0);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [form, setForm] = useState({ amount: '', wallet: '', method: 'USDT_TRC20' });
  const [loading, setLoading] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);
  const [kycStatus, setKycStatus] = useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingSubmit, setPendingSubmit] = useState<{ amount: number; wallet: string } | null>(null);
  const [expandedWithdrawal, setExpandedWithdrawal] = useState<string | null>(null);
  const [withdrawalSettings, setWithdrawalSettings] = useState<WithdrawalSettings>({
    minWithdraw: 10,
    maxWithdraw: 10000,
    withdrawalFee: 2,
  });
  const [showCustomAmount, setShowCustomAmount] = useState(false);
  const [customAmountValue, setCustomAmountValue] = useState('');

  const animatedBalance = useCountUp(available, 1500, !dataLoading);

  const fetchData = async () => {
    setDataLoading(true);
    try {
      const [wRes, pRes, settingsRes] = await Promise.all([
        fetch('/api/withdrawals?page=' + page),
        fetch('/api/profits?limit=1'),
        fetch('/api/settings'),
      ]);
      const wData = await wRes.json();
      const pData = await pRes.json();
      const sData = await settingsRes.json();

      setWithdrawals(wData.withdrawals || []);
      setTotal(wData.total || 0);

      const pending = await fetch('/api/withdrawals?status=pending');
      const pendingData = await pending.json();
      const pendingTotal = (pendingData.withdrawals || []).reduce(
        (s: number, w: Withdrawal) => s + w.amount,
        0
      );
      setAvailable((pData.totalProfits || 0) - pendingTotal);

      // Withdrawal settings
      if (sData) {
        setWithdrawalSettings({
          minWithdraw: sData.minWithdraw || 10,
          maxWithdraw: sData.maxWithdraw || 10000,
          withdrawalFee: sData.withdrawalFee || 2,
        });
      }

      const kycRes = await fetch('/api/kyc');
      const kycData = await kycRes.json();
      setKycStatus(kycData.kyc?.status || 'not_submitted');
    } catch (err) {
      console.error('Withdrawals fetch error:', err);
    }
    setDataLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [page]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(form.amount);
    if (!amount || !form.wallet) return;

    if (amount < withdrawalSettings.minWithdraw) {
      showToast(
        `الحد الأدنى للسحب هو $${withdrawalSettings.minWithdraw}`,
        'error'
      );
      return;
    }
    if (amount > withdrawalSettings.maxWithdraw) {
      showToast(
        `الحد الأقصى للسحب هو $${withdrawalSettings.maxWithdraw}`,
        'error'
      );
      return;
    }
    if (amount + withdrawalSettings.withdrawalFee > available) {
      showToast('الرصيد غير كافي لتغطية المبلغ والرسوم', 'error');
      return;
    }

    setPendingSubmit({ amount, wallet: form.wallet });
    setConfirmOpen(true);
  };

  const confirmWithdrawal = async () => {
    if (!pendingSubmit) return;
    setConfirmOpen(false);
    setLoading(true);
    try {
      const res = await fetch('/api/withdrawals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: pendingSubmit.amount,
          walletAddress: pendingSubmit.wallet,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error || 'حدث خطأ', 'error');
        return;
      }
      showToast(data.message || 'تم تقديم طلب السحب بنجاح');
      setForm({ amount: '', wallet: '', method: 'USDT_TRC20' });
      setPendingSubmit(null);
      fetchData();
    } catch (err) {
      console.error('Withdrawal submit error:', err);
      showToast('حدث خطأ', 'error');
    }
    setLoading(false);
  };

  const statusBadge = (s: string) => {
    const map: Record<string, string> = {
      pending: 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20',
      processing: 'bg-blue-500/10 text-blue-400 border border-blue-500/20',
      approved: 'bg-[#2ECC71]/10 text-[#2ECC71] border border-[#2ECC71]/20',
      rejected: 'bg-red-500/10 text-red-400 border border-red-500/20',
    };
    const label: Record<string, string> = {
      pending: 'معلق',
      processing: 'قيد المعالجة',
      approved: 'تم التحويل',
      rejected: 'مرفوض',
    };
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-medium ${map[s] || ''}`}>
        {label[s] || s}
      </span>
    );
  };

  const getNetworkFee = () => {
    switch (form.method) {
      case 'USDT_TRC20': return 1;
      case 'USDT_ERC20': return 3;
      case 'BANK': return 5;
      default: return 2;
    }
  };

  const handleQuickAmount = (amount: number) => {
    setForm((prev) => ({ ...prev, amount: String(amount) }));
    setShowCustomAmount(false);
  };

  const handleAllBalance = () => {
    const fee = getNetworkFee() + withdrawalSettings.withdrawalFee;
    const maxAmount = Math.max(0, available - fee);
    setForm((prev) => ({ ...prev, amount: String(maxAmount.toFixed(2)) }));
    setShowCustomAmount(false);
  };

  const parseAmount = parseFloat(form.amount) || 0;
  const totalFee = getNetworkFee() + withdrawalSettings.withdrawalFee;
  const isInsufficient = parseAmount > 0 && parseAmount + totalFee > available;

  const exportCSV = (data: Withdrawal[], filename: string) => {
    if (data.length === 0) return;
    const headers = ['التاريخ', 'المبلغ', 'المحفظة', 'الحالة'];
    const statusLabels: Record<string, string> = {
      pending: 'معلق',
      approved: 'موافق',
      rejected: 'مرفوض',
      processing: 'قيد المعالجة',
    };
    const rows = data.map((row) => {
      const date = new Date(row.createdAt).toLocaleDateString('ar');
      const amount = row.amount.toFixed(2);
      const wallet = row.walletAddress;
      const status = statusLabels[row.status] || row.status;
      return [date, amount, wallet, status].map((v) => `"${v}"`).join(',');
    });
    const csv = [headers.join(','), ...rows].join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 animate-fadeIn pb-20 lg:pb-6">
      <h1 className="text-2xl font-bold text-white">السحب</h1>

      <ConfirmDialog
        open={confirmOpen}
        title="تأكيد طلب السحب"
        message={`هل أنت متأكد من طلب سحب مبلغ $${pendingSubmit?.amount.toFixed(2)}؟ سيتم خصم رسوم بقيمة $${totalFee.toFixed(2)}. سيتم مراجعة طلبك خلال 24 ساعة.`}
        confirmText="تأكيد السحب"
        cancelText="إلغاء"
        variant="warning"
        onConfirm={confirmWithdrawal}
        onCancel={() => {
          setConfirmOpen(false);
          setPendingSubmit(null);
        }}
      />

      {/* KYC Status */}
      {kycStatus && kycStatus !== 'verified' && (
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4 flex items-start gap-3 animate-scaleIn">
          <ShieldX size={20} className="text-yellow-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-yellow-400 font-bold text-sm">
              يجب توثيق الحساب (KYC) قبل السحب
            </p>
            <p className="text-gray-400 text-xs mt-1">
              {kycStatus === 'not_submitted'
                ? 'لم تقم بتقديم وثائق التوثيق بعد.'
                : kycStatus === 'pending'
                ? 'وثائقك قيد المراجعة حالياً.'
                : 'تم رفض وثائق التوثيق. يرجى إعادة التقديم.'}
            </p>
            <button
              onClick={() => router.push('/dashboard/kyc')}
              className="mt-2 px-4 py-1.5 bg-[#FFD700]/10 border border-[#FFD700]/20 rounded-lg text-[#FFD700] text-xs font-medium hover:bg-[#FFD700]/20 transition-colors"
            >
              {kycStatus === 'rejected' ? 'إعادة التقديم' : 'توثيق الحساب'}
            </button>
          </div>
        </div>
      )}

      {kycStatus === 'verified' && (
        <div className="bg-[#2ECC71]/10 border border-[#2ECC71]/20 rounded-xl p-3 flex items-center gap-2 animate-fadeInUp">
          <ShieldCheck size={18} className="text-[#2ECC71]" />
          <p className="text-[#2ECC71] text-xs font-medium">
            الحساب موثق - يمكنك السحب
          </p>
        </div>
      )}

      {/* Available Balance - Prominent */}
      <div className="glass-card-premium p-5 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute top-0 left-0 w-32 h-32 bg-[#FFD700]/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-[#2ECC71]/5 rounded-full translate-x-1/2 translate-y-1/2" />

        <div className="relative flex items-start justify-between">
          <div>
            <p className="text-gray-400 text-sm mb-1">الرصيد المتاح للسحب</p>
            <p className="text-3xl sm:text-4xl font-bold text-[#FFD700] number-glow tabular-nums">
              ${animatedBalance.toFixed(2)}
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center icon-pulse-gold">
            <Wallet size={22} className="text-[#FFD700]" />
          </div>
        </div>

        {available < withdrawalSettings.minWithdraw && !dataLoading && (
          <div className="mt-3 flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-lg p-2.5">
            <AlertTriangle size={14} className="text-red-400 shrink-0" />
            <p className="text-red-400 text-xs">
              رصيدك أقل من الحد الأدنى للسحب (${withdrawalSettings.minWithdraw})
            </p>
          </div>
        )}
      </div>

      {/* Withdrawal Limits Info */}
      <div className="grid grid-cols-3 gap-2 stagger-children">
        <div className="glass-card p-3 text-center">
          <p className="text-gray-500 text-[10px] mb-1">الحد الأدنى</p>
          <p className="text-white font-bold text-sm tabular-nums">
            ${withdrawalSettings.minWithdraw}
          </p>
        </div>
        <div className="glass-card p-3 text-center">
          <p className="text-gray-500 text-[10px] mb-1">الحد الأقصى</p>
          <p className="text-white font-bold text-sm tabular-nums">
            ${withdrawalSettings.maxWithdraw.toLocaleString()}
          </p>
        </div>
        <div className="glass-card p-3 text-center">
          <p className="text-gray-500 text-[10px] mb-1">رسوم السحب</p>
          <p className="text-yellow-400 font-bold text-sm tabular-nums">
            ${withdrawalSettings.withdrawalFee}
          </p>
        </div>
      </div>

      {/* Withdrawal Form */}
      <form
        onSubmit={handleSubmit}
        className="glass-card p-5 space-y-4 neon-emerald"
      >
        {/* Withdrawal Method */}
        <div>
          <label className="text-gray-400 text-xs block mb-2 font-medium">
            طريقة السحب
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {[
              {
                id: 'USDT_TRC20',
                name: 'USDT TRC20',
                icon: '⚡',
                fee: 1,
                time: '5-15 دقيقة',
                desc: 'سريع ورسوم منخفضة',
              },
              {
                id: 'USDT_ERC20',
                name: 'USDT ERC20',
                icon: '🔗',
                fee: 3,
                time: '10-30 دقيقة',
                desc: 'آمن وموثوق',
              },
              {
                id: 'BANK',
                name: 'تحويل بنكي',
                icon: '🏦',
                fee: 5,
                time: '1-3 أيام عمل',
                desc: 'تحويل مباشر',
              },
            ].map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setForm((prev) => ({ ...prev, method: m.id }))}
                className={`p-3 rounded-xl border text-right transition-all duration-300 ${
                  form.method === m.id
                    ? 'border-[#2ECC71] bg-[#2ECC71]/10 neon-emerald'
                    : 'border-[#2A3040] bg-[#12161F] hover:border-[#3A4050]'
                }`}
              >
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-lg">{m.icon}</span>
                  <div className="flex-1">
                    <span
                      className={`font-medium text-sm block ${
                        form.method === m.id ? 'text-[#2ECC71]' : 'text-white'
                      }`}
                    >
                      {m.name}
                    </span>
                  </div>
                  {form.method === m.id && (
                    <Check size={14} className="text-[#2ECC71]" />
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-yellow-400 text-[10px]">
                    رسوم: ${m.fee}
                  </span>
                  <span className="text-gray-500 text-[10px]">{m.time}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Amount */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-gray-400 text-xs font-medium">
              المبلغ ($)
            </label>
            <button
              type="button"
              onClick={handleAllBalance}
              className="text-[#2ECC71] text-[11px] font-medium hover:underline"
            >
              سحب الكل
            </button>
          </div>
          <div className="relative">
            <input
              type="number"
              min="10"
              step="0.01"
              placeholder="أدخل المبلغ"
              value={form.amount}
              onChange={(e) => {
                setForm((prev) => ({ ...prev, amount: e.target.value }));
                setShowCustomAmount(false);
              }}
              required
              className="input-premium !pl-16"
              dir="ltr"
            />
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-bold">
              USD
            </span>
          </div>
        </div>

        {/* Quick Amount Buttons */}
        <div>
          <label className="text-gray-500 text-[10px] block mb-2">
            مبالغ سريعة
          </label>
          <div className="flex gap-2 flex-wrap">
            {QUICK_AMOUNTS.map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => handleQuickAmount(amt)}
                className={`px-4 py-2 rounded-xl text-sm font-bold transition-all duration-200 ${
                  form.amount === String(amt) && !showCustomAmount
                    ? 'bg-[#FFD700] text-[#0A0F0D] shadow-lg shadow-[#FFD700]/20'
                    : 'bg-[#12161F] border border-[#2A3040] text-gray-300 hover:border-[#FFD700]/50 hover:text-[#FFD700]'
                }`}
              >
                ${amt}
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                setShowCustomAmount(true);
                setForm((prev) => ({ ...prev, amount: '' }));
              }}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all duration-200 ${
                showCustomAmount
                  ? 'bg-[#FFD700] text-[#0A0F0D] shadow-lg shadow-[#FFD700]/20'
                  : 'bg-[#12161F] border border-[#2A3040] text-gray-300 hover:border-[#FFD700]/50 hover:text-[#FFD700]'
              }`}
            >
              مخصص
            </button>
          </div>
          {showCustomAmount && (
            <div className="mt-2">
              <input
                type="number"
                placeholder="أدخل مبلغ مخصص"
                value={customAmountValue}
                onChange={(e) => {
                  setCustomAmountValue(e.target.value);
                  setForm((prev) => ({ ...prev, amount: e.target.value }));
                }}
                className="input-premium text-sm"
                dir="ltr"
                autoFocus
              />
            </div>
          )}
        </div>

        {/* Insufficient Balance Warning */}
        {isInsufficient && (
          <div className="flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-lg p-2.5 animate-fadeIn">
            <AlertTriangle size={14} className="text-red-400 shrink-0" />
            <p className="text-red-400 text-xs">
              الرصيد غير كافي. الرصيد المطلوب: ${(parseAmount + totalFee).toFixed(2)}
            </p>
          </div>
        )}

        {/* Network Fee Indicator */}
        {parseAmount > 0 && (
          <div className="bg-[#12161F] rounded-xl p-3 border border-[#2A3040]/50 animate-fadeIn">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">المبلغ المطلوب</span>
              <span className="text-white font-bold tabular-nums">
                ${parseAmount.toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs mt-1">
              <div className="flex items-center gap-1">
                <Zap size={10} className="text-yellow-400" />
                <span className="text-gray-500">رسوم الشبكة ({form.method})</span>
              </div>
              <span className="text-yellow-400 tabular-nums">
                -${getNetworkFee().toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs mt-1">
              <span className="text-gray-500">رسوم المنصة</span>
              <span className="text-yellow-400 tabular-nums">
                -${withdrawalSettings.withdrawalFee.toFixed(2)}
              </span>
            </div>
            <div className="gradient-divider my-2" />
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-300 font-medium">المبلغ الصافي</span>
              <span
                className={`font-bold tabular-nums ${
                  isInsufficient ? 'text-red-400' : 'text-[#2ECC71]'
                }`}
              >
                $
                {Math.max(0, parseAmount - totalFee).toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px] mt-1 text-gray-500">
              <span>إجمالي الرسوم</span>
              <span>${totalFee.toFixed(2)}</span>
            </div>
          </div>
        )}

        {/* Wallet Address */}
        <div>
          <label className="text-gray-400 text-xs mb-1 block font-medium">
            عنوان محفظة {form.method === 'BANK' ? 'البنك (IBAN)' : 'USDT'}
          </label>
          <input
            placeholder={
              form.method === 'BANK'
                ? 'أدخل رقم IBAN أو الحساب البنكي'
                : '0x... أو T...'
            }
            value={form.wallet}
            onChange={(e) => setForm((prev) => ({ ...prev, wallet: e.target.value }))}
            required
            className="input-premium"
            dir="ltr"
          />
        </div>

        {/* Info */}
        <div className="flex items-center gap-2 text-yellow-400 text-xs bg-yellow-500/5 rounded-lg p-2.5">
          <AlertTriangle size={14} className="shrink-0" />
          <span>سيتم مراجعة طلبك خلال 24 ساعة</span>
        </div>

        <button
          type="submit"
          disabled={loading || isInsufficient || !form.wallet}
          className="btn-premium-gold disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              جاري التقديم...
            </>
          ) : (
            'تقديم طلب سحب'
          )}
        </button>
      </form>

      {/* Withdrawals History */}
      {dataLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="glass-card p-4">
              <div className="skeleton-premium h-4 w-32 mb-2" />
              <div className="skeleton-premium h-3 w-48 mb-1" />
              <div className="skeleton-premium h-3 w-24" />
            </div>
          ))}
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <h2 className="text-white font-bold text-lg">سجل السحوبات</h2>
            <div className="flex items-center gap-2">
              {!dataLoading && withdrawals.length > 0 && (
                <button
                  onClick={() =>
                    exportCSV(
                      withdrawals,
                      `withdrawals-${new Date().toISOString().slice(0, 10)}.csv`
                    )
                  }
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium bg-[#1A1F2E] text-gray-300 border border-[#2A3040] hover:border-[#2ECC71] transition-colors"
                >
                  <Download size={14} />
                  <span className="hidden sm:inline">تصدير</span>
                </button>
              )}
              {total > 0 && (
                <span className="text-gray-500 text-xs">{total} سحب</span>
              )}
            </div>
          </div>

          {withdrawals.length === 0 ? (
            <div className="glass-card p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
                <ArrowDownToLine size={28} className="text-gray-600" />
              </div>
              <p className="text-gray-400 text-lg font-medium mb-2">
                لا توجد طلبات سحب بعد
              </p>
              <p className="text-gray-500 text-sm">قدم طلب سحب أولي الآن</p>
            </div>
          ) : (
            <div className="space-y-3">
              {withdrawals.map((w, idx) => {
                const isExpanded = expandedWithdrawal === w.id;
                const netAmount = Math.max(
                  0,
                  w.amount - totalFee
                );

                return (
                  <div
                    key={w.id}
                    className="glass-card overflow-hidden animate-fadeInUp"
                    style={{ animationDelay: `${idx * 0.05}s` }}
                  >
                    {/* Desktop Row */}
                    <div className="hidden md:block">
                      <div className="flex items-center p-3 hover:bg-[#2A3040]/20 transition-colors">
                        <div className="flex-1 flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center">
                            <ArrowDownToLine size={18} className="text-[#FFD700]" />
                          </div>
                          <div>
                            <p className="text-white font-bold text-sm">
                              ${w.amount.toFixed(2)}
                            </p>
                            <p
                              className="text-gray-500 text-xs max-w-[140px] truncate"
                              dir="ltr"
                            >
                              {w.walletAddress}
                            </p>
                          </div>
                        </div>
                        <div className="text-gray-300 text-xs">
                          {new Date(w.createdAt).toLocaleDateString('ar', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })}
                        </div>
                        <div className="text-gray-400 text-xs">
                          <span className="text-yellow-400">-${totalFee}$</span> رسوم
                        </div>
                        <div className="w-28">{statusBadge(w.status)}</div>
                      </div>
                      {(w.status === 'pending' || w.status === 'processing' || w.status === 'rejected') && (
                        <div className="px-3 pb-3 border-t border-[#2A3040]/30">
                          <StatusTimeline
                            status={w.status}
                            rejectReason={w.rejectReason}
                          />
                        </div>
                      )}
                    </div>

                    {/* Mobile Card */}
                    <div className="md:hidden p-4">
                      <div
                        className="flex items-center justify-between"
                        onClick={() =>
                          setExpandedWithdrawal(isExpanded ? null : w.id)
                        }
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center">
                            <ArrowDownToLine size={18} className="text-[#FFD700]" />
                          </div>
                          <div>
                            <p className="text-white font-bold">
                              ${w.amount.toFixed(2)}
                            </p>
                            <p className="text-gray-500 text-xs">سحب</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {statusBadge(w.status)}
                          <ChevronDown
                            size={16}
                            className={`text-gray-500 transition-transform duration-200 ${
                              isExpanded ? 'rotate-180' : ''
                            }`}
                          />
                        </div>
                      </div>

                      <div
                        className={`overflow-hidden transition-all duration-300 ${
                          isExpanded
                            ? 'max-h-80 opacity-100 mt-3'
                            : 'max-h-0 opacity-0'
                        }`}
                      >
                        <div className="pt-3 border-t border-[#2A3040]/50 space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">التاريخ</span>
                            <span className="text-gray-300">
                              {new Date(w.createdAt).toLocaleDateString('ar', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric',
                              })}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">المحفظة</span>
                            <span
                              className="text-gray-400 max-w-[160px] truncate"
                              dir="ltr"
                            >
                              {w.walletAddress}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">الرسوم</span>
                            <span className="text-yellow-400">-${totalFee}$</span>
                          </div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">صافي المبلغ</span>
                            <span className="text-[#2ECC71] font-bold">
                              ${netAmount.toFixed(2)}
                            </span>
                          </div>
                          {(w.status === 'pending' ||
                            w.status === 'processing' ||
                            w.status === 'rejected') && (
                            <StatusTimeline
                              status={w.status}
                              rejectReason={w.rejectReason}
                            />
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Pagination */}
      {total > 10 && (
        <div className="flex justify-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-50"
          >
            السابق
          </button>
          <span className="px-4 py-2 text-gray-400 text-xs">
            صفحة {page} من {Math.ceil(total / 10)}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={page >= Math.ceil(total / 10)}
            className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-50"
          >
            التالي
          </button>
        </div>
      )}
    </div>
  );
}
