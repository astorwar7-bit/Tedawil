'use client';
import { useEffect, useState, useRef } from 'react';
import {
  TrendingUp, Wallet, Clock, CheckCircle, BarChart3,
  ChevronLeft, ChevronRight, Filter
} from 'lucide-react';

interface PlanInfo {
  name: string;
  nameEn: string;
  icon: string;
  color: string;
}

interface Investment {
  id: string;
  amount: number;
  dailyRate: number;
  startDate: string;
  endDate: string;
  expectedProfit: number;
  actualProfit: number;
  isActive: boolean;
  createdAt: string;
  plan?: PlanInfo | null;
}

interface Stats {
  totalInvested: number;
  activeCount: number;
  totalEarned: number;
  pendingReturns: number;
}

const STATUS_FILTERS = [
  { key: '', label: 'الكل' },
  { key: 'active', label: 'نشطة' },
  { key: 'completed', label: 'منتهية' },
];

// Animated count-up hook
function useCountUp(target: number, duration: number = 1200, enabled: boolean = true) {
  const [value, setValue] = useState(0);
  const startRef = useRef<number | null>(null);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    if (!enabled) { setValue(0); return; }
    startRef.current = null;

    let active = true;

    const step = (timestamp: number) => {
      if (!active) return;
      if (!startRef.current) startRef.current = timestamp;
      const elapsed = timestamp - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(eased * target);
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(step);
      }
    };

    frameRef.current = requestAnimationFrame(step);
    return () => {
      active = false;
      cancelAnimationFrame(frameRef.current);
    };
  }, [target, duration, enabled]);

  return value;
}

function ProgressRing({ progress, size = 44, strokeWidth = 4, color = '#2ECC71' }: {
  progress: number; size?: number; strokeWidth?: number; color?: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (Math.min(progress, 100) / 100) * circumference;

  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle
        cx={size / 2} cy={size / 2} r={radius}
        stroke="rgba(42,48,64,0.5)" strokeWidth={strokeWidth} fill="none"
      />
      <circle
        cx={size / 2} cy={size / 2} r={radius}
        stroke={color} strokeWidth={strokeWidth} fill="none"
        strokeDasharray={circumference} strokeDashoffset={offset}
        strokeLinecap="round"
        className="transition-all duration-1000 ease-out"
      />
    </svg>
  );
}

function StatCardSkeleton() {
  return (
    <div className="glass-card p-4 text-center">
      <div className="skeleton-premium w-10 h-10 rounded-xl mx-auto mb-2" />
      <div className="skeleton-premium h-5 w-20 mx-auto mb-1" />
      <div className="skeleton-premium h-3 w-16 mx-auto" />
    </div>
  );
}

function InvestmentCardSkeleton() {
  return (
    <div className="glass-card p-5">
      <div className="flex items-center gap-3 mb-4">
        <div className="skeleton-premium w-12 h-12 rounded-xl" />
        <div className="flex-1">
          <div className="skeleton-premium h-4 w-32 mb-2" />
          <div className="skeleton-premium h-3 w-24" />
        </div>
        <div className="skeleton-premium w-16 h-6 rounded-full" />
      </div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i}>
            <div className="skeleton-premium h-3 w-12 mb-1" />
            <div className="skeleton-premium h-4 w-20" />
          </div>
        ))}
      </div>
      <div className="skeleton-premium h-2 w-full rounded-full" />
    </div>
  );
}

export default function InvestmentsPage() {
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats>({
    totalInvested: 0, activeCount: 0, totalEarned: 0, pendingReturns: 0,
  });

  const animatedTotal = useCountUp(stats.totalInvested, 1400, !loading);
  const animatedEarned = useCountUp(stats.totalEarned, 1200, !loading);
  const animatedPending = useCountUp(stats.pendingReturns, 1000, !loading);
  const limit = 10;

  const fetchInvestments = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/investments?page=${page}&limit=${limit}&status=${status}`);
      const data = await res.json();
      const invList = data.investments || [];

      setInvestments(invList);
      setTotal(data.total || 0);

      // Calculate stats from the investments
      const totalInvested = invList.reduce((s: number, i: Investment) => s + i.amount, 0);
      const activeCount = invList.filter((i: Investment) => i.isActive).length;
      const totalEarned = invList.reduce((s: number, i: Investment) => s + i.actualProfit, 0);
      const pendingReturns = invList
        .filter((i: Investment) => i.isActive)
        .reduce((s: number, i: Investment) => s + (i.expectedProfit - i.actualProfit), 0);

      setStats({ totalInvested, activeCount, totalEarned, pendingReturns });
    } catch (err) {
      console.error('Investments fetch error:', err);
    }
    setLoading(false);
  };

  useEffect(() => { fetchInvestments(); }, [page, status]);

  const getDaysInfo = (start: string, end: string) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    const now = new Date();
    const totalDays = Math.max(1, Math.ceil((endDate.getTime() - startDate.getTime()) / 86400000));
    const elapsed = Math.max(0, Math.ceil((now.getTime() - startDate.getTime()) / 86400000));
    const remaining = Math.max(0, totalDays - elapsed);
    const progress = Math.min(100, (elapsed / totalDays) * 100);
    return { totalDays, elapsed, remaining, progress };
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6">
      {/* Page Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-[#2ECC71]/10 via-[#1A1F2E] to-[#FFD700]/10 border border-[#2A3040] p-5">
        <div className="absolute top-0 left-0 w-32 h-32 bg-[#2ECC71]/5 rounded-full -translate-x-1/2 -translate-y-1/2 animate-glow-pulse" />
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-[#FFD700]/5 rounded-full translate-x-1/2 translate-y-1/2 animate-glow-pulse" />
        <div className="relative flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#2ECC71]/10 border border-[#2ECC71]/20 flex items-center justify-center icon-pulse-emerald">
            <TrendingUp size={24} className="text-[#2ECC71]" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">استثماراتي</h1>
            <p className="text-gray-400 text-xs mt-0.5">تتبع استثماراتك وأرباحك اليومية</p>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 stagger-children">
        {loading ? (
          <>
            <StatCardSkeleton />
            <StatCardSkeleton />
            <StatCardSkeleton />
            <StatCardSkeleton />
          </>
        ) : (
          <>
            <div className="glass-card p-4 text-center premium-shimmer">
              <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center icon-pulse-gold">
                <BarChart3 size={18} className="text-[#FFD700]" />
              </div>
              <p className="text-lg font-bold text-[#FFD700] number-glow tabular-nums">
                ${animatedTotal.toFixed(2)}
              </p>
              <p className="text-gray-400 text-[10px] mt-1">إجمالي المستثمر</p>
            </div>
            <div className="glass-card p-4 text-center premium-shimmer">
              <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-[#2ECC71]/10 border border-[#2ECC71]/20 flex items-center justify-center icon-pulse-emerald">
                <TrendingUp size={18} className="text-[#2ECC71]" />
              </div>
              <p className="text-lg font-bold text-[#2ECC71] number-glow tabular-nums">
                {stats.activeCount}
              </p>
              <p className="text-gray-400 text-[10px] mt-1">استثمارات نشطة</p>
            </div>
            <div className="glass-card p-4 text-center premium-shimmer">
              <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                <CheckCircle size={18} className="text-emerald-400" />
              </div>
              <p className="text-lg font-bold text-emerald-400 number-glow tabular-nums">
                ${animatedEarned.toFixed(2)}
              </p>
              <p className="text-gray-400 text-[10px] mt-1">إجمالي الأرباح</p>
            </div>
            <div className="glass-card p-4 text-center premium-shimmer">
              <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center">
                <Clock size={18} className="text-yellow-400" />
              </div>
              <p className="text-lg font-bold text-yellow-400 number-glow tabular-nums">
                ${animatedPending.toFixed(2)}
              </p>
              <p className="text-gray-400 text-[10px] mt-1">عوائد متوقعة</p>
            </div>
          </>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        <Filter size={14} className="text-gray-500 shrink-0" />
        {STATUS_FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => { setStatus(f.key); setPage(1); }}
            className={`flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all duration-300 ${
              status === f.key
                ? 'bg-[#2ECC71] text-white shadow-lg shadow-[#2ECC71]/20'
                : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-[#2ECC71]/50 hover:text-gray-300'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Investments List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <InvestmentCardSkeleton key={i} />
          ))}
        </div>
      ) : investments.length === 0 ? (
        <div className="glass-card p-8 sm:p-12 text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
            <Wallet size={36} className="text-gray-600" />
          </div>
          <p className="text-gray-300 font-bold text-lg mb-2">لا توجد استثمارات بعد</p>
          <p className="text-gray-500 text-sm max-w-xs mx-auto">
            {status === 'active'
              ? 'لا توجد استثمارات نشطة حالياً. ابدأ استثماراً جديداً لتحقيق أرباح يومية.'
              : status === 'completed'
              ? 'لم تنتهِ أي استثمارات بعد. استثماراتك النشطة ما زالت تعمل.'
              : 'ابدأ الاستثمار الآن واستمتع بأرباح يومية مستدامة من خطط الاستثمار المتنوعة.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {investments.map((inv, idx) => {
            const daysInfo = getDaysInfo(inv.startDate, inv.endDate);
            const planIcon = inv.plan?.icon || '📊';
            const planName = inv.plan?.name || 'خطة افتراضية';
            const planColor = inv.plan?.color || '#2ECC71';

            return (
              <div
                key={inv.id}
                className="glass-card overflow-hidden animate-fadeInUp"
                style={{ animationDelay: `${idx * 0.06}s` }}
              >
                {/* Card Header */}
                <div className="p-4 sm:p-5">
                  <div className="flex items-center gap-3 mb-4">
                    {/* Plan Icon */}
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center text-xl shrink-0"
                      style={{
                        background: `${planColor}15`,
                        border: `1px solid ${planColor}30`,
                      }}
                    >
                      {planIcon}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-white font-bold text-sm truncate">{planName}</h3>
                        {inv.isActive && (
                          <span className="relative flex h-2 w-2 shrink-0">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#2ECC71] opacity-75" />
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#2ECC71]" />
                          </span>
                        )}
                      </div>
                      <p className="text-gray-500 text-xs mt-0.5">
                        {inv.dailyRate}% يومياً • {daysInfo.totalDays} يوم
                      </p>
                    </div>

                    {/* Status Badge */}
                    <span
                      className={`px-3 py-1 rounded-full text-[10px] font-bold border whitespace-nowrap ${
                        inv.isActive
                          ? 'bg-[#2ECC71]/10 text-[#2ECC71] border-[#2ECC71]/20'
                          : 'bg-gray-500/10 text-gray-400 border-gray-500/20'
                      }`}
                    >
                      {inv.isActive ? 'نشط' : 'منتهي'}
                    </span>
                  </div>

                  {/* Info Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                    <div className="bg-[#12161F] rounded-lg p-2.5">
                      <p className="text-gray-500 text-[10px] mb-0.5">مبلغ الاستثمار</p>
                      <p className="text-white font-bold text-sm tabular-nums">${inv.amount.toFixed(2)}</p>
                    </div>
                    <div className="bg-[#12161F] rounded-lg p-2.5">
                      <p className="text-gray-500 text-[10px] mb-0.5">الربح المتوقع</p>
                      <p className="text-[#FFD700] font-bold text-sm tabular-nums">${inv.expectedProfit.toFixed(2)}</p>
                    </div>
                    <div className="bg-[#12161F] rounded-lg p-2.5">
                      <p className="text-gray-500 text-[10px] mb-0.5">الربح المكتسب</p>
                      <p className="text-[#2ECC71] font-bold text-sm tabular-nums">${inv.actualProfit.toFixed(2)}</p>
                    </div>
                    <div className="bg-[#12161F] rounded-lg p-2.5">
                      <p className="text-gray-500 text-[10px] mb-0.5">تاريخ الانتهاء</p>
                      <p className="text-gray-300 font-medium text-xs tabular-nums">
                        {new Date(inv.endDate).toLocaleDateString('ar', {
                          month: 'short', day: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>

                  {/* Progress Section */}
                  <div className="flex items-center gap-3">
                    <ProgressRing
                      progress={daysInfo.progress}
                      size={40}
                      strokeWidth={3.5}
                      color={inv.isActive ? '#2ECC71' : '#4B5563'}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-gray-400 text-[10px]">
                          {inv.isActive
                            ? `${daysInfo.remaining} يوم متبقي`
                            : 'اكتملت المدة'}
                        </span>
                        <span className="text-gray-400 text-[10px] tabular-nums">
                          {Math.round(daysInfo.progress)}%
                        </span>
                      </div>
                      <div className="h-1.5 bg-[#12161F] rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full transition-all duration-1000 ease-out"
                          style={{
                            width: `${Math.min(daysInfo.progress, 100)}%`,
                            background: inv.isActive
                              ? `linear-gradient(to left, #2ECC71, #27AE60)`
                              : '#4B5563',
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bottom Divider */}
                <div className="gradient-divider" />
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {!loading && total > limit && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="flex items-center gap-1 px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-40 transition-colors hover:border-[#2ECC71]/50"
          >
            <ChevronRight size={14} />
            السابق
          </button>
          <span className="px-4 py-2 text-gray-400 text-xs tabular-nums">
            صفحة {page} من {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={page >= totalPages}
            className="flex items-center gap-1 px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-40 transition-colors hover:border-[#2ECC71]/50"
          >
            التالي
            <ChevronLeft size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
