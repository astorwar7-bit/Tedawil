'use client';
import { useEffect, useState } from 'react';
import { ExternalLink } from 'lucide-react';

interface Ad { id: string; type: string; title: string; content: string; link: string; imageUrl: string; priority: number; }

export default function AdsPage() {
  const [ads, setAds] = useState<Ad[]>([]);

  useEffect(() => {
    fetch('/api/ads').then(r => r.json()).then(d => setAds(d.ads || []));
  }, []);

  return (
    <div className="space-y-4 animate-fadeIn pb-20 lg:pb-6">
      <h1 className="text-2xl font-bold text-white">الإعلانات</h1>

      {ads.length === 0 ? (
        <div className="bg-[#1A1F2E] rounded-xl p-8 border border-[#2A3040] text-center text-gray-500">لا توجد إعلانات حالياً</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {ads.map(ad => (
            <div key={ad.id} className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040] hover:border-[#FFD700]/30 transition-colors">
              {ad.type === 'image' && ad.imageUrl && (
                <img src={ad.imageUrl} alt={ad.title} className="w-full h-40 object-cover rounded-lg mb-3" />
              )}
              <h3 className="text-white font-bold mb-2">{ad.title}</h3>
              {ad.content && <p className="text-gray-400 text-sm mb-3">{ad.content}</p>}
              {ad.link && (
                <a href={ad.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[#FFD700] text-sm hover:underline">
                  عرض التفاصيل <ExternalLink size={14} />
                </a>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
