'use client';
import { useEffect, useState } from 'react';
import { Copy, Check, Users, Gift, TrendingUp, DollarSign, Wallet, UserPlus, Clock, Star } from 'lucide-react';

interface ReferralData {
  referralCode: string;
  referralLink: string;
  totalReferred: number;
  totalReferralEarnings: number;
  totalSignupBonuses: number;
  totalDailyReferral: number;
  todayReferralEarnings: number;
  referralBonusRate: number;
  referralFixedBonus: number;
  referredUsers: { username: string; fullName: string; createdAt: string }[];
}

export default function ReferralsPage() {
  const [data, setData] = useState<ReferralData | null>(null);
  const [copied, setCopied] = useState('');

  useEffect(() => {
    fetch('/api/referrals').then(r => r.json()).then(d => setData(d));
  }, []);

  const copyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(''), 2000);
  };

  if (!data) {
    return (
      <div className="space-y-4 animate-fadeIn pb-20 lg:pb-6">
        <div className="skeleton-premium h-7 w-32" />
        <div className="skeleton-card" />
        <div className="grid grid-cols-2 gap-3">
          <div className="skeleton-premium h-24 rounded-xl" />
          <div className="skeleton-premium h-24 rounded-xl" />
        </div>
        <div className="skeleton-premium h-16 rounded-xl" />
        <div className="skeleton-card" />
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-fadeIn pb-20 lg:pb-6">
      <h1 className="text-2xl font-bold text-white">الإحالات</h1>

      {/* كود ورابط الإحالة */}
      <div className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040] space-y-4">
        <div>
          <label className="text-gray-400 text-sm mb-1 block">كود الإحالة</label>
          <div className="flex gap-2">
            <input readOnly value={data.referralCode} className="flex-1 bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-3 text-[#FFD700] font-bold text-sm" dir="ltr" />
            <button onClick={() => copyText(data.referralCode, 'code')} className="px-4 py-3 bg-[#2A3040] rounded-xl hover:bg-[#3A4050] transition-colors">
              {copied === 'code' ? <Check size={18} className="text-[#2ECC71]" /> : <Copy size={18} className="text-gray-400" />}
            </button>
          </div>
        </div>
        <div>
          <label className="text-gray-400 text-sm mb-1 block">رابط الدعوة</label>
          <div className="flex gap-2">
            <input readOnly value={data.referralLink} className="flex-1 bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-3 text-gray-300 text-xs truncate" dir="ltr" />
            <button onClick={() => copyText(data.referralLink, 'link')} className="px-4 py-3 bg-[#2A3040] rounded-xl hover:bg-[#3A4050] transition-colors">
              {copied === 'link' ? <Check size={18} className="text-[#2ECC71]" /> : <Copy size={18} className="text-gray-400" />}
            </button>
          </div>
        </div>
      </div>

      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-[#1A1F2E] rounded-xl p-4 border border-[#2A3040]">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-[#FFD700]/10 flex items-center justify-center">
              <Users size={16} className="text-[#FFD700]" />
            </div>
            <span className="text-gray-400 text-xs">عدد المدعوين</span>
          </div>
          <p className="text-2xl font-bold text-white">{data.totalReferred}</p>
          <p className="text-[10px] text-gray-600 mt-1">أشخاص سجلوا بكودك</p>
        </div>

        <div className="bg-[#1A1F2E] rounded-xl p-4 border border-[#2A3040]">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center">
              <DollarSign size={16} className="text-[#2ECC71]" />
            </div>
            <span className="text-gray-400 text-xs">إجمالي الأرباح</span>
          </div>
          <p className="text-2xl font-bold text-[#2ECC71]">${data.totalReferralEarnings.toFixed(2)}</p>
          <p className="text-[10px] text-gray-600 mt-1">اليوم: ${data.todayReferralEarnings.toFixed(2)}</p>
        </div>

        <div className="bg-[#1A1F2E] rounded-xl p-4 border border-[#2A3040]">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-[#FFD700]/10 flex items-center justify-center">
              <Gift size={16} className="text-[#FFD700]" />
            </div>
            <span className="text-gray-400 text-xs">مكافآت التسجيل</span>
          </div>
          <p className="text-2xl font-bold text-[#FFD700]">${data.totalSignupBonuses.toFixed(2)}</p>
          <p className="text-[10px] text-gray-600 mt-1">${data.referralFixedBonus} لكل تسجيل جديد</p>
        </div>

        <div className="bg-[#1A1F2E] rounded-xl p-4 border border-[#2A3040]">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-[#3498DB]/10 flex items-center justify-center">
              <TrendingUp size={16} className="text-[#3498DB]" />
            </div>
            <span className="text-gray-400 text-xs">أرباح يومية من الدعوة</span>
          </div>
          <p className="text-2xl font-bold text-[#3498DB]">${data.totalDailyReferral.toFixed(2)}</p>
          <p className="text-[10px] text-gray-600 mt-1">{data.referralBonusRate}% من أرباحهم</p>
        </div>
      </div>

      {/* كيف تعمل الإحالات */}
      <div className="bg-[#1A1F2E] rounded-xl p-5 border border-[#2A3040] space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Star size={16} className="text-[#FFD700]" />
          كيف تعمل الإحالات؟
        </h3>
        <div className="space-y-2.5">
          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/[0.02]">
            <div className="w-7 h-7 rounded-lg bg-[#FFD700]/10 flex items-center justify-center shrink-0 mt-0.5">
              <UserPlus size={13} className="text-[#FFD700]" />
            </div>
            <div>
              <p className="text-gray-200 text-sm font-medium">مكافأة عند التسجيل</p>
              <p className="text-gray-500 text-xs">تحصل على <span className="text-[#FFD700] font-bold">${data.referralFixedBonus}</span> فوراً في رصيدك لكل شخص يسجل بكود إحالتك</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/[0.02]">
            <div className="w-7 h-7 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center shrink-0 mt-0.5">
              <TrendingUp size={13} className="text-[#2ECC71]" />
            </div>
            <div>
              <p className="text-gray-200 text-sm font-medium">أرباح يومية مستمرة</p>
              <p className="text-gray-500 text-xs">تحصل على <span className="text-[#2ECC71] font-bold">{data.referralBonusRate}%</span> من أرباح كل شخص تدعوه يومياً طالما يستثمر</p>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/[0.02]">
            <div className="w-7 h-7 rounded-lg bg-[#3498DB]/10 flex items-center justify-center shrink-0 mt-0.5">
              <Wallet size={13} className="text-[#3498DB]" />
            </div>
            <div>
              <p className="text-gray-200 text-sm font-medium">سحب فوري</p>
              <p className="text-gray-500 text-xs">جميع المكافآت تُضاف لرصيدك الفعلي ويمكنك سحبها في أي وقت</p>
            </div>
          </div>
        </div>
      </div>

      {/* قائمة المدعوين */}
      <div className="bg-[#1A1F2E] rounded-xl border border-[#2A3040] overflow-hidden">
        <div className="p-4 border-b border-[#2A3040] flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Users size={16} className="text-gray-400" />
            الأشخاص الذين دعوتهم
          </h3>
          <span className="text-xs text-gray-500">{data.totalReferred} شخص</span>
        </div>

        {/* Desktop: Table view */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#2A3040]/50">
                <th className="text-right p-3 text-gray-500 font-medium text-xs">المستخدم</th>
                <th className="text-right p-3 text-gray-500 font-medium text-xs">تاريخ التسجيل</th>
                <th className="text-right p-3 text-gray-500 font-medium text-xs">مكافأة التسجيل</th>
              </tr>
            </thead>
            <tbody>
              {data.referredUsers.length === 0 ? (
                <tr>
                  <td colSpan={3}>
                    <div className="text-center py-12">
                      <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
                        <Users size={28} className="text-gray-600" />
                      </div>
                      <p className="text-gray-400 font-medium mb-1">لم تقم بدعوة أحد بعد</p>
                      <p className="text-gray-500 text-sm">شارك رابط الدعوة واكسب مكافآت حقيقية!</p>
                    </div>
                  </td>
                </tr>
              ) :
              data.referredUsers.map((u, i) => (
                <tr key={i} className="border-b border-[#2A3040]/50 hover:bg-white/[0.01] transition-colors">
                  <td className="p-3">
                    <div>
                      <p className="text-white font-medium">{u.username}</p>
                      <p className="text-gray-500 text-xs">{u.fullName}</p>
                    </div>
                  </td>
                  <td className="p-3 text-gray-400 text-xs flex items-center gap-1">
                    <Clock size={10} className="text-gray-600" />
                    {new Date(u.createdAt).toLocaleDateString('ar')}
                  </td>
                  <td className="p-3">
                    <span className="text-[#2ECC71] font-bold text-sm">+${data.referralFixedBonus.toFixed(2)}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile: Card view */}
        <div className="sm:hidden">
          {data.referredUsers.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
                <Users size={24} className="text-gray-600" />
              </div>
              <p className="text-gray-400 font-medium text-sm mb-1">لم تقم بدعوة أحد بعد</p>
              <p className="text-gray-500 text-xs">شارك رابط الدعوة واكسب مكافآت حقيقية!</p>
            </div>
          ) : (
            <div className="divide-y divide-[#2A3040]/50">
              {data.referredUsers.map((u, i) => (
                <div key={i} className="flex items-center gap-3 p-3">
                  <div className="w-9 h-9 rounded-full bg-[#12161F] border border-[#2A3040] flex items-center justify-center flex-shrink-0">
                    <span className="text-[#FFD700] font-bold text-xs">{u.username[0]?.toUpperCase()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{u.username}</p>
                    <div className="flex items-center gap-1 mt-0.5">
                      <Clock size={10} className="text-gray-600" />
                      <span className="text-[10px] text-gray-500">{new Date(u.createdAt).toLocaleDateString('ar')}</span>
                    </div>
                  </div>
                  <span className="text-xs font-bold text-[#2ECC71] flex-shrink-0">+${data.referralFixedBonus.toFixed(2)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
