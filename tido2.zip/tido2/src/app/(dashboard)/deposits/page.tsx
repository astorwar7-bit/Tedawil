'use client';
import { useEffect, useState, useRef, useCallback } from 'react';
import { useToast } from '@/contexts/ToastContext';
import {
  DollarSign, Clock, CheckCircle, ArrowUpCircle, Copy, Check,
  ChevronDown, X, Zap, Link2, Building2, CircleDot, Loader2,
  Wallet, TrendingUp, ArrowLeftRight
} from 'lucide-react';

interface Deposit {
  id: string;
  amount: number;
  method: string;
  txHash: string;
  screenshot: string;
  status: string;
  createdAt: string;
}

interface Stats {
  total: number;
  count: number;
  pending: number;
  approved: number;
}

interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
  iconBg: string;
  address: string;
  desc: string;
  fee: number;
  feeLabel: string;
  estimatedTime: string;
  network: string;
}

const DEFAULT_METHODS: PaymentMethod[] = [
  {
    id: 'USDT_TRC20',
    name: 'USDT TRC20',
    icon: '⚡',
    iconBg: 'from-orange-500/20 to-amber-500/20',
    address: '',
    desc: 'شبكة Tron - سريع ورسوم منخفضة',
    fee: 1,
    feeLabel: 'رسوم الشبكة',
    estimatedTime: '5-15 دقيقة',
    network: 'TRC20',
  },
  {
    id: 'USDT_ERC20',
    name: 'USDT ERC20',
    icon: '🔗',
    iconBg: 'from-blue-500/20 to-purple-500/20',
    address: '',
    desc: 'شبكة Ethereum - آمن وموثوق',
    fee: 3,
    feeLabel: 'رسوم الشبكة',
    estimatedTime: '10-30 دقيقة',
    network: 'ERC20',
  },
  {
    id: 'BANK',
    name: 'تحويل بنكي',
    icon: '🏦',
    iconBg: 'from-emerald-500/20 to-teal-500/20',
    address: '',
    desc: 'تحويل مباشر إلى الحساب البنكي',
    fee: 5,
    feeLabel: 'رسوم التحويل',
    estimatedTime: '1-3 أيام عمل',
    network: 'SWIFT',
  },
];

const QUICK_AMOUNTS = [100, 500, 1000, 5000];

// Animated count-up hook
function useCountUp(target: number, duration: number = 1200, enabled: boolean = true) {
  const [value, setValue] = useState(0);
  const startRef = useRef<number | null>(null);
  const frameRef = useRef<number>(0);

  const animate = useCallback((timestamp: number) => {
    if (!startRef.current) startRef.current = timestamp;
    const elapsed = timestamp - startRef.current;
    const progress = Math.min(elapsed / duration, 1);
    // Ease out cubic
    const eased = 1 - Math.pow(1 - progress, 3);
    setValue(eased * target);
    if (progress < 1) {
      frameRef.current = requestAnimationFrame(animate);
    }
  }, [target, duration]);

  useEffect(() => {
    if (!enabled) {
      setValue(0);
      return;
    }
    startRef.current = null;
    frameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameRef.current);
  }, [animate, enabled]);

  return value;
}

// Status Timeline component
function StatusTimeline({ status }: { status: string }) {
  const steps = [
    { key: 'pending', label: 'تم التقديم', icon: CircleDot },
    { key: 'processing', label: 'قيد المعالجة', icon: Loader2 },
    { key: 'approved', label: 'تمت الموافقة', icon: CheckCircle },
  ];

  const statusOrder: Record<string, number> = {
    pending: 0, processing: 1, approved: 2, rejected: -1,
  };
  const currentIdx = statusOrder[status] ?? 0;

  return (
    <div className="flex items-center gap-1 py-2">
      {steps.map((step, idx) => {
        const isCompleted = currentIdx >= idx + 1;
        const isActive = currentIdx === idx && status !== 'rejected';
        const isRejected = status === 'rejected';

        const Icon = step.icon;
        const isLast = idx === steps.length - 1;

        return (
          <div key={step.key} className="flex items-center">
            <div className="flex flex-col items-center gap-1">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-500 ${
                  isCompleted
                    ? 'bg-[#2ECC71]/20 border border-[#2ECC71]/50'
                    : isActive
                    ? 'bg-[#FFD700]/20 border border-[#FFD700]/50 animate-breathe'
                    : isRejected && step.key === 'approved'
                    ? 'bg-red-500/20 border border-red-500/50'
                    : 'bg-[#12161F] border border-[#2A3040]'
                }`}
              >
                {isActive && status === 'processing' ? (
                  <Loader2 size={14} className={`text-[#FFD700] animate-spin`} />
                ) : (
                  <Icon
                    size={14}
                    className={
                      isCompleted
                        ? 'text-[#2ECC71]'
                        : isActive
                        ? 'text-[#FFD700]'
                        : isRejected && step.key === 'approved'
                        ? 'text-red-400'
                        : 'text-gray-600'
                    }
                  />
                )}
              </div>
              <span
                className={`text-[10px] whitespace-nowrap ${
                  isCompleted
                    ? 'text-[#2ECC71]'
                    : isActive
                    ? 'text-[#FFD700]'
                    : 'text-gray-600'
                }`}
              >
                {isRejected && step.key === 'approved' ? 'مرفوض' : step.label}
              </span>
            </div>
            {!isLast && (
              <div
                className={`w-8 sm:w-10 h-0.5 mx-1 mt-[-16px] transition-all duration-500 ${
                  isCompleted ? 'bg-[#2ECC71]/50' : 'bg-[#2A3040]'
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function DepositsPage() {
  const { showToast } = useToast();
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [stats, setStats] = useState<Stats>({ total: 0, count: 0, pending: 0, approved: 0 });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ amount: '', method: 'USDT_TRC20', txHash: '', screenshot: '' });
  const [showForm, setShowForm] = useState(false);
  const [copiedAddr, setCopiedAddr] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(DEFAULT_METHODS);
  const [expandedDeposit, setExpandedDeposit] = useState<string | null>(null);
  const [customAmount, setCustomAmount] = useState(false);

  // Animated stats
  const animatedTotal = useCountUp(stats.total, 1400, !loading);
  const animatedPending = useCountUp(stats.pending, 1000, !loading);
  const animatedApproved = useCountUp(stats.approved, 1200, !loading);

  const fetchDeposits = async () => {
    setLoading(true);
    try {
      const [depRes, settingsRes] = await Promise.all([
        fetch(`/api/deposits?page=${page}&limit=10`),
        fetch('/api/settings'),
      ]);
      const data = await depRes.json();
      const settingsData = await settingsRes.json();
      setDeposits(data.deposits || []);
      setTotal(data.total || 0);
      setStats(data.stats || { total: 0, count: 0, pending: 0, approved: 0 });

      const mainAddress = settingsData.mainWalletAddress || '';
      if (mainAddress) {
        setPaymentMethods([
          {
            ...DEFAULT_METHODS[0],
            address: mainAddress,
          },
          {
            ...DEFAULT_METHODS[1],
            address: mainAddress,
          },
          {
            ...DEFAULT_METHODS[2],
          },
        ]);
      }
    } catch (err) {
      console.error('Deposits fetch error:', err);
      showToast('حدث خطأ أثناء التحميل', 'error');
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchDeposits();
  }, [page]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch('/api/deposits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error, 'error');
        return;
      }
      showToast(data.message);
      setForm({ amount: '', method: 'USDT_TRC20', txHash: '', screenshot: '' });
      setShowForm(false);
      fetchDeposits();
    } catch (err) {
      console.error('Deposit submit error:', err);
      showToast('حدث خطأ', 'error');
    }
    setSubmitting(false);
  };

  const statusBadge = (s: string) => {
    const map: Record<string, string> = {
      pending: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
      processing: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
      approved: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
      rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
    };
    const label: Record<string, string> = {
      pending: 'معلق',
      processing: 'قيد المعالجة',
      approved: 'موافق عليه',
      rejected: 'مرفوض',
    };
    return (
      <span
        className={`px-3 py-1 rounded-full text-xs font-medium border ${map[s] || ''}`}
      >
        {label[s] || s}
      </span>
    );
  };

  const methodLabel = (m: string) => {
    const found = paymentMethods.find((p) => p.id === m);
    return found ? found.name : m;
  };

  const methodIcon = (m: string) => {
    const found = paymentMethods.find((p) => p.id === m);
    return found ? found.icon : '💰';
  };

  const methodFee = (m: string) => {
    const found = paymentMethods.find((p) => p.id === m);
    return found ? found.fee : 0;
  };

  const copyAddress = (addr: string) => {
    navigator.clipboard.writeText(addr);
    setCopiedAddr(addr);
    setTimeout(() => setCopiedAddr(''), 2000);
    showToast('تم نسخ العنوان', 'success');
  };

  const selectedMethod = paymentMethods.find((p) => p.id === form.method);

  const handleQuickAmount = (amount: number) => {
    setForm((prev) => ({ ...prev, amount: String(amount) }));
    setCustomAmount(false);
  };

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">الإيداعات</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-premium-emerald !w-auto px-6 text-sm"
        >
          {showForm ? 'إلغاء' : '+ إيداع جديد'}
        </button>
      </div>

      {/* Stats Cards with Count-Up Animation */}
      <div className="grid grid-cols-3 gap-2 sm:gap-3 stagger-children">
        <div className="glass-card p-3 sm:p-4 text-center premium-shimmer">
          <div className="w-8 h-8 sm:w-10 sm:h-10 mx-auto mb-1.5 sm:mb-2 rounded-xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center icon-pulse-gold">
            <DollarSign size={18} className="text-[#FFD700]" />
          </div>
          <p className="text-base sm:text-xl font-bold text-[#FFD700] number-glow tabular-nums">
            ${animatedTotal.toFixed(2)}
          </p>
          <p className="text-gray-400 text-[10px] sm:text-xs mt-1">إجمالي الإيداعات</p>
        </div>
        <div className="glass-card p-3 sm:p-4 text-center premium-shimmer">
          <div className="w-8 h-8 sm:w-10 sm:h-10 mx-auto mb-1.5 sm:mb-2 rounded-xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center">
            <Clock size={18} className="text-yellow-400" />
          </div>
          <p className="text-base sm:text-xl font-bold text-yellow-400 number-glow tabular-nums">
            ${animatedPending.toFixed(2)}
          </p>
          <p className="text-gray-400 text-[10px] sm:text-xs mt-1">قيد المراجعة</p>
        </div>
        <div className="glass-card p-3 sm:p-4 text-center premium-shimmer">
          <div className="w-8 h-8 sm:w-10 sm:h-10 mx-auto mb-1.5 sm:mb-2 rounded-xl bg-[#2ECC71]/10 border border-[#2ECC71]/20 flex items-center justify-center icon-pulse-emerald">
            <CheckCircle size={18} className="text-[#2ECC71]" />
          </div>
          <p className="text-base sm:text-xl font-bold text-[#2ECC71] number-glow tabular-nums">
            ${animatedApproved.toFixed(2)}
          </p>
          <p className="text-gray-400 text-[10px] sm:text-xs mt-1">تمت الموافقة</p>
        </div>
      </div>

      {/* Deposit Form */}
      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="glass-card p-5 space-y-4 neon-emerald animate-scaleIn"
        >
          <h3 className="text-white font-bold text-lg flex items-center gap-2">
            <ArrowUpCircle size={20} className="text-[#2ECC71]" />
            إيداع جديد
          </h3>

          {/* Payment Methods with Fee Display */}
          <div>
            <label className="text-gray-400 text-xs block mb-2 font-medium">
              اختر طريقة الدفع
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {paymentMethods.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setForm({ ...form, method: m.id })}
                  className={`p-3 rounded-xl border text-right transition-all duration-300 ${
                    form.method === m.id
                      ? 'border-[#2ECC71] bg-[#2ECC71]/10 neon-emerald'
                      : 'border-[#2A3040] bg-[#12161F] hover:border-[#3A4050]'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">{m.icon}</span>
                    <div className="flex-1">
                      <span
                        className={`font-medium text-sm block ${
                          form.method === m.id ? 'text-[#2ECC71]' : 'text-white'
                        }`}
                      >
                        {m.name}
                      </span>
                      <span className="text-gray-500 text-[10px] block">
                        {m.desc}
                      </span>
                    </div>
                    {form.method === m.id && (
                      <Check size={16} className="text-[#2ECC71]" />
                    )}
                  </div>
                  {/* Fee & Details */}
                  <div className="flex items-center justify-between pt-2 border-t border-[#2A3040]/50">
                    <div className="flex items-center gap-1">
                      <Zap size={10} className="text-yellow-400" />
                      <span className="text-yellow-400 text-[10px] font-medium">
                        رسوم: ${m.fee}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={10} className="text-gray-500" />
                      <span className="text-gray-500 text-[10px]">
                        {m.estimatedTime}
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Wallet Address */}
          {selectedMethod?.address ? (
            <div className="bg-[#12161F] rounded-xl p-3 border border-[#2A3040]">
              <label className="text-gray-400 text-xs block mb-1">
                عنوان المحفظة — {selectedMethod.network}
              </label>
              <div className="flex items-center gap-2">
                <code
                  className="flex-1 text-[#FFD700] text-xs break-all"
                  dir="ltr"
                >
                  {selectedMethod.address}
                </code>
                <button
                  type="button"
                  onClick={() => copyAddress(selectedMethod.address)}
                  className="p-2 rounded-lg bg-[#2A3040] hover:bg-[#3A4050] transition-colors shrink-0"
                >
                  {copiedAddr === selectedMethod.address ? (
                    <Check size={14} className="text-[#2ECC71]" />
                  ) : (
                    <Copy size={14} className="text-gray-400" />
                  )}
                </button>
              </div>
            </div>
          ) : form.method !== 'BANK' ? (
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 text-center">
              <p className="text-yellow-400 text-xs">
                عنوان المحفظة غير متوفر حالياً. يرجى{' '}
                <a
                  href="/dashboard/support"
                  className="text-[#FFD700] underline font-medium"
                >
                  تواصل مع الدعم
                </a>
              </p>
            </div>
          ) : null}

          {/* Amount Input */}
          <div>
            <label className="text-gray-400 text-xs block mb-2 font-medium">
              المبلغ ($)
            </label>
            <div className="relative">
              <input
                type="number"
                min="100"
                step="0.01"
                placeholder="أدخل المبلغ"
                value={form.amount}
                onChange={(e) => {
                  setForm({ ...form, amount: e.target.value });
                  setCustomAmount(true);
                }}
                required
                className="input-premium !pl-16"
                dir="ltr"
              />
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-bold">
                USD
              </span>
            </div>
          </div>

          {/* Quick Amount Buttons */}
          <div>
            <label className="text-gray-500 text-[10px] block mb-2">
              مبالغ سريعة
            </label>
            <div className="flex gap-2 flex-wrap">
              {QUICK_AMOUNTS.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => handleQuickAmount(amt)}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all duration-200 ${
                    form.amount === String(amt) && !customAmount
                      ? 'bg-[#FFD700] text-[#0A0F0D] shadow-lg shadow-[#FFD700]/20'
                      : 'bg-[#12161F] border border-[#2A3040] text-gray-300 hover:border-[#FFD700]/50 hover:text-[#FFD700]'
                  }`}
                >
                  ${amt.toLocaleString('en')}
                </button>
              ))}
            </div>
          </div>

          {/* Net Amount Preview */}
          {form.amount && parseFloat(form.amount) > 0 && selectedMethod && (
            <div className="bg-[#12161F] rounded-xl p-3 border border-[#2A3040]/50">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400">المبلغ المطلوب إيداعه</span>
                <span className="text-white font-bold tabular-nums">
                  ${parseFloat(form.amount).toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs mt-1">
                <span className="text-gray-500">الرسوم ({selectedMethod.name})</span>
                <span className="text-yellow-400 tabular-nums">
                  -${selectedMethod.fee.toFixed(2)}
                </span>
              </div>
              <div className="gradient-divider my-2" />
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-300 font-medium">صافي الإيداع</span>
                <span className="text-[#2ECC71] font-bold tabular-nums">
                  ${Math.max(0, parseFloat(form.amount) - selectedMethod.fee).toFixed(2)}
                </span>
              </div>
            </div>
          )}

          {/* TX Hash for crypto */}
          {form.method !== 'BANK' && (
            <div>
              <label className="text-gray-400 text-xs block mb-1">
                رقم العملة (TX Hash)
              </label>
              <input
                placeholder="0x... أو T..."
                value={form.txHash}
                onChange={(e) => setForm({ ...form, txHash: e.target.value })}
                className="input-premium"
                dir="ltr"
              />
            </div>
          )}

          {/* Info */}
          <div className="flex items-center gap-2 text-yellow-400 text-xs bg-yellow-500/5 rounded-lg p-2.5">
            <Clock size={14} className="shrink-0" />
            <span>سيتم مراجعة الإيداع خلال 24 ساعة</span>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="btn-premium-gold disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {submitting ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                جاري التقديم...
              </>
            ) : (
              'تأكيد الإيداع'
            )}
          </button>
        </form>
      )}

      {/* Deposit History */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-white font-bold">سجل الإيداعات</h3>
          {total > 0 && (
            <span className="text-gray-500 text-xs">
              {total} إيداع
            </span>
          )}
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="glass-card p-4">
                <div className="skeleton-premium h-4 w-32 mb-2" />
                <div className="skeleton-premium h-3 w-48 mb-1" />
                <div className="skeleton-premium h-3 w-24" />
              </div>
            ))}
          </div>
        ) : deposits.length === 0 ? (
          <div className="glass-card p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
              <Wallet size={28} className="text-gray-600" />
            </div>
            <p className="text-gray-400 font-medium mb-1">لا توجد إيداعات بعد</p>
            <p className="text-gray-500 text-sm">قم بأول إيداع الآن وابدأ الاستثمار</p>
          </div>
        ) : (
          <div className="space-y-3">
            {deposits.map((d, idx) => {
              const isExpanded = expandedDeposit === d.id;
              const fee = methodFee(d.method);
              return (
                <div
                  key={d.id}
                  className="glass-card overflow-hidden animate-fadeInUp"
                  style={{ animationDelay: `${idx * 0.05}s` }}
                >
                  {/* Desktop Table Row */}
                  <div className="hidden md:block">
                    <div className="flex items-center p-3 hover:bg-[#2A3040]/20 transition-colors">
                      <div className="flex-1 flex items-center gap-3">
                        <span className="text-xl">{methodIcon(d.method)}</span>
                        <div>
                          <p className="text-white font-bold text-sm">
                            ${d.amount.toFixed(2)}
                          </p>
                          <p className="text-gray-500 text-xs">
                            {methodLabel(d.method)}
                          </p>
                        </div>
                      </div>
                      <div className="text-gray-300 text-xs">
                        {new Date(d.createdAt).toLocaleDateString('ar', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </div>
                      <div className="text-gray-400 text-xs">
                        <span className="text-yellow-400">-${fee}$</span> رسوم
                      </div>
                      <div className="w-40">{statusBadge(d.status)}</div>
                    </div>
                    {/* Timeline for pending */}
                    {(d.status === 'pending' || d.status === 'processing') && (
                      <div className="px-3 pb-3 border-t border-[#2A3040]/30">
                        <StatusTimeline status={d.status} />
                      </div>
                    )}
                  </div>

                  {/* Mobile Card */}
                  <div className="md:hidden p-4">
                    <div
                      className="flex items-center justify-between"
                      onClick={() =>
                        setExpandedDeposit(isExpanded ? null : d.id)
                      }
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{methodIcon(d.method)}</span>
                        <div>
                          <p className="text-white font-bold">
                            ${d.amount.toFixed(2)}
                          </p>
                          <p className="text-gray-500 text-xs">
                            {methodLabel(d.method)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {statusBadge(d.status)}
                        <ChevronDown
                          size={16}
                          className={`text-gray-500 transition-transform duration-200 ${
                            isExpanded ? 'rotate-180' : ''
                          }`}
                        />
                      </div>
                    </div>

                    {/* Expanded Details */}
                    <div
                      className={`overflow-hidden transition-all duration-300 ${
                        isExpanded ? 'max-h-60 opacity-100 mt-3' : 'max-h-0 opacity-0'
                      }`}
                    >
                      <div className="pt-3 border-t border-[#2A3040]/50 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500">التاريخ</span>
                          <span className="text-gray-300">
                            {new Date(d.createdAt).toLocaleDateString('ar', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500">الرسوم</span>
                          <span className="text-yellow-400">-${fee}$</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-gray-500">صافي الإيداع</span>
                          <span className="text-[#2ECC71] font-bold">
                            ${(d.amount - fee).toFixed(2)}
                          </span>
                        </div>
                        {d.txHash && (
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-500">TX Hash</span>
                            <span
                              className="text-gray-400 max-w-[120px] truncate"
                              dir="ltr"
                            >
                              {d.txHash}
                            </span>
                          </div>
                        )}
                        {/* Timeline */}
                        {(d.status === 'pending' ||
                          d.status === 'processing') && (
                          <StatusTimeline status={d.status} />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Pagination */}
      {total > 10 && (
        <div className="flex justify-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-50"
          >
            السابق
          </button>
          <span className="px-4 py-2 text-gray-400 text-xs">
            صفحة {page} من {Math.ceil(total / 10)}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={page >= Math.ceil(total / 10)}
            className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-50"
          >
            التالي
          </button>
        </div>
      )}
    </div>
  );
}
