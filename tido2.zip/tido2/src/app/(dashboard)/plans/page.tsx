'use client';
import { useEffect, useState } from 'react';
import { Gem, TrendingUp, Calculator, Plus, X, Check, Users, Clock, Percent, DollarSign, ArrowLeft, Tag, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';

interface Plan {
  id: string;
  name: string;
  nameEn: string;
  minAmount: number;
  maxAmount: number;
  dailyRate: number;
  duration: number;
  icon: string;
  color: string;
  description: string | null;
  _count: { investments: number };
}

interface CouponValidation {
  valid: boolean;
  coupon: {
    id: string;
    code: string;
    type: string;
    discount: number;
    discountAmount: number;
    originalAmount: number;
    finalAmount: number;
    remainingUses: number;
    expiresAt: string | null;
  };
}

export default function PlansPage() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [invForm, setInvForm] = useState({ amount: '', coupon: '' });
  const [calcAmounts, setCalcAmounts] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  // Coupon validation states
  const [couponLoading, setCouponLoading] = useState(false);
  const [couponValidated, setCouponValidated] = useState<CouponValidation | null>(null);
  const [couponError, setCouponError] = useState('');

  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const res = await fetch('/api/plans');
        const data = await res.json();
        setPlans(data.plans || []);
      } catch {}
      setLoading(false);
    };
    fetchPlans();
  }, []);

  const openInvestModal = (plan: Plan) => {
    setSelectedPlan(plan);
    setInvForm({ amount: String(plan.minAmount), coupon: '' });
    setCouponValidated(null);
    setCouponError('');
    setCouponLoading(false);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setCouponValidated(null);
    setCouponError('');
    setCouponLoading(false);
  };

  const applyCoupon = async () => {
    const code = invForm.coupon.trim();
    const amount = parseFloat(invForm.amount);

    if (!code) {
      setCouponError('يرجى إدخال كود الكوبون');
      setCouponValidated(null);
      return;
    }

    if (!amount || amount <= 0) {
      setCouponError('يرجى إدخال مبلغ الاستثمار أولاً');
      setCouponValidated(null);
      return;
    }

    setCouponLoading(true);
    setCouponError('');
    setCouponValidated(null);

    try {
      const res = await fetch('/api/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('tedawilai_token')}` },
        body: JSON.stringify({ code, amount }),
      });
      const data = await res.json();

      if (!res.ok) {
        setCouponError(data.error || 'كوبون غير صالح');
        setCouponValidated(null);
      } else {
        setCouponValidated(data);
        setCouponError('');
      }
    } catch {
      setCouponError('حدث خطأ أثناء التحقق من الكوبون');
      setCouponValidated(null);
    } finally {
      setCouponLoading(false);
    }
  };

  const removeCoupon = () => {
    setInvForm({ ...invForm, coupon: '' });
    setCouponValidated(null);
    setCouponError('');
  };

  const createInvestment = async () => {
    if (submitting) return;
    setSubmitting(true);
    try {
      const res = await fetch('/api/investments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('tedawilai_token')}` },
        body: JSON.stringify({
          amount: parseFloat(invForm.amount),
          planId: selectedPlan?.id,
          couponCode: invForm.coupon || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) { alert(data.error); setSubmitting(false); return; }
      setShowModal(false);
      window.location.href = '/dashboard';
    } catch { alert('حدث خطأ'); setSubmitting(false); }
  };

  // Recalculate coupon when amount changes
  useEffect(() => {
    if (couponValidated && invForm.amount) {
      setCouponValidated(null);
      setCouponError('');
      if (invForm.coupon.trim()) {
        applyCoupon();
      }
    }
  }, [invForm.amount, couponValidated, invForm.coupon]);

  const getExpectedProfit = (plan: Plan) => {
    const amount = parseFloat(calcAmounts[plan.id] || String(plan.minAmount));
    return amount * (plan.dailyRate / 100) * plan.duration;
  };

  const fmt = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const effectiveAmount = couponValidated ? couponValidated.coupon.finalAmount : parseFloat(invForm.amount || '0');

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn pb-20 lg:pb-6">
      {/* Page Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-[#FFD700]/5 via-[#1A1F2E] to-[#2ECC71]/5 border border-[#2A3040] p-5">
        <div className="absolute top-0 left-0 w-32 h-32 bg-[#FFD700]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-40 h-40 bg-[#2ECC71]/5 rounded-full blur-3xl" />
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center">
              <Gem size={20} className="text-[#0A0F0D]" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">خطط الاستثمار</h1>
              <p className="text-xs text-gray-400">اختر الخطة المناسبة لك وابدأ رحلتك الاستثمارية</p>
            </div>
          </div>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 stagger-children">
        {plans.map((plan, index) => {
          const calcAmount = parseFloat(calcAmounts[plan.id] || String(plan.minAmount));
          const expectedProfit = plan.dailyRate / 100 * calcAmount * plan.duration;
          const isGold = plan.nameEn === 'Gold';
          const isDiamond = plan.nameEn === 'Diamond';

          return (
            <div
              key={plan.id}
              className={`glass-card p-5 relative overflow-hidden animate-slide-up transition-all hover:scale-[1.01] group ${
                isDiamond ? 'featured-border' : isGold ? 'featured-border' : ''
              }`}
              style={{ borderTopColor: plan.color, borderTopWidth: '3px', animationDelay: `${index * 100}ms` }}
            >
              {/* Background glow */}
              <div
                className="absolute top-0 left-0 w-40 h-40 rounded-full blur-3xl opacity-10 group-hover:opacity-20 transition-opacity"
                style={{ background: plan.color }}
              />

              <div className="relative z-10">
                {/* Plan Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                      style={{ background: `${plan.color}15`, border: `1px solid ${plan.color}30` }}
                    >
                      {plan.icon}
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-base">{plan.name}</h3>
                      <p className="text-xs text-gray-500">{plan.nameEn}</p>
                    </div>
                  </div>
                  <div
                    className="px-3 py-1 rounded-full text-xs font-bold"
                    style={{ background: `${plan.color}15`, color: plan.color }}
                  >
                    {plan.dailyRate}% يومياً
                  </div>
                </div>

                {/* Description */}
                {plan.description && (
                  <p className="text-xs text-gray-400 mb-4 leading-relaxed">{plan.description}</p>
                )}

                {/* Stats Grid */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="bg-[#12161F] rounded-lg p-2.5 text-center border border-[#2A3040]/50">
                    <DollarSign size={12} className="text-gray-500 mx-auto mb-1" />
                    <p className="text-[10px] text-gray-500 mb-0.5">الحد الأدنى</p>
                    <p className="text-xs font-bold text-white">${plan.minAmount.toLocaleString()}</p>
                  </div>
                  <div className="bg-[#12161F] rounded-lg p-2.5 text-center border border-[#2A3040]/50">
                    <DollarSign size={12} className="text-gray-500 mx-auto mb-1" />
                    <p className="text-[10px] text-gray-500 mb-0.5">الحد الأقصى</p>
                    <p className="text-xs font-bold text-white">{plan.maxAmount > 0 ? `$${plan.maxAmount.toLocaleString()}` : '∞'}</p>
                  </div>
                  <div className="bg-[#12161F] rounded-lg p-2.5 text-center border border-[#2A3040]/50">
                    <Clock size={12} className="text-gray-500 mx-auto mb-1" />
                    <p className="text-[10px] text-gray-500 mb-0.5">المدة</p>
                    <p className="text-xs font-bold text-white">{plan.duration} يوم</p>
                  </div>
                </div>

                {/* Profit Calculator */}
                <div className="bg-[#0D1117] rounded-xl p-3 mb-4 border border-[#2A3040]/50">
                  <div className="flex items-center gap-2 mb-2.5">
                    <Calculator size={13} className="text-[#FFD700]" />
                    <span className="text-xs font-bold text-[#FFD700]">حاسبة الأرباح</span>
                  </div>
                  <div className="flex gap-2 mb-2">
                    <input
                      type="number"
                      value={calcAmounts[plan.id] || plan.minAmount}
                      onChange={e => setCalcAmounts({ ...calcAmounts, [plan.id]: e.target.value })}
                      className="flex-1 bg-[#1A1F2E] border border-[#2A3040] rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#FFD700]/50"
                      dir="ltr"
                      min={plan.minAmount}
                      max={plan.maxAmount > 0 ? plan.maxAmount : undefined}
                    />
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed">
                    إذا استثمرت{' '}
                    <span className="font-bold text-white">{fmt(calcAmount)}</span>
                    {' '}لمدة{' '}
                    <span className="font-bold text-white">{plan.duration} يوم</span>
                    :
                  </p>
                  <div className="mt-2 flex items-center gap-2">
                    <TrendingUp size={14} style={{ color: plan.color }} />
                    <span className="text-lg font-bold number-glow" style={{ color: plan.color }}>
                      {fmt(expectedProfit)}
                    </span>
                    <span className="text-[10px] text-gray-500">ربح متوقع</span>
                  </div>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-gray-500">
                    <Users size={12} />
                    <span className="text-[10px]">{plan._count.investments} مستثمر</span>
                  </div>
                  <button
                    onClick={() => openInvestModal(plan)}
                    className="btn-ripple px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all hover:scale-105"
                    style={{ background: `linear-gradient(135deg, ${plan.color}20, ${plan.color}10)`, color: plan.color, border: `1px solid ${plan.color}40` }}
                  >
                    <Plus size={14} />
                    استثمر الآن
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Investment Modal */}
      {showModal && selectedPlan && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={closeModal}>
          <div className="glass-card p-6 w-full max-w-md relative z-10 animate-fadeIn" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
                  style={{ background: `${selectedPlan.color}15` }}
                >
                  {selectedPlan.icon}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">استثمر في {selectedPlan.name}</h3>
                  <p className="text-xs text-gray-400">{selectedPlan.dailyRate}% يومياً • {selectedPlan.duration} يوم</p>
                </div>
              </div>
              <button onClick={closeModal} className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-[#1A1F2E] transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Plan Details */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              <div className="bg-[#12161F] rounded-lg p-3 text-center border border-[#2A3040]/50">
                <p className="text-[10px] text-gray-500">الحد الأدنى</p>
                <p className="text-sm font-bold text-white">${selectedPlan.minAmount.toLocaleString()}</p>
              </div>
              <div className="bg-[#12161F] rounded-lg p-3 text-center border border-[#2A3040]/50">
                <p className="text-[10px] text-gray-500">الحد الأقصى</p>
                <p className="text-sm font-bold text-white">{selectedPlan.maxAmount > 0 ? `$${selectedPlan.maxAmount.toLocaleString()}` : '∞'}</p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Amount Input */}
              <div>
                <label className="text-gray-400 text-sm mb-2 block font-medium">مبلغ الاستثمار ($)</label>
                <input
                  type="number"
                  min={selectedPlan.minAmount}
                  max={selectedPlan.maxAmount > 0 ? selectedPlan.maxAmount : undefined}
                  value={invForm.amount}
                  onChange={e => setInvForm({ ...invForm, amount: e.target.value })}
                  className="input-premium"
                  dir="ltr"
                />
                <div className="flex justify-between mt-1.5">
                  <span className="text-[10px] text-gray-500">الحد الأدنى: ${selectedPlan.minAmount.toLocaleString()}</span>
                  {selectedPlan.maxAmount > 0 && <span className="text-[10px] text-gray-500">الحد الأقصى: ${selectedPlan.maxAmount.toLocaleString()}</span>}
                </div>
              </div>

              {/* Expected Profit */}
              {parseFloat(invForm.amount) > 0 && (
                <div className="p-3 rounded-xl bg-gradient-to-l from-[#FFD700]/5 to-[#2ECC71]/5 border border-[#2A3040] animate-fadeIn">
                  <div className="flex items-center gap-2 mb-1">
                    <Calculator size={14} className="text-[#FFD700]" />
                    <span className="text-xs font-bold text-[#FFD700]">حاسبة الأرباح</span>
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed">
                    إذا استثمرت{' '}
                    <span className="font-bold text-white">${parseFloat(invForm.amount || '0').toLocaleString()}</span>
                    {' '}لمدة{' '}
                    <span className="font-bold text-white">{selectedPlan.duration} يوم</span>
                    {' ،ربحك المتوقع: '}
                    <span className="font-bold number-glow" style={{ color: selectedPlan.color }}>
                      ${((effectiveAmount * (selectedPlan.dailyRate / 100)) * selectedPlan.duration).toFixed(2)}
                    </span>
                  </p>
                </div>
              )}

              {/* Coupon Section */}
              <div>
                <label className="text-gray-400 text-sm mb-2 block font-medium flex items-center gap-2">
                  <Tag size={14} />
                  كوبون الخصم (اختياري)
                </label>

                {/* Coupon applied successfully */}
                {couponValidated && couponValidated.valid ? (
                  <div className="bg-[#2ECC71]/5 border border-[#2ECC71]/30 rounded-xl p-3 animate-fadeIn">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <CheckCircle size={16} className="text-[#2ECC71]" />
                        <span className="text-sm font-bold text-[#2ECC71]">تم تطبيق الكوبون!</span>
                      </div>
                      <button onClick={removeCoupon} className="text-gray-400 hover:text-red-400 p-1 rounded-lg hover:bg-red-500/10 transition-all">
                        <X size={14} />
                      </button>
                    </div>
                    <div className="bg-[#0D1117] rounded-lg p-2.5 space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">الكود</span>
                        <span className="text-[#FFD700] font-bold" dir="ltr">{couponValidated.coupon.code}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">نوع الخصم</span>
                        <span className="text-white">
                          {couponValidated.coupon.type === 'fixed' ? (
                            <span className="flex items-center gap-1"><DollarSign size={10} className="text-blue-400" /> مبلغ ثابت</span>
                          ) : (
                            <span className="flex items-center gap-1"><Percent size={10} className="text-purple-400" /> نسبة مئوية</span>
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">قيمة الخصم</span>
                        <span className="text-red-400 font-bold">-${couponValidated.coupon.discountAmount.toFixed(2)} {couponValidated.coupon.type === 'percentage' ? `(${couponValidated.coupon.discount}%)` : ''}</span>
                      </div>
                      <div className="border-t border-[#2A3040] pt-1.5 flex justify-between text-xs">
                        <span className="text-gray-400">المبلغ بعد الخصم</span>
                        <span className="text-[#2ECC71] font-bold">${couponValidated.coupon.finalAmount.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-400">الاستخدامات المتبقية</span>
                        <span className="text-gray-300">{couponValidated.coupon.remainingUses}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Coupon input */
                  <div className="flex gap-2">
                    <input
                      placeholder="أدخل كود الخصم"
                      value={invForm.coupon}
                      onChange={e => {
                        setInvForm({ ...invForm, coupon: e.target.value.toUpperCase() });
                        setCouponValidated(null);
                        setCouponError('');
                      }}
                      onKeyDown={e => { if (e.key === 'Enter') applyCoupon(); }}
                      className="input-premium flex-1"
                      dir="ltr"
                      disabled={couponLoading}
                    />
                    <button
                      onClick={applyCoupon}
                      disabled={couponLoading || !invForm.coupon.trim()}
                      className="btn-ripple px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-[#FFD700]/10 text-[#FFD700] border border-[#FFD700]/30 hover:bg-[#FFD700]/20 transition-all disabled:opacity-40 disabled:cursor-not-allowed whitespace-nowrap"
                    >
                      {couponLoading ? (
                        <Loader2 size={14} className="animate-spin" />
                      ) : (
                        <Check size={14} />
                      )}
                      تطبيق
                    </button>
                  </div>
                )}

                {/* Coupon Error */}
                {couponError && !couponValidated && (
                  <div className="flex items-center gap-2 mt-2 p-2 rounded-lg bg-red-500/5 border border-red-500/20 animate-fadeIn">
                    <AlertCircle size={13} className="text-red-400 flex-shrink-0" />
                    <span className="text-xs text-red-400">{couponError}</span>
                  </div>
                )}
              </div>

              {/* Summary */}
              {couponValidated && couponValidated.valid && parseFloat(invForm.amount) > 0 && (
                <div className="bg-[#0D1117] rounded-xl p-4 border border-[#2A3040] animate-fadeIn">
                  <h4 className="text-xs font-bold text-gray-400 mb-3 flex items-center gap-2">
                    <Calculator size={13} />
                    ملخص الاستثمار
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">مبلغ الاستثمار الأصلي</span>
                      <span className="text-white font-medium">${parseFloat(invForm.amount).toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-400">الخصم</span>
                      <span className="text-red-400 font-medium">
                        -${couponValidated.coupon.discountAmount.toFixed(2)}
                        {couponValidated.coupon.type === 'percentage' && (
                          <span className="text-[10px] text-gray-500 mr-1">({couponValidated.coupon.discount}%)</span>
                        )}
                      </span>
                    </div>
                    <div className="border-t border-[#2A3040] pt-2 flex justify-between items-center">
                      <span className="text-gray-300 font-bold text-sm">المبلغ النهائي</span>
                      <span className="text-[#2ECC71] font-bold text-lg">${couponValidated.coupon.finalAmount.toFixed(2)}</span>
                    </div>
                    <div className="border-t border-[#2A3040] pt-2 flex justify-between items-center">
                      <span className="text-gray-300 font-bold text-sm">الربح المتوقع ({selectedPlan.duration} يوم)</span>
                      <span className="font-bold text-lg number-glow" style={{ color: selectedPlan.color }}>
                        ${((couponValidated.coupon.finalAmount * (selectedPlan.dailyRate / 100)) * selectedPlan.duration).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <button onClick={createInvestment} disabled={submitting} className="btn-premium-emerald btn-ripple w-full flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
                {submitting ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Check size={18} /> تأكيد الاستثمار
                  </>
                )}
              </button>
              <button onClick={closeModal} className="w-full text-gray-400 hover:text-white text-sm py-2 transition-colors">إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
