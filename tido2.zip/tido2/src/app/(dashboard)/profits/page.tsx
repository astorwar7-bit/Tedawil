'use client';
import { useEffect, useState, useRef } from 'react';
import {
  TrendingUp, Users, Download, DollarSign, Gift,
  ChevronLeft, ChevronRight, Filter, Sparkles
} from 'lucide-react';

interface Profit {
  id: string;
  amount: number;
  type: string;
  date: string;
  rate: number | null;
  investmentId?: string | null;
  investment?: {
    plan?: {
      name: string;
      nameEn: string;
      icon: string;
      color: string;
    } | null;
  } | null;
}

interface ProfitTypeInfo {
  key: string;
  label: string;
  icon: typeof TrendingUp;
  color: string;
  bgColor: string;
  borderColor: string;
}

const PROFIT_TYPES: ProfitTypeInfo[] = [
  { key: '', label: 'الكل', icon: Filter, color: 'text-gray-400', bgColor: 'bg-gray-500/10', borderColor: 'border-gray-500/20' },
  { key: 'investment', label: 'استثماري', icon: TrendingUp, color: 'text-[#2ECC71]', bgColor: 'bg-[#2ECC71]/10', borderColor: 'border-[#2ECC71]/20' },
  { key: 'referral', label: 'إحالة', icon: Users, color: 'text-[#FFD700]', bgColor: 'bg-[#FFD700]/10', borderColor: 'border-[#FFD700]/20' },
  { key: 'welcome_bonus', label: 'مكافأة ترحيب', icon: Gift, color: 'text-blue-400', bgColor: 'bg-blue-500/10', borderColor: 'border-blue-500/20' },
];

const TYPE_CONFIG: Record<string, { label: string; icon: typeof TrendingUp; color: string; bgColor: string; borderColor: string }> = {
  investment: { label: 'ربح استثماري', icon: TrendingUp, color: 'text-[#2ECC71]', bgColor: 'bg-[#2ECC71]/10', borderColor: 'border-[#2ECC71]/20' },
  referral: { label: 'عمولة إحالة', icon: Users, color: 'text-[#FFD700]', bgColor: 'bg-[#FFD700]/10', borderColor: 'border-[#FFD700]/20' },
  welcome_bonus: { label: 'مكافأة ترحيب', icon: Gift, color: 'text-blue-400', bgColor: 'bg-blue-500/10', borderColor: 'border-blue-500/20' },
};

// Animated count-up hook
function useCountUp(target: number, duration: number = 1400, enabled: boolean = true) {
  const [value, setValue] = useState(0);
  const startRef = useRef<number | null>(null);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    if (!enabled) { setValue(0); return; }
    startRef.current = null;

    let active = true;

    const step = (timestamp: number) => {
      if (!active) return;
      if (!startRef.current) startRef.current = timestamp;
      const elapsed = timestamp - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(eased * target);
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(step);
      }
    };

    frameRef.current = requestAnimationFrame(step);
    return () => {
      active = false;
      cancelAnimationFrame(frameRef.current);
    };
  }, [target, duration, enabled]);

  return value;
}

function ProfitCardSkeleton() {
  return (
    <div className="glass-card p-4">
      <div className="flex items-center gap-3">
        <div className="skeleton-premium w-11 h-11 rounded-xl shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="skeleton-premium h-4 w-28 mb-2" />
          <div className="skeleton-premium h-3 w-40" />
        </div>
        <div className="text-left shrink-0">
          <div className="skeleton-premium h-5 w-20 mb-1" />
          <div className="skeleton-premium h-3 w-16" />
        </div>
      </div>
    </div>
  );
}

export default function ProfitsPage() {
  const [profits, setProfits] = useState<Profit[]>([]);
  const [allProfits, setAllProfits] = useState<Profit[]>([]);
  const [total, setTotal] = useState(0);
  const [totalProfits, setTotalProfits] = useState(0);
  const [page, setPage] = useState(1);
  const [type, setType] = useState('');
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const limit = 15;

  const animatedTotal = useCountUp(totalProfits, 1600, !loading);

  useEffect(() => {
    const fetchProfits = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/profits?page=${page}&limit=${limit}&type=${type}`);
        const data = await res.json();
        setProfits(data.profits || []);
        setTotal(data.total || 0);
        setTotalProfits(data.totalProfits || 0);

        // Fetch all profits for CSV export (type-filtered total)
        if (type) {
          const allRes = await fetch(`/api/profits?page=1&limit=9999&type=${type}`);
          const allData = await allRes.json();
          setAllProfits(allData.profits || []);
        } else {
          const allRes = await fetch(`/api/profits?page=1&limit=9999`);
          const allData = await allRes.json();
          setAllProfits(allData.profits || []);
        }
      } catch (err) {
        console.error('Profits fetch error:', err);
      }
      setLoading(false);
    };
    fetchProfits();
  }, [page, type]);

  const exportCSV = async () => {
    setExporting(true);
    try {
      const dataToExport = allProfits.length > 0 ? allProfits : profits;
      if (dataToExport.length === 0) return;

      const headers = ['التاريخ', 'المبلغ', 'النوع', 'النسبة', 'خطة الاستثمار'];
      const typeLabels: Record<string, string> = {
        investment: 'استثماري',
        referral: 'إحالة',
        welcome_bonus: 'مكافأة ترحيب',
      };
      const rows = dataToExport.map((row) => {
        const date = new Date(row.date).toLocaleDateString('ar');
        const amount = row.amount.toFixed(2);
        const typeLabel = typeLabels[row.type] || row.type;
        const rate = row.rate ? `${row.rate}%` : '-';
        const planName = row.investment?.plan?.name || '-';
        return [date, amount, typeLabel, rate, planName].map((v) => `"${v}"`).join(',');
      });
      const csv = [headers.join(','), ...rows].join('\n');
      const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `profits-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export error:', err);
    }
    setExporting(false);
  };

  const getTypeConfig = (t: string) => {
    return TYPE_CONFIG[t] || { label: t, icon: DollarSign, color: 'text-gray-400', bgColor: 'bg-gray-500/10', borderColor: 'border-gray-500/20' };
  };

  const totalPages = Math.ceil(total / limit);

  // Calculate totals by type for summary
  const investmentTotal = profits.filter((p) => p.type === 'investment').reduce((s, p) => s + p.amount, 0);
  const referralTotal = profits.filter((p) => p.type === 'referral').reduce((s, p) => s + p.amount, 0);
  const welcomeTotal = profits.filter((p) => p.type === 'welcome_bonus').reduce((s, p) => s + p.amount, 0);

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6">
      {/* Page Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-[#FFD700]/10 via-[#1A1F2E] to-[#2ECC71]/10 border border-[#2A3040] p-5">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#FFD700]/5 rounded-full translate-x-1/2 -translate-y-1/2 animate-glow-pulse" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-[#2ECC71]/5 rounded-full -translate-x-1/2 translate-y-1/2 animate-glow-pulse" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center icon-pulse-gold">
              <Sparkles size={24} className="text-[#FFD700]" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white">أرباحي</h1>
              <p className="text-gray-400 text-xs mt-0.5">جميع أرباحك في مكان واحد</p>
            </div>
          </div>
          {!loading && profits.length > 0 && (
            <button
              onClick={exportCSV}
              disabled={exporting}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium bg-[#1A1F2E] text-gray-300 border border-[#2A3040] hover:border-[#2ECC71]/50 transition-all duration-300 disabled:opacity-50 shrink-0"
            >
              <Download size={14} className={exporting ? 'animate-bounce' : ''} />
              <span className="hidden sm:inline">تصدير CSV</span>
            </button>
          )}
        </div>
      </div>

      {/* Total Profits Card - Prominent */}
      <div className="glass-card-premium p-5 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-40 h-40 bg-[#FFD700]/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-28 h-28 bg-[#2ECC71]/5 rounded-full translate-x-1/2 translate-y-1/2" />
        <div className="relative">
          <p className="text-gray-400 text-sm mb-1">إجمالي الأرباح</p>
          <p className="text-3xl sm:text-4xl font-bold text-[#FFD700] number-glow tabular-nums">
            ${loading ? '0.00' : animatedTotal.toFixed(2)}
          </p>
          {!loading && (
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-[#2ECC71]" />
                <span className="text-gray-400 text-[10px]">استثماري: <span className="text-[#2ECC71] font-medium tabular-nums">${investmentTotal.toFixed(2)}</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-[#FFD700]" />
                <span className="text-gray-400 text-[10px]">إحالة: <span className="text-[#FFD700] font-medium tabular-nums">${referralTotal.toFixed(2)}</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-blue-400" />
                <span className="text-gray-400 text-[10px]">ترحيب: <span className="text-blue-400 font-medium tabular-nums">${welcomeTotal.toFixed(2)}</span></span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        {PROFIT_TYPES.map((t) => {
          const Icon = t.icon;
          const isActive = type === t.key;
          return (
            <button
              key={t.key}
              onClick={() => { setType(t.key); setPage(1); }}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all duration-300 ${
                isActive
                  ? `${t.bgColor} ${t.color} border ${t.borderColor} shadow-lg`
                  : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-gray-500/50 hover:text-gray-300'
              }`}
            >
              <Icon size={12} />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Profit Items */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <ProfitCardSkeleton key={i} />
          ))}
        </div>
      ) : profits.length === 0 ? (
        <div className="glass-card p-8 sm:p-12 text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
            <DollarSign size={36} className="text-gray-600" />
          </div>
          <p className="text-gray-300 font-bold text-lg mb-2">لا توجد أرباح بعد</p>
          <p className="text-gray-500 text-sm max-w-xs mx-auto">
            {type
              ? `لا توجد أرباح من النوع "${PROFIT_TYPES.find(t => t.key === type)?.label || type}". جرب تغيير الفلتر.`
              : 'ابدأ الاستثمار واحصل على أرباح يومية مستدامة من خططنا المتنوعة.'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {profits.map((p, idx) => {
            const config = getTypeConfig(p.type);
            const Icon = config.icon;
            const planName = p.investment?.plan?.name;
            const planIcon = p.investment?.plan?.icon;
            const planColor = p.investment?.plan?.color;

            return (
              <div
                key={p.id}
                className="glass-card p-4 animate-fadeInUp card-lift"
                style={{ animationDelay: `${idx * 0.04}s` }}
              >
                <div className="flex items-center gap-3">
                  {/* Type Icon */}
                  <div className={`w-11 h-11 rounded-xl ${config.bgColor} border ${config.borderColor} flex items-center justify-center shrink-0`}>
                    <Icon size={18} className={config.color} />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className={`font-bold text-sm ${config.color}`}>
                        ${p.amount.toFixed(2)}
                      </p>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${config.bgColor} ${config.color} border ${config.borderColor}`}>
                        {config.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-gray-500 text-[10px]">
                        {new Date(p.date).toLocaleDateString('ar', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </span>
                      {p.rate && p.rate > 0 && (
                        <>
                          <span className="text-gray-600 text-[10px]">•</span>
                          <span className="text-gray-400 text-[10px] tabular-nums">{p.rate}%</span>
                        </>
                      )}
                      {planName && (
                        <>
                          <span className="text-gray-600 text-[10px]">•</span>
                          <span className="text-gray-400 text-[10px]">{planIcon} {planName}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Amount on the left */}
                  <div className="text-left shrink-0 hidden sm:block">
                    <p className={`font-bold text-lg tabular-nums ${config.color}`}>
                      +${p.amount.toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {!loading && total > limit && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="flex items-center gap-1 px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-40 transition-colors hover:border-[#2ECC71]/50"
          >
            <ChevronRight size={14} />
            السابق
          </button>
          <span className="px-4 py-2 text-gray-400 text-xs tabular-nums">
            صفحة {page} من {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={page >= totalPages}
            className="flex items-center gap-1 px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-40 transition-colors hover:border-[#2ECC71]/50"
          >
            التالي
            <ChevronLeft size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
