'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Lock, CheckCircle, Eye, EyeOff, RefreshCw, Shield } from 'lucide-react';

export default function PinPage() {
  const { showToast } = useToast();
  const [hasPin, setHasPin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const fetchPin = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/pin');
      const data = await res.json();
      setHasPin(data.hasPin);
    } catch { showToast('حدث خطأ', 'error'); }
    setLoading(false);
  };

  useEffect(() => { fetchPin(); }, []);

  const handleSubmit = async () => {
    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      showToast('رمز PIN يجب أن يكون 4 أرقام', 'error');
      return;
    }

    if (hasPin && currentPin.length !== 4) {
      showToast('يرجى إدخال الرمز الحالي', 'error');
      return;
    }

    if (newPin !== confirmPin) {
      showToast('الرمز غير متطابق', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: hasPin ? 'change' : 'set',
          pin: newPin,
          currentPin: hasPin ? currentPin : undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      setCurrentPin('');
      setNewPin('');
      setConfirmPin('');
      fetchPin();
    } catch { showToast('حدث خطأ', 'error'); }
    setSubmitting(false);
  };

  const PinInput = ({ label, value, onChange, show, setShow, placeholder }: {
    label: string; value: string; onChange: (v: string) => void; show: boolean; setShow: (v: boolean) => void; placeholder: string;
  }) => (
    <div>
      <label className="text-gray-400 text-xs block mb-1.5">{label}</label>
      <div className="relative">
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={e => {
            const v = e.target.value.replace(/\D/g, '').slice(0, 4);
            onChange(v);
          }}
          placeholder={placeholder}
          className="input-premium text-center text-2xl tracking-[0.5em] !py-4 font-mono"
          dir="ltr"
          maxLength={4}
        />
        <button type="button" onClick={() => setShow(!show)} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
          {show ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>
      {/* PIN Dots */}
      <div className="flex justify-center gap-3 mt-2">
        {[0, 1, 2, 3].map(i => (
          <div key={i} className={`w-3 h-3 rounded-full transition-all ${
            value.length > i ? 'bg-[#FFD700] scale-110' : 'bg-[#2A3040]'
          }`} />
        ))}
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="space-y-4 animate-fadeIn">
        <h1 className="text-2xl font-bold text-white">رمز PIN</h1>
        <div className="glass-card p-6"><div className="skeleton-premium h-40"></div></div>
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-fadeIn">
      <h1 className="text-2xl font-bold text-white flex items-center gap-2">
        <Shield size={24} className="text-[#FFD700]" />
        رمز PIN
      </h1>

      {/* Status */}
      <div className={`glass-card p-5 ${hasPin ? 'neon-gold' : 'neon-emerald'}`}>
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${hasPin ? 'bg-[#FFD700]/10' : 'bg-[#2ECC71]/10'}`}>
            {hasPin ? <Lock size={28} className="text-[#FFD700]" /> : <Lock size={28} className="text-[#2ECC71]" />}
          </div>
          <div>
            <p className={`font-bold text-lg ${hasPin ? 'text-[#FFD700]' : 'text-[#2ECC71]'}`}>
              {hasPin ? 'رمز PIN مفعل' : 'لم يتم إنشاء رمز PIN'}
            </p>
            <p className="text-gray-400 text-xs mt-0.5">
              {hasPin ? 'يمكنك تغيير رمز PIN الحالي' : 'أنشئ رمز PIN لإضافته طبقة أمان إضافية'}
            </p>
          </div>
        </div>
      </div>

      {/* PIN Form */}
      <div className="glass-card p-5 space-y-4">
        <h3 className="text-white font-bold flex items-center gap-2">
          {hasPin ? <RefreshCw size={16} className="text-[#FFD700]" /> : <Lock size={16} className="text-[#2ECC71]" />}
          {hasPin ? 'تغيير رمز PIN' : 'إنشاء رمز PIN'}
        </h3>

        {hasPin && (
          <PinInput label="الرمز الحالي" value={currentPin} onChange={setCurrentPin} show={showCurrent} setShow={setShowCurrent} placeholder="****" />
        )}

        <PinInput label="الرمز الجديد" value={newPin} onChange={setNewPin} show={showNew} setShow={setShowNew} placeholder="****" />

        <PinInput label="تأكيد الرمز" value={confirmPin} onChange={setConfirmPin} show={showConfirm} setShow={setShowConfirm} placeholder="****" />

        {confirmPin && newPin && confirmPin !== newPin && (
          <p className="text-red-400 text-xs text-center flex items-center justify-center gap-1">
            <EyeOff size={12} /> الرمز غير متطابق
          </p>
        )}

        {newPin.length === 4 && confirmPin.length === 4 && newPin === confirmPin && (
          <p className="text-[#2ECC71] text-xs text-center flex items-center justify-center gap-1">
            <CheckCircle size={12} /> الرمز متطابق ✓
          </p>
        )}

        <button
          onClick={handleSubmit}
          disabled={submitting || newPin.length !== 4 || confirmPin.length !== 4 || (hasPin && currentPin.length !== 4)}
          className="btn-premium-gold disabled:opacity-50">
          {submitting ? 'جاري الحفظ...' : hasPin ? 'تغيير الرمز' : 'إنشاء الرمز'}
        </button>
      </div>

      {/* Security Tips */}
      <div className="glass-card p-4">
        <h3 className="text-gray-400 text-xs font-medium mb-2">نصائح أمنية</h3>
        <ul className="space-y-1.5 text-gray-500 text-[11px]">
          <li className="flex items-center gap-1.5"><Shield size={10} className="text-[#FFD700]" /> لا تستخدم تاريخ ميلادك أو أرقام متسلسلة</li>
          <li className="flex items-center gap-1.5"><Shield size={10} className="text-[#FFD700]" /> لا تشارك رمز PIN مع أي شخص</li>
          <li className="flex items-center gap-1.5"><Shield size={10} className="text-[#FFD700]" /> غيّر الرمز بشكل دوري</li>
        </ul>
      </div>
    </div>
  );
}
