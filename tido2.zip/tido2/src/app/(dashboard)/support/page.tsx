'use client';
import { useEffect, useState, useCallback } from 'react';
import { useToast } from '@/contexts/ToastContext';
import {
  Plus, Send, ChevronLeft, X, Clock, AlertCircle, CheckCircle2,
  MessageSquare, Filter, Loader2, Headphones,
} from 'lucide-react';

/* ─── types ─── */
interface TicketReply {
  id: string;
  message: string;
  isAdmin: boolean;
  createdAt: string;
  user: { username: string; fullName: string };
}

interface Ticket {
  id: string;
  subject: string;
  message: string;
  status: string;
  priority: string;
  category: string;
  createdAt: string;
  updatedAt: string;
  replies: { message: string; createdAt: string; isAdmin: boolean }[];
}

/* ─── labels & colors ─── */
const statusLabels: Record<string, string> = {
  open: 'مفتوحة', in_progress: 'قيد المراجعة', resolved: 'تم الحل', closed: 'مغلقة',
};
const statusColors: Record<string, string> = {
  open: 'bg-[#2ECC71]/15 text-[#2ECC71] border-[#2ECC71]/30',
  in_progress: 'bg-[#3498DB]/15 text-[#3498DB] border-[#3498DB]/30',
  resolved: 'bg-[#FFD700]/15 text-[#FFD700] border-[#FFD700]/30',
  closed: 'bg-[#8899AA]/15 text-[#8899AA] border-[#8899AA]/30',
};
const priorityLabels: Record<string, string> = {
  low: 'منخفضة', medium: 'متوسطة', high: 'عالية', urgent: 'عاجلة',
};
const priorityColors: Record<string, string> = {
  urgent: 'bg-[#EF4444]/15 text-[#EF4444] border-[#EF4444]/30',
  high: 'bg-[#FF8C00]/15 text-[#FF8C00] border-[#FF8C00]/30',
  medium: 'bg-[#3498DB]/15 text-[#3498DB] border-[#3498DB]/30',
  low: 'bg-[#8899AA]/15 text-[#8899AA] border-[#8899AA]/30',
};
const categoryLabels: Record<string, string> = {
  general: 'عام', deposit: 'الإيداع', withdrawal: 'السحب',
  investment: 'الاستثمار', technical: 'تقني', other: 'أخرى',
};

/* ─── component ─── */
export default function SupportPage() {
  const { showToast } = useToast();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [replies, setReplies] = useState<TicketReply[]>([]);
  const [replyText, setReplyText] = useState('');
  const [submitting, setSubmitting] = useState(false);

  /* form state */
  const [form, setForm] = useState({
    subject: '', message: '', category: 'general', priority: 'medium',
  });

  const fetchTickets = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/tickets?status=${filter}&limit=20`);
      const data = await res.json();
      if (data.success) {
        setTickets(data.data.tickets);
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ في الاتصال', 'error');
    }
    setLoading(false);
  }, [filter, showToast]);

  useEffect(() => { fetchTickets(); }, [fetchTickets]);

  const openTicket = async (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setReplies([]);
    setReplyText('');
    try {
      const res = await fetch(`/api/tickets/${ticket.id}`);
      const data = await res.json();
      if (data.success) {
        setReplies(data.data.ticket.replies || []);
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
  };

  const closeTicket = async () => {
    if (!selectedTicket) return;
    try {
      const res = await fetch(`/api/tickets/${selectedTicket.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'closed' }),
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم إغلاق التذكرة', 'success');
        setSelectedTicket({ ...selectedTicket, status: 'closed' });
        fetchTickets();
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
  };

  const submitReply = async () => {
    if (!replyText.trim() || !selectedTicket) return;
    setSubmitting(true);
    try {
      const res = await fetch(`/api/tickets/${selectedTicket.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: replyText }),
      });
      const data = await res.json();
      if (data.success) {
        setReplyText('');
        // re-fetch ticket
        const tRes = await fetch(`/api/tickets/${selectedTicket.id}`);
        const tData = await tRes.json();
        if (tData.success) {
          setReplies(tData.data.ticket.replies || []);
          if (tData.data.ticket.status !== selectedTicket.status) {
            setSelectedTicket(tData.data.ticket);
          }
        }
        fetchTickets();
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
    setSubmitting(false);
  };

  const submitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.subject.trim() || !form.message.trim()) {
      showToast('يرجى إدخال الموضوع والرسالة', 'error');
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.success) {
        showToast('تم إنشاء التذكرة بنجاح', 'success');
        setForm({ subject: '', message: '', category: 'general', priority: 'medium' });
        setShowForm(false);
        fetchTickets();
      } else {
        showToast(data.error || 'حدث خطأ', 'error');
      }
    } catch {
      showToast('حدث خطأ', 'error');
    }
    setSubmitting(false);
  };

  /* ─── detail view ─── */
  if (selectedTicket) {
    return (
      <div className="animate-fadeIn pb-20 lg:pb-6 space-y-4">
        {/* header */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSelectedTicket(null)}
            className="p-2 rounded-xl bg-[#1A1F2E] border border-[#2A3040] text-gray-400 hover:text-white transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-lg font-bold text-white truncate">{selectedTicket.subject}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-1">
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColors[selectedTicket.status]}`}>
                {statusLabels[selectedTicket.status]}
              </span>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${priorityColors[selectedTicket.priority]}`}>
                {priorityLabels[selectedTicket.priority]}
              </span>
              <span className="text-xs text-gray-500">
                {categoryLabels[selectedTicket.category] || selectedTicket.category}
              </span>
              <span className="text-xs text-gray-500">
                <Clock size={12} className="inline ml-1" />
                {new Date(selectedTicket.createdAt).toLocaleDateString('ar')}
              </span>
            </div>
          </div>
          {selectedTicket.status !== 'closed' && (
            <button
              onClick={closeTicket}
              className="px-4 py-2 rounded-xl text-xs font-medium bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20 transition-colors"
            >
              إغلاق التذكرة
            </button>
          )}
        </div>

        {/* original message */}
        <div className="glass-card p-4 rounded-xl">
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare size={16} className="text-[#2ECC71]" />
            <span className="text-sm font-medium text-[#2ECC71]">رسالتك الأصلية</span>
            <span className="text-xs text-gray-500 mr-auto">
              {new Date(selectedTicket.createdAt).toLocaleString('ar')}
            </span>
          </div>
          <p className="text-gray-300 text-sm whitespace-pre-wrap leading-relaxed">{selectedTicket.message}</p>
        </div>

        {/* replies */}
        <div className="space-y-3 max-h-[50vh] overflow-y-auto scrollbar-thin">
          {replies.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Headphones size={40} className="mx-auto mb-2 opacity-30" />
              <p className="text-sm">لا توجد ردود بعد. سيتم الرد قريباً.</p>
            </div>
          )}
          {replies.map((reply) => (
            <div
              key={reply.id}
              className={`p-4 rounded-xl ${
                reply.isAdmin
                  ? 'bg-[#12161F] border border-[#FFD700]/20 mr-4'
                  : 'bg-[#1A1F2E] border border-[#2A3040] ml-4'
              }`}
            >
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                  reply.isAdmin
                    ? 'bg-[#FFD700]/20 text-[#FFD700]'
                    : 'bg-[#2ECC71]/20 text-[#2ECC71]'
                }`}>
                  {reply.isAdmin ? 'م' : 'أ'}
                </div>
                <span className={`text-sm font-medium ${reply.isAdmin ? 'text-[#FFD700]' : 'text-[#2ECC71]'}`}>
                  {reply.isAdmin ? 'فريق الدعم' : (reply.user?.fullName || reply.user?.username || 'أنت')}
                </span>
                {reply.isAdmin && (
                  <CheckCircle2 size={14} className="text-[#FFD700]" />
                )}
                <span className="text-xs text-gray-500 mr-auto">
                  {new Date(reply.createdAt).toLocaleString('ar')}
                </span>
              </div>
              <p className="text-gray-300 text-sm whitespace-pre-wrap leading-relaxed">{reply.message}</p>
            </div>
          ))}
        </div>

        {/* reply form */}
        {selectedTicket.status !== 'closed' && (
          <div className="glass-card p-4 rounded-xl sticky bottom-4">
            <div className="flex gap-2">
              <textarea
                placeholder="اكتب ردك هنا..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                className="flex-1 bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-3 text-white text-sm focus:border-[#2ECC71] focus:outline-none resize-none h-16"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    submitReply();
                  }
                }}
              />
              <button
                onClick={submitReply}
                disabled={submitting || !replyText.trim()}
                className="px-4 bg-[#2ECC71] hover:bg-[#25A25A] text-white rounded-xl transition-colors disabled:opacity-50 self-end h-16"
              >
                {submitting ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  /* ─── list view ─── */
  return (
    <div className="animate-fadeIn pb-20 lg:pb-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">الدعم الفني</h1>
        <button
          onClick={() => setShowForm(true)}
          className="btn-premium-emerald px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2"
        >
          <Plus size={18} />
          تذكرة جديدة
        </button>
      </div>

      {/* filters */}
      <div className="flex gap-2 flex-wrap">
        {[
          { key: 'all', label: 'الكل' },
          { key: 'open', label: 'مفتوحة' },
          { key: 'in_progress', label: 'قيد المراجعة' },
          { key: 'resolved', label: 'تم الحل' },
          { key: 'closed', label: 'مغلقة' },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
              filter === f.key
                ? 'bg-[#2ECC71] text-[#0A0F0D]'
                : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-[#2ECC71]/40'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* ticket list */}
      {loading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 size={32} className="animate-spin text-[#2ECC71]" />
        </div>
      ) : tickets.length === 0 ? (
        <div className="glass-card rounded-xl p-8 text-center">
          <Headphones size={48} className="mx-auto mb-3 text-gray-600" />
          <p className="text-gray-400 text-sm mb-1">لا توجد تذاكر دعم</p>
          <p className="text-gray-500 text-xs">يمكنك إنشاء تذكرة جديدة للحصول على المساعدة</p>
        </div>
      ) : (
        <div className="space-y-2">
          {tickets.map((ticket) => (
            <button
              key={ticket.id}
              onClick={() => openTicket(ticket)}
              className="w-full glass-card rounded-xl p-4 text-right transition-all hover:border-[#2ECC71]/40 card-lift"
            >
              <div className="flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <h3 className="text-white font-medium text-sm truncate">{ticket.subject}</h3>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border shrink-0 ${statusColors[ticket.status]}`}>
                      {statusLabels[ticket.status]}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border shrink-0 ${priorityColors[ticket.priority]}`}>
                      {priorityLabels[ticket.priority]}
                    </span>
                  </div>
                  <p className="text-gray-500 text-xs truncate mb-1">{ticket.message}</p>
                  <div className="flex items-center gap-3 text-[11px] text-gray-600">
                    <span>{categoryLabels[ticket.category] || ticket.category}</span>
                    <span className="flex items-center gap-1">
                      <Clock size={10} />
                      {new Date(ticket.updatedAt).toLocaleDateString('ar')}
                    </span>
                    {ticket.replies.length > 0 && (
                      <span className="flex items-center gap-1">
                        <MessageSquare size={10} />
                        {ticket.replies.length} رد
                      </span>
                    )}
                  </div>
                </div>
                <ChevronLeft size={16} className="text-gray-600 mt-1 shrink-0" />
              </div>
            </button>
          ))}
        </div>
      )}

      {/* create form modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowForm(false)}>
          <div
            className="bg-[#0D1117] rounded-2xl border border-[#2A3040] w-full max-w-lg max-h-[90vh] overflow-y-auto scrollbar-thin animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b border-[#2A3040]">
              <h2 className="text-white font-bold text-lg">تذكرة جديدة</h2>
              <button onClick={() => setShowForm(false)} className="p-1.5 rounded-lg hover:bg-[#1A1F2E] text-gray-400 hover:text-white transition-colors">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={submitTicket} className="p-4 space-y-4">
              <div>
                <label className="text-gray-400 text-sm mb-1.5 block">الموضوع *</label>
                <input
                  type="text"
                  placeholder="مثال: مشكلة في سحب الأرباح"
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  className="w-full input-premium rounded-xl px-4 py-3 text-white text-sm"
                  required
                  maxLength={200}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 text-sm mb-1.5 block">التصنيف</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full input-premium rounded-xl px-4 py-3 text-white text-sm"
                  >
                    <option value="general">عام</option>
                    <option value="deposit">الإيداع</option>
                    <option value="withdrawal">السحب</option>
                    <option value="investment">الاستثمار</option>
                    <option value="technical">تقني</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>
                <div>
                  <label className="text-gray-400 text-sm mb-1.5 block">الأولوية</label>
                  <select
                    value={form.priority}
                    onChange={(e) => setForm({ ...form, priority: e.target.value })}
                    className="w-full input-premium rounded-xl px-4 py-3 text-white text-sm"
                  >
                    <option value="low">منخفضة</option>
                    <option value="medium">متوسطة</option>
                    <option value="high">عالية</option>
                    <option value="urgent">عاجلة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-gray-400 text-sm mb-1.5 block">الرسالة *</label>
                <textarea
                  placeholder="اشرح مشكلتك بالتفصيل..."
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full input-premium rounded-xl px-4 py-3 text-white text-sm resize-none h-32"
                  required
                  maxLength={5000}
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full btn-premium-emerald py-3 rounded-xl text-sm font-bold disabled:opacity-50"
              >
                {submitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 size={16} className="animate-spin" />
                    جاري الإنشاء...
                  </span>
                ) : (
                  'إنشاء التذكرة'
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
