'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Users, TrendingUp, UserPlus, UserMinus, Award, DollarSign, BarChart3, AlertTriangle, CheckCircle } from 'lucide-react';

interface Trader {
  id: string;
  username: string;
  winRate: number;
  avgReturn: number;
  totalProfit: number;
  level: string;
  isFollowed: boolean;
}

interface CopyTrade {
  id: string;
  traderUsername: string;
  traderWinRate: number;
  avgReturn: number;
  totalProfit: number;
  isActive: boolean;
  createdAt: string;
}

export default function CopyTradingPage() {
  const { showToast } = useToast();
  const [traders, setTraders] = useState<Trader[]>([]);
  const [activeTrades, setActiveTrades] = useState<CopyTrade[]>([]);
  const [totalCopyProfit, setTotalCopyProfit] = useState(0);
  const [totalCopyVolume, setTotalCopyVolume] = useState(0);
  const [maxFollows] = useState(3);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/copy-trading');
      const data = await res.json();
      setTraders(data.traders || []);
      setActiveTrades(data.activeTrades || []);
      setTotalCopyProfit(data.totalCopyProfit || 0);
      setTotalCopyVolume(data.totalCopyVolume || 0);
    } catch (err) { console.error('Copy trading fetch error:', err); showToast('حدث خطأ أثناء التحميل', 'error'); }
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const toggleFollow = async (trader: Trader) => {
    setActionLoading(trader.id);
    try {
      const res = await fetch('/api/copy-trading', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: trader.isFollowed ? 'unfollow' : 'follow',
          traderId: trader.id,
          traderUsername: trader.username,
        }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      fetchData();
    } catch (err) { console.error('Copy trading toggle error:', err); showToast('حدث خطأ', 'error'); }
    setActionLoading(null);
  };

  const riskColor = (level: string) => {
    if (level === 'ماسي') return 'text-purple-400';
    if (level === 'ذهبي') return 'text-[#FFD700]';
    if (level === 'فضي') return 'text-gray-300';
    return 'text-orange-400';
  };

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6">
      <h1 className="text-2xl font-bold text-white">نسخ التداول</h1>

      <div className="grid grid-cols-2 gap-3">
        <div className="glass-card p-4 text-center">
          <DollarSign size={20} className="text-[#2ECC71] mx-auto mb-1" />
          <p className="text-xl font-bold text-[#2ECC71]">${totalCopyProfit.toFixed(2)}</p>
          <p className="text-gray-400 text-xs mt-1">إجمالي أرباح النسخ</p>
        </div>
        <div className="glass-card p-4 text-center">
          <Users size={20} className="text-[#FFD700] mx-auto mb-1" />
          <p className="text-xl font-bold text-[#FFD700]">{activeTrades.length}/{maxFollows}</p>
          <p className="text-gray-400 text-xs mt-1">التداولات النشطة</p>
        </div>
      </div>

      {activeTrades.length > 0 && (
        <div>
          <h3 className="text-white font-bold mb-3 flex items-center gap-2"><BarChart3 size={18} className="text-[#2ECC71]" /> النسخ النشط</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {activeTrades.map(t => (
              <div key={t.id} className="glass-card p-4 neon-emerald">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-[#2ECC71]/20 flex items-center justify-center text-[#2ECC71] font-bold">
                      {t.traderUsername[0]}
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm">{t.traderUsername}</p>
                      <p className="text-gray-400 text-[10px]">منذ {new Date(t.createdAt).toLocaleDateString('ar')}</p>
                    </div>
                  </div>
                  <button onClick={() => toggleFollow({ id: t.id, username: t.traderUsername, winRate: t.traderWinRate, avgReturn: t.avgReturn, totalProfit: t.totalProfit, level: '', isFollowed: true })}
                    disabled={actionLoading === t.id}
                    className="px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs hover:bg-red-500/20 transition-colors disabled:opacity-50">
                    {actionLoading === t.id ? '...' : 'إلغاء'}
                  </button>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-[#2ECC71] font-bold text-sm">{t.traderWinRate}%</p>
                    <p className="text-gray-500 text-[10px]">نسبة الفوز</p>
                  </div>
                  <div>
                    <p className="text-[#FFD700] font-bold text-sm">{t.avgReturn}%</p>
                    <p className="text-gray-500 text-[10px]">متوسط العائد</p>
                  </div>
                  <div>
                    <p className="text-white font-bold text-sm">${t.totalProfit.toFixed(0)}</p>
                    <p className="text-gray-500 text-[10px]">الربح</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <h3 className="text-white font-bold mb-3 flex items-center gap-2"><Award size={18} className="text-[#FFD700]" /> المتداولون المتاحون</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {loading ? (
            <div className="col-span-full space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="skeleton-card" />
              ))}
            </div>
          ) : traders.length === 0 ? (
            <div className="col-span-2 text-center py-12">
              <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#1A1F2E] border border-[#2A3040] flex items-center justify-center">
                <Users size={28} className="text-gray-600" />
              </div>
              <p className="text-gray-400 font-medium mb-1">لا يوجد متداولون حالياً</p>
              <p className="text-gray-500 text-sm">عُد لاحقاً للعثور على متداولين مناسبين</p>
            </div>
          ) : (
            traders.map(trader => (
              <div key={trader.id} className={`glass-card p-4 card-lift ${trader.isFollowed ? 'neon-emerald' : ''}`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-full flex items-center justify-center font-bold ${trader.isFollowed ? 'bg-[#2ECC71]/20 text-[#2ECC71]' : 'bg-[#FFD700]/20 text-[#FFD700]'}`}>
                      {trader.username[0]}
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm flex items-center gap-1">
                        {trader.username}
                        <span className={`text-[10px] ${riskColor(trader.level)}`}>({trader.level})</span>
                      </p>
                      <p className="text-gray-400 text-[10px]">ربح إجمالي: ${trader.totalProfit.toLocaleString()}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="bg-[#12161F] rounded-lg p-2 text-center">
                    <TrendingUp size={14} className="text-[#2ECC71] mx-auto mb-0.5" />
                    <p className="text-white font-bold text-sm">{trader.winRate}%</p>
                    <p className="text-gray-500 text-[10px]">نسبة الفوز</p>
                  </div>
                  <div className="bg-[#12161F] rounded-lg p-2 text-center">
                    <BarChart3 size={14} className="text-[#FFD700] mx-auto mb-0.5" />
                    <p className="text-white font-bold text-sm">{trader.avgReturn}%</p>
                    <p className="text-gray-500 text-[10px]">متوسط العائد</p>
                  </div>
                </div>

                <button
                  onClick={() => toggleFollow(trader)}
                  disabled={actionLoading === trader.id || (!trader.isFollowed && activeTrades.length >= maxFollows)}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all disabled:opacity-50 ${
                    trader.isFollowed
                      ? 'bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20'
                      : 'btn-premium-emerald'
                  }`}>
                  {actionLoading === trader.id ? '...' : trader.isFollowed ? (
                    <span className="flex items-center justify-center gap-1"><UserMinus size={14} /> إلغاء المتابعة</span>
                  ) : (
                    <span className="flex items-center justify-center gap-1"><UserPlus size={14} /> متابعة</span>
                  )}
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
