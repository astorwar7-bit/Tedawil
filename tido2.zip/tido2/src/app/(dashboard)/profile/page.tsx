'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/contexts/ToastContext';
import { Camera, Copy, Check, Lock, Save, User, Mail, Phone, Shield, KeyRound, Loader2 } from 'lucide-react';

export default function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const { showToast } = useToast();
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', avatar: '' });
  const [passForm, setPassForm] = useState({ current: '', newPass: '', confirm: '' });
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);
  const [changingPass, setChangingPass] = useState(false);

  useEffect(() => {
    if (user) setForm({ fullName: user.fullName, email: user.email, phone: user.phone, avatar: user.avatar });
  }, [user]);

  const updateProfile = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'updateProfile', ...form }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); setSaving(false); return; }
      showToast('تم تحديث البيانات بنجاح');
      refreshUser();
    } catch { showToast('حدث خطأ', 'error'); }
    setSaving(false);
  };

  const changePassword = async () => {
    if (passForm.newPass !== passForm.confirm) { showToast('كلمتا السر غير متطابقتين', 'error'); return; }
    if (passForm.newPass.length < 8) { showToast('كلمة السر يجب أن تكون 8 أحرف على الأقل', 'error'); return; }
    setChangingPass(true);
    try {
      const res = await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'changePassword', currentPassword: passForm.current, newPassword: passForm.newPass }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); setChangingPass(false); return; }
      showToast('تم تغيير كلمة السر بنجاح');
      setPassForm({ current: '', newPass: '', confirm: '' });
    } catch { showToast('حدث خطأ', 'error'); }
    setChangingPass(false);
  };

  const uploadAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { showToast('حجم الصورة يجب أن يكون أقل من 5MB', 'error'); return; }
    const fd = new FormData();
    fd.append('avatar', file);
    try {
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      const data = await res.json();
      if (res.ok) {
        setForm(f => ({ ...f, avatar: data.url }));
        showToast('تم رفع الصورة بنجاح');
      }
    } catch { showToast('حدث خطأ أثناء رفع الصورة', 'error'); }
  };

  if (!user) return null;

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6 max-w-2xl mx-auto">

      {/* Page Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-[#FFD700]/5 via-[#1A1F2E] to-[#2ECC71]/5 border border-[#2A3040] p-5">
        <div className="absolute top-0 left-0 w-32 h-32 bg-[#FFD700]/5 rounded-full -translate-x-1/2 -translate-y-1/2 animate-glow-pulse" />
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-[#2ECC71]/5 rounded-full translate-x-1/2 translate-y-1/2 animate-glow-pulse" />
        <div className="relative flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#FFD700]/10 border border-[#FFD700]/20 flex items-center justify-center icon-pulse-gold">
            <User size={24} className="text-[#FFD700]" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">الملف الشخصي</h1>
            <p className="text-gray-400 text-xs mt-0.5">إدارة بياناتك وتفضيلاتك</p>
          </div>
        </div>
      </div>

      {/* Avatar + User Info Card */}
      <div className="glass-card p-6">
        <div className="flex items-center gap-5">
          <div className="relative group">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 border-2 border-[#FFD700]/30 flex items-center justify-center text-[#FFD700] font-bold text-2xl overflow-hidden shadow-lg shadow-[#FFD700]/10">
              {form.avatar ? (
                <img src={form.avatar} alt="" className="w-full h-full object-cover" />
              ) : (
                user.username[0]?.toUpperCase()
              )}
            </div>
            <label className="absolute -bottom-1 -left-1 w-8 h-8 bg-gradient-to-br from-[#2ECC71] to-emerald-600 rounded-xl flex items-center justify-center cursor-pointer hover:scale-110 transition-transform shadow-lg shadow-[#2ECC71]/20">
              <Camera size={14} className="text-white" />
              <input type="file" accept="image/*" onChange={uploadAvatar} className="hidden" />
            </label>
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-bold text-white truncate">{user.fullName || user.username}</h3>
            <p className="text-gray-400 text-sm mt-0.5">@{user.username}</p>
            <div className="flex items-center gap-3 mt-2">
              <span className="text-xs px-3 py-1 rounded-full bg-[#2ECC71]/10 text-[#2ECC71] border border-[#2ECC71]/20 font-medium">
                {user.balance?.toFixed(2)} $
              </span>
              <span className="text-xs px-3 py-1 rounded-full bg-[#FFD700]/10 text-[#FFD700] border border-[#FFD700]/20 font-medium">
                رصيدك
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Card */}
      <div className="glass-card p-5">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-lg bg-[#2ECC71]/10 flex items-center justify-center">
            <Shield size={16} className="text-[#2ECC71]" />
          </div>
          <h3 className="text-sm font-bold text-white">تعديل البيانات الشخصية</h3>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-gray-400 text-xs mb-2 block font-medium flex items-center gap-1.5">
              <User size={12} className="text-gray-500" />
              الاسم الكامل
            </label>
            <input
              value={form.fullName}
              onChange={e => setForm({ ...form, fullName: e.target.value })}
              className="input-premium"
              placeholder="أدخل اسمك الكامل"
            />
          </div>
          <div>
            <label className="text-gray-400 text-xs mb-2 block font-medium flex items-center gap-1.5">
              <Mail size={12} className="text-gray-500" />
              البريد الإلكتروني
            </label>
            <input
              type="email"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              className="input-premium"
              placeholder="example@email.com"
              dir="ltr"
            />
          </div>
          <div>
            <label className="text-gray-400 text-xs mb-2 block font-medium flex items-center gap-1.5">
              <Phone size={12} className="text-gray-500" />
              رقم الهاتف
            </label>
            <input
              value={form.phone}
              onChange={e => setForm({ ...form, phone: e.target.value })}
              className="input-premium"
              placeholder="+964 xxx xxx xxxx"
              dir="ltr"
            />
          </div>
          <button
            onClick={updateProfile}
            disabled={saving}
            className="btn-premium-emerald btn-ripple w-full flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
            {saving ? 'جارٍ الحفظ...' : 'حفظ التغييرات'}
          </button>
        </div>
      </div>

      {/* Change Password Card */}
      <div className="glass-card p-5">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-lg bg-[#FFD700]/10 flex items-center justify-center">
            <KeyRound size={16} className="text-[#FFD700]" />
          </div>
          <h3 className="text-sm font-bold text-white">تغيير كلمة السر</h3>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-gray-400 text-xs mb-2 block font-medium flex items-center gap-1.5">
              <Lock size={12} className="text-gray-500" />
              كلمة السر الحالية
            </label>
            <input
              type="password"
              value={passForm.current}
              onChange={e => setPassForm({ ...passForm, current: e.target.value })}
              className="input-premium"
              placeholder="أدخل كلمة السر الحالية"
            />
          </div>
          <div>
            <label className="text-gray-400 text-xs mb-2 block font-medium flex items-center gap-1.5">
              <Lock size={12} className="text-gray-500" />
              كلمة السر الجديدة
            </label>
            <input
              type="password"
              value={passForm.newPass}
              onChange={e => setPassForm({ ...passForm, newPass: e.target.value })}
              className="input-premium"
              placeholder="8 أحرف على الأقل"
            />
          </div>
          <div>
            <label className="text-gray-400 text-xs mb-2 block font-medium flex items-center gap-1.5">
              <Lock size={12} className="text-gray-500" />
              تأكيد كلمة السر الجديدة
            </label>
            <input
              type="password"
              value={passForm.confirm}
              onChange={e => setPassForm({ ...passForm, confirm: e.target.value })}
              className="input-premium"
              placeholder="أعد كتابة كلمة السر الجديدة"
            />
          </div>
          <button
            onClick={changePassword}
            disabled={changingPass || !passForm.current || !passForm.newPass || !passForm.confirm}
            className="btn-premium-gold btn-ripple w-full flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {changingPass ? <Loader2 size={16} className="animate-spin" /> : <Lock size={16} />}
            {changingPass ? 'جارٍ التغيير...' : 'تغيير كلمة السر'}
          </button>
        </div>
      </div>

      {/* Referral Code Card */}
      <div className="glass-card p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center">
            <Copy size={16} className="text-purple-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">كود الإحالة الخاص بك</h3>
            <p className="text-[10px] text-gray-500 mt-0.5">شارك هذا الكود مع أصدقائك لتحصل على مكافآت</p>
          </div>
        </div>
        <div className="flex gap-2">
          <div className="flex-1 bg-[#12161F] border border-[#2A3040] rounded-xl px-4 py-3 text-[#FFD700] font-bold text-sm text-center tracking-wider" dir="ltr">
            {user.referralCode}
          </div>
          <button
            onClick={() => {
              navigator.clipboard.writeText(user.referralCode);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
              showToast('تم نسخ الكود بنجاح');
            }}
            className={`px-4 rounded-xl transition-all flex items-center justify-center ${
              copied
                ? 'bg-[#2ECC71]/10 border border-[#2ECC71]/20'
                : 'bg-[#1A1F2E] border border-[#2A3040] hover:border-[#FFD700]/50'
            }`}
          >
            {copied ? <Check size={16} className="text-[#2ECC71]" /> : <Copy size={16} className="text-gray-400" />}
          </button>
        </div>
      </div>
    </div>
  );
}
