'use client';
import { useEffect, useState, useRef } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { Shield, Upload, CheckCircle, Clock, XCircle, AlertTriangle, Camera, FileText, User } from 'lucide-react';

interface KYCData {
  status: string;
  idFront: string;
  idBack: string;
  selfie: string;
  rejectReason?: string;
}

export default function KYCPage() {
  const { showToast } = useToast();
  const [kyc, setKyc] = useState<KYCData>({ status: 'not_submitted', idFront: '', idBack: '', selfie: '' });
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [idFront, setIdFront] = useState('');
  const [idBack, setIdBack] = useState('');
  const [selfie, setSelfie] = useState('');
  const frontRef = useRef<HTMLInputElement>(null);
  const backRef = useRef<HTMLInputElement>(null);
  const selfieRef = useRef<HTMLInputElement>(null);

  const fetchKYC = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/kyc');
      const data = await res.json();
      setKyc(data.kyc);
      if (data.kyc.status === 'rejected') {
        setIdFront(data.kyc.idFront || '');
        setIdBack(data.kyc.idBack || '');
        setSelfie(data.kyc.selfie || '');
      }
    } catch { showToast('حدث خطأ', 'error'); }
    setLoading(false);
  };

  useEffect(() => { fetchKYC(); }, []);

  const handleFileUpload = async (file: File, field: 'idFront' | 'idBack' | 'selfie') => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      if (field === 'idFront') setIdFront(base64);
      if (field === 'idBack') setIdBack(base64);
      if (field === 'selfie') setSelfie(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async () => {
    if (!idFront || !idBack || !selfie) {
      showToast('يرجى رفع جميع المستندات', 'error');
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch('/api/kyc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idFront, idBack, selfie }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      fetchKYC();
    } catch { showToast('حدث خطأ', 'error'); }
    setSubmitting(false);
  };

  const statusConfig: Record<string, { icon: typeof CheckCircle; label: string; color: string; bg: string; desc: string }> = {
    not_submitted: { icon: Shield, label: 'لم يتم التقديم', color: 'text-gray-400', bg: 'bg-gray-500/10', desc: 'قم برفع المستندات لتأكيد هويتك' },
    pending: { icon: Clock, label: 'قيد المراجعة', color: 'text-yellow-400', bg: 'bg-yellow-500/10', desc: 'سيتم مراجعة مستنداتك خلال 24-48 ساعة' },
    verified: { icon: CheckCircle, label: 'تم التحقق', color: 'text-emerald-400', bg: 'bg-emerald-500/10', desc: 'تم التحقق من هويتك بنجاح' },
    rejected: { icon: XCircle, label: 'مرفوض', color: 'text-red-400', bg: 'bg-red-500/10', desc: 'تم رفض الطلب. يرجى إعادة التقديم' },
  };

  const currentStatus = statusConfig[kyc.status] || statusConfig.not_submitted;
  const StatusIcon = currentStatus.icon;
  const canSubmit = kyc.status === 'not_submitted' || kyc.status === 'rejected';

  const UploadBox = ({ label, value, field, refTarget, icon: Icon }: {
    label: string; value: string; field: 'idFront' | 'idBack' | 'selfie'; refTarget: React.RefObject<HTMLInputElement | null>; icon: typeof Camera;
  }) => (
    <div className="bg-[#12161F] rounded-xl border border-[#2A3040] overflow-hidden">
      <label className="text-gray-400 text-xs block p-3 pb-2">{label}</label>
      <input type="file" accept="image/*" ref={refTarget} className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleFileUpload(f, field); }} />
      {value ? (
        <div className="relative group">
          <img src={value} alt={label} className="w-full h-32 object-cover" />
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer" onClick={() => refTarget.current?.click()}>
            <Camera size={24} className="text-white" />
          </div>
        </div>
      ) : (
        <div className="p-6 flex flex-col items-center justify-center cursor-pointer hover:bg-[#1A1F2E] transition-colors" onClick={() => refTarget.current?.click()}>
          <div className="w-14 h-14 rounded-full bg-[#2A3040] flex items-center justify-center mb-2">
            <Icon size={24} className="text-gray-400" />
          </div>
          <p className="text-gray-400 text-xs">اضغط لرفع الصورة</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6">
      <h1 className="text-2xl font-bold text-white flex items-center gap-2">
        <Shield size={24} className="text-[#2ECC71]" />
        التحقق من الهوية (KYC)
      </h1>

      {/* Status */}
      <div className={`glass-card p-5 flex items-center gap-4 ${currentStatus.bg}`}>
        <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${currentStatus.bg}`}>
          <StatusIcon size={28} className={currentStatus.color} />
        </div>
        <div>
          <p className={`font-bold text-lg ${currentStatus.color}`}>{currentStatus.label}</p>
          <p className="text-gray-400 text-xs mt-0.5">{currentStatus.desc}</p>
        </div>
      </div>

      {kyc.status === 'rejected' && kyc.rejectReason && (
        <div className="glass-card p-4 border-red-500/20 border flex items-center gap-3">
          <AlertTriangle size={18} className="text-red-400" />
          <div>
            <p className="text-red-400 font-medium text-sm">سبب الرفض</p>
            <p className="text-gray-400 text-xs">{kyc.rejectReason}</p>
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="glass-card p-4">
        <h3 className="text-white font-bold text-sm mb-3 flex items-center gap-2"><FileText size={16} className="text-[#FFD700]" /> تعليمات</h3>
        <ul className="space-y-2 text-gray-400 text-xs">
          <li className="flex items-start gap-2"><CheckCircle size={14} className="text-[#2ECC71] mt-0.5 flex-shrink-0" /> ارفع صورة واضحة للوجه الأمامي من بطاقة الهوية أو جواز السفر</li>
          <li className="flex items-start gap-2"><CheckCircle size={14} className="text-[#2ECC71] mt-0.5 flex-shrink-0" /> ارفع صورة واضحة للوجه الخلفي</li>
          <li className="flex items-start gap-2"><CheckCircle size={14} className="text-[#2ECC71] mt-0.5 flex-shrink-0" /> ارفع صورة شخصية (سيلفي) مع البطاقة</li>
          <li className="flex items-start gap-2"><CheckCircle size={14} className="text-[#2ECC71] mt-0.5 flex-shrink-0" /> تأكد من وضوح النصوص والصور</li>
        </ul>
      </div>

      {/* Upload Form */}
      {canSubmit && (
        <div className="space-y-3">
          <UploadBox label="الوجه الأمامي" value={idFront} field="idFront" refTarget={frontRef} icon={FileText} />
          <UploadBox label="الوجه الخلفي" value={idBack} field="idBack" refTarget={backRef} icon={FileText} />
          <UploadBox label="صورة شخصية (سيلفي)" value={selfie} field="selfie" refTarget={selfieRef} icon={User} />

          <button onClick={handleSubmit} disabled={submitting || !idFront || !idBack || !selfie} className="btn-premium-emerald disabled:opacity-50 flex items-center justify-center gap-2">
            <Upload size={16} />
            {submitting ? 'جاري التقديم...' : 'تقديم للتحقق'}
          </button>
        </div>
      )}

      {kyc.status === 'verified' && (
        <div className="glass-card p-5 text-center neon-emerald">
          <CheckCircle size={48} className="text-[#2ECC71] mx-auto mb-3" />
          <p className="text-white font-bold text-lg">تم التحقق من هويتك بنجاح!</p>
          <p className="text-gray-400 text-xs mt-1">يمكنك الآن استخدام جميع ميزات المنصة</p>
        </div>
      )}

      {kyc.status === 'pending' && (
        <div className="glass-card p-5 text-center">
          <Clock size={48} className="text-yellow-400 mx-auto mb-3" />
          <p className="text-white font-bold text-lg">طلبك قيد المراجعة</p>
          <p className="text-gray-400 text-xs mt-1">سيتم إشعارك بالنتيجة خلال 24-48 ساعة</p>
        </div>
      )}
    </div>
  );
}
