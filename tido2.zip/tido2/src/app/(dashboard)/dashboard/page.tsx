'use client';
import { useEffect, useState, useCallback } from 'react';
import {
  Wallet, TrendingUp, DollarSign, Clock, ArrowUpRight, ArrowDownRight,
  Plus, Check, ChevronDown, Gem, Activity, PieChart as PieIcon, BarChart3,
  CircleDollarSign, Loader2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { useToast } from '@/contexts/ToastContext';

/* ─────────── types ─────────── */
interface Plan {
  id: string;
  name: string;
  nameEn: string;
  minAmount: number;
  maxAmount: number;
  dailyRate: number;
  duration: number;
  icon: string;
  color: string;
  description: string | null;
  _count: { investments: number };
}

interface StatCard {
  label: string;
  value: number;
  icon: React.ElementType;
  color: string;
  trend?: 'up' | 'down' | null;
}

/* ─────────── animated counter ─────────── */
function AnimatedValue({ value, prefix = '$' }: { value: number; prefix?: string }) {
  const [displayed, setDisplayed] = useState(0);
  useEffect(() => {
    const duration = 900;
    const startTime = Date.now();
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayed(value * eased);
      if (progress < 1) requestAnimationFrame(animate);
    };
    animate();
  }, [value]);

  return <span>{prefix}{displayed.toFixed(2)}</span>;
}

/* ─────────── tooltip style ─────────── */
const tooltipStyle: React.CSSProperties = {
  background: '#1A1F2E',
  border: '1px solid #2A3040',
  borderRadius: '12px',
  color: '#E8E8E8',
  fontSize: '13px',
  boxShadow: '0 12px 40px rgba(0,0,0,0.5)',
  padding: '10px 14px',
};

const axisStyle = { stroke: '#8899AA', fontSize: 11 };

/* ─────────── arabic month names ─────────── */
const AR_MONTHS: Record<string, string> = {
  '01': 'يناير', '02': 'فبراير', '03': 'مارس', '04': 'أبريل',
  '05': 'مايو', '06': 'يونيو', '07': 'يوليو', '08': 'أغسطس',
  '09': 'سبتمبر', '10': 'أكتوبر', '11': 'نوفمبر', '12': 'ديسمبر',
};

function formatArabicDate(d: string) {
  const date = new Date(d);
  return `${date.getDate()} ${AR_MONTHS[String(date.getMonth() + 1).padStart(2, '0')]}`;
}

function formatArabicMonth(d: string) {
  const date = new Date(d);
  return `${AR_MONTHS[String(date.getMonth() + 1).padStart(2, '0')]} ${date.getFullYear()}`;
}

/* ─────────── activity icon mapper ─────────── */
function getActivityIcon(action: string) {
  if (action.includes('deposit')) return <CircleDollarSign size={16} className="text-emerald-brand" />;
  if (action.includes('withdraw')) return <ArrowUpRight size={16} className="text-red-400" />;
  if (action.includes('invest')) return <TrendingUp size={16} className="text-gold" />;
  if (action.includes('login')) return <Wallet size={16} className="text-blue-400" />;
  if (action.includes('register') || action.includes('signup')) return <Check size={16} className="text-emerald-brand" />;
  if (action.includes('ticket')) return <Activity size={16} className="text-purple-400" />;
  return <Activity size={16} className="text-gray-400" />;
}

/* ─────────── pie colors ─────────── */
const PIE_COLORS = ['#FFD700', '#2ECC71', '#3B82F6', '#8B5CF6', '#EC4899', '#F97316'];

/* ─────────── custom legend for pie ─────────── */
function CustomPieLegend({ payload }: { payload?: Array<{ value: string; color: string; payload?: { percent?: number } }> }) {
  if (!payload) return null;
  return (
    <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 mt-2">
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center gap-1.5 text-xs">
          <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: entry.color }} />
          <span className="text-gray-300">{entry.value}</span>
          {entry.payload?.percent !== undefined && (
            <span className="text-gray-500">({(entry.payload.percent * 100).toFixed(1)}%)</span>
          )}
        </div>
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════
   MAIN DASHBOARD COMPONENT
   ═══════════════════════════════════════════ */
export default function DashboardPage() {
  const { showToast } = useToast();

  /* ── state ── */
  const [loading, setLoading] = useState(true);
  const [totalBalance, setTotalBalance] = useState(0);
  const [activeInvestmentsCount, setActiveInvestmentsCount] = useState(0);
  const [totalProfits, setTotalProfits] = useState(0);
  const [pendingDeposits, setPendingDeposits] = useState(0);

  const [balanceChart, setBalanceChart] = useState<{ date: string; amount: number; label: string }[]>([]);
  const [investmentDistribution, setInvestmentDistribution] = useState<{ name: string; value: number; color: string }[]>([]);
  const [monthlyProfits, setMonthlyProfits] = useState<{ month: string; profits: number }[]>([]);
  const [recentActivities, setRecentActivities] = useState<Array<{
    id: string; action: string; details: string; amount: number; createdAt: string;
  }>>([]);

  const [showModal, setShowModal] = useState(false);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [invForm, setInvForm] = useState({ amount: '', coupon: '' });
  const [showPlanDropdown, setShowPlanDropdown] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  /* ── auth helper ── */
  const authHeaders = useCallback(() => {
    const token = localStorage.getItem('tedawilai_token');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token && token !== 'undefined' && token !== 'null') {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  }, []);

  /* ── data fetching ── */
  useEffect(() => {
    let cancelled = false;

    async function fetchDashboard() {
      setLoading(true);
      try {
        const [meRes, profitsRes, invRes, activityRes, depositsRes, plansRes] = await Promise.all([
          fetch('/api/auth/me', { headers: authHeaders() }),
          fetch('/api/profits?limit=60', { headers: authHeaders() }),
          fetch('/api/investments?status=active', { headers: authHeaders() }),
          fetch('/api/activity-log?limit=5', { headers: authHeaders() }),
          fetch('/api/deposits?status=pending&limit=50', { headers: authHeaders() }),
          fetch('/api/plans', { headers: authHeaders() }),
        ]);

        if (cancelled) return;

        const [meData, profitsData, invData, activityData, depositsData, plansData] = await Promise.all([
          meRes.json(),
          profitsRes.json(),
          invRes.json(),
          activityRes.json(),
          depositsRes.json(),
          plansRes.json(),
        ]);

        /* stats */
        setTotalBalance(meData.user?.balance ?? 0);
        const profits = profitsData.profits || [];
        setTotalProfits(profitsData.totalProfits || 0);
        const investments = invData.investments || [];
        setActiveInvestmentsCount(investments.length);
        const deposits = depositsData.deposits || [];
        const pendingTotal = deposits.reduce((s: number, d: { amount: number }) => s + d.amount, 0);
        setPendingDeposits(pendingTotal);
        setPlans(plansData.plans || []);

        /* 1) Balance growth — last 30 days from profit records */
        const last30 = profits.slice(0, 30).reverse();
        let cumulative = meData.user?.balance ?? 0;
        const today = new Date();
        today.setHours(23, 59, 59, 999);
        const thirtyDaysAgo = new Date(today);
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 29);

        // Create date map of profits
        const profitMap = new Map<string, number>();
        last30.forEach((p: { date: string; amount: number }) => {
          const d = new Date(p.date);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
          profitMap.set(key, (profitMap.get(key) || 0) + p.amount);
        });

        // Generate 30-day balance data (simulated cumulative balance)
        const balanceData: { date: string; amount: number; label: string }[] = [];
        let runningBalance = cumulative;
        for (let i = 29; i >= 0; i--) {
          const d = new Date(today);
          d.setDate(d.getDate() - i);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
          const dayProfit = profitMap.get(key) || 0;
          runningBalance += dayProfit;
          balanceData.push({
            date: key,
            amount: parseFloat(runningBalance.toFixed(2)),
            label: `${d.getDate()}/${d.getMonth() + 1}`,
          });
        }
        setBalanceChart(balanceData);

        /* 2) Investment distribution */
        if (investments.length > 0) {
          const grouped = new Map<string, number>();
          const colorMap = new Map<string, string>();
          investments.forEach((inv: { plan?: { name: string; color: string } | null; amount: number }) => {
            const name = inv.plan?.name || 'خطة افتراضية';
            grouped.set(name, (grouped.get(name) || 0) + inv.amount);
            if (inv.plan?.color) colorMap.set(name, inv.plan.color);
          });
          const dist = Array.from(grouped.entries()).map(([name, value], i) => ({
            name,
            value,
            color: colorMap.get(name) || PIE_COLORS[i % PIE_COLORS.length],
          }));
          setInvestmentDistribution(dist);
        }

        /* 3) Monthly profits — last 6 months */
        const monthMap = new Map<string, number>();
        profits.forEach((p: { date: string; amount: number }) => {
          const d = new Date(p.date);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
          monthMap.set(key, (monthMap.get(key) || 0) + p.amount);
        });

        const months: string[] = [];
        for (let i = 5; i >= 0; i--) {
          const d = new Date(today);
          d.setDate(d.getDate());
          d.setMonth(d.getMonth() - i);
          months.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
        }

        const monthly = months.map((m) => ({
          month: AR_MONTHS[m.split('-')[1]] || m,
          profits: parseFloat((monthMap.get(m) || 0).toFixed(2)),
        }));
        setMonthlyProfits(monthly);

        /* 4) Recent activities */
        setRecentActivities(activityData.activities || []);

      } catch {
        showToast('حدث خطأ أثناء تحميل البيانات', 'error');
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchDashboard();
    return () => { cancelled = true; };
  }, [authHeaders, showToast]);

  /* ── investment modal ── */
  const openModalWithPlan = (plan?: Plan) => {
    setSelectedPlan(plan || null);
    setInvForm({ amount: plan ? String(plan.minAmount) : '', coupon: '' });
    setShowPlanDropdown(false);
    setShowModal(true);
  };

  const createInvestment = async () => {
    if (submitting) return;
    setSubmitting(true);
    try {
      const payload: Record<string, unknown> = {
        amount: parseFloat(invForm.amount),
        couponCode: invForm.coupon || undefined,
      };
      if (selectedPlan) payload.planId = selectedPlan.id;

      const res = await fetch('/api/investments', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify(payload),
      });
      const result = await res.json();
      if (!res.ok) {
        showToast(result.error || 'حدث خطأ', 'error');
        setSubmitting(false);
        return;
      }
      showToast('تم إنشاء الاستثمار بنجاح!', 'success');
      setShowModal(false);
      window.location.reload();
    } catch {
      showToast('حدث خطأ أثناء إنشاء الاستثمار', 'error');
      setSubmitting(false);
    }
  };

  const fmt = (n: number) => `$${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const cards: StatCard[] = [
    { label: 'إجمالي الرصيد', value: totalBalance, icon: Wallet, color: '#FFD700' },
    { label: 'الاستثمارات النشطة', value: activeInvestmentsCount, icon: TrendingUp, color: '#2ECC71', trend: activeInvestmentsCount > 0 ? 'up' : null },
    { label: 'إجمالي الأرباح', value: totalProfits, icon: DollarSign, color: '#3B82F6', trend: totalProfits > 0 ? 'up' : totalProfits < 0 ? 'down' : null },
    { label: 'إيداعات معلقة', value: pendingDeposits, icon: Clock, color: '#F97316' },
  ];

  const dateStr = new Date().toLocaleDateString('ar', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

  /* ── loading skeleton ── */
  if (loading) {
    return (
      <div className="space-y-6 pb-20 lg:pb-6">
        <div className="skeleton-card h-28" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <div key={i} className="skeleton-card h-28" />)}
        </div>
        <div className="skeleton-card h-80" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="skeleton-card h-72" />
          <div className="skeleton-card h-72" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn pb-20 lg:pb-6">

      {/* ═══ Greeting Header ═══ */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-[#FFD700]/5 via-[#1A1F2E] to-[#2ECC71]/5 border border-[#2A3040] p-4 sm:p-5">
        <div className="absolute top-0 left-0 w-32 h-32 bg-[#FFD700]/5 rounded-full blur-3xl animate-glow-pulse" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-[#2ECC71]/5 rounded-full blur-3xl animate-glow-pulse" />
        <div className="relative z-10">
          <h1 className="text-xl sm:text-2xl font-bold text-white">
            <span className="animate-wave">👋</span> مرحباً بك
          </h1>
          <p className="text-gray-400 text-xs sm:text-sm mt-1 bg-[#12161F] inline-block px-3 py-1 rounded-lg border border-[#2A3040]">{dateStr}</p>
        </div>
      </div>

      {/* ═══ Summary Stats Cards ═══ */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 stagger-children">
        {cards.map((c, i) => (
          <div key={i} className="glass-card card-lift premium-shimmer p-3 sm:p-4">
            <div className="flex items-center justify-between mb-2 sm:mb-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center ${c.color === '#FFD700' ? 'icon-pulse-gold' : 'icon-pulse-emerald'}`}
                style={{ background: `${c.color}15` }}
              >
                <c.icon size={18} style={{ color: c.color }} />
              </div>
              {c.trend && (
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${c.trend === 'up' ? 'bg-[#2ECC71]/10' : 'bg-red-500/10'}`}>
                  {c.trend === 'up'
                    ? <ArrowUpRight size={14} className="text-[#2ECC71]" />
                    : <ArrowDownRight size={14} className="text-red-500" />}
                </div>
              )}
            </div>
            <p className="text-xs text-gray-400 mb-1">{c.label}</p>
            <p className="text-base sm:text-lg lg:text-xl font-bold text-white">
              {i === 1 ? (
                <span>{c.value}</span>
              ) : (
                <AnimatedValue value={c.value} />
              )}
            </p>
          </div>
        ))}
      </div>

      {/* ═══ Balance Growth Chart (Area) ═══ */}
      <div className="glass-card p-4 sm:p-5">
        <h3 className="text-xs sm:text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
          <TrendingUp size={16} className="text-[#2ECC71]" />
          نمو الرصيد — آخر 30 يوم
        </h3>
        {balanceChart.length > 0 ? (
          <div className="h-52 sm:h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={balanceChart} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="balanceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2ECC71" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#2ECC71" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#2A3040" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: '#8899AA', fontSize: 9 }}
                  axisLine={{ stroke: '#2A3040' }}
                  tickLine={false}
                  interval="preserveStartEnd"
                />
                <YAxis
                  tick={{ fill: '#8899AA', fontSize: 9 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v: number) => `$${(v / 1000).toFixed(1)}K`}
                  width={45}
                />
                <Tooltip
                  contentStyle={tooltipStyle}
                  formatter={(value: number) => [`$${value.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 'الرصيد']}
                  labelFormatter={(label: string) => `التاريخ: ${label}`}
                  cursor={{ stroke: '#2ECC71', strokeWidth: 1, strokeDasharray: '4 4' }}
                />
                <Area
                  type="monotone"
                  dataKey="amount"
                  stroke="#2ECC71"
                  strokeWidth={2.5}
                  fill="url(#balanceGradient)"
                  dot={false}
                  activeDot={{ r: 5, fill: '#2ECC71', stroke: '#0A0F0D', strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-52 sm:h-64 flex items-center justify-center text-gray-500 text-sm">
            لا توجد بيانات لعرض الرسم البياني
          </div>
        )}
      </div>

      {/* ═══ Charts Grid: Pie + Bar ═══ */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* ── Investment Distribution (Donut) ── */}
        <div className="glass-card p-4 sm:p-5">
          <h3 className="text-xs sm:text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <PieIcon size={16} className="text-[#FFD700]" />
            توزيع الاستثمارات النشطة
          </h3>
          {investmentDistribution.length > 0 ? (
            <div>
              <div className="h-48 sm:h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={investmentDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={70}
                      paddingAngle={3}
                      dataKey="value"
                      nameKey="name"
                      stroke="none"
                    >
                      {investmentDistribution.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={tooltipStyle}
                      formatter={(value: number) => [`$${value.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 'المبلغ']}
                    />
                    <Legend content={<CustomPieLegend />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          ) : (
            <div className="h-48 sm:h-56 flex items-center justify-center text-gray-500 text-sm">
              <div className="text-center">
                <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
                  <PieIcon size={24} className="text-gray-600" />
                </div>
                <p>لا توجد استثمارات نشطة</p>
                <button
                  onClick={() => openModalWithPlan()}
                  className="mt-3 text-xs text-[#FFD700] hover:underline inline-flex items-center gap-1"
                >
                  <Plus size={14} /> ابدأ الاستثمار الآن
                </button>
              </div>
            </div>
          )}
        </div>

        {/* ── Monthly Profits (Bar) ── */}
        <div className="glass-card p-4 sm:p-5">
          <h3 className="text-xs sm:text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <BarChart3 size={16} className="text-[#2ECC71]" />
            الأرباح الشهرية — آخر 6 أشهر
          </h3>
          {monthlyProfits.some(m => m.profits > 0) ? (
            <div className="h-48 sm:h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyProfits} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2A3040" vertical={false} />
                  <XAxis
                    dataKey="month"
                    tick={{ fill: '#8899AA', fontSize: 9 }}
                    axisLine={{ stroke: '#2A3040' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: '#8899AA', fontSize: 9 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v: number) => `$${(v / 1000).toFixed(1)}K`}
                    width={45}
                  />
                  <Tooltip
                    contentStyle={tooltipStyle}
                    formatter={(value: number) => [`$${value.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 'الأرباح']}
                    cursor={{ fill: 'rgba(46,204,113,0.06)' }}
                  />
                  <Bar
                    dataKey="profits"
                    fill="#2ECC71"
                    fillOpacity={0.8}
                    radius={[6, 6, 0, 0]}
                    maxBarSize={48}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-48 sm:h-56 flex items-center justify-center text-gray-500 text-sm">
              <div className="text-center">
                <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
                  <BarChart3 size={24} className="text-gray-600" />
                </div>
                <p>لا توجد أرباح بعد</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ═══ Recent Activity ═══ */}
      <div className="glass-card p-4 sm:p-5">
        <h3 className="text-xs sm:text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
          <Activity size={16} className="text-[#8B5CF6]" />
          آخر النشاطات
        </h3>
        {recentActivities.length > 0 ? (
          <div className="space-y-3 max-h-80 overflow-y-auto scrollbar-thin">
            {recentActivities.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-3 p-3 rounded-xl bg-[#12161F]/60 border border-[#2A3040]/50 hover:border-[#2A3040] transition-colors"
              >
                <div className="w-9 h-9 rounded-lg bg-[#1A1F2E] flex items-center justify-center flex-shrink-0">
                  {getActivityIcon(item.action)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-200 truncate">{item.details}</p>
                  <p className="text-[11px] text-gray-500 mt-0.5">
                    {new Date(item.createdAt).toLocaleDateString('ar', {
                      year: 'numeric', month: 'short', day: 'numeric',
                    })}
                    {' — '}
                    {new Date(item.createdAt).toLocaleTimeString('ar', {
                      hour: '2-digit', minute: '2-digit',
                    })}
                  </p>
                </div>
                {item.amount > 0 && (
                  <span className="text-xs font-bold text-[#2ECC71] flex-shrink-0">
                    +${item.amount.toFixed(2)}
                  </span>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500 text-sm">
            <Activity size={28} className="mx-auto mb-2 text-gray-600" />
            لا توجد نشاطات بعد
          </div>
        )}
      </div>

      {/* ═══ Quick Plans Preview ═══ */}
      {plans.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-gray-300 flex items-center gap-2">
              <TrendingUp size={16} className="text-[#FFD700]" />
              خطط الاستثمار
            </h3>
            <a href="/plans" className="text-xs text-[#FFD700] hover:underline">عرض الكل</a>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
            {plans.slice(0, 4).map((plan) => (
              <button
                key={plan.id}
                onClick={() => openModalWithPlan(plan)}
                className="glass-card card-lift p-4 text-right transition-all hover:scale-[1.02] group"
                style={{ borderTopColor: plan.color, borderTopWidth: '2px' }}
              >
                <div className="text-2xl mb-2">{plan.icon}</div>
                <p className="text-xs font-bold text-white mb-1">{plan.name}</p>
                <p className="text-[10px] text-gray-400 mb-2">{plan.duration} يوم • {plan.dailyRate}% يومياً</p>
                <div className="flex items-center gap-1">
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ background: `${plan.color}15`, color: plan.color }}>
                    من {plan.minAmount >= 1000 ? `$${(plan.minAmount / 1000).toFixed(plan.minAmount % 1000 === 0 ? 0 : 1)}K` : `$${plan.minAmount}`}
                  </span>
                </div>
                <p className="text-[10px] text-gray-500 mt-1.5">{plan._count.investments} مستثمر</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {activeInvestmentsCount > 0 && (
        <button
          onClick={() => openModalWithPlan()}
          className="w-full btn-premium-gold btn-ripple flex items-center justify-center gap-2"
        >
          <Plus size={18} /> استثمار جديد
        </button>
      )}

      {/* ═══ Investment Modal ═══ */}
      {showModal && (
        <div
          className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => setShowModal(false)}
        >
          <div
            className="glass-card p-6 w-full max-w-md relative z-10 animate-fadeIn max-h-[90vh] overflow-y-auto scrollbar-thin"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#FFD700]/10 flex items-center justify-center">
                  <Plus size={20} className="text-[#FFD700]" />
                </div>
                <h3 className="text-lg font-bold text-white">استثمار جديد</h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-[#1A1F2E] transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Plan Selector */}
            <div className="mb-4">
              <label className="text-gray-400 text-sm mb-2 block font-medium">اختر خطة الاستثمار</label>
              <div className="relative">
                <button
                  onClick={() => setShowPlanDropdown(!showPlanDropdown)}
                  className="w-full input-premium flex items-center justify-between text-right"
                >
                  <div className="flex items-center gap-2">
                    {selectedPlan ? (
                      <>
                        <span>{selectedPlan.icon}</span>
                        <span className="text-white font-medium">{selectedPlan.name}</span>
                        <span className="text-xs text-gray-400">({selectedPlan.dailyRate}% يومياً)</span>
                      </>
                    ) : (
                      <span className="text-gray-500">اختر خطة (اختياري)</span>
                    )}
                  </div>
                  <ChevronDown size={16} className={`text-gray-400 transition-transform ${showPlanDropdown ? 'rotate-180' : ''}`} />
                </button>

                {showPlanDropdown && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-[#151A26] border border-[#2A3040] rounded-xl overflow-hidden z-20 shadow-2xl max-h-72 overflow-y-auto scrollbar-thin">
                    <button
                      onClick={() => { setSelectedPlan(null); setInvForm({ ...invForm, amount: '' }); setShowPlanDropdown(false); }}
                      className={`w-full px-4 py-3 text-right hover:bg-[#1A1F2E] transition-colors flex items-center gap-3 text-sm ${!selectedPlan ? 'bg-[#FFD700]/5 text-[#FFD700]' : 'text-gray-300'}`}
                    >
                      <span className="text-lg">⚡</span>
                      <div className="flex-1">
                        <p className="font-medium">بدون خطة (افتراضي)</p>
                        <p className="text-xs text-gray-500">استخدم النظام الافتراضي</p>
                      </div>
                      {!selectedPlan && <Check size={14} className="text-[#FFD700]" />}
                    </button>
                    {plans.map(plan => (
                      <button
                        key={plan.id}
                        onClick={() => { setSelectedPlan(plan); setInvForm({ ...invForm, amount: String(plan.minAmount) }); setShowPlanDropdown(false); }}
                        className={`w-full px-4 py-3 text-right hover:bg-[#1A1F2E] transition-colors flex items-center gap-3 text-sm ${selectedPlan?.id === plan.id ? 'bg-[#FFD700]/5' : ''}`}
                      >
                        <span className="text-lg">{plan.icon}</span>
                        <div className="flex-1">
                          <p className="font-medium" style={{ color: selectedPlan?.id === plan.id ? plan.color : '#fff' }}>{plan.name}</p>
                          <p className="text-xs text-gray-500">
                            {plan.duration} يوم • {plan.dailyRate}% يومياً • من ${plan.minAmount.toLocaleString()}
                            {plan.maxAmount > 0 && ` - $${plan.maxAmount.toLocaleString()}`}
                          </p>
                        </div>
                        {selectedPlan?.id === plan.id && <Check size={14} style={{ color: plan.color }} />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Selected Plan Info */}
            {selectedPlan && (
              <div className="mb-4 p-3 rounded-xl border border-[#2A3040] bg-[#12161F] space-y-2 animate-fadeIn">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xl">{selectedPlan.icon}</span>
                  <span className="font-bold text-sm" style={{ color: selectedPlan.color }}>{selectedPlan.name}</span>
                </div>
                <p className="text-xs text-gray-400">{selectedPlan.description}</p>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <div className="bg-[#1A1F2E] rounded-lg p-2 text-center">
                    <p className="text-[10px] text-gray-500">الحد الأدنى</p>
                    <p className="text-sm font-bold text-white">${selectedPlan.minAmount.toLocaleString()}</p>
                  </div>
                  <div className="bg-[#1A1F2E] rounded-lg p-2 text-center">
                    <p className="text-[10px] text-gray-500">الحد الأقصى</p>
                    <p className="text-sm font-bold text-white">{selectedPlan.maxAmount > 0 ? `$${selectedPlan.maxAmount.toLocaleString()}` : '∞'}</p>
                  </div>
                  <div className="bg-[#1A1F2E] rounded-lg p-2 text-center">
                    <p className="text-[10px] text-gray-500">النسبة اليومية</p>
                    <p className="text-sm font-bold" style={{ color: selectedPlan.color }}>{selectedPlan.dailyRate}%</p>
                  </div>
                  <div className="bg-[#1A1F2E] rounded-lg p-2 text-center">
                    <p className="text-[10px] text-gray-500">المدة</p>
                    <p className="text-sm font-bold text-white">{selectedPlan.duration} يوم</p>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="text-gray-400 text-sm mb-2 block font-medium">المبلغ ($)</label>
                <input
                  type="number"
                  min={selectedPlan ? selectedPlan.minAmount : 100}
                  max={selectedPlan && selectedPlan.maxAmount > 0 ? selectedPlan.maxAmount : undefined}
                  placeholder={selectedPlan ? `الحد الأدنى: $${selectedPlan.minAmount.toLocaleString()}` : '100'}
                  value={invForm.amount}
                  onChange={e => setInvForm({ ...invForm, amount: e.target.value })}
                  className="input-premium"
                  dir="ltr"
                />
                {selectedPlan && (
                  <div className="flex justify-between mt-1.5">
                    <span className="text-[10px] text-gray-500">الحد الأدنى: ${selectedPlan.minAmount.toLocaleString()}</span>
                    {selectedPlan.maxAmount > 0 && <span className="text-[10px] text-gray-500">الحد الأقصى: ${selectedPlan.maxAmount.toLocaleString()}</span>}
                  </div>
                )}
              </div>

              {/* Profit Calculator */}
              {(selectedPlan || invForm.amount) && parseFloat(invForm.amount) > 0 && (
                <div className="p-3 rounded-xl bg-gradient-to-l from-[#FFD700]/5 to-[#2ECC71]/5 border border-[#2A3040] animate-fadeIn">
                  <p className="text-xs text-gray-300 leading-relaxed">
                    إذا استثمرت{' '}
                    <span className="font-bold text-white">${parseFloat(invForm.amount || '0').toLocaleString()}</span>
                    {' '}لمدة{' '}
                    <span className="font-bold text-white">{selectedPlan ? selectedPlan.duration : 30} يوم</span>
                    {' ،ربحك المتوقع: '}
                    <span className="font-bold text-[#2ECC71] number-glow">
                      ${((parseFloat(invForm.amount || '0') * ((selectedPlan?.dailyRate || 1.2) / 100)) * (selectedPlan?.duration || 30)).toFixed(2)}
                    </span>
                  </p>
                  <p className="text-[10px] text-gray-500 mt-1">
                    ({selectedPlan ? selectedPlan.dailyRate : 1.2}% يومياً × {selectedPlan ? selectedPlan.duration : 30} يوم)
                  </p>
                </div>
              )}

              <div>
                <label className="text-gray-400 text-sm mb-2 block font-medium">كود الكوبون (اختياري)</label>
                <input
                  placeholder="أدخل كود الخصم"
                  value={invForm.coupon}
                  onChange={e => setInvForm({ ...invForm, coupon: e.target.value })}
                  className="input-premium"
                  dir="ltr"
                />
              </div>

              <button
                onClick={createInvestment}
                disabled={submitting}
                className="btn-premium-emerald btn-ripple w-full flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submitting ? (
                  <Loader2 size={18} className="animate-spin" />
                ) : (
                  <Check size={18} />
                )}
                {submitting ? 'جارٍ المعالجة...' : 'تأكيد الاستثمار'}
              </button>
              <button
                onClick={() => setShowModal(false)}
                className="w-full text-gray-400 hover:text-white text-sm py-2 transition-colors"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
