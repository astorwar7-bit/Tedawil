'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Trophy, Medal, Crown, Users, TrendingUp, Star } from 'lucide-react';

interface LeaderEntry {
  userId: string;
  username: string;
  fullName: string;
  avatar: string;
  totalProfit: number;
  totalInvested: number;
  winRate: number;
  level: string;
  rank: number;
}

export default function LeaderboardPage() {
  const { user } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderEntry[]>([]);
  const [totalParticipants, setTotalParticipants] = useState(0);
  const [period, setPeriod] = useState('all-time');
  const [loading, setLoading] = useState(true);

  const fetchLeaderboard = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/leaderboard?period=${period}`);
      const data = await res.json();
      setLeaderboard(data.leaderboard || []);
      setTotalParticipants(data.totalParticipants || 0);
    } catch (err) { console.error('Leaderboard fetch error:', err); }
    setLoading(false);
  };

  useEffect(() => { fetchLeaderboard(); }, [period]);

  const periods = [
    { id: 'daily', label: 'يومي' },
    { id: 'weekly', label: 'أسبوعي' },
    { id: 'monthly', label: 'شهري' },
    { id: 'all-time', label: 'الكل' },
  ];

  const top3 = leaderboard.slice(0, 3);
  const rest = leaderboard.slice(3);

  const podiumOrder = [1, 0, 2];
  const podiumColors = ['text-yellow-400', 'text-gray-300', 'text-orange-400'];
  const podiumBg = ['bg-yellow-500/10 border-yellow-500/20', 'bg-gray-300/10 border-gray-300/20', 'bg-orange-500/10 border-orange-500/20'];
  const podiumGlow = ['neon-gold border-yellow-500/30', 'border-gray-400/20', 'neon-emerald border-orange-500/20'];

  const levelColor = (level: string) => {
    if (level === 'ماسي') return 'text-purple-400';
    if (level === 'ذهبي') return 'text-[#FFD700]';
    if (level === 'فضي') return 'text-gray-300';
    if (level === 'برونزي') return 'text-orange-400';
    return 'text-gray-400';
  };

  return (
    <div className="space-y-5 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Trophy size={24} className="text-[#FFD700]" />
          لوحة المتصدرين
        </h1>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <Users size={14} />
          <span>{totalParticipants} متداول</span>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        {periods.map(p => (
          <button key={p.id} onClick={() => setPeriod(p.id)}
            className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
              period === p.id ? 'bg-[#FFD700] text-[#0A0F0D] font-bold neon-gold' : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-[#FFD700]'
            }`}>
            {p.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            {[0, 1, 2].map(i => <div key={i} className="skeleton-premium h-48 rounded-2xl"></div>)}
          </div>
          {[0, 1, 2, 3, 4].map(i => <div key={i} className="skeleton-line" />)}
        </div>
      ) : leaderboard.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[#1A1F2E] border border-[#2A3040] flex items-center justify-center">
            <Trophy size={32} className="text-gray-600" />
          </div>
          <p className="text-gray-400 text-lg font-medium mb-2">لا توجد بيانات حالياً</p>
          <p className="text-gray-500 text-sm">سيتم عرض المتصدرين عند توفر بيانات كافية</p>
        </div>
      ) : (
        <>
          {/* Top 3 Podium */}
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            {podiumOrder.map((idx) => {
              const entry = top3[idx];
              if (!entry) return <div key={idx} />;
              const isMe = entry.userId === user?.id;
              return (
                <div key={entry.userId} className={`rounded-2xl p-3 sm:p-4 text-center border ${podiumBg[idx]} ${podiumGlow[idx]} transition-all ${isMe ? 'featured-border' : ''}`}>
                  <div className={`text-3xl sm:text-4xl mb-1 ${podiumColors[idx]}`}>
                    {idx === 0 ? '🥇' : idx === 1 ? '🥈' : '🥉'}
                  </div>
                  <div className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full mx-auto mb-2 flex items-center justify-center text-lg font-bold ${
                    entry.avatar ? 'overflow-hidden' : 'bg-[#2A3040]'
                  }`}>
                    {entry.avatar ? <img src={entry.avatar} alt="" className="w-full h-full object-cover" /> : entry.username[0]?.toUpperCase()}
                  </div>
                  <p className={`font-bold text-xs sm:text-sm ${isMe ? 'text-[#FFD700]' : 'text-white'} truncate`}>
                    {entry.fullName || entry.username}
                  </p>
                  <p className="text-gray-400 text-[10px] mb-2">@{entry.username}</p>
                  <p className={`font-bold text-sm sm:text-base ${podiumColors[idx]}`}>${entry.totalProfit.toLocaleString()}</p>
                  <p className="text-gray-500 text-[10px]">الربح</p>
                  <div className="flex items-center justify-center gap-2 mt-2">
                    <span className="text-[10px] text-gray-400">فوز {entry.winRate}%</span>
                    <span className={`text-[10px] font-medium ${levelColor(entry.level)}`}>{entry.level}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Rest of leaderboard */}
          <div className="glass-card overflow-hidden">
            <div className="divide-y divide-[#2A3040]/50">
              {rest.map(entry => {
                const isMe = entry.userId === user?.id;
                return (
                  <div key={entry.userId} className={`flex items-center gap-3 p-3 transition-colors hover:bg-[#2A3040]/30 ${isMe ? 'bg-[#FFD700]/5' : ''}`}>
                    <div className={`w-8 text-center font-bold text-sm ${entry.rank <= 10 ? 'text-[#FFD700]' : 'text-gray-500'}`}>#{entry.rank}</div>
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold ${entry.avatar ? 'overflow-hidden' : 'bg-[#2A3040]'}`}>
                      {entry.avatar ? <img src={entry.avatar} alt="" className="w-full h-full object-cover" /> : entry.username[0]?.toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium truncate ${isMe ? 'text-[#FFD700]' : 'text-white'}`}>
                        {entry.fullName || entry.username} {isMe && <span className="text-[10px] text-[#2ECC71]">(أنت)</span>}
                      </p>
                      <p className="text-gray-500 text-[10px]">@{entry.username} · {entry.level}</p>
                    </div>
                    <div className="text-left">
                      <p className="text-[#2ECC71] font-bold text-sm">${entry.totalProfit.toLocaleString()}</p>
                      <p className="text-gray-500 text-[10px]">فوز {entry.winRate}%</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
