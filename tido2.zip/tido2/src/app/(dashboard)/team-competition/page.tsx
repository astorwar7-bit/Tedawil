'use client';
import { useEffect, useState } from 'react';
import { useToast } from '@/contexts/ToastContext';
import { useAuth } from '@/contexts/AuthContext';
import { Users, Plus, LogIn, Copy, Check, Crown, LogOut, Trash2, X, Trophy } from 'lucide-react';

interface TeamMember {
  id: string;
  userId: string;
  joinedAt: string;
  user: { id: string; username: string; fullName: string; avatar: string };
}

interface Team {
  id: string;
  name: string;
  code: string;
  creatorId: string;
  memberCount: number;
  members: TeamMember[];
  isFull: boolean;
  isMyTeam: boolean;
}

export default function TeamCompetitionPage() {
  const { showToast } = useToast();
  const { user } = useAuth();
  const [myTeam, setMyTeam] = useState<Team | null>(null);
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showJoin, setShowJoin] = useState(false);
  const [teamName, setTeamName] = useState('');
  const [teamCode, setTeamCode] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/team-competition');
      const data = await res.json();
      setMyTeam(data.myTeam || null);
      setTeams((data.teams || []).filter((t: Team) => !t.isMyTeam));
    } catch { showToast('حدث خطأ', 'error'); }
    setLoading(false);
  };

  useEffect(() => { fetchData(); }, []);

  const handleCreate = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('/api/team-competition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create', teamName }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      setShowCreate(false);
      setTeamName('');
      fetchData();
    } catch { showToast('حدث خطأ', 'error'); }
    setSubmitting(false);
  };

  const handleJoin = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('/api/team-competition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'join', teamCode }),
      });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      setShowJoin(false);
      setTeamCode('');
      fetchData();
    } catch { showToast('حدث خطأ', 'error'); }
    setSubmitting(false);
  };

  const handleLeave = async () => {
    try {
      const res = await fetch('/api/team-competition?action=leave', { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      fetchData();
    } catch { showToast('حدث خطأ', 'error'); }
  };

  const handleDissolve = async () => {
    try {
      const res = await fetch('/api/team-competition?action=dissolve', { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok) { showToast(data.error, 'error'); return; }
      showToast(data.message);
      fetchData();
    } catch { showToast('حدث خطأ', 'error'); }
  };

  const copyCode = () => {
    if (myTeam?.code) {
      navigator.clipboard.writeText(myTeam.code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const isCreator = myTeam?.creatorId === user?.id;

  return (
    <div className="space-y-5 animate-fadeIn">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Trophy size={24} className="text-[#FFD700]" />
          منافسة الفرق
        </h1>
        {!myTeam && (
          <div className="flex gap-2">
            <button onClick={() => setShowCreate(true)} className="btn-premium-gold !w-auto px-4 text-xs flex items-center gap-1">
              <Plus size={14} /> إنشاء فريق
            </button>
            <button onClick={() => setShowJoin(true)} className="btn-premium-emerald !w-auto px-4 text-xs flex items-center gap-1">
              <LogIn size={14} /> انضمام
            </button>
          </div>
        )}
      </div>

      {/* My Team */}
      {myTeam && (
        <div className="glass-card p-5 featured-border">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#FFD700]/20 flex items-center justify-center">
                <Crown size={24} className="text-[#FFD700]" />
              </div>
              <div>
                <p className="text-white font-bold text-lg">{myTeam.name}</p>
                <p className="text-gray-400 text-xs">
                  {isCreator && <span className="text-[#FFD700]">قائد الفريق</span>}
                  {!isCreator && <span>عضو</span>}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              {isCreator && (
                <button onClick={handleDissolve} className="px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs hover:bg-red-500/20 transition-colors">
                  <Trash2 size={14} />
                </button>
              )}
              {!isCreator && (
                <button onClick={handleLeave} className="px-3 py-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs hover:bg-red-500/20 transition-colors">
                  <LogOut size={14} />
                </button>
              )}
            </div>
          </div>

          <div className="bg-[#12161F] rounded-xl p-3 flex items-center justify-between mb-4">
            <div>
              <p className="text-gray-400 text-xs">كود الفريق</p>
              <p className="text-[#FFD700] font-bold text-lg tracking-widest" dir="ltr">{myTeam.code}</p>
            </div>
            <div className="flex items-center gap-3 text-center">
              <div>
                <p className="text-white font-bold">{myTeam.memberCount}</p>
                <p className="text-gray-500 text-[10px]">الأعضاء</p>
              </div>
              <button onClick={copyCode} className="p-2 rounded-lg bg-[#2A3040] hover:bg-[#3A4050] transition-colors">
                {copiedCode ? <Check size={14} className="text-[#2ECC71]" /> : <Copy size={14} className="text-gray-400" />}
              </button>
            </div>
          </div>

          <div>
            <p className="text-gray-400 text-xs mb-2">الأعضاء ({myTeam.memberCount}/10)</p>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {myTeam.members.map((m: TeamMember) => (
                <div key={m.id} className="flex items-center gap-2 bg-[#12161F] rounded-lg p-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${m.user.avatar ? 'overflow-hidden' : 'bg-[#2A3040]'}`}>
                    {m.user.avatar ? <img src={m.user.avatar} alt="" className="w-full h-full object-cover" /> : m.user.username[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-xs font-medium truncate">{m.user.fullName || m.user.username}</p>
                    <p className="text-gray-500 text-[10px]">@{m.user.username}</p>
                  </div>
                  {m.userId === myTeam.creatorId && <Crown size={12} className="text-[#FFD700]" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Public Teams */}
      {!myTeam && (
        <div>
          <h3 className="text-white font-bold mb-3">الفرق المتاحة</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="glass-card p-4">
                  <div className="skeleton-premium h-5 w-32 mb-3"></div>
                  <div className="skeleton-premium h-10 mb-2"></div>
                  <div className="skeleton-premium h-8"></div>
                </div>
              ))
            ) : teams.length === 0 ? (
              <div className="col-span-2 text-center py-12">
                <Users size={40} className="text-gray-600 mx-auto mb-3" />
                <p className="text-gray-500">لا توجد فرق متاحة حالياً. أنشئ فريقك!</p>
              </div>
            ) : (
              teams.map(team => (
                <div key={team.id} className="glass-card p-4 card-lift">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-[#FFD700]/20 flex items-center justify-center">
                      <Users size={20} className="text-[#FFD700]" />
                    </div>
                    <div>
                      <p className="text-white font-bold text-sm">{team.name}</p>
                      <p className="text-gray-400 text-[10px]">{team.memberCount}/10 أعضاء</p>
                    </div>
                  </div>

                  <div className="bg-[#12161F] rounded-lg p-2 mb-3 flex items-center justify-between">
                    <span className="text-gray-400 text-xs">كود:</span>
                    <code className="text-[#FFD700] font-bold text-sm tracking-wider" dir="ltr">{team.code}</code>
                  </div>

                  <button
                    onClick={() => { setTeamCode(team.code); setShowJoin(true); }}
                    disabled={team.isFull}
                    className={`w-full py-2 rounded-xl text-xs font-bold transition-all ${
                      team.isFull
                        ? 'bg-gray-500/10 text-gray-500 cursor-not-allowed'
                        : 'btn-premium-emerald'
                    }`}>
                    {team.isFull ? 'الفريق ممتلئ' : 'انضمام'}
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Create Team Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setShowCreate(false)}>
          <div className="glass-card p-5 w-full max-w-sm neon-gold" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">إنشاء فريق جديد</h3>
              <button onClick={() => setShowCreate(false)} className="text-gray-400 hover:text-white"><X size={18} /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-gray-400 text-xs block mb-1">اسم الفريق</label>
                <input value={teamName} onChange={e => setTeamName(e.target.value)} placeholder="أدخل اسم الفريق" className="input-premium" minLength={3} />
              </div>
              <p className="text-gray-500 text-xs">سيتم إنشاء كود فريد تلقائياً</p>
              <button onClick={handleCreate} disabled={submitting || teamName.length < 3} className="btn-premium-gold disabled:opacity-50">
                {submitting ? 'جاري الإنشاء...' : 'إنشاء الفريق'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Join Team Modal */}
      {showJoin && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setShowJoin(false)}>
          <div className="glass-card p-5 w-full max-w-sm neon-emerald" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">الانضمام لفريق</h3>
              <button onClick={() => setShowJoin(false)} className="text-gray-400 hover:text-white"><X size={18} /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-gray-400 text-xs block mb-1">كود الفريق</label>
                <input value={teamCode} onChange={e => setTeamCode(e.target.value.toUpperCase())} placeholder="XXXXXX" className="input-premium text-center tracking-widest text-lg" maxLength={6} dir="ltr" />
              </div>
              <button onClick={handleJoin} disabled={submitting || teamCode.length < 6} className="btn-premium-emerald disabled:opacity-50">
                {submitting ? 'جاري الانضمام...' : 'انضمام'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
