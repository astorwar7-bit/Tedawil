import DashLayout from '@/components/DashLayout';

export default function Layout({ children }: { children: React.ReactNode }) {
  return <DashLayout>{children}</DashLayout>;
}
