'use client';
import { useEffect, useState, useRef } from 'react';
import { useToast } from '@/contexts/ToastContext';
import {
  Activity, ArrowDownCircle, ArrowUpCircle, TrendingUp, Users,
  Gift, Wallet, XCircle, CheckCircle, Clock, Filter,
  ChevronLeft, ChevronRight, DollarSign,
  ArrowRightLeft, Sparkles
} from 'lucide-react';

interface ActivityItem {
  id: string;
  action: string;
  details: string;
  amount: number;
  createdAt: string;
}

interface SummaryStats {
  totalIn: number;
  totalOut: number;
  netBalance: number;
}

// Filter group definitions
interface FilterGroup {
  key: string;
  label: string;
  actions: string[];
  icon: typeof Activity;
  color: string;
}

const FILTER_GROUPS: FilterGroup[] = [
  { key: '', label: 'الكل', actions: [], icon: Filter, color: 'text-[#2ECC71]' },
  { key: 'deposits', label: 'الإيداعات', actions: ['deposit_request', 'DEPOSIT_APPROVED'], icon: ArrowDownCircle, color: 'text-[#2ECC71]' },
  { key: 'investments', label: 'الاستثمارات', actions: ['INVESTMENT_CREATE'], icon: TrendingUp, color: 'text-[#FFD700]' },
  { key: 'profits', label: 'الأرباح', actions: ['DAILY_PROFIT', 'REFERRAL_PROFIT'], icon: DollarSign, color: 'text-[#2ECC71]' },
  { key: 'withdrawals', label: 'السحوبات', actions: ['WITHDRAWAL_REQUEST', 'WITHDRAWAL_APPROVED', 'WITHDRAWAL_REJECTED'], icon: ArrowUpCircle, color: 'text-red-400' },
  { key: 'bonuses', label: 'المكافآت', actions: ['REFERRAL_BONUS', 'WELCOME_BONUS'], icon: Gift, color: 'text-purple-400' },
];

// Action type detailed config
interface ActionConfig {
  label: string;
  icon: typeof Activity;
  color: string;
  bgColor: string;
  borderColor: string;
  badgeColor: string;
}

const ACTION_CONFIG: Record<string, ActionConfig> = {
  deposit_request: {
    label: 'إيداع',
    icon: ArrowDownCircle,
    color: 'text-[#2ECC71]',
    bgColor: 'bg-[#2ECC71]/10',
    borderColor: 'border-[#2ECC71]/20',
    badgeColor: 'bg-[#2ECC71]/10 text-[#2ECC71] border-[#2ECC71]/20',
  },
  DEPOSIT_APPROVED: {
    label: 'إيداع مقبول',
    icon: CheckCircle,
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/10',
    borderColor: 'border-emerald-500/20',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  },
  INVESTMENT_CREATE: {
    label: 'استثمار جديد',
    icon: TrendingUp,
    color: 'text-[#FFD700]',
    bgColor: 'bg-[#FFD700]/10',
    borderColor: 'border-[#FFD700]/20',
    badgeColor: 'bg-[#FFD700]/10 text-[#FFD700] border-[#FFD700]/20',
  },
  DEPOSIT_REJECTED: {
    label: 'إيداع مرفوض',
    icon: XCircle,
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/20',
    badgeColor: 'bg-red-500/10 text-red-400 border-red-500/20',
  },
  WITHDRAWAL_REQUEST: {
    label: 'طلب سحب',
    icon: Clock,
    color: 'text-yellow-400',
    bgColor: 'bg-yellow-500/10',
    borderColor: 'border-yellow-500/20',
    badgeColor: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  },
  WITHDRAWAL_APPROVED: {
    label: 'سحب مكتمل',
    icon: CheckCircle,
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/20',
    badgeColor: 'bg-red-500/10 text-red-400 border-red-500/20',
  },
  WITHDRAWAL_REJECTED: {
    label: 'سحب مرفوض',
    icon: XCircle,
    color: 'text-red-400',
    bgColor: 'bg-red-500/10',
    borderColor: 'border-red-500/20',
    badgeColor: 'bg-red-500/10 text-red-400 border-red-500/20',
  },
  DAILY_PROFIT: {
    label: 'ربح يومي',
    icon: DollarSign,
    color: 'text-[#2ECC71]',
    bgColor: 'bg-[#2ECC71]/10',
    borderColor: 'border-[#2ECC71]/20',
    badgeColor: 'bg-[#2ECC71]/10 text-[#2ECC71] border-[#2ECC71]/20',
  },
  REFERRAL_PROFIT: {
    label: 'عمولة إحالة',
    icon: Users,
    color: 'text-[#FFD700]',
    bgColor: 'bg-[#FFD700]/10',
    borderColor: 'border-[#FFD700]/20',
    badgeColor: 'bg-[#FFD700]/10 text-[#FFD700] border-[#FFD700]/20',
  },
  REFERRAL_BONUS: {
    label: 'مكافأة إحالة',
    icon: Gift,
    color: 'text-purple-400',
    bgColor: 'bg-purple-500/10',
    borderColor: 'border-purple-500/20',
    badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  },
  WELCOME_BONUS: {
    label: 'مكافأة ترحيب',
    icon: Sparkles,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10',
    borderColor: 'border-blue-500/20',
    badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  },
};

const DEFAULT_CONFIG: ActionConfig = {
  label: 'نشاط',
  icon: Activity,
  color: 'text-gray-400',
  bgColor: 'bg-gray-500/10',
  borderColor: 'border-gray-500/20',
  badgeColor: 'bg-gray-500/10 text-gray-400 border-gray-500/20',
};

// Animated count-up hook
function useCountUp(target: number, duration: number = 1200, enabled: boolean = true) {
  const [value, setValue] = useState(0);
  const startRef = useRef<number | null>(null);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    if (!enabled) { setValue(0); return; }
    startRef.current = null;

    let active = true;

    const step = (timestamp: number) => {
      if (!active) return;
      if (!startRef.current) startRef.current = timestamp;
      const elapsed = timestamp - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(eased * target);
      if (progress < 1) {
        frameRef.current = requestAnimationFrame(step);
      }
    };

    frameRef.current = requestAnimationFrame(step);
    return () => {
      active = false;
      cancelAnimationFrame(frameRef.current);
    };
  }, [target, duration, enabled]);

  return value;
}

function formatRelativeTime(dateStr: string): string {
  const date = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  const diffWeeks = Math.floor(diffDays / 7);
  const diffMonths = Math.floor(diffDays / 30);

  if (diffSecs < 60) return 'الآن';
  if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
  if (diffHours < 24) return `منذ ${diffHours} ساعة`;
  if (diffDays < 7) return `منذ ${diffDays} يوم`;
  if (diffWeeks < 4) return `منذ ${diffWeeks} أسبوع`;
  if (diffMonths < 12) return `منذ ${diffMonths} شهر`;
  return date.toLocaleDateString('ar', { year: 'numeric', month: 'short', day: 'numeric' });
}

function TransactionCardSkeleton() {
  return (
    <div className="glass-card p-4">
      <div className="flex items-center gap-3">
        <div className="skeleton-premium w-10 h-10 rounded-xl shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="skeleton-premium h-4 w-48 mb-2" />
          <div className="skeleton-premium h-3 w-32" />
        </div>
        <div className="text-left shrink-0">
          <div className="skeleton-premium h-5 w-16 mb-1" />
          <div className="skeleton-premium h-3 w-12" />
        </div>
      </div>
    </div>
  );
}

export default function ActivityLogPage() {
  const { showToast } = useToast();
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [filter, setFilter] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<SummaryStats>({ totalIn: 0, totalOut: 0, netBalance: 0 });
  const limit = 20;

  const animatedIn = useCountUp(summary.totalIn, 1400, !loading);
  const animatedOut = useCountUp(summary.totalOut, 1200, !loading);
  const animatedNet = useCountUp(summary.netBalance, 1600, !loading);

  // Determine which API actions to query based on filter
  const getApiActions = (): string[] => {
    if (!filter) return [];
    const group = FILTER_GROUPS.find((g) => g.key === filter);
    return group ? group.actions : [];
  };

  const fetchActivities = async () => {
    setLoading(true);
    try {
      // Fetch paginated activities (use first action of group for API filter)
      const actions = getApiActions();
      const actionParam = actions.length > 0 ? actions[0] : '';
      const params = new URLSearchParams({
        page: String(page),
        limit: String(limit),
      });
      if (actionParam) params.set('action', actionParam);

      const res = await fetch(`/api/activity-log?${params}`);
      const data = await res.json();
      let activityList = data.activities || [];

      // If group has multiple actions, fetch all of them and merge
      if (actions.length > 1) {
        const allPromises = actions.map(async (action) => {
          const p = new URLSearchParams({ page: '1', limit: String(page * limit) });
          p.set('action', action);
          const r = await fetch(`/api/activity-log?${p}`);
          const d = await r.json();
          return d.activities || [];
        });
        const allResults = await Promise.all(allPromises);
        activityList = allResults.flat();
        // Sort by date desc and paginate client-side
        activityList.sort((a: ActivityItem, b: ActivityItem) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        activityList = activityList.slice((page - 1) * limit, page * limit);

        // Set total as max of all groups
        let totalCount = 0;
        for (const action of actions) {
          const p = new URLSearchParams({ page: '1', limit: '1' });
          p.set('action', action);
          const r = await fetch(`/api/activity-log?${p}`);
          const d = await r.json();
          totalCount = Math.max(totalCount, d.total || 0);
        }
        setTotal(totalCount);
      } else {
        setTotal(data.total || 0);
      }

      setActivities(activityList);

      // Fetch all activities for summary (only on first load or filter change)
      if (page === 1) {
        await fetchSummary(actions);
      }
    } catch {
      showToast('حدث خطأ أثناء التحميل', 'error');
    }
    setLoading(false);
  };

  const fetchSummary = async (actions: string[]) => {
    try {
      // Fetch all activities to calculate summary
      const params = new URLSearchParams({ page: '1', limit: '9999' });
      const res = await fetch(`/api/activity-log?${params}`);
      const data = await res.json();
      const allActivities: ActivityItem[] = data.activities || [];

      let filtered = allActivities;
      if (actions.length > 0) {
        filtered = allActivities.filter((a: ActivityItem) => actions.includes(a.action));
      }

      let totalIn = 0;
      let totalOut = 0;

      for (const item of filtered) {
        if (item.amount > 0) {
          totalIn += item.amount;
        } else if (item.amount < 0) {
          totalOut += Math.abs(item.amount);
        }
      }

      setSummary({ totalIn, totalOut, netBalance: totalIn - totalOut });
    } catch {
      // Silent fail for summary
    }
  };

  useEffect(() => {
    fetchActivities();
  }, [page, filter]);

  const getAmountColor = (amount: number): string => {
    if (amount > 0) return 'text-[#2ECC71]';
    if (amount < 0) return 'text-red-400';
    return 'text-gray-400';
  };

  const getAmountPrefix = (amount: number): string => {
    if (amount > 0) return '+';
    if (amount < 0) return '-';
    return '';
  };

  const getActionConfig = (action: string): ActionConfig => {
    return ACTION_CONFIG[action] || DEFAULT_CONFIG;
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-5 animate-fadeIn pb-20 lg:pb-6">
      {/* Page Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-[#2ECC71]/10 via-[#1A1F2E] to-[#FFD700]/10 border border-[#2A3040] p-5">
        <div className="absolute top-0 left-0 w-32 h-32 bg-[#2ECC71]/5 rounded-full -translate-x-1/2 -translate-y-1/2 animate-glow-pulse" />
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-[#FFD700]/5 rounded-full translate-x-1/2 translate-y-1/2 animate-glow-pulse" />
        <div className="relative flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#2ECC71]/10 border border-[#2ECC71]/20 flex items-center justify-center icon-pulse-emerald">
            <ArrowRightLeft size={24} className="text-[#2ECC71]" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white">سجل المعاملات المالية</h1>
            <p className="text-gray-400 text-xs mt-0.5">كل حركة مالية في حسابك مسجلة هنا</p>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3 stagger-children">
        {loading ? (
          <>
            <div className="glass-card p-4 text-center">
              <div className="skeleton-premium w-10 h-10 rounded-xl mx-auto mb-2" />
              <div className="skeleton-premium h-5 w-16 mx-auto mb-1" />
              <div className="skeleton-premium h-3 w-14 mx-auto" />
            </div>
            <div className="glass-card p-4 text-center">
              <div className="skeleton-premium w-10 h-10 rounded-xl mx-auto mb-2" />
              <div className="skeleton-premium h-5 w-16 mx-auto mb-1" />
              <div className="skeleton-premium h-3 w-14 mx-auto" />
            </div>
            <div className="glass-card p-4 text-center">
              <div className="skeleton-premium w-10 h-10 rounded-xl mx-auto mb-2" />
              <div className="skeleton-premium h-5 w-16 mx-auto mb-1" />
              <div className="skeleton-premium h-3 w-14 mx-auto" />
            </div>
          </>
        ) : (
          <>
            {/* Total In */}
            <div className="glass-card p-4 text-center premium-shimmer">
              <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-[#2ECC71]/10 border border-[#2ECC71]/20 flex items-center justify-center icon-pulse-emerald">
                <ArrowDownCircle size={18} className="text-[#2ECC71]" />
              </div>
              <p className="text-base sm:text-lg font-bold text-[#2ECC71] number-glow tabular-nums">
                ${animatedIn.toFixed(2)}
              </p>
              <p className="text-gray-400 text-[10px] mt-1">إجمالي الوارد</p>
            </div>
            {/* Total Out */}
            <div className="glass-card p-4 text-center premium-shimmer">
              <div className="w-10 h-10 mx-auto mb-2 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                <ArrowUpCircle size={18} className="text-red-400" />
              </div>
              <p className="text-base sm:text-lg font-bold text-red-400 number-glow tabular-nums">
                ${animatedOut.toFixed(2)}
              </p>
              <p className="text-gray-400 text-[10px] mt-1">إجمالي الصادر</p>
            </div>
            {/* Net Balance */}
            <div className="glass-card p-4 text-center premium-shimmer">
              <div className={`w-10 h-10 mx-auto mb-2 rounded-xl flex items-center justify-center icon-pulse-gold ${
                summary.netBalance >= 0
                  ? 'bg-[#FFD700]/10 border border-[#FFD700]/20'
                  : 'bg-red-500/10 border border-red-500/20'
              }`}>
                <Wallet
                  size={18}
                  className={summary.netBalance >= 0 ? 'text-[#FFD700]' : 'text-red-400'}
                />
              </div>
              <p className={`text-base sm:text-lg font-bold number-glow tabular-nums ${
                summary.netBalance >= 0 ? 'text-[#FFD700]' : 'text-red-400'
              }`}>
                {animatedNet >= 0 ? '' : '-'}${Math.abs(animatedNet).toFixed(2)}
              </p>
              <p className="text-gray-400 text-[10px] mt-1">صافي الرصيد</p>
            </div>
          </>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        {FILTER_GROUPS.map((group) => {
          const Icon = group.icon;
          const isActive = filter === group.key;
          return (
            <button
              key={group.key}
              onClick={() => { setFilter(group.key); setPage(1); }}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all duration-300 ${
                isActive
                  ? 'bg-[#2ECC71] text-white shadow-lg shadow-[#2ECC71]/20'
                  : 'bg-[#1A1F2E] text-gray-400 border border-[#2A3040] hover:border-[#2ECC71]/50 hover:text-gray-300'
              }`}
            >
              <Icon size={12} />
              {group.label}
            </button>
          );
        })}
      </div>

      {/* Transaction List */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <TransactionCardSkeleton key={i} />
          ))}
        </div>
      ) : activities.length === 0 ? (
        <div className="glass-card p-8 sm:p-12 text-center">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[#12161F] border border-[#2A3040] flex items-center justify-center">
            <Activity size={36} className="text-gray-600" />
          </div>
          <p className="text-gray-300 font-bold text-lg mb-2">لا توجد معاملات</p>
          <p className="text-gray-500 text-sm max-w-xs mx-auto">
            {filter
              ? `لا توجد معاملات من نوع "${FILTER_GROUPS.find(g => g.key === filter)?.label || filter}" بعد.`
              : 'لم تسجل أي معاملات مالية بعد. ابدأ بإيداع أو استثمار لتظهر هنا.'}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {activities.map((item, idx) => {
            const config = getActionConfig(item.action);
            const Icon = config.icon;
            const amountColor = getAmountColor(item.amount);
            const amountPrefix = getAmountPrefix(item.amount);

            return (
              <div
                key={item.id}
                className="glass-card p-4 animate-fadeInUp card-lift"
                style={{ animationDelay: `${idx * 0.03}s` }}
              >
                <div className="flex items-center gap-3">
                  {/* Action Type Icon */}
                  <div className={`w-10 h-10 rounded-xl ${config.bgColor} border ${config.borderColor} flex items-center justify-center shrink-0`}>
                    <Icon size={18} className={config.color} />
                  </div>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-white text-sm font-medium truncate">{item.details}</p>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span className="text-gray-500 text-[10px]">
                        {formatRelativeTime(item.createdAt)}
                      </span>
                      <span className="text-gray-600 text-[10px]">•</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${config.badgeColor}`}>
                        {config.label}
                      </span>
                    </div>
                  </div>

                  {/* Amount */}
                  <div className="text-left shrink-0">
                    <p className={`font-bold text-sm tabular-nums ${amountColor}`}>
                      {amountPrefix}${Math.abs(item.amount).toFixed(2)}
                    </p>
                    <p className="text-gray-500 text-[10px] tabular-nums">
                      {new Date(item.createdAt).toLocaleDateString('ar', {
                        month: 'short', day: 'numeric',
                      })}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {!loading && total > limit && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="flex items-center gap-1 px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-40 transition-colors hover:border-[#2ECC71]/50"
          >
            <ChevronRight size={14} />
            السابق
          </button>
          <span className="px-4 py-2 text-gray-400 text-xs tabular-nums">
            صفحة {page} من {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={page >= totalPages}
            className="flex items-center gap-1 px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-xs text-gray-300 disabled:opacity-40 transition-colors hover:border-[#2ECC71]/50"
          >
            التالي
            <ChevronLeft size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
