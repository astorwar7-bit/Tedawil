'use client';
import { useEffect, useState } from 'react';
import { CheckCheck, Bell } from 'lucide-react';

interface Notif { id: string; title: string; message: string; type: string; isRead: boolean; createdAt: string; }

export default function NotificationsPage() {
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchNotifs = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/notifications?page=${page}&limit=20`);
      const data = await res.json();
      setNotifs(data.notifications || []);
      setTotal(data.total || 0);
    } catch (err) { console.error('Notifications fetch error:', err); }
    setLoading(false);
  };

  useEffect(() => {
    const init = async () => {
      // Mark all as read first, then fetch so they show as read
      await fetch('/api/notifications/mark-all', { method: 'PUT' });
      fetchNotifs();
    };
    init();
  }, [page]);

  const markAllRead = async () => {
    await fetch('/api/notifications/mark-all', { method: 'PUT' });
    setNotifs(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const typeColor = (t: string) => {
    const map: Record<string, string> = { normal: 'border-[#2A3040]', alert: 'border-yellow-500/30', urgent: 'border-red-500/30' };
    return map[t] || map.normal;
  };

  return (
    <div className="space-y-4 animate-fadeIn pb-20 lg:pb-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">الإشعارات</h1>
        {!loading && notifs.length > 0 && (
          <button onClick={markAllRead} className="flex items-center gap-1 text-[#2ECC71] text-sm hover:underline"><CheckCheck size={16} /> تحديد الكل كمقروء</button>
        )}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="skeleton-card" />
          ))}
        </div>
      ) : notifs.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[#1A1F2E] border border-[#2A3040] flex items-center justify-center">
            <Bell size={32} className="text-gray-600" />
          </div>
          <p className="text-gray-400 text-lg font-medium mb-2">لا توجد إشعارات</p>
          <p className="text-gray-500 text-sm">ستظهر هنا الإشعارات والتحديثات الجديدة</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifs.map(n => (
            <div key={n.id} className={`bg-[#1A1F2E] rounded-xl p-4 border ${typeColor(n.type)} ${!n.isRead ? 'border-r-2 border-r-[#FFD700]' : ''}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <h3 className={`text-sm font-medium ${!n.isRead ? 'text-white' : 'text-gray-300'}`}>{n.title}</h3>
                  <p className="text-gray-400 text-xs mt-1">{n.message}</p>
                  <p className="text-gray-500 text-[10px] mt-2">{new Date(n.createdAt).toLocaleString('ar')}</p>
                </div>
                {!n.isRead && <div className="w-2 h-2 bg-[#FFD700] rounded-full mt-2 shrink-0" />}
              </div>
            </div>
          ))}
        </div>
      )}

      {total > 20 && (
        <div className="flex justify-center gap-2">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-sm text-gray-300">السابق</button>
          <span className="px-4 py-2 text-gray-400 text-sm">صفحة {page}</span>
          <button onClick={() => setPage(p => p + 1)} className="px-4 py-2 bg-[#1A1F2E] border border-[#2A3040] rounded-xl text-sm text-gray-300">التالي</button>
        </div>
      )}
    </div>
  );
}
