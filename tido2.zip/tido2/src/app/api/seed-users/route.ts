import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, generateReferralCode } from '@/lib/auth';

export async function POST() {
  try {
    // Check if seed users already exist
    const existingCount = await db.user.count({
      where: { username: { startsWith: 'investor_' } }
    });
    if (existingCount >= 20) {
      return NextResponse.json({ message: `يوجد بالفعل ${existingCount} مستخدم تجريبي`, count: existingCount });
    }

    const fakeUsers = [
      { username: 'investor_ahmed', fullName: 'أحمد المنصوري', email: 'ahmed.m@mail.com', phone: '+966501234567' },
      { username: 'investor_sara', fullName: 'سارة الخالدي', email: 'sara.k@mail.com', phone: '+971502345678' },
      { username: 'investor_omar', fullName: 'عمر الشمري', email: 'omar.s@mail.com', phone: '+965603456789' },
      { username: 'investor_fatima', fullName: 'فاطمة العتيبي', email: 'fatima.a@mail.com', phone: '+974704567890' },
      { username: 'investor_youssef', fullName: 'يوسف الحربي', email: 'youssef.h@mail.com', phone: '+973805678901' },
      { username: 'investor_nora', fullName: 'نورة القحطاني', email: 'nora.q@mail.com', phone: '+968906789012' },
      { username: 'investor_khalid', fullName: 'خالد الدوسري', email: 'khalid.d@mail.com', phone: '+964107890123' },
      { username: 'investor_layla', fullName: 'ليلى الزهراني', email: 'layla.z@mail.com', phone: '+962208901234' },
      { username: 'investor_tariq', fullName: 'طارق الغامدي', email: 'tariq.g@mail.com', phone: '+961309012345' },
      { username: 'investor_hind', fullName: 'هند المالكي', email: 'hind.m@mail.com', phone: '+963410123456' },
      { username: 'investor_rami', fullName: 'رامي العبدالله', email: 'rami.a@mail.com', phone: '+970512345678' },
      { username: 'investor_dina', fullName: 'دينا السعيد', email: 'dina.s@mail.com', phone: '+20623456789' },
      { username: 'investor_mazen', fullName: 'مازن الراشد', email: 'mazen.r@mail.com', phone: '+212734567890' },
      { username: 'investor_reem', fullName: 'ريم العمران', email: 'reem.a@mail.com', phone: '+213845678901' },
      { username: 'investor_faisal', fullName: 'فيصل النفيعي', email: 'faisal.n@mail.com', phone: '+216956789012' },
      { username: 'investor_amal', fullName: 'أمال البلوي', email: 'amal.b@mail.com', phone: '+21867890123' },
      { username: 'investor_samer', fullName: 'سامر التميمي', email: 'samer.t@mail.com', phone: '+24978901234' },
      { username: 'investor_ghada', fullName: 'غادة السبيعي', email: 'ghada.s@mail.com', phone: '+96789012345' },
      { username: 'investor_basel', fullName: 'باسل المطيري', email: 'basel.m@mail.com', phone: '+90912345678' },
      { username: 'investor_ruba', fullName: 'ربة الشهري', email: 'ruba.s@mail.com', phone: '+10123456789' },
    ];

    const hashedPassword = await hashPassword('Investor123A');
    const planIds = await db.investmentPlan.findMany({ select: { id: true, minAmount: true, maxAmount: true, dailyRate: true, duration: true } });

    if (planIds.length === 0) {
      return NextResponse.json({ error: 'لا توجد خطط استثمار. شغّل setup-database.js أولاً' }, { status: 400 });
    }

    const createdUsers = [];
    let investmentCount = 0;

    for (const userData of fakeUsers) {
      // Check if user already exists
      const exists = await db.user.findUnique({ where: { username: userData.username } });
      if (exists) continue;

      // Random balance between $500 and $50,000
      const balance = Math.floor(Math.random() * 49500 + 500);

      // Random join date between 10 and 180 days ago
      const daysAgo = Math.floor(Math.random() * 170 + 10);
      const createdAt = new Date(Date.now() - daysAgo * 86400000);

      const user = await db.user.create({
        data: {
          username: userData.username,
          fullName: userData.fullName,
          email: userData.email,
          phone: userData.phone,
          password: hashedPassword,
          balance: balance,
          referralCode: generateReferralCode(),
          isActive: true,
          createdAt,
        },
      });

      createdUsers.push(user);

      // Welcome notification
      await db.notification.create({
        data: {
          userId: user.id,
          title: 'مرحباً بك! 🎉',
          message: 'تم إنشاء حسابك بنجاح. يمكنك الآن البدء بالاستثمار وتحقيق أرباح يومية.',
          type: 'bonus',
          isRead: true,
          createdAt,
        },
      });

      // Create 1-3 investments per user
      const numInvestments = Math.floor(Math.random() * 3) + 1;
      for (let i = 0; i < numInvestments; i++) {
        const plan = planIds[Math.floor(Math.random() * planIds.length)];
        const minInvest = Math.min(100, plan.minAmount);
        const maxInvest = Math.min(balance, plan.maxAmount);
        const amount = Math.floor(Math.random() * (maxInvest - minInvest + 1)) + minInvest;

        const investDaysAgo = Math.floor(Math.random() * Math.max(1, daysAgo - 1));
        const investCreatedAt = new Date(Date.now() - investDaysAgo * 86400000);

        const expectedProfit = amount * (plan.dailyRate / 100) * plan.duration;
        const isActive = investDaysAgo < plan.duration;

        const investment = await db.investment.create({
          data: {
            userId: user.id,
            planId: plan.id,
            amount,
            dailyRate: plan.dailyRate,
            duration: plan.duration,
            expectedProfit,
            currentDay: isActive ? Math.min(investDaysAgo, plan.duration) : plan.duration,
            isActive,
            createdAt: investCreatedAt,
          },
        });

        investmentCount++;

        // Create daily profits for completed days
        const daysToCreate = isActive ? Math.min(investDaysAgo, plan.duration) : plan.duration;
        const profitAmount = amount * (plan.dailyRate / 100);

        for (let day = 0; day < daysToCreate; day++) {
          const profitDate = new Date(investCreatedAt.getTime() + day * 86400000);
          await db.dailyProfit.create({
            data: {
              userId: user.id,
              investmentId: investment.id,
              amount: profitAmount,
              rate: plan.dailyRate,
              type: 'investment',
              createdAt: profitDate,
            },
          });
        }

        // Investment notification
        await db.notification.create({
          data: {
            userId: user.id,
            title: 'تم إنشاء استثمار جديد 💰',
            message: `تم إنشاء استثمار بقيمة $${amount.toFixed(2)} بنسبة ${plan.dailyRate}% يومياً لمدة ${plan.duration} يوم. الأرباح المتوقعة: $${expectedProfit.toFixed(2)}`,
            type: 'profit',
            isRead: investDaysAgo > 1,
            createdAt: investCreatedAt,
          },
        });
      }
    }

    return NextResponse.json({
      message: `تم إنشاء ${createdUsers.length} مستخدم و ${investmentCount} استثمار بنجاح`,
      users: createdUsers.length,
      investments: investmentCount,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ أثناء إنشاء المستخدمين';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
