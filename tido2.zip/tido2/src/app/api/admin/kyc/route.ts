import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || '';
    const search = searchParams.get('search') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where: Record<string, unknown> = {
      status: { notIn: ['not_submitted'] },
    };

    if (status && status !== 'all') {
      where.status = status;
    }

    if (search) {
      where.user = {
        OR: [
          { username: { contains: search } },
          { fullName: { contains: search } },
          { email: { contains: search } },
        ],
      };
    }

    const [kycSubmissions, total] = await Promise.all([
      db.kYC.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          user: {
            select: { username: true, fullName: true, email: true, createdAt: true },
          },
        },
      }),
      db.kYC.count({ where }),
    ]);

    const [statsTotal, statsPending, statsApproved, statsRejected] = await Promise.all([
      db.kYC.count({ where: { status: { notIn: ['not_submitted'] } } }),
      db.kYC.count({ where: { status: 'pending' } }),
      db.kYC.count({ where: { status: 'verified' } }),
      db.kYC.count({ where: { status: 'rejected' } }),
    ]);

    const mappedSubmissions = kycSubmissions.map(k => ({
      id: k.id,
      userId: k.userId,
      username: k.user?.username || '',
      fullName: k.user?.fullName || '',
      email: k.user?.email || '',
      idFront: k.idFront,
      idBack: k.idBack,
      selfie: k.selfie,
      status: k.status,
      rejectReason: k.rejectReason,
      createdAt: k.createdAt.toISOString(),
      updatedAt: k.updatedAt.toISOString(),
    }));

    return NextResponse.json({
      submissions: mappedSubmissions,
      total,
      pages: Math.ceil(total / limit),
      stats: {
        total: statsTotal,
        pending: statsPending,
        approved: statsApproved,
        rejected: statsRejected,
      },
    });
  } catch (error) {
    console.error('Admin KYC list error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
