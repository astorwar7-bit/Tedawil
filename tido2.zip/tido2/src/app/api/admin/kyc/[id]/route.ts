import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity, sendRealtimeNotification } from '@/lib/helpers';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const body = await request.json();
    const { action, reason } = body;

    if (!action || !['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
    }

    const kyc = await db.kYC.findUnique({
      where: { id },
      include: { user: true },
    });

    if (!kyc) return NextResponse.json({ error: 'طلب التحقق غير موجود' }, { status: 404 });
    if (kyc.status !== 'pending') {
      return NextResponse.json({ error: 'تم معالجة هذا الطلب مسبقاً' }, { status: 400 });
    }

    if (action === 'approve') {
      await db.kYC.update({
        where: { id },
        data: { status: 'verified', rejectReason: '' },
      });

      await sendRealtimeNotification(
        kyc.userId,
        'تم قبول طلب التحقق من الهوية',
        'تهانينا! تم قبول طلب التحقق من هويتك بنجاح. يمكنك الآن الاستفادة من جميع مزايا المنصة.',
        'success'
      );

      await db.userActivity.create({
        data: {
          userId: kyc.userId,
          action: 'KYC_APPROVED',
          details: 'تم قبول طلب التحقق من الهوية',
        },
      });

      await logActivity(
        user.username,
        'APPROVE_KYC',
        `تم قبول طلب التحقق من هوية المستخدم ${kyc.user.username}`
      );

      return NextResponse.json({ message: 'تم قبول طلب التحقق بنجاح' });
    }

    if (action === 'reject') {
      if (!reason || reason.trim().length === 0) {
        return NextResponse.json({ error: 'يرجى إدخال سبب الرفض' }, { status: 400 });
      }

      await db.kYC.update({
        where: { id },
        data: { status: 'rejected', rejectReason: reason.trim() },
      });

      await sendRealtimeNotification(
        kyc.userId,
        'تم رفض طلب التحقق من الهوية',
        `عذراً، تم رفض طلب التحقق من هويتك. السبب: ${reason.trim()}. يمكنك إعادة تقديم الطلب بعد تعديل المستندات.`,
        'alert'
      );

      await db.userActivity.create({
        data: {
          userId: kyc.userId,
          action: 'KYC_REJECTED',
          details: `تم رفض طلب التحقق من الهوية. السبب: ${reason.trim()}`,
        },
      });

      await logActivity(
        user.username,
        'REJECT_KYC',
        `تم رفض طلب التحقق من هوية المستخدم ${kyc.user.username}. السبب: ${reason.trim()}`
      );

      return NextResponse.json({ message: 'تم رفض طلب التحقق' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    console.error('Admin KYC action error:', error);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
