import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const thisMonth = new Date();
    thisMonth.setDate(1);
    thisMonth.setHours(0, 0, 0, 0);

    const [
      totalUsers, newToday,
      totalDeposits, totalProfits,
      pendingWithdrawals, completedWithdrawals,
      totalAgents,
      activeInvestments,
      totalInvestments,
      totalAgentCommission,
      thisMonthDeposits,
    ] = await Promise.all([
      db.user.count({ where: { isAdmin: false } }).catch(() => 0),
      db.user.count({ where: { isAdmin: false, createdAt: { gte: today } } }).catch(() => 0),
      db.investment.aggregate({ _sum: { amount: true } }).catch(() => ({ _sum: { amount: null } })),
      db.dailyProfit.aggregate({ _sum: { amount: true } }).catch(() => ({ _sum: { amount: null } })),
      db.withdrawal.aggregate({ where: { status: 'pending' }, _sum: { amount: true }, _count: true }).catch(() => ({ _sum: { amount: null }, _count: 0 })),
      db.withdrawal.aggregate({ where: { status: 'approved', createdAt: { gte: thisMonth } }, _sum: { amount: true } }).catch(() => ({ _sum: { amount: null } })),
      db.user.count({ where: { isAgent: true } }).catch(() => 0),
      db.investment.count({ where: { isActive: true } }).catch(() => 0),
      db.investment.count().catch(() => 0),
      db.userActivity.aggregate({ where: { action: 'AGENT_COMMISSION' }, _sum: { amount: true } }).catch(() => ({ _sum: { amount: null } })),
      db.deposit.aggregate({ where: { status: 'approved', createdAt: { gte: thisMonth } }, _sum: { amount: true } }).catch(() => ({ _sum: { amount: null } })),
    ]);

    // Investment plan distribution
    let planData: { name: string; color: string; count: number }[] = [];
    try {
      const planDistribution = await db.investment.groupBy({
        by: ['planId'],
        _count: { id: true },
        where: { planId: { not: null } },
      });

      const planIds = planDistribution.map(p => p.planId!);
      const plans = planIds.length > 0
        ? await db.investmentPlan.findMany({
            where: { id: { in: planIds } },
            select: { id: true, name: true, color: true },
          })
        : [];

      const planMap = Object.fromEntries(plans.map(p => [p.id!, p] as const));
      planData = planDistribution.map(p => {
        const planInfo = p.planId ? planMap[p.planId] : null;
        return {
          name: planInfo?.name || 'بدون خطة',
          color: planInfo?.color || '#8899AA',
          count: p._count.id ?? 0,
        };
      });
    } catch {
      // plan distribution is non-critical, skip on error
    }

    // Chart data: daily deposits and withdrawals for last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 29);
    thirtyDaysAgo.setHours(0, 0, 0, 0);

    let chartData: { date: string; deposits: number; withdrawals: number }[] = [];
    try {
      const [dailyDeposits, dailyWithdrawals] = await Promise.all([
        db.deposit.groupBy({
          by: ['createdAt'],
          where: { createdAt: { gte: thirtyDaysAgo } },
          _sum: { amount: true },
        }).catch(() => []),
        db.withdrawal.groupBy({
          by: ['createdAt'],
          where: { createdAt: { gte: thirtyDaysAgo } },
          _sum: { amount: true },
        }).catch(() => []),
      ]);

      for (let i = 0; i < 30; i++) {
        const day = new Date(thirtyDaysAgo);
        day.setDate(day.getDate() + i);
        const dayStr = day.toISOString().split('T')[0];

        const dayDeposits = dailyDeposits
          .filter(d => d.createdAt.toISOString().split('T')[0] === dayStr)
          .reduce((s, d) => s + (d._sum.amount || 0), 0);

        const dayWithdrawals = dailyWithdrawals
          .filter(w => w.createdAt.toISOString().split('T')[0] === dayStr)
          .reduce((s, w) => s + (w._sum.amount || 0), 0);

        chartData.push({
          date: `${day.getDate()}`,
          deposits: dayDeposits,
          withdrawals: dayWithdrawals,
        });
      }
    } catch {
      // chart data is non-critical, return empty on error
    }

    const pendingCount = typeof pendingWithdrawals._count === 'number'
      ? pendingWithdrawals._count
      : (pendingWithdrawals._count ? 1 : 0);

    return NextResponse.json({
      totalUsers: typeof totalUsers === 'number' ? totalUsers : 0,
      newToday: typeof newToday === 'number' ? newToday : 0,
      totalDeposits: totalDeposits._sum?.amount || 0,
      totalProfits: totalProfits._sum?.amount || 0,
      pendingWithdrawals: pendingCount,
      pendingWithdrawalAmount: pendingWithdrawals._sum?.amount || 0,
      completedWithdrawals: completedWithdrawals._sum?.amount || 0,
      totalAgents: typeof totalAgents === 'number' ? totalAgents : 0,
      activeInvestments: typeof activeInvestments === 'number' ? activeInvestments : 0,
      totalInvestments: typeof totalInvestments === 'number' ? totalInvestments : 0,
      totalAgentCommission: totalAgentCommission._sum?.amount || 0,
      thisMonthDeposits: thisMonthDeposits._sum?.amount || 0,
      planDistribution: planData,
      chartData,
    });
  } catch (error) {
    console.error('Admin dashboard error:', error);
    return NextResponse.json({
      totalUsers: 0, newToday: 0, totalDeposits: 0, totalProfits: 0,
      pendingWithdrawals: 0, pendingWithdrawalAmount: 0, completedWithdrawals: 0,
      totalAgents: 0, activeInvestments: 0, totalInvestments: 0,
      totalAgentCommission: 0, thisMonthDeposits: 0, planDistribution: [], chartData: [],
    });
  }
}
