import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { target, targetUserId, title, message, type } = body;

    if (!title || !message) return NextResponse.json({ error: 'العنوان والنص مطلوبان' }, { status: 400 });

    if (target === 'all') {
      const users = await db.user.findMany({ where: { isAdmin: false }, select: { id: true } });
      await db.notification.createMany({
        data: users.map(u => ({ userId: u.id, title, message, type: type || 'normal' })),
      });
      await logActivity(user.username, 'SEND_NOTIFICATION_ALL', `إشعار جماعي: ${title}`);
      return NextResponse.json({ message: `تم إرسال الإشعار إلى ${users.length} مستخدم` });
    }

    if (target === 'user' && targetUserId) {
      // Look up user by username, email, or ID
      const targetUser = await db.user.findFirst({
        where: { OR: [{ username: targetUserId }, { email: targetUserId }, { id: targetUserId }] },
        select: { id: true },
      });
      if (!targetUser) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

      await db.notification.create({ data: { userId: targetUser.id, title, message, type: type || 'normal' } });
      await logActivity(user.username, 'SEND_NOTIFICATION', `إشعار إلى مستخدم: ${title}`);
      return NextResponse.json({ message: 'تم إرسال الإشعار' });
    }

    return NextResponse.json({ error: 'يرجى تحديد المستلم' }, { status: 400 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
