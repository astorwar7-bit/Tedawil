import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || '';
    const search = searchParams.get('search') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const where: Record<string, unknown> = {};

    if (status && status !== 'all') {
      where.status = status;
    }

    if (search) {
      where.user = {
        OR: [
          { username: { contains: search } },
          { fullName: { contains: search } },
        ],
      };
    }

    const [deposits, total] = await Promise.all([
      db.deposit.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          user: { select: { username: true, fullName: true } },
        },
      }),
      db.deposit.count({ where }),
    ]);

    // Compute stats
    const [statsTotal, statsPending, statsApproved, statsRejected] = await Promise.all([
      db.deposit.aggregate({ _sum: { amount: true } }),
      db.deposit.aggregate({ where: { status: 'pending' }, _sum: { amount: true }, _count: true }),
      db.deposit.count({ where: { status: 'approved' } }),
      db.deposit.count({ where: { status: 'rejected' } }),
    ]);

    const mappedDeposits = deposits.map(d => ({
      id: d.id,
      userId: d.userId,
      userName: d.user?.fullName || d.user?.username || '',
      amount: d.amount,
      paymentMethod: d.method,
      transactionHash: d.txHash,
      screenshotUrl: d.screenshot,
      status: d.status,
      createdAt: d.createdAt.toISOString(),
    }));

    return NextResponse.json({
      deposits: mappedDeposits,
      total,
      pages: Math.ceil(total / limit),
      stats: {
        total: statsTotal._sum.amount || 0,
        pending: statsPending._count || 0,
        pendingAmount: statsPending._sum.amount || 0,
        approved: statsApproved,
        rejected: statsRejected,
      },
    });
  } catch (error) {
    console.error('Admin deposits list error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { depositId, action } = body;

    if (!depositId || !action) {
      return NextResponse.json({ error: 'بيانات غير مكتملة' }, { status: 400 });
    }

    const deposit = await db.deposit.findUnique({
      where: { id: depositId },
      include: { user: true },
    });

    if (!deposit) return NextResponse.json({ error: 'الإيداع غير موجود' }, { status: 404 });
    if (deposit.status !== 'pending') return NextResponse.json({ error: 'تم معالجة هذا الإيداع مسبقاً' }, { status: 400 });

    if (action === 'approve') {
      await db.$transaction(async (tx) => {
        await tx.deposit.update({
          where: { id: depositId },
          data: { status: 'approved' },
        });

        await tx.user.update({
          where: { id: deposit.userId },
          data: { balance: { increment: deposit.amount } },
        });

        await tx.notification.create({
          data: {
            userId: deposit.userId,
            title: 'تم قبول الإيداع',
            message: `تم قبول إيداعك بقيمة $${deposit.amount.toFixed(2)} وإضافته إلى رصيدك.`,
            type: 'success',
          },
        });

        await tx.userActivity.create({
          data: {
            userId: deposit.userId,
            action: 'DEPOSIT_APPROVED',
            details: `تم قبول إيداع $${deposit.amount.toFixed(2)} بطريقة ${deposit.method}`,
            amount: deposit.amount,
          },
        });
      });

      await logActivity(
        user.username,
        'APPROVE_DEPOSIT',
        `تم قبول إيداع $${deposit.amount.toFixed(2)} للمستخدم ${deposit.user.username}`
      );

      return NextResponse.json({ message: 'تم قبول الإيداع بنجاح' });
    }

    if (action === 'reject') {
      await db.deposit.update({
        where: { id: depositId },
        data: { status: 'rejected' },
      });

      await db.notification.create({
        data: {
          userId: deposit.userId,
          title: 'تم رفض الإيداع',
          message: `تم رفض إيداعك بقيمة $${deposit.amount.toFixed(2)}. يرجى التواصل مع الدعم الفني للمزيد من المعلومات.`,
          type: 'alert',
        },
      });

      await logActivity(
        user.username,
        'REJECT_DEPOSIT',
        `تم رفض إيداع $${deposit.amount.toFixed(2)} للمستخدم ${deposit.user.username}`
      );

      return NextResponse.json({ message: 'تم رفض الإيداع' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
