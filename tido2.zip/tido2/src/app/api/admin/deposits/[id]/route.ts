import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity, sendRealtimeNotification } from '@/lib/helpers';

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const body = await request.json();
    const { action } = body;

    if (!action || !['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
    }

    const deposit = await db.deposit.findUnique({
      where: { id },
      include: { user: true },
    });

    if (!deposit) return NextResponse.json({ error: 'الإيداع غير موجود' }, { status: 404 });
    if (deposit.status !== 'pending') return NextResponse.json({ error: 'تم معالجة هذا الإيداع مسبقاً' }, { status: 400 });

    if (action === 'approve') {
      await db.$transaction(async (tx) => {
        await tx.deposit.update({
          where: { id },
          data: { status: 'approved' },
        });

        await tx.user.update({
          where: { id: deposit.userId },
          data: { balance: { increment: deposit.amount } },
        });

        await sendRealtimeNotification(
          deposit.userId,
          'تم قبول الإيداع',
          `تم قبول إيداعك بقيمة $${deposit.amount.toFixed(2)} وإضافته إلى رصيدك.`,
          'success'
        );

        await tx.userActivity.create({
          data: {
            userId: deposit.userId,
            action: 'DEPOSIT_APPROVED',
            details: `تم قبول إيداع $${deposit.amount.toFixed(2)} بطريقة ${deposit.method}`,
            amount: deposit.amount,
          },
        });

        // Check if this user was referred and referral bonus hasn't been given yet
        if (deposit.user.referredBy && !deposit.user.referralBonusGiven) {
          const settings = await tx.setting.findFirst();
          const referralFixedBonus = settings?.referralFixedBonus || 0;

          if (referralFixedBonus > 0) {
            // Give the referrer their fixed bonus
            await tx.user.update({
              where: { id: deposit.user.referredBy },
              data: { balance: { increment: referralFixedBonus } },
            });

            // Record the referral bonus
            await tx.dailyProfit.create({
              data: {
                userId: deposit.user.referredBy,
                amount: referralFixedBonus,
                type: 'referral_signup',
                rate: 0,
              },
            });

            // Mark that the referral bonus was given for this user
            await tx.user.update({
              where: { id: deposit.userId },
              data: { referralBonusGiven: true },
            });

            // Notify the referrer about their bonus
            await tx.notification.create({
              data: {
                userId: deposit.user.referredBy,
                title: 'مكافأة إحالة جديدة! 🎁',
                message: `حصلت على مكافأة $${referralFixedBonus.toFixed(2)} بفضل إيداع ${deposit.user.username} الأول.`,
                type: 'referral',
              },
            });

            // Notify the referred user
            await tx.notification.create({
              data: {
                userId: deposit.userId,
                title: 'تم تفعيل كود الإحالة ✨',
                message: `تم إيداعك الأول بنجاح! حصل ${deposit.user.referredBy} على مكافأة $${referralFixedBonus.toFixed(2)} بفضل كود الإحالة الخاص به.`,
                type: 'referral',
              },
            });

            // Log the referral bonus for the referrer
            await tx.userActivity.create({
              data: {
                userId: deposit.user.referredBy,
                action: 'REFERRAL_BONUS',
                details: `مكافأة إحالة: $${referralFixedBonus.toFixed(2)} بسبب إيداع ${deposit.user.username} الأول`,
                amount: referralFixedBonus,
              },
            });
          }
        }

        // Agent Commission: Check if the referrer is an agent
        if (deposit.user.referredBy) {
          const referrer = await tx.user.findUnique({
            where: { id: deposit.user.referredBy },
            select: { id: true, isAgent: true, agentCommissionRate: true, username: true },
          });

          if (referrer && referrer.isAgent && referrer.agentCommissionRate > 0) {
            const commission = deposit.amount * (referrer.agentCommissionRate / 100);

            // Add commission to agent's balance
            await tx.user.update({
              where: { id: referrer.id },
              data: { balance: { increment: commission } },
            });

            // Record commission activity
            await tx.userActivity.create({
              data: {
                userId: referrer.id,
                action: 'AGENT_COMMISSION',
                details: `عمولة وكيل من إيداع ${deposit.user.username}: $${commission.toFixed(2)} (${referrer.agentCommissionRate}% من $${deposit.amount.toFixed(2)})`,
                amount: commission,
              },
            });

            // Notify the agent
            await tx.notification.create({
              data: {
                userId: referrer.id,
                title: 'عمولة جديدة من إحالتك 💰',
                message: `حصلت على عمولة $${commission.toFixed(2)} من إيداع ${deposit.user.username} بقيمة $${deposit.amount.toFixed(2)} (نسبة ${referrer.agentCommissionRate}%)`,
                type: 'referral',
              },
            });
          }
        }
      });

      await logActivity(
        user.username,
        'APPROVE_DEPOSIT',
        `تم قبول إيداع $${deposit.amount.toFixed(2)} للمستخدم ${deposit.user.username}`
      );

      return NextResponse.json({ message: 'تم قبول الإيداع بنجاح' });
    }

    if (action === 'reject') {
      await db.$transaction([
        db.deposit.update({
          where: { id },
          data: { status: 'rejected' },
        }),
        db.userActivity.create({
          data: {
            userId: deposit.userId,
            action: 'DEPOSIT_REJECTED',
            details: `تم رفض إيداع $${deposit.amount.toFixed(2)} بطريقة ${deposit.method}`,
            amount: 0,
          },
        }),
      ]);

      await sendRealtimeNotification(
        deposit.userId,
        'تم رفض الإيداع',
        `تم رفض إيداعك بقيمة $${deposit.amount.toFixed(2)}. يرجى التواصل مع الدعم الفني.`,
        'alert'
      );

      await logActivity(
        user.username,
        'REJECT_DEPOSIT',
        `تم رفض إيداع $${deposit.amount.toFixed(2)} للمستخدم ${deposit.user.username}`
      );

      return NextResponse.json({ message: 'تم رفض الإيداع' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
