import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings, logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const settings = await getSettings();
    return NextResponse.json({ settings });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await request.json();
    const settings = await getSettings();
    await db.setting.update({
      where: { id: settings.id },
      data: {
        platformName: body.platformName ?? settings.platformName,
        platformNameEn: body.platformNameEn ?? settings.platformNameEn,
        platformDesc: body.platformDesc ?? settings.platformDesc,
        platformLogo: body.platformLogo ?? settings.platformLogo,
        mainWalletAddress: body.mainWalletAddress ?? settings.mainWalletAddress,
        minDeposit: body.minDeposit ?? settings.minDeposit,
        minWithdraw: body.minWithdraw ?? settings.minWithdraw,
        referralBonusRate: body.referralBonusRate ?? settings.referralBonusRate,
        referralLevel2Rate: body.referralLevel2Rate ?? settings.referralLevel2Rate,
        referralFixedBonus: body.referralFixedBonus ?? settings.referralFixedBonus,
        monthlyCommissionCap: body.monthlyCommissionCap ?? settings.monthlyCommissionCap,
        minDailyRate: body.minDailyRate ?? settings.minDailyRate,
        maxDailyRate: body.maxDailyRate ?? settings.maxDailyRate,
        welcomeBonus: body.welcomeBonus ?? settings.welcomeBonus,
      },
    });
    await logActivity(user.username, 'UPDATE_SETTINGS', 'تم تحديث الإعدادات العامة');
    return NextResponse.json({ message: 'تم تحديث الإعدادات بنجاح' });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}
