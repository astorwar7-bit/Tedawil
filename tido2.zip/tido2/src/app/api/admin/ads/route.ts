import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const ads = await db.advertisement.findMany({ orderBy: { priority: 'desc', createdAt: 'desc' } });
    return NextResponse.json({ ads });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await request.json();
    const { type, title, content, link, imageUrl, startDate, endDate, priority, isActive } = body;
    if (!title || !startDate) return NextResponse.json({ error: 'العنوان وتاريخ البداية مطلوبان' }, { status: 400 });
    const ad = await db.advertisement.create({
      data: { type: type || 'text', title, content: content || '', link: link || '', imageUrl: imageUrl || '', startDate: new Date(startDate), endDate: endDate ? new Date(endDate) : null, priority: priority || 0, isActive: isActive !== false },
    });
    await logActivity(user.username, 'CREATE_AD', `تم إنشاء إعلان: ${title}`);
    return NextResponse.json({ message: 'تم إنشاء الإعلان', ad }, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await request.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ error: 'معرف الإعلان مطلوب' }, { status: 400 });
    if (data.startDate) data.startDate = new Date(data.startDate);
    if (data.endDate) data.endDate = new Date(data.endDate);
    const ad = await db.advertisement.update({ where: { id }, data });
    await logActivity(user.username, 'UPDATE_AD', `تم تحديث إعلان: ${ad.title}`);
    return NextResponse.json({ message: 'تم تحديث الإعلان', ad });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'معرف الإعلان مطلوب' }, { status: 400 });
    await db.advertisement.delete({ where: { id } });
    await logActivity(user.username, 'DELETE_AD', `تم حذف إعلان: ${id}`);
    return NextResponse.json({ message: 'تم حذف الإعلان' });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}
