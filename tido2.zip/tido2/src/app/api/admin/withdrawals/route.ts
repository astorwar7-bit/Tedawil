import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity, sendRealtimeNotification } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');

    const where: Record<string, unknown> = {};
    if (status) where.status = status;

    const [withdrawals, total] = await Promise.all([
      db.withdrawal.findMany({
        where, orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit, take: limit,
        include: { user: { select: { username: true, fullName: true } } },
      }),
      db.withdrawal.count({ where }),
    ]);

    return NextResponse.json({ withdrawals, total, pages: Math.ceil(total / limit) });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { withdrawalId, action, rejectReason } = body;

    const withdrawal = await db.withdrawal.findUnique({ where: { id: withdrawalId }, include: { user: true } });
    if (!withdrawal) return NextResponse.json({ error: 'طلب السحب غير موجود' }, { status: 404 });

    if (action === 'approve') {
      await db.$transaction([
        db.withdrawal.update({ where: { id: withdrawalId }, data: { status: 'approved' } }),
        db.user.update({ where: { id: withdrawal.userId }, data: { balance: { decrement: withdrawal.amount } } }),
        db.userActivity.create({
          data: {
            userId: withdrawal.userId,
            action: 'WITHDRAWAL_APPROVED',
            details: `تم تحويل سحب $${withdrawal.amount.toFixed(2)} إلى محفظتك`,
            amount: -withdrawal.amount,
          },
        }),
      ]);
      await sendRealtimeNotification(withdrawal.userId, 'تم التحويل', `تم تحويل مبلغ $${withdrawal.amount.toFixed(2)} إلى محفظتك بنجاح.`, 'success');
      await logActivity(user.username, 'APPROVE_WITHDRAWAL', `تم الموافقة على سحب $${withdrawal.amount} للمستخدم ${withdrawal.user.username}`);
      return NextResponse.json({ message: 'تم الموافقة على طلب السحب' });
    }

    if (action === 'reject') {
      if (!rejectReason) return NextResponse.json({ error: 'يرجى إدخال سبب الرفض' }, { status: 400 });

      await db.$transaction([
        db.withdrawal.update({ where: { id: withdrawalId }, data: { status: 'rejected', rejectReason } }),
        db.userActivity.create({
          data: {
            userId: withdrawal.userId,
            action: 'WITHDRAWAL_REJECTED',
            details: `تم رفض سحب $${withdrawal.amount.toFixed(2)}. السبب: ${rejectReason}`,
            amount: 0,
          },
        }),
      ]);

      await db.notification.create({
        data: {
          userId: withdrawal.userId,
          title: 'تم رفض طلب السحب',
          message: `تم رفض طلب سحب $${withdrawal.amount}. السبب: ${rejectReason}`,
          type: 'alert',
        },
      });

      await logActivity(user.username, 'REJECT_WITHDRAWAL', `تم رفض سحب $${withdrawal.amount} للمستخدم ${withdrawal.user.username}. السبب: ${rejectReason}`);
      return NextResponse.json({ message: 'تم رفض طلب السحب' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
