import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity, sendRealtimeNotification } from '@/lib/helpers';

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { withdrawalIds, action, rejectReason } = body;

    if (!withdrawalIds || !Array.isArray(withdrawalIds) || withdrawalIds.length === 0) {
      return NextResponse.json({ error: 'يرجى تحديد طلبات السحب' }, { status: 400 });
    }

    if (!action || !['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
    }

    if (action === 'reject' && !rejectReason) {
      return NextResponse.json({ error: 'يرجى إدخال سبب الرفض' }, { status: 400 });
    }

    // Get all withdrawals
    const withdrawals = await db.withdrawal.findMany({
      where: { id: { in: withdrawalIds } },
      include: { user: true },
    });

    if (withdrawals.length === 0) {
      return NextResponse.json({ error: 'لا توجد طلبات سحب مطابقة' }, { status: 404 });
    }

    // Filter only pending ones
    const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending');
    if (pendingWithdrawals.length === 0) {
      return NextResponse.json({ error: 'جميع الطلبات المحددة تم معالجتها مسبقاً' }, { status: 400 });
    }

    const pendingIds = pendingWithdrawals.map(w => w.id);

    let processedCount = 0;

    if (action === 'approve') {
      await db.withdrawal.updateMany({
        where: { id: { in: pendingIds } },
        data: { status: 'approved' },
      });

      processedCount = pendingWithdrawals.length;

      // Create notifications for each user
      for (const w of pendingWithdrawals) {
        await sendRealtimeNotification(
          w.userId,
          'تم الموافقة على طلب السحب',
          `تم الموافقة على طلب سحبك بقيمة $${w.amount.toFixed(2)}`,
          'success'
        );
      }

      const totalAmount = pendingWithdrawals.reduce((sum, w) => sum + w.amount, 0);
      await logActivity(
        user.username,
        'BULK_APPROVE_WITHDRAWALS',
        `موافقة جماعية على ${processedCount} طلب سحب بقيمة إجمالية $${totalAmount.toFixed(2)}`
      );
    }

    if (action === 'reject') {
      await db.withdrawal.updateMany({
        where: { id: { in: pendingIds } },
        data: { status: 'rejected', rejectReason: rejectReason || '' },
      });

      processedCount = pendingWithdrawals.length;

      for (const w of pendingWithdrawals) {
        await sendRealtimeNotification(
          w.userId,
          'تم رفض طلب السحب',
          `تم رفض طلب سحبك بقيمة $${w.amount.toFixed(2)}. السبب: ${rejectReason}`,
          'alert'
        );
      }

      await logActivity(
        user.username,
        'BULK_REJECT_WITHDRAWALS',
        `رفض جماعي لـ ${processedCount} طلب سحب. السبب: ${rejectReason}`
      );
    }

    return NextResponse.json({
      message: action === 'approve' ? `تمت الموافقة على ${processedCount} طلب` : `تم رفض ${processedCount} طلب`,
      processedCount,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
