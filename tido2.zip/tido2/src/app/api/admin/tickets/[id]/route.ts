import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;

    const ticket = await db.supportTicket.findUnique({
      where: { id },
      include: {
        replies: {
          orderBy: { createdAt: 'asc' },
          include: {
            user: { select: { username: true, fullName: true } },
          },
        },
        user: { select: { username: true, fullName: true, email: true, phone: true } },
      },
    });

    if (!ticket) {
      return NextResponse.json({ error: 'التذكرة غير موجودة' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: { ticket } });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const body = await request.json();
    const { status } = body;

    const validStatuses = ['open', 'in_progress', 'resolved', 'closed'];
    if (!status || !validStatuses.includes(status)) {
      return NextResponse.json({ error: 'حالة غير صالحة' }, { status: 400 });
    }

    const ticket = await db.supportTicket.findUnique({
      where: { id },
      include: { user: true },
    });

    if (!ticket) {
      return NextResponse.json({ error: 'التذكرة غير موجودة' }, { status: 404 });
    }

    const updated = await db.supportTicket.update({
      where: { id },
      data: { status },
    });

    const statusLabels: Record<string, string> = {
      open: 'مفتوحة',
      in_progress: 'قيد المراجعة',
      resolved: 'تم الحل',
      closed: 'مغلقة',
    };

    await logActivity(
      user.username,
      'UPDATE_TICKET_STATUS',
      `تم تغيير حالة التذكرة #${id.slice(-6)} إلى ${statusLabels[status]}`
    );

    // Notify user about status change
    if (status === 'resolved') {
      await db.notification.create({
        data: {
          userId: ticket.userId,
          title: 'تم حل تذكرتك',
          message: `تم حل تذكرتك بعنوان "${ticket.subject}"`,
          type: 'success',
        },
      });
    }

    return NextResponse.json({ success: true, data: { ticket: updated } });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const body = await request.json();
    const { message } = body;

    if (!message || message.trim().length === 0) {
      return NextResponse.json({ error: 'يرجى إدخال الرسالة' }, { status: 400 });
    }

    if (message.length > 5000) {
      return NextResponse.json({ error: 'الرسالة طويلة جداً' }, { status: 400 });
    }

    const ticket = await db.supportTicket.findUnique({
      where: { id },
      include: { user: true },
    });

    if (!ticket) {
      return NextResponse.json({ error: 'التذكرة غير موجودة' }, { status: 404 });
    }

    const reply = await db.ticketReply.create({
      data: {
        ticketId: id,
        userId: user.userId,
        message,
        isAdmin: true,
      },
    });

    // Update ticket status to in_progress if it was open
    if (ticket.status === 'open') {
      await db.supportTicket.update({
        where: { id },
        data: { status: 'in_progress' },
      });
    }

    // Notify user about new reply
    await db.notification.create({
      data: {
        userId: ticket.userId,
        title: 'رد جديد على تذكرتك',
        message: `تم الرد على تذكرتك بعنوان "${ticket.subject}"`,
        type: 'normal',
      },
    });

    await logActivity(
      user.username,
      'REPLY_TICKET',
      `تم الرد على التذكرة #${id.slice(-6)}`
    );

    return NextResponse.json({ success: true, data: { reply } }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
