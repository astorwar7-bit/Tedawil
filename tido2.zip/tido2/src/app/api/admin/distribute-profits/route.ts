import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings, logActivity } from '@/lib/helpers';

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const now = new Date();

    // Get all active investments that haven't expired
    const activeInvestments = await db.investment.findMany({
      where: { isActive: true, endDate: { gt: now } },
      include: {
        user: { select: { id: true, username: true, balance: true, referredBy: true } },
      },
    });

    if (activeInvestments.length === 0) {
      return NextResponse.json({
        totalDistributed: 0,
        investorsCount: 0,
        referralBonuses: 0,
        message: 'لا توجد استثمارات نشطة',
      });
    }

    // Fetch platform settings for referral bonus rate
    const settings = await getSettings();
    const REFERRAL_BONUS_RATE = (settings.referralBonusRate || 5) / 100;
    let totalDistributed = 0;
    let referralBonuses = 0;
    const profitRecords: {
      userId: string;
      investmentId: string;
      amount: number;
      rate: number;
      type: string;
    }[] = [];
    const userBalanceUpdates: Record<string, number> = {};
    const investmentProfitUpdates: Record<string, number> = {};
    const referralRecords: {
      userId: string;
      amount: number;
      rate: number;
      type: string;
      referredByUsername: string;
    }[] = [];

    // Calculate profits for each investment
    for (const investment of activeInvestments) {
      const profit = investment.amount * (investment.dailyRate / 100);

      profitRecords.push({
        userId: investment.userId,
        investmentId: investment.id,
        amount: profit,
        rate: investment.dailyRate,
        type: 'investment',
      });

      // Update user balance accumulator
      userBalanceUpdates[investment.userId] = (userBalanceUpdates[investment.userId] || 0) + profit;

      // Update investment actual profit accumulator
      investmentProfitUpdates[investment.id] = (investmentProfitUpdates[investment.id] || 0) + profit;

      totalDistributed += profit;

      // Handle referral bonus
      if (investment.user.referredBy) {
        const referralBonus = profit * REFERRAL_BONUS_RATE;
        referralBonuses += referralBonus;

        // Add referral bonus to referrer's balance
        userBalanceUpdates[investment.user.referredBy] =
          (userBalanceUpdates[investment.user.referredBy] || 0) + referralBonus;

        referralRecords.push({
          userId: investment.user.referredBy,
          amount: referralBonus,
          rate: REFERRAL_BONUS_RATE * 100,
          type: 'referral',
          referredByUsername: investment.user.username,
        });
      }
    }

    // Execute all in a transaction
    await db.$transaction(async (tx) => {
      // Create DailyProfit records for investment profits
      for (const record of profitRecords) {
        await tx.dailyProfit.create({
          data: {
            userId: record.userId,
            investmentId: record.investmentId,
            amount: record.amount,
            type: record.type,
            rate: record.rate,
          },
        });

        // Create UserActivity record for each daily profit
        await tx.userActivity.create({
          data: {
            userId: record.userId,
            action: 'DAILY_PROFIT',
            details: `ربح يومي من الاستثمار: $${record.amount.toFixed(2)} (معدل ${record.rate}%)`,
            amount: record.amount,
          },
        });
      }

      // Create DailyProfit records for referral bonuses
      for (const record of referralRecords) {
        await tx.dailyProfit.create({
          data: {
            userId: record.userId,
            amount: record.amount,
            type: record.type,
            rate: record.rate,
          },
        });

        // Create notification for referrer
        await tx.notification.create({
          data: {
            userId: record.userId,
            title: 'مكافأة إحالة',
            message: `حصلت على مكافأة إحالة $${record.amount.toFixed(2)} من استثمار المستخدم ${record.referredByUsername}`,
            type: 'referral',
          },
        });

        // Create UserActivity record for referral profit
        await tx.userActivity.create({
          data: {
            userId: record.userId,
            action: 'REFERRAL_PROFIT',
            details: `عمولة إحالة من استثمار ${record.referredByUsername}: $${record.amount.toFixed(2)}`,
            amount: record.amount,
          },
        });
      }

      // Update user balances
      for (const [userId, amount] of Object.entries(userBalanceUpdates)) {
        await tx.user.update({
          where: { id: userId },
          data: { balance: { increment: amount } },
        });
      }

      // Update investment actual profits
      for (const [investmentId, profit] of Object.entries(investmentProfitUpdates)) {
        await tx.investment.update({
          where: { id: investmentId },
          data: { actualProfit: { increment: profit } },
        });
      }
    });

    // Log activity
    await logActivity(
      user.username,
      'DISTRIBUTE_PROFITS',
      `تم توزيع أرباح يومية: $${totalDistributed.toFixed(2)} لـ ${activeInvestments.length} مستثمر. مكافآت إحالة: $${referralBonuses.toFixed(2)}`
    );

    return NextResponse.json({
      totalDistributed,
      investorsCount: activeInvestments.length,
      referralBonuses,
      message: `تم توزيع الأرباح بنجاح`,
    });
  } catch (error) {
    console.error('Profit distribution error:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء توزيع الأرباح' }, { status: 500 });
  }
}
