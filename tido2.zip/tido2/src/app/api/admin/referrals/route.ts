import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings, logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const settings = await getSettings();
    const totalReferralProfits = await db.dailyProfit.aggregate({ where: { type: 'referral' }, _sum: { amount: true } });
    const referralUsers = await db.dailyProfit.groupBy({ by: ['userId'], where: { type: 'referral' }, _count: true });
    return NextResponse.json({ referralBonusRate: settings.referralBonusRate, totalReferralProfits: totalReferralProfits._sum.amount || 0, referralUsersCount: referralUsers.length });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await request.json();
    const { referralBonusRate } = body;
    if (referralBonusRate === undefined || referralBonusRate < 0 || referralBonusRate > 30) {
      return NextResponse.json({ error: 'نسبة غير صالحة (0-30)' }, { status: 400 });
    }
    const settings = await getSettings();
    await db.setting.update({ where: { id: settings.id }, data: { referralBonusRate } });
    await logActivity(user.username, 'UPDATE_REFERRAL', `تم تحديث نسبة الإحالات إلى ${referralBonusRate}%`);
    return NextResponse.json({ message: 'تم تحديث نسبة الإحالات' });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}
