import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

// GET: List all agents with stats
export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const agents = await db.user.findMany({
      where: { isAgent: true },
      select: {
        id: true, username: true, email: true, fullName: true, balance: true,
        isAgent: true, agentCommissionRate: true, referralCode: true, createdAt: true,
        referredUsers: { select: { id: true, balance: true, isActive: true, createdAt: true } },
        activities: { where: { action: 'AGENT_COMMISSION' }, select: { amount: true, createdAt: true } },
      },
    });

    const agentsWithStats = agents.map(agent => {
      const referredUsersCount = agent.referredUsers.length;
      const activeReferrals = agent.referredUsers.filter(u => u.isActive).length;
      const totalCommissionEarned = agent.activities.reduce((sum, a) => sum + a.amount, 0);
      const totalDepositsFromReferrals = agent.referredUsers.reduce((sum, u) => sum + u.balance, 0);

      return {
        id: agent.id,
        username: agent.username,
        email: agent.email,
        fullName: agent.fullName,
        balance: agent.balance,
        commissionRate: agent.agentCommissionRate,
        referralCode: agent.referralCode,
        createdAt: agent.createdAt,
        referredUsersCount,
        activeReferrals,
        totalCommissionEarned,
        totalDepositsFromReferrals,
      };
    });

    return NextResponse.json({ agents: agentsWithStats });
  } catch (error) {
    console.error('Admin agents list error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

// POST: Create agent from existing user
export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { userId, commissionRate } = body;

    if (!userId) return NextResponse.json({ error: 'معرف المستخدم مطلوب' }, { status: 400 });
    if (commissionRate === undefined || commissionRate < 0 || commissionRate > 50) {
      return NextResponse.json({ error: 'نسبة العمولة يجب أن تكون بين 0 و 50' }, { status: 400 });
    }

    // Find user by username, email, or id
    const targetUser = await db.user.findFirst({
      where: { OR: [{ username: userId }, { email: userId }, { id: userId }] },
    });
    if (!targetUser) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    if (targetUser.isAdmin) return NextResponse.json({ error: 'لا يمكن تعيين المدير كوكيل' }, { status: 400 });
    if (targetUser.isAgent) return NextResponse.json({ error: 'المستخدم هو وكيل بالفعل' }, { status: 400 });

    await db.user.update({
      where: { id: targetUser.id },
      data: { isAgent: true, agentCommissionRate: commissionRate },
    });

    await db.userActivity.create({
      data: {
        userId: targetUser.id,
        action: 'AGENT_CREATED',
        details: `تم تعيينك كوكيل بنسبة عمولة ${commissionRate}%`,
      },
    });

    await logActivity(user.username, 'CREATE_AGENT', `تعيين ${targetUser.username} كوكيل بنسبة ${commissionRate}%`);

    return NextResponse.json({ message: 'تم تعيين الوكيل بنجاح' });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

// PUT: Update agent commission rate or deactivate
export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { agentId, commissionRate, deactivate } = body;

    if (!agentId) return NextResponse.json({ error: 'معرف الوكيل مطلوب' }, { status: 400 });

    const agent = await db.user.findUnique({ where: { id: agentId } });
    if (!agent || !agent.isAgent) return NextResponse.json({ error: 'الوكيل غير موجود' }, { status: 404 });

    if (deactivate) {
      await db.user.update({
        where: { id: agentId },
        data: { isAgent: false, agentCommissionRate: 0 },
      });
      await logActivity(user.username, 'DEACTIVATE_AGENT', `إلغاء وكالة ${agent.username}`);
      return NextResponse.json({ message: 'تم إلغاء حالة الوكيل' });
    }

    if (commissionRate !== undefined) {
      if (commissionRate < 0 || commissionRate > 50) {
        return NextResponse.json({ error: 'نسبة العمولة يجب أن تكون بين 0 و 50' }, { status: 400 });
      }
      await db.user.update({
        where: { id: agentId },
        data: { agentCommissionRate: commissionRate },
      });
      await logActivity(user.username, 'UPDATE_AGENT_RATE', `تحديث نسبة عمولة ${agent.username} إلى ${commissionRate}%`);
      return NextResponse.json({ message: 'تم تحديث نسبة العمولة' });
    }

    // Balance adjustment for agent (deposit/withdraw from admin)
    if (body.balanceAction && body.balanceAmount !== undefined) {
      const { balanceAction, balanceAmount, balanceNote } = body;
      const amount = parseFloat(String(balanceAmount));
      if (isNaN(amount) || amount <= 0) {
        return NextResponse.json({ error: 'المبلغ غير صالح' }, { status: 400 });
      }

      if (balanceAction === 'deposit') {
        await db.$transaction([
          db.user.update({ where: { id: agentId }, data: { balance: { increment: amount } } }),
          db.userActivity.create({
            data: { userId: agentId, action: 'ADMIN_DEPOSIT', details: `إيداع من الإدارة: ${balanceNote || ''}`, amount },
          }),
        ]);
        await logActivity(user.username, 'AGENT_DEPOSIT', `إيداع $${amount.toFixed(2)} لوكيل ${agent.username} ${balanceNote ? `- ${balanceNote}` : ''}`);
        return NextResponse.json({ message: `تم إيداع $${amount.toFixed(2)} لرصيد الوكيل` });
      }

      if (balanceAction === 'withdraw') {
        if (agent.balance < amount) {
          return NextResponse.json({ error: `رصيد الوكيل غير كافي (الرصيد الحالي: $${agent.balance.toFixed(2)})` }, { status: 400 });
        }
        await db.$transaction([
          db.user.update({ where: { id: agentId }, data: { balance: { decrement: amount } } }),
          db.userActivity.create({
            data: { userId: agentId, action: 'ADMIN_WITHDRAW', details: `سحب من الإدارة: ${balanceNote || ''}`, amount: -amount },
          }),
        ]);
        await logActivity(user.username, 'AGENT_WITHDRAW', `سحب $${amount.toFixed(2)} من وكيل ${agent.username} ${balanceNote ? `- ${balanceNote}` : ''}`);
        return NextResponse.json({ message: `تم سحب $${amount.toFixed(2)} من رصيد الوكيل` });
      }
    }

    return NextResponse.json({ error: 'لم يتم تحديد أي إجراء' }, { status: 400 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
