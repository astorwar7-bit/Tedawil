import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const { searchParams } = new URL(request.url);
    const reportType = searchParams.get('type') || 'users';

    if (reportType === 'users') {
      const users = await db.user.findMany({ where: { isAdmin: false }, select: { username: true, fullName: true, email: true, phone: true, balance: true, isActive: true, createdAt: true } });
      return NextResponse.json({ type: 'users', data: users });
    }
    if (reportType === 'transactions') {
      const profits = await db.dailyProfit.findMany({ include: { user: { select: { username: true } } }, orderBy: { date: 'desc' }, take: 1000 });
      return NextResponse.json({ type: 'transactions', data: profits });
    }
    if (reportType === 'withdrawals') {
      const withdrawals = await db.withdrawal.findMany({ include: { user: { select: { username: true } } }, orderBy: { createdAt: 'desc' } });
      return NextResponse.json({ type: 'withdrawals', data: withdrawals });
    }
    if (reportType === 'referralProfits') {
      const referralProfits = await db.dailyProfit.findMany({ where: { type: 'referral' }, include: { user: { select: { username: true } } } });
      return NextResponse.json({ type: 'referralProfits', data: referralProfits });
    }

    return NextResponse.json({ error: 'نوع التقرير غير صالح' }, { status: 400 });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}
