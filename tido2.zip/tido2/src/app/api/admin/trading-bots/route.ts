import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

// GET /api/admin/trading-bots
export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const bots = await db.tradingBot.findMany({
      orderBy: { sortOrder: 'asc' },
      include: { _count: { select: { subscriptions: { where: { isActive: true } } } } },
    });

    return NextResponse.json({ bots: bots.map(b => ({ ...b, activeSubscribers: b._count.subscriptions, _count: undefined })) });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

// POST /api/admin/trading-bots
export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { name, description, strategy, dailyReturn, riskLevel, minBalance, icon, color, isActive, sortOrder } = await request.json();

    if (!name || !strategy || dailyReturn === undefined || !riskLevel || minBalance === undefined) {
      return NextResponse.json({ error: 'جميع الحقول المطلوبة يجب ملؤها' }, { status: 400 });
    }
    if (dailyReturn < 0 || dailyReturn > 100) return NextResponse.json({ error: 'العائد اليومي يجب أن يكون بين 0 و 100' }, { status: 400 });

    const validRisk = ['منخفض', 'متوسط', 'عالي', 'عالي جداً'];
    if (!validRisk.includes(riskLevel)) return NextResponse.json({ error: 'مستوى المخاطرة غير صالح' }, { status: 400 });

    const bot = await db.tradingBot.create({
      data: {
        name, description: description || '', strategy,
        dailyReturn: parseFloat(dailyReturn), riskLevel,
        minBalance: parseFloat(minBalance), icon: icon || 'Bot',
        color: color || '#FFD700', isActive: isActive !== false, sortOrder: sortOrder || 0,
      },
    });

    await logActivity(user.username, 'create_bot', `إنشاء بوت تداول: ${name}`);
    return NextResponse.json({ bot, message: 'تم إنشاء البوت بنجاح' }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
