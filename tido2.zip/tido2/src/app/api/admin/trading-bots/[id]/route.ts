import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

// PUT /api/admin/trading-bots/[id]
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const existing = await db.tradingBot.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 });

    const body = await request.json();

    const updated = await db.tradingBot.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.strategy !== undefined && { strategy: body.strategy }),
        ...(body.dailyReturn !== undefined && { dailyReturn: parseFloat(body.dailyReturn) }),
        ...(body.riskLevel !== undefined && { riskLevel: body.riskLevel }),
        ...(body.minBalance !== undefined && { minBalance: parseFloat(body.minBalance) }),
        ...(body.icon !== undefined && { icon: body.icon }),
        ...(body.color !== undefined && { color: body.color }),
        ...(body.isActive !== undefined && { isActive: body.isActive }),
        ...(body.sortOrder !== undefined && { sortOrder: body.sortOrder }),
      },
    });

    await logActivity(user.username, 'update_bot', `تحديث بوت تداول: ${updated.name}`);
    return NextResponse.json({ bot: updated, message: 'تم تحديث البوت بنجاح' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

// DELETE /api/admin/trading-bots/[id]
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const existing = await db.tradingBot.findUnique({ where: { id } });
    if (!existing) return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 });

    await db.tradingBot.delete({ where: { id } });
    await logActivity(user.username, 'delete_bot', `حذف بوت تداول: ${existing.name}`);
    return NextResponse.json({ message: 'تم حذف البوت بنجاح' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
