import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const coupons = await db.coupon.findMany({
      include: { _count: { select: { usages: true, investments: true } } },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ coupons });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await request.json();
    const { code, discount, type, maxUses, maxUsesPerUser, minInvestment, expiresAt, isActive } = body;

    if (!code || !discount || !maxUses) {
      return NextResponse.json({ error: 'الكود والنسبة والحد الأقصى مطلوبة' }, { status: 400 });
    }

    const couponType = type === 'fixed' ? 'fixed' : 'percentage';

    if (couponType === 'percentage' && (discount <= 0 || discount > 100)) {
      return NextResponse.json({ error: 'نسبة الخصم يجب أن تكون بين 0 و 100' }, { status: 400 });
    }

    if (couponType === 'fixed' && discount <= 0) {
      return NextResponse.json({ error: 'مبلغ الخصم يجب أن يكون أكبر من صفر' }, { status: 400 });
    }

    const coupon = await db.coupon.create({
      data: {
        code: code.toUpperCase(),
        discount,
        type: couponType,
        maxUses,
        maxUsesPerUser: maxUsesPerUser || 1,
        minInvestment: minInvestment || 0,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        isActive: isActive !== false,
      },
    });
    await logActivity(user.username, 'CREATE_COUPON', `تم إنشاء كوبون: ${code} (نوع: ${couponType === 'fixed' ? 'مبلغ ثابت $' + discount : 'نسبة مئوية ' + discount + '%'}, حد لكل مستخدم: ${maxUsesPerUser || 1})`);
    return NextResponse.json({ message: 'تم إنشاء الكوبون بنجاح', coupon }, { status: 201 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await request.json();
    const { id, type, ...data } = body;
    if (!id) return NextResponse.json({ error: 'معرف الكوبون مطلوب' }, { status: 400 });

    if (data.expiresAt) data.expiresAt = new Date(data.expiresAt);
    if (type) data.type = type === 'fixed' ? 'fixed' : 'percentage';

    if (data.type === 'percentage' && data.discount !== undefined && (data.discount <= 0 || data.discount > 100)) {
      return NextResponse.json({ error: 'نسبة الخصم يجب أن تكون بين 0 و 100' }, { status: 400 });
    }

    const coupon = await db.coupon.update({ where: { id }, data });
    await logActivity(user.username, 'UPDATE_COUPON', `تم تحديث كوبون: ${coupon.code}`);
    return NextResponse.json({ message: 'تم تحديث الكوبون بنجاح', coupon });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'معرف الكوبون مطلوب' }, { status: 400 });

    const coupon = await db.coupon.findUnique({ where: { id } });
    await db.coupon.delete({ where: { id } });
    await logActivity(user.username, 'DELETE_COUPON', `تم حذف كوبون: ${coupon?.code || id}`);
    return NextResponse.json({ message: 'تم حذف الكوبون بنجاح' });
  } catch { return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 }); }
}
