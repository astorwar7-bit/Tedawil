import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const plan = await db.investmentPlan.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            investments: { where: { isActive: true } },
          },
        },
      },
    });

    if (!plan) {
      return NextResponse.json({ error: 'الخطة غير موجودة' }, { status: 404 });
    }

    return NextResponse.json({ plan });
  } catch (error) {
    console.error('Error fetching plan:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء جلب الخطة' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const body = await request.json();

    // Check plan exists
    const existing = await db.investmentPlan.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'الخطة غير موجودة' }, { status: 404 });
    }

    const { name, nameEn, minAmount, maxAmount, dailyRate, duration, icon, color, isActive, sortOrder, description } = body;

    // Validate if fields are provided
    if (name !== undefined && !name) {
      return NextResponse.json({ error: 'اسم الخطة مطلوب' }, { status: 400 });
    }
    if (nameEn !== undefined && !nameEn) {
      return NextResponse.json({ error: 'الاسم الإنجليزي مطلوب' }, { status: 400 });
    }
    if (minAmount !== undefined && minAmount < 0) {
      return NextResponse.json({ error: 'الحد الأدنى يجب أن يكون موجباً' }, { status: 400 });
    }
    if (maxAmount !== undefined && maxAmount < 0) {
      return NextResponse.json({ error: 'الحد الأقصى يجب أن يكون موجباً' }, { status: 400 });
    }
    if (dailyRate !== undefined && (dailyRate <= 0 || dailyRate > 100)) {
      return NextResponse.json({ error: 'النسبة اليومية يجب أن تكون بين 0 و 100' }, { status: 400 });
    }
    if (duration !== undefined && duration < 1) {
      return NextResponse.json({ error: 'المدة يجب أن تكون يوم واحد على الأقل' }, { status: 400 });
    }

    const updateData: Record<string, unknown> = {};
    if (name !== undefined) updateData.name = name;
    if (nameEn !== undefined) updateData.nameEn = nameEn;
    if (minAmount !== undefined) updateData.minAmount = parseFloat(minAmount);
    if (maxAmount !== undefined) updateData.maxAmount = parseFloat(maxAmount);
    if (dailyRate !== undefined) updateData.dailyRate = parseFloat(dailyRate);
    if (duration !== undefined) updateData.duration = parseInt(duration);
    if (icon !== undefined) updateData.icon = icon;
    if (color !== undefined) updateData.color = color;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (sortOrder !== undefined) updateData.sortOrder = parseInt(sortOrder);
    if (description !== undefined) updateData.description = description || null;

    const plan = await db.investmentPlan.update({
      where: { id },
      data: updateData,
    });

    await logActivity(user.username, 'UPDATE_PLAN', `تم تحديث خطة استثمار: ${plan.name} (${plan.nameEn})`);

    return NextResponse.json({ message: 'تم تحديث الخطة بنجاح', plan });
  } catch (error) {
    console.error('Error updating plan:', error);
    const msg = error instanceof Error ? error.message : 'حدث خطأ أثناء تحديث الخطة';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;

    // Check plan exists
    const plan = await db.investmentPlan.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            investments: { where: { isActive: true } },
          },
        },
      },
    });

    if (!plan) {
      return NextResponse.json({ error: 'الخطة غير موجودة' }, { status: 404 });
    }

    // Prevent deletion if active investments exist
    if (plan._count.investments > 0) {
      return NextResponse.json(
        { error: `لا يمكن حذف الخطة "${plan.name}" لأنها تحتوي على ${plan._count.investments} استثمار(ات) نشط(ة). يرجى تعطيلها بدلاً من حذفها.` },
        { status: 400 }
      );
    }

    await db.investmentPlan.delete({ where: { id } });

    await logActivity(user.username, 'DELETE_PLAN', `تم حذف خطة استثمار: ${plan.name} (${plan.nameEn})`);

    return NextResponse.json({ message: 'تم حذف الخطة بنجاح' });
  } catch (error) {
    console.error('Error deleting plan:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء حذف الخطة' }, { status: 500 });
  }
}

// Toggle plan active status
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;

    const plan = await db.investmentPlan.findUnique({ where: { id } });
    if (!plan) {
      return NextResponse.json({ error: 'الخطة غير موجودة' }, { status: 404 });
    }

    const updated = await db.investmentPlan.update({
      where: { id },
      data: { isActive: !plan.isActive },
    });

    const statusText = updated.isActive ? 'تفعيل' : 'تعطيل';
    await logActivity(user.username, 'TOGGLE_PLAN', `تم ${statusText} خطة استثمار: ${plan.name} (${plan.nameEn})`);

    return NextResponse.json({
      message: `تم ${updated.isActive ? 'تفعيل' : 'تعطيل'} الخطة بنجاح`,
      plan: updated,
    });
  } catch (error) {
    console.error('Error toggling plan:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء تغيير حالة الخطة' }, { status: 500 });
  }
}
