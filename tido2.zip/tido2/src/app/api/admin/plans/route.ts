import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const plans = await db.investmentPlan.findMany({
      orderBy: { sortOrder: 'asc' },
      include: {
        _count: {
          select: {
            investments: { where: { isActive: true } },
          },
        },
      },
    });

    return NextResponse.json({ plans });
  } catch (error) {
    console.error('Error fetching admin plans:', error);
    return NextResponse.json({ error: 'حدث خطأ أثناء جلب الخطط' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { name, nameEn, minAmount, maxAmount, dailyRate, duration, icon, color, isActive, sortOrder, description } = body;

    // Validate required fields
    if (!name || !nameEn || minAmount == null || maxAmount == null || !dailyRate || !duration || !icon || !color) {
      return NextResponse.json(
        { error: 'جميع الحقول مطلوبة (الاسم، الاسم الإنجليزي، الحد الأدنى، الحد الأقصى، النسبة اليومية، المدة، الأيقونة، اللون)' },
        { status: 400 }
      );
    }

    if (minAmount < 0 || maxAmount < 0) {
      return NextResponse.json({ error: 'المبالغ يجب أن تكون موجبة' }, { status: 400 });
    }

    if (minAmount > maxAmount && maxAmount !== 0) {
      return NextResponse.json({ error: 'الحد الأدنى يجب أن يكون أقل من الحد الأقصى' }, { status: 400 });
    }

    if (dailyRate <= 0 || dailyRate > 100) {
      return NextResponse.json({ error: 'النسبة اليومية يجب أن تكون بين 0 و 100' }, { status: 400 });
    }

    if (duration < 1) {
      return NextResponse.json({ error: 'المدة يجب أن تكون يوم واحد على الأقل' }, { status: 400 });
    }

    const plan = await db.investmentPlan.create({
      data: {
        name,
        nameEn,
        minAmount: parseFloat(minAmount),
        maxAmount: parseFloat(maxAmount),
        dailyRate: parseFloat(dailyRate),
        duration: parseInt(duration),
        icon,
        color,
        isActive: isActive !== false,
        sortOrder: sortOrder != null ? parseInt(sortOrder) : 0,
        description: description || null,
      },
    });

    await logActivity(user.username, 'CREATE_PLAN', `تم إنشاء خطة استثمار: ${name} (${nameEn})`);

    return NextResponse.json({ message: 'تم إنشاء الخطة بنجاح', plan }, { status: 201 });
  } catch (error) {
    console.error('Error creating plan:', error);
    const msg = error instanceof Error ? error.message : 'حدث خطأ أثناء إنشاء الخطة';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
