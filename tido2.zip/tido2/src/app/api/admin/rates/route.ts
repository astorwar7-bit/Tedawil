import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings, logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const settings = await getSettings();
    const logs = await db.dailyRateLog.findMany({ orderBy: { createdAt: 'desc' }, take: 30 });

    return NextResponse.json({ settings, logs });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { action } = body;

    const settings = await getSettings();
    const minRate = body.minDailyRate || settings.minDailyRate;
    const maxRate = body.maxDailyRate || settings.maxDailyRate;

    if (action === 'apply') {
      const rate = parseFloat((Math.random() * (maxRate - minRate) + minRate).toFixed(2));

      const activeInvestments = await db.investment.findMany({ where: { isActive: true } });

      const results = await db.$transaction(
        activeInvestments.map((inv) => {
          const profit = inv.amount * (rate / 100);
          return db.dailyProfit.create({
            data: {
              userId: inv.userId,
              investmentId: inv.id,
              amount: parseFloat(profit.toFixed(2)),
              type: 'investment',
              rate,
            },
          });
        })
      );

      // Referral bonuses
      for (const inv of activeInvestments) {
        const referredBy = (await db.user.findUnique({ where: { id: inv.userId } }))?.referredBy;
        if (referredBy) {
          const profit = inv.amount * (rate / 100);
          const referralBonus = profit * (settings.referralBonusRate / 100);
          await db.dailyProfit.create({
            data: {
              userId: referredBy,
              amount: parseFloat(referralBonus.toFixed(2)),
              type: 'referral',
              rate: settings.referralBonusRate,
            },
          });
        }
      }

      await db.dailyRateLog.create({
        data: { rate, affectedCount: activeInvestments.length, appliedBy: user.username },
      });

      await logActivity(user.username, 'APPLY_RATE', `تم تطبيق نسبة ${rate}% على ${activeInvestments.length} مستثمر`);

      return NextResponse.json({ message: `تم توزيع الأرباح بنسبة ${rate}% على ${activeInvestments.length} مستثمر`, rate, affectedCount: activeInvestments.length });
    }

    if (action === 'simulate') {
      const rate = parseFloat((Math.random() * (maxRate - minRate) + minRate).toFixed(2));
      const activeInvestments = await db.investment.findMany({ where: { isActive: true } });
      const totalDistribution = activeInvestments.reduce((sum, inv) => sum + inv.amount * (rate / 100), 0);

      return NextResponse.json({ simulatedRate: rate, affectedCount: activeInvestments.length, totalDistribution: parseFloat(totalDistribution.toFixed(2)) });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
