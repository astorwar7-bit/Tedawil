import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const search = searchParams.get('search') || '';

    const where: Record<string, unknown> = { isAdmin: false };
    if (search) {
      where.OR = [
        { username: { contains: search } },
        { email: { contains: search } },
        { phone: { contains: search } },
      ];
    }

    const [users, total] = await Promise.all([
      db.user.findMany({
        where, orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit, take: limit,
        select: { id: true, username: true, fullName: true, email: true, phone: true, avatar: true, balance: true, isActive: true, createdAt: true },
      }),
      db.user.count({ where }),
    ]);

    return NextResponse.json({ users, total, pages: Math.ceil(total / limit) });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { userId, action, balance, reason } = body;

    if (action === 'toggleActive') {
      const target = await db.user.findUnique({ where: { id: userId } });
      if (!target) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

      await db.user.update({ where: { id: userId }, data: { isActive: !target.isActive } });
      await logActivity(user.username, 'TOGGLE_USER', `تم ${target.isActive ? 'تعليق' : 'تفعيل'} حساب ${target.username}`);

      return NextResponse.json({ message: `تم ${target.isActive ? 'تعليق' : 'تفعيل'} الحساب` });
    }

    if (action === 'updateBalance') {
      if (!balance || !reason) return NextResponse.json({ error: 'يرجى إدخال المبلغ والسبب' }, { status: 400 });

      const target = await db.user.findUnique({ where: { id: userId } });
      if (!target) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

      await db.user.update({ where: { id: userId }, data: { balance: { increment: balance } } });
      await logActivity(user.username, 'UPDATE_BALANCE', `تعديل رصيد ${target.username}: ${balance > 0 ? '+' : ''}${balance}. السبب: ${reason}`);

      return NextResponse.json({ message: 'تم تحديث الرصيد' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    if (!userId) return NextResponse.json({ error: 'معرف المستخدم مطلوب' }, { status: 400 });

    const target = await db.user.findUnique({ where: { id: userId } });
    if (!target) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

    await db.user.delete({ where: { id: userId } });
    await logActivity(user.username, 'DELETE_USER', `تم حذف المستخدم ${target.username}`);

    return NextResponse.json({ message: 'تم حذف المستخدم وجميع بياناته' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
