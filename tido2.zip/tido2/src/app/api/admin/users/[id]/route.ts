import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { logActivity } from '@/lib/helpers';
import { hashPassword } from '@/lib/auth';

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const target = await db.user.findUnique({
      where: { id },
      select: { id: true, username: true, fullName: true, email: true, phone: true, avatar: true, balance: true, isActive: true, referralCode: true, referredBy: true, createdAt: true },
    });
    if (!target) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

    const [investments, profits, withdrawals, referredUsers] = await Promise.all([
      db.investment.findMany({ where: { userId: id }, orderBy: { createdAt: 'desc' } }),
      db.dailyProfit.findMany({ where: { userId: id }, orderBy: { date: 'desc' }, take: 50 }),
      db.withdrawal.findMany({ where: { userId: id }, orderBy: { createdAt: 'desc' } }),
      db.user.findMany({ where: { referredBy: id }, select: { username: true, createdAt: true } }),
    ]);

    return NextResponse.json({ user: target, investments, profits, withdrawals, referredUsers });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getRequestUser(request);
    if (!user?.isAdmin) return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { id } = await params;
    const body = await request.json();
    const { action } = body;

    const target = await db.user.findUnique({ where: { id } });
    if (!target) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

    if (action === 'reset_password') {
      const { newPassword } = body;
      if (!newPassword) return NextResponse.json({ error: 'كلمة المرور الجديدة مطلوبة' }, { status: 400 });
      if (newPassword.length < 8 || !/[A-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
        return NextResponse.json({ error: 'كلمة السر يجب أن تكون 8 أحرف على الأقل وتحتوي على حرف كبير ورقم' }, { status: 400 });
      }

      const hashedPassword = await hashPassword(newPassword);
      await db.user.update({ where: { id }, data: { password: hashedPassword } });
      await logActivity(user.username, 'RESET_PASSWORD', `تم إعادة تعيين كلمة مرور المستخدم ${target.username}`);

      return NextResponse.json({ message: 'تم إعادة تعيين كلمة المرور' });
    }

    if (action === 'update_balance') {
      const { balance, reason } = body;
      if (balance === undefined || !reason) return NextResponse.json({ error: 'يرجى إدخال المبلغ والسبب' }, { status: 400 });

      await db.user.update({ where: { id }, data: { balance: { increment: balance } } });
      await logActivity(user.username, 'UPDATE_BALANCE', `تعديل رصيد ${target.username}: ${balance > 0 ? '+' : ''}${balance}. السبب: ${reason}`);

      return NextResponse.json({ message: 'تم تحديث الرصيد' });
    }

    if (action === 'toggle_active') {
      await db.user.update({ where: { id }, data: { isActive: !target.isActive } });
      await logActivity(user.username, 'TOGGLE_USER', `تم ${target.isActive ? 'تعليق' : 'تفعيل'} حساب ${target.username}`);

      return NextResponse.json({ message: `تم ${target.isActive ? 'تعليق' : 'تفعيل'} الحساب` });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
