import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    }
    const fullUser = await db.user.findUnique({
      where: { id: user.userId },
      select: { id: true, username: true, fullName: true, email: true, phone: true, avatar: true, balance: true, isAdmin: true, isAgent: true, referralCode: true, createdAt: true },
    });
    if (!fullUser) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    return NextResponse.json({ user: fullUser });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
