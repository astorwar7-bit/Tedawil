import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username } = body;

    if (!username || !username.trim()) {
      return NextResponse.json({ error: 'يرجى إدخال اسم المستخدم' }, { status: 400 });
    }

    const user = await db.user.findFirst({
      where: {
        OR: [{ username: username.trim() }, { email: username.trim() }],
      },
      include: { pin: true },
    });

    // For security: always return exists:true to prevent user enumeration
    // But we need to tell the frontend whether a PIN is set for the actual user
    if (user) {
      const hasPin = !!user.pin && !!user.pin.pinHash;
      return NextResponse.json({
        exists: true,
        hasPin,
        username: user.username,
      });
    }

    // User doesn't exist — return exists:true with hasPin:false
    // The reset-password endpoint will reject anyway
    return NextResponse.json({
      exists: true,
      hasPin: false,
      username: username.trim(),
    });
  } catch (error: unknown) {
    console.error('Forgot password error:', error);
    const message = error instanceof Error ? error.message : 'حدث خطأ أثناء التحقق';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
