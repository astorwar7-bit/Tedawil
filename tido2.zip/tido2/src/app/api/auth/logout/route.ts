import { NextResponse } from 'next/server';
import { clearTokenCookie } from '@/lib/middleware';

export async function POST() {
  const response = NextResponse.json({ message: 'تم تسجيل الخروج بنجاح' });
  clearTokenCookie(response);
  return response;
}
