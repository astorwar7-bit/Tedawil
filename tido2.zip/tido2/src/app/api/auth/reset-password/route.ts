import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, comparePassword } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, pin, newPassword } = body;

    if (!username || !username.trim()) {
      return NextResponse.json({ error: 'يرجى إدخال اسم المستخدم' }, { status: 400 });
    }

    if (!newPassword || newPassword.length < 8) {
      return NextResponse.json({ error: 'كلمة السر يجب أن تكون 8 أحرف على الأقل' }, { status: 400 });
    }

    const user = await db.user.findFirst({
      where: {
        OR: [{ username: username.trim() }, { email: username.trim() }],
      },
      include: { pin: true },
    });

    if (!user) {
      // Don't reveal if user exists
      return NextResponse.json({ error: 'اسم المستخدم غير موجود' }, { status: 404 });
    }

    if (!user.isActive) {
      return NextResponse.json({ error: 'حسابك موقوف. يرجى التواصل مع الإدارة' }, { status: 403 });
    }

    // Check if user has a PIN set
    const userPin = user.pin;
    if (!userPin || !userPin.pinHash) {
      return NextResponse.json({
        error: 'لم تقم بإعداد رمز PIN. يرجى التواصل مع الدعم الفني لاستعادة كلمة السر.',
        needsSupport: true,
      }, { status: 400 });
    }

    // Verify PIN
    if (!pin || pin.length !== 4) {
      return NextResponse.json({ error: 'يرجى إدخال رمز PIN المكون من 4 أرقام' }, { status: 400 });
    }

    const pinValid = await comparePassword(pin, userPin.pinHash);
    if (!pinValid) {
      return NextResponse.json({ error: 'رمز PIN غير صحيح' }, { status: 401 });
    }

    // Check new password is different from current
    const samePassword = await comparePassword(newPassword, user.password);
    if (samePassword) {
      return NextResponse.json({ error: 'كلمة السر الجديدة يجب أن تختلف عن كلمة السر الحالية' }, { status: 400 });
    }

    // Hash new password and update
    const hashedPassword = await hashPassword(newPassword);
    await db.user.update({
      where: { id: user.id },
      data: { password: hashedPassword },
    });

    // Delete all user's tokens/sessions (clear localStorage on client side)
    // We clear the cookie - client will also clear localStorage
    const response = NextResponse.json({
      message: 'تم تغيير كلمة السر بنجاح. يرجى تسجيل الدخول بكلمة السر الجديدة.',
      success: true,
    });

    // Clear the auth cookie
    response.cookies.set('token', '', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 0,
      path: '/',
    });

    return response;
  } catch (error: unknown) {
    console.error('Reset password error:', error);
    const message = error instanceof Error ? error.message : 'حدث خطأ أثناء إعادة تعيين كلمة السر';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
