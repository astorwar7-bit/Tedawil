import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const code = request.nextUrl.searchParams.get('code');
    if (!code) return NextResponse.json({ valid: false, error: 'لم يتم تقديم كود' }, { status: 400 });

    const referrer = await db.user.findUnique({ where: { referralCode: code }, select: { username: true } });
    if (!referrer) return NextResponse.json({ valid: false, error: 'كود غير صحيح' });

    return NextResponse.json({ valid: true, username: referrer.username });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
