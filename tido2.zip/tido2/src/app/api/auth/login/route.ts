import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { comparePassword, generateToken } from '@/lib/auth';
import { setTokenCookie } from '@/lib/middleware';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { usernameOrEmail, password } = body;

    if (!usernameOrEmail || !password) {
      return NextResponse.json({ error: 'يرجى إدخال بيانات الدخول' }, { status: 400 });
    }

    const user = await db.user.findFirst({
      where: {
        OR: [{ username: usernameOrEmail }, { email: usernameOrEmail }],
      },
    });

    if (!user || !(await comparePassword(password, user.password))) {
      return NextResponse.json({ error: 'اسم المستخدم أو كلمة السر غير صحيحة' }, { status: 401 });
    }

    if (!user.isActive) {
      return NextResponse.json({ error: 'حسابك موقوف. يرجى التواصل مع الإدارة' }, { status: 403 });
    }

    const token = generateToken({
      userId: user.id,
      username: user.username,
      email: user.email,
      isAdmin: user.isAdmin,
      isAgent: user.isAgent,
    });

    const response = NextResponse.json({
      message: 'تم تسجيل الدخول بنجاح',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        isAdmin: user.isAdmin,
        isAgent: user.isAgent,
      },
    });
    setTokenCookie(response, token);
    return response;
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ أثناء تسجيل الدخول';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
