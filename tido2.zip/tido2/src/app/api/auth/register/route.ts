import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, generateToken, generateUniqueReferralCode } from '@/lib/auth';
import { setTokenCookie } from '@/lib/middleware';
import { getSettings } from '@/lib/helpers';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { fullName, username, email, phone, password, referralCode } = body;

    if (!fullName || !username || !email || !password) {
      return NextResponse.json({ error: 'جميع الحقول المطلوبة يجب أن تُملأ' }, { status: 400 });
    }

    // Validate username
    if (!/^[a-zA-Z0-9]{3,}$/.test(username)) {
      return NextResponse.json({ error: 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل (أحرف إنجليزية وأرقام فقط)' }, { status: 400 });
    }

    // Validate password
    if (password.length < 8 || !/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
      return NextResponse.json({ error: 'كلمة السر يجب أن تكون 8 أحرف على الأقل وتحتوي على حرف كبير ورقم' }, { status: 400 });
    }

    // Check unique fields
    const existingUser = await db.user.findFirst({
      where: { OR: [{ username }, { email }] }
    });
    if (existingUser) {
      return NextResponse.json({ error: 'اسم المستخدم أو البريد الإلكتروني مستخدم بالفعل' }, { status: 400 });
    }

    // Get settings for bonuses
    const settings = await getSettings();
    const welcomeBonus = settings.welcomeBonus || 0;
    const referralFixedBonus = settings.referralFixedBonus || 0;

    // Get client IP for fraud prevention
    const clientIp = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim()
      || request.headers.get('x-real-ip')
      || 'unknown';

    // Check referral code with fraud prevention
    let referredById: string | undefined;
    let referrerUsername: string | undefined;
    if (referralCode) {
      const referrer = await db.user.findUnique({
        where: { referralCode },
        select: { id: true, username: true, email: true, registerIp: true },
      });

      if (!referrer) {
        return NextResponse.json({ error: 'كود الإحالة غير صحيح' }, { status: 400 });
      }

      // Fraud prevention: prevent self-referral via same email pattern
      if (referrer.email === email) {
        return NextResponse.json({ error: 'لا يمكنك استخدام كود الإحالة الخاص بك' }, { status: 400 });
      }

      // Fraud prevention: IP-based detection
      // Check if the referrer registered from the same IP (block if so)
      if (referrer.registerIp && referrer.registerIp !== 'unknown' && clientIp !== 'unknown') {
        const ipMatch = referrer.registerIp === clientIp;
        if (ipMatch) {
          return NextResponse.json({ error: 'لا يمكن استخدام كود الإحالة من نفس الجهاز' }, { status: 400 });
        }
      }

      // Fraud prevention: check if multiple accounts from this IP already used referral
      if (clientIp !== 'unknown') {
        const ipRefCount = await db.user.count({
          where: {
            referredBy: referrer.id,
            registerIp: clientIp,
          },
        });
        if (ipRefCount >= 2) {
          return NextResponse.json({ error: 'تم تجاوز الحد المسموح للإحالات من هذا الجهاز' }, { status: 400 });
        }
      }

      referredById = referrer.id;
      referrerUsername = referrer.username;
    }

    const hashedPassword = await hashPassword(password);

    // Generate a unique referral code with collision handling
    const uniqueReferralCode = await generateUniqueReferralCode();

    // Create user with welcome bonus
    const user = await db.user.create({
      data: {
        fullName,
        username,
        email,
        phone: phone || '',
        password: hashedPassword,
        referralCode: uniqueReferralCode,
        referredBy: referredById,
        balance: welcomeBonus,
        registerIp: clientIp,
      },
    });

    // Welcome notification with bonus info
    await db.notification.create({
      data: {
        userId: user.id,
        title: 'مرحباً بك!',
        message: welcomeBonus > 0
          ? `تم إنشاء حسابك بنجاح وحصولك على مكافأة ترحيب $${welcomeBonus.toFixed(2)}. يمكنك الآن البدء بالاستثمار وتحقيق أرباح يومية.`
          : 'تم إنشاء حسابك بنجاح. يمكنك الآن البدء بالاستثمار وتحقيق أرباح يومية.',
        type: 'bonus',
      },
    });

    // Record welcome bonus in DailyProfit for tracking
    if (welcomeBonus > 0) {
      await db.$transaction([
        db.dailyProfit.create({
          data: {
            userId: user.id,
            amount: welcomeBonus,
            type: 'welcome_bonus',
            rate: 0,
          },
        }),
        db.userActivity.create({
          data: {
            userId: user.id,
            action: 'WELCOME_BONUS',
            details: `مكافأة ترحيب عند التسجيل: $${welcomeBonus.toFixed(2)}`,
            amount: welcomeBonus,
          },
        }),
      ]);
    }

    // Notify about referral relationship
    if (referredById) {
      await db.notification.create({
        data: {
          userId: user.id,
          title: 'تم التسجيل بكود إحالة',
          message: `تم تسجيلك بنجاح بكود إحالة ${referrerUsername}. سيحصل ${referrerUsername} على مكافأة $${referralFixedBonus.toFixed(2)} بعد إيداعك الأول. كما يحصل على ${(settings.referralBonusRate || 5)}% من أرباحك اليومية تُضاف لرصيده!`,
          type: 'referral',
        },
      });

      await db.notification.create({
        data: {
          userId: referredById,
          title: 'مستخدم جديد عبر كود إحالتك!',
          message: `قام ${username} بالتسجيل باستخدام كود إحالتك. ستحصل على مكافأة $${referralFixedBonus.toFixed(2)} بعد قيامه بأول إيداع حقيقي.`,
          type: 'referral',
        },
      });
    }

    const token = generateToken({
      userId: user.id,
      username: user.username,
      email: user.email,
      isAdmin: user.isAdmin,
    });

    const response = NextResponse.json({
      message: welcomeBonus > 0
        ? `تم إنشاء حسابك بنجاح! حصلت على مكافأة ترحيب $${welcomeBonus.toFixed(2)}`
        : 'تم إنشاء حسابك بنجاح',
      token,
      user: { id: user.id, username: user.username, email: user.email, fullName: user.fullName, balance: user.balance },
    });
    setTokenCookie(response, token);
    return response;
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ أثناء التسجيل';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
