import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

const MAX_FOLLOWS = 3;

const MOCK_TRADERS = [
  { id: 'trader_1', username: 'Ahmed_Pro', winRate: 78.5, avgReturn: 3.2, totalProfit: 15420, level: 'ذهبي' },
  { id: 'trader_2', username: 'Sara_Trader', winRate: 72.1, avgReturn: 2.8, totalProfit: 12350, level: 'ذهبي' },
  { id: 'trader_3', username: 'Omar_FX', winRate: 65.3, avgReturn: 2.1, totalProfit: 8900, level: 'فضي' },
  { id: 'trader_4', username: 'Lina_Crypto', winRate: 81.2, avgReturn: 4.1, totalProfit: 22100, level: 'ماسي' },
  { id: 'trader_5', username: 'Khalid_Bull', winRate: 69.8, avgReturn: 2.5, totalProfit: 10200, level: 'فضي' },
  { id: 'trader_6', username: 'Mona_Invest', winRate: 75.6, avgReturn: 3.0, totalProfit: 13800, level: 'ذهبي' },
];

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const activeTrades = await db.copyTrade.findMany({
      where: { userId: user.userId, isActive: true },
    });

    const totalCopyProfit = activeTrades.reduce((sum, t) => sum + t.totalProfit, 0);
    const totalCopyVolume = activeTrades.length;

    const followedIds = new Set(activeTrades.map(t => t.traderUsername));
    const traders = MOCK_TRADERS.map(t => ({
      ...t,
      isFollowed: followedIds.has(t.username),
    }));

    return NextResponse.json({
      traders,
      activeTrades,
      totalCopyProfit,
      totalCopyVolume,
      maxFollows: MAX_FOLLOWS,
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { action, traderId, traderUsername } = body;

    if (action === 'follow') {
      const activeCount = await db.copyTrade.count({
        where: { userId: user.userId, isActive: true },
      });
      if (activeCount >= MAX_FOLLOWS) {
        return NextResponse.json({ error: `يمكنك متابعة ${MAX_FOLLOWS} متداولين فقط` }, { status: 400 });
      }

      const existing = await db.copyTrade.findFirst({
        where: { userId: user.userId, traderUsername },
      });
      if (existing) {
        if (existing.isActive) {
          return NextResponse.json({ error: 'أنت بالفعل تتابع هذا المتداول' }, { status: 400 });
        }
        await db.copyTrade.update({ where: { id: existing.id }, data: { isActive: true } });
      } else {
        const trader = MOCK_TRADERS.find(t => t.id === traderId);
        await db.copyTrade.create({
          data: {
            userId: user.userId,
            traderUsername: traderUsername || trader?.username || '',
            traderWinRate: trader?.winRate || 0,
            avgReturn: trader?.avgReturn || 0,
          },
        });
      }

      await db.userActivity.create({
        data: {
          userId: user.userId,
          action: 'copy_follow',
          details: `متابعة المتداول ${traderUsername}`,
        },
      });

      return NextResponse.json({ message: `تمت متابعة ${traderUsername} بنجاح` });
    }

    if (action === 'unfollow') {
      await db.copyTrade.updateMany({
        where: { userId: user.userId, traderUsername, isActive: true },
        data: { isActive: false },
      });

      await db.userActivity.create({
        data: {
          userId: user.userId,
          action: 'copy_unfollow',
          details: `إلغاء متابعة ${traderUsername}`,
        },
      });

      return NextResponse.json({ message: `تم إلغاء متابعة ${traderUsername}` });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 });

    await db.copyTrade.deleteMany({
      where: { id, userId: user.userId },
    });

    return NextResponse.json({ message: 'تم الحذف بنجاح' });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
