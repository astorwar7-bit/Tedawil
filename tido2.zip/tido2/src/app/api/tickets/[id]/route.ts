import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { id } = await params;

    const ticket = await db.supportTicket.findUnique({
      where: { id },
      include: {
        replies: {
          orderBy: { createdAt: 'asc' },
          include: {
            user: { select: { username: true, fullName: true } },
          },
        },
        user: { select: { username: true, fullName: true } },
      },
    });

    if (!ticket) {
      return NextResponse.json({ error: 'التذكرة غير موجودة' }, { status: 404 });
    }

    if (ticket.userId !== user.userId && !user.isAdmin) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    return NextResponse.json({ success: true, data: { ticket } });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { id } = await params;
    const body = await request.json();
    const { message } = body;

    if (!message || message.trim().length === 0) {
      return NextResponse.json({ error: 'يرجى إدخال الرسالة' }, { status: 400 });
    }

    if (message.length > 5000) {
      return NextResponse.json({ error: 'الرسالة طويلة جداً' }, { status: 400 });
    }

    const ticket = await db.supportTicket.findUnique({ where: { id } });

    if (!ticket) {
      return NextResponse.json({ error: 'التذكرة غير موجودة' }, { status: 404 });
    }

    if (ticket.userId !== user.userId && !user.isAdmin) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    if (ticket.status === 'closed') {
      return NextResponse.json({ error: 'التذكرة مغلقة' }, { status: 400 });
    }

    // If user is replying, change status back to open
    const updateData: Record<string, unknown> = {};
    if (!user.isAdmin && ticket.status !== 'open') {
      updateData.status = 'open';
    }

    const reply = await db.ticketReply.create({
      data: {
        ticketId: id,
        userId: user.userId,
        message,
        isAdmin: user.isAdmin || false,
      },
    });

    if (Object.keys(updateData).length > 0) {
      await db.supportTicket.update({
        where: { id },
        data: updateData,
      });
    }

    return NextResponse.json({ success: true, data: { reply } }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { id } = await params;

    const ticket = await db.supportTicket.findUnique({ where: { id } });

    if (!ticket) {
      return NextResponse.json({ error: 'التذكرة غير موجودة' }, { status: 404 });
    }

    if (ticket.userId !== user.userId) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }

    const body = await request.json();
    const { status } = body;

    if (status === 'closed') {
      const updated = await db.supportTicket.update({
        where: { id },
        data: { status: 'closed' },
      });

      return NextResponse.json({ success: true, data: { ticket: updated } });
    }

    return NextResponse.json({ error: 'يمكنك فقط إغلاق التذكرة' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
