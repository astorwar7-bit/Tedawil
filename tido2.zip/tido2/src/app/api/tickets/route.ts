import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status') || '';

    const where: Record<string, unknown> = { userId: user.userId };
    if (status && status !== 'all') where.status = status;

    const [tickets, total] = await Promise.all([
      db.supportTicket.findMany({
        where,
        orderBy: { updatedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          replies: {
            orderBy: { createdAt: 'desc' },
            take: 1,
            select: { message: true, createdAt: true, isAdmin: true },
          },
        },
      }),
      db.supportTicket.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: { tickets, total, pages: Math.ceil(total / limit) },
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { subject, message, category, priority } = body;

    if (!subject || !message) {
      return NextResponse.json({ error: 'يرجى إدخال الموضوع والرسالة' }, { status: 400 });
    }

    if (subject.length > 200) {
      return NextResponse.json({ error: 'الموضوع طويل جداً' }, { status: 400 });
    }

    if (message.length > 5000) {
      return NextResponse.json({ error: 'الرسالة طويلة جداً' }, { status: 400 });
    }

    const validCategories = ['general', 'deposit', 'withdrawal', 'investment', 'technical', 'other'];
    const validPriorities = ['low', 'medium', 'high', 'urgent'];

    const ticket = await db.supportTicket.create({
      data: {
        userId: user.userId,
        subject,
        message,
        category: validCategories.includes(category) ? category : 'general',
        priority: validPriorities.includes(priority) ? priority : 'medium',
      },
    });

    return NextResponse.json({ success: true, data: { ticket } }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
