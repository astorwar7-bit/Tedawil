import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { comparePassword, hashPassword } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const fullUser = await db.user.findUnique({
      where: { id: user.userId },
      select: { id: true, username: true, fullName: true, email: true, phone: true, avatar: true, referralCode: true, createdAt: true },
    });
    if (!fullUser) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });
    return NextResponse.json({ user: fullUser });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { action } = body;

    if (action === 'updateProfile') {
      const { fullName, email, phone, avatar } = body;

      if (email) {
        const existing = await db.user.findFirst({ where: { email, NOT: { id: user.userId } } });
        if (existing) return NextResponse.json({ error: 'البريد الإلكتروني مستخدم بالفعل' }, { status: 400 });
      }

      const updateData: Record<string, string> = {};
      if (fullName) updateData.fullName = fullName;
      if (email) updateData.email = email;
      if (phone) updateData.phone = phone;
      if (avatar) updateData.avatar = avatar;

      await db.user.update({ where: { id: user.userId }, data: updateData });
      return NextResponse.json({ message: 'تم تحديث البيانات بنجاح' });
    }

    if (action === 'changePassword') {
      const { currentPassword, newPassword } = body;
      if (!currentPassword || !newPassword) {
        return NextResponse.json({ error: 'يرجى إدخال كلمتي السر' }, { status: 400 });
      }

      const fullUser = await db.user.findUnique({ where: { id: user.userId } });
      if (!fullUser || !(await comparePassword(currentPassword, fullUser.password))) {
        return NextResponse.json({ error: 'كلمة السر الحالية غير صحيحة' }, { status: 400 });
      }

      if (newPassword.length < 8 || !/[A-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
        return NextResponse.json({ error: 'كلمة السر الجديدة يجب أن تكون 8 أحرف على الأقل وتحتوي على حرف كبير ورقم' }, { status: 400 });
      }

      await db.user.update({
        where: { id: user.userId },
        data: { password: await hashPassword(newPassword) },
      });

      return NextResponse.json({ message: 'تم تغيير كلمة السر بنجاح' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
