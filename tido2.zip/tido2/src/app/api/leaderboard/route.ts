import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

const LEVELS: Record<string, string> = { '0': 'مبتدئ', '500': 'برونزي', '2000': 'فضي', '10000': 'ذهبي', '50000': 'ماسي' };

function getLevel(totalProfit: number): string {
  if (totalProfit >= 50000) return 'ماسي';
  if (totalProfit >= 10000) return 'ذهبي';
  if (totalProfit >= 2000) return 'فضي';
  if (totalProfit >= 500) return 'برونزي';
  return 'مبتدئ';
}

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || 'all-time';

    let dateFilter: Record<string, unknown> = {};
    if (period === 'daily') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      dateFilter = { gte: today };
    } else if (period === 'weekly') {
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      dateFilter = { gte: weekAgo };
    } else if (period === 'monthly') {
      const monthAgo = new Date();
      monthAgo.setDate(monthAgo.getDate() - 30);
      dateFilter = { gte: monthAgo };
    }

    const users = await db.user.findMany({
      where: { isActive: true, isAdmin: false },
      include: {
        profits: { where: dateFilter ? { date: dateFilter } : undefined },
        investments: true,
      },
    });

    const leaderboard = users
      .map(u => {
        const totalProfit = u.profits.reduce((s, p) => s + p.amount, 0);
        const totalInvested = u.investments.reduce((s, i) => s + i.amount, 0);
        // Calculate consistent win rate from actual profit data
        const profitableDays = u.profits.filter(p => p.amount > 0).length;
        const totalDays = u.profits.length;
        const winRate = totalDays > 0 ? parseFloat(((profitableDays / totalDays) * 100).toFixed(1)) : 0;
        return {
          userId: u.id,
          username: u.username,
          fullName: u.fullName || u.username,
          avatar: u.avatar,
          totalProfit,
          totalInvested,
          winRate,
          level: getLevel(totalProfit),
          rank: 0,
        };
      })
      .sort((a, b) => b.totalProfit - a.totalProfit)
      .map((entry, index) => ({ ...entry, rank: index + 1 }));

    return NextResponse.json({
      leaderboard,
      totalParticipants: leaderboard.length,
      period,
    });
  } catch (error) {
    console.error('Leaderboard error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
