import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

function generateTeamCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const myMembership = await db.teamMember.findFirst({
      where: { userId: user.userId },
      include: {
        team: {
          include: {
            members: {
              include: { user: { select: { id: true, username: true, fullName: true, avatar: true } } },
            },
          },
        },
      },
    });

    const allTeams = await db.team.findMany({
      include: {
        members: { include: { user: { select: { id: true, username: true, fullName: true, avatar: true } } } },
        _count: { select: { members: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      myTeam: myMembership?.team || null,
      teams: allTeams.map(t => ({
        id: t.id,
        name: t.name,
        code: t.code,
        creatorId: t.creatorId,
        memberCount: t.members.length,
        members: t.members,
        isFull: t.members.length >= 10,
        isMyTeam: t.creatorId === user.userId || t.members.some(m => m.userId === user.userId),
      })),
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { action, teamName, teamCode } = body;

    if (action === 'create') {
      if (!teamName || teamName.trim().length < 3) {
        return NextResponse.json({ error: 'اسم الفريق يجب أن يكون 3 أحرف على الأقل' }, { status: 400 });
      }

      const existingMembership = await db.teamMember.findFirst({
        where: { userId: user.userId },
        include: { team: true },
      });
      if (existingMembership) {
        return NextResponse.json({ error: 'أنت بالفعل في فريق. اخرج أولاً لإنشاء فريق جديد' }, { status: 400 });
      }

      let code = generateTeamCode();
      let exists = await db.team.findUnique({ where: { code } });
      while (exists) {
        code = generateTeamCode();
        exists = await db.team.findUnique({ where: { code } });
      }

      const team = await db.team.create({
        data: { name: teamName.trim(), code, creatorId: user.userId },
      });

      await db.teamMember.create({
        data: { teamId: team.id, userId: user.userId },
      });

      await db.userActivity.create({
        data: { userId: user.userId, action: 'team_create', details: `إنشاء فريق "${teamName}"` },
      });

      return NextResponse.json({ message: 'تم إنشاء الفريق بنجاح', team: { id: team.id, name: team.name, code: team.code } });
    }

    if (action === 'join') {
      if (!teamCode) {
        return NextResponse.json({ error: 'يرجى إدخال كود الفريق' }, { status: 400 });
      }

      const existingMembership = await db.teamMember.findFirst({
        where: { userId: user.userId },
      });
      if (existingMembership) {
        return NextResponse.json({ error: 'أنت بالفعل في فريق. اخرج أولاً' }, { status: 400 });
      }

      const team = await db.team.findUnique({
        where: { code: teamCode.toUpperCase() },
        include: { members: true },
      });
      if (!team) {
        return NextResponse.json({ error: 'كود الفريق غير صحيح' }, { status: 404 });
      }
      if (team.members.length >= 10) {
        return NextResponse.json({ error: 'الفريق ممتلئ (الحد الأقصى 10 أعضاء)' }, { status: 400 });
      }

      await db.teamMember.create({
        data: { teamId: team.id, userId: user.userId },
      });

      await db.userActivity.create({
        data: { userId: user.userId, action: 'team_join', details: `الانضمام إلى فريق "${team.name}"` },
      });

      return NextResponse.json({ message: `تم الانضمام إلى فريق "${team.name}" بنجاح` });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action') || 'leave';

    const membership = await db.teamMember.findFirst({
      where: { userId: user.userId },
      include: { team: true },
    });
    if (!membership) {
      return NextResponse.json({ error: 'أنت لست في أي فريق' }, { status: 400 });
    }

    if (action === 'dissolve' && membership.team.creatorId === user.userId) {
      await db.teamMember.deleteMany({ where: { teamId: membership.team.id } });
      await db.team.delete({ where: { id: membership.team.id } });
      await db.userActivity.create({
        data: { userId: user.userId, action: 'team_dissolve', details: `حل فريق "${membership.team.name}"` },
      });
      return NextResponse.json({ message: 'تم حل الفريق بنجاح' });
    }

    if (action === 'leave') {
      if (membership.team.creatorId === user.userId) {
        return NextResponse.json({ error: 'لا يمكنك مغادرة فريقك. قم بحله أو نقل الملكية' }, { status: 400 });
      }
      await db.teamMember.delete({ where: { id: membership.id } });
      await db.userActivity.create({
        data: { userId: user.userId, action: 'team_leave', details: `مغادرة فريق "${membership.team.name}"` },
      });
      return NextResponse.json({ message: 'تم مغادرة الفريق بنجاح' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
