import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status') || '';

    const where: Record<string, unknown> = { userId: user.userId };
    if (status) where.status = status;

    const [withdrawals, total] = await Promise.all([
      db.withdrawal.findMany({
        where, orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit, take: limit,
      }),
      db.withdrawal.count({ where }),
    ]);

    return NextResponse.json({ withdrawals, total, pages: Math.ceil(total / limit) });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const fullUser = await db.user.findUnique({ where: { id: user.userId } });
    if (!fullUser) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

    // Check KYC status before withdrawal
    const kyc = await db.kYC.findUnique({ where: { userId: user.userId } });
    if (!kyc || kyc.status !== 'verified') {
      return NextResponse.json({ error: 'يجب توثيق الحساب (KYC) قبل السحب', kycStatus: kyc?.status || 'not_submitted' }, { status: 403 });
    }

    const body = await request.json();
    const { amount, walletAddress } = body;

    if (!amount || !walletAddress) {
      return NextResponse.json({ error: 'يرجى إدخال جميع البيانات' }, { status: 400 });
    }

    const settings = await getSettings();
    if (amount < settings.minWithdraw) {
      return NextResponse.json({ error: `الحد الأدنى للسحب هو $${settings.minWithdraw}` }, { status: 400 });
    }

    // Calculate available balance (total profits - pending withdrawals)
    const totalProfits = await db.dailyProfit.aggregate({
      where: { userId: user.userId },
      _sum: { amount: true },
    });
    const pendingWithdrawals = await db.withdrawal.aggregate({
      where: { userId: user.userId, status: 'pending' },
      _sum: { amount: true },
    });
    const available = (totalProfits._sum.amount || 0) - (pendingWithdrawals._sum.amount || 0);

    if (amount > available) {
      return NextResponse.json({ error: `رصيدك المتاح للسحب هو $${available.toFixed(2)}` }, { status: 400 });
    }

    await db.$transaction([
      db.withdrawal.create({
        data: { userId: user.userId, amount, walletAddress, status: 'pending' },
      }),
      db.userActivity.create({
        data: {
          userId: user.userId,
          action: 'WITHDRAWAL_REQUEST',
          details: `طلب سحب $${amount.toFixed(2)} إلى المحفظة ${walletAddress.slice(0, 10)}...`,
          amount: -amount,
        },
      }),
    ]);

    return NextResponse.json({ message: 'تم تقديم طلب السحب بنجاح. سيتم مراجعته خلال 24 ساعة.' });
  } catch (error: unknown) {
    console.error('Withdrawal POST error:', error);
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
