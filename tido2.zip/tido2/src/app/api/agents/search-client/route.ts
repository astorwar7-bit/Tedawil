import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

// GET: Search for any client by username or email (agent only)
export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const agent = await db.user.findUnique({
      where: { id: user.userId },
      select: { isAgent: true },
    });
    if (!agent?.isAgent) return NextResponse.json({ error: 'ليس لديك صلاحية' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const q = searchParams.get('q')?.trim();

    if (!q || q.length < 2) {
      return NextResponse.json({ clients: [] });
    }

    const clients = await db.user.findMany({
      where: {
        isAdmin: false,
        isAgent: false,
        isActive: true,
        OR: [
          { username: { contains: q } },
          { email: { contains: q } },
        ],
      },
      select: {
        id: true,
        username: true,
        email: true,
        fullName: true,
        balance: true,
        isActive: true,
        createdAt: true,
        referredBy: true,
        deposits: {
          where: { status: 'approved' },
          select: { amount: true },
        },
        investments: {
          select: { amount: true, isActive: true },
        },
      },
      take: 10,
      orderBy: { createdAt: 'desc' },
    });

    const enriched = clients.map(c => ({
      id: c.id,
      username: c.username,
      email: c.email,
      fullName: c.fullName,
      balance: c.balance,
      isActive: c.isActive,
      createdAt: c.createdAt,
      isMyReferral: c.referredBy === user.userId,
      totalDeposits: c.deposits.reduce((s, d) => s + d.amount, 0),
      totalInvestments: c.investments.reduce((s, inv) => s + inv.amount, 0),
      activeInvestmentsCount: c.investments.filter(inv => inv.isActive).length,
    }));

    return NextResponse.json({ clients: enriched });
  } catch (error) {
    console.error('Agent search client error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
