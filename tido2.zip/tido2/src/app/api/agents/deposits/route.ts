import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { sendRealtimeNotification } from '@/lib/helpers';
import { processApprovedDeposit } from '@/lib/deposit-processor';

// GET: Get deposits submitted by this agent
export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const agent = await db.user.findUnique({
      where: { id: user.userId },
      select: { isAgent: true },
    });
    if (!agent?.isAgent) return NextResponse.json({ error: 'ليس لديك صلاحية' }, { status: 403 });

    const agentDeposits = await db.deposit.findMany({
      where: { submittedByAgentId: user.userId },
      include: {
        user: { select: { username: true, fullName: true, email: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return NextResponse.json({ deposits: agentDeposits });
  } catch (error) {
    console.error('Agent deposits error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

// POST: Agent submits deposit for client — AUTO-APPROVED (no admin approval needed)
export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const agent = await db.user.findUnique({
      where: { id: user.userId },
      select: { isAgent: true, username: true },
    });
    if (!agent?.isAgent) return NextResponse.json({ error: 'ليس لديك صلاحية' }, { status: 403 });

    const body = await request.json();
    const { targetUserId, amount, method, txHash, screenshot } = body;

    if (!targetUserId || !amount || amount <= 0) {
      return NextResponse.json({ error: 'يرجى تحديد العميل والمبلغ' }, { status: 400 });
    }

    // Get minimum deposit from settings
    const settings = await db.setting.findFirst();
    const minDeposit = settings?.minDeposit || 10;

    if (amount < minDeposit) {
      return NextResponse.json({ error: `الحد الأدنى للإيداع $${minDeposit}` }, { status: 400 });
    }

    // Maximum single deposit limit for security
    if (amount > 50000) {
      return NextResponse.json({ error: 'الحد الأقصى للإيداع الواحد هو $50,000' }, { status: 400 });
    }

    // Allow deposit for ANY active non-admin, non-agent user
    const targetUser = await db.user.findFirst({
      where: {
        id: targetUserId,
        isActive: true,
        isAdmin: false,
        isAgent: false,
      },
    });
    if (!targetUser) {
      return NextResponse.json({ error: 'العميل غير موجود أو غير نشط' }, { status: 404 });
    }

    // Rate limiting: max 20 deposits per agent per day
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const todayDeposits = await db.deposit.count({
      where: {
        submittedByAgentId: user.userId,
        createdAt: { gte: todayStart },
      },
    });

    if (todayDeposits >= 20) {
      return NextResponse.json({ error: 'تم تجاوز الحد اليومي لإيداعات الوكيل (20 إيداع)' }, { status: 429 });
    }

    // Create deposit with status 'pending' first
    const deposit = await db.deposit.create({
      data: {
        userId: targetUser.id,
        amount,
        method: method || 'تحويل من الوكيل',
        txHash: txHash || '',
        screenshot: screenshot || '',
        status: 'pending',
        submittedByAgentId: user.userId,
      },
    });

    // AUTO-APPROVE: Process the deposit immediately (credit balance, referral bonuses, agent commissions)
    await processApprovedDeposit(deposit.id);

    // Log activity for the agent
    await db.userActivity.create({
      data: {
        userId: user.userId,
        action: 'AGENT_CLIENT_DEPOSIT',
        details: `إيداع تلقائي $${amount.toFixed(2)} للعميل ${targetUser.username} (تم القبول فوراً)`,
        amount,
      },
    });

    // Notify the agent about success
    await sendRealtimeNotification(
      user.userId,
      'تم إيداع المبلغ بنجاح',
      `تم إيداع $${amount.toFixed(2)} للعميل ${targetUser.username} وقبوله تلقائياً في رصيده.`,
      'success'
    );

    // Notify the client
    await sendRealtimeNotification(
      targetUser.id,
      'إيداع جديد ناجح',
      `تم إيداع $${amount.toFixed(2)} في حسابك بواسطة وكيلك ${agent.username}. الرصيد متاح الآن للاستثمار.`,
      'info'
    );

    return NextResponse.json({
      message: `تم إيداع $${amount.toFixed(2)} للعميل ${targetUser.username} بنجاح وقبوله تلقائياً`,
      deposit,
    });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
