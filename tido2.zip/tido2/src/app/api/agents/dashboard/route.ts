import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

// GET: Agent dashboard stats
export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const fullUser = await db.user.findUnique({
      where: { id: user.userId },
      select: {
        id: true, username: true, email: true, fullName: true, balance: true,
        isAgent: true, agentCommissionRate: true, referralCode: true,
        referredUsers: {
          select: {
            id: true, username: true, email: true, fullName: true, balance: true, isActive: true, createdAt: true,
            investments: { select: { amount: true, isActive: true, dailyRate: true, startDate: true } },
            deposits: { select: { amount: true, status: true, createdAt: true } },
          },
          orderBy: { createdAt: 'desc' },
        },
        activities: {
          where: { action: { in: ['AGENT_COMMISSION', 'ADMIN_DEPOSIT', 'ADMIN_WITHDRAW'] } },
          select: { amount: true, details: true, createdAt: true, action: true },
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
      },
    });

    if (!fullUser || !fullUser.isAgent) {
      return NextResponse.json({ error: 'ليس لديك صلاحية الوصول' }, { status: 403 });
    }

    const totalCommissionEarned = fullUser.activities.filter(a => a.action === 'AGENT_COMMISSION').reduce((sum, a) => sum + a.amount, 0);
    const referredUsersCount = fullUser.referredUsers.length;
    const activeReferrals = fullUser.referredUsers.filter(u => u.isActive).length;
    const totalDepositsFromReferrals = fullUser.referredUsers.reduce((sum, u) => sum + u.deposits.filter(d => d.status === 'approved').reduce((s, d) => s + d.amount, 0), 0);
    const totalInvestmentsFromReferrals = fullUser.referredUsers.reduce((sum, u) => sum + u.investments.reduce((s, inv) => s + inv.amount, 0), 0);

    // Build enriched referral list
    const enrichedReferrals = fullUser.referredUsers.map(u => {
      const approvedDeposits = u.deposits.filter(d => d.status === 'approved');
      const totalDeposited = approvedDeposits.reduce((s, d) => s + d.amount, 0);
      const totalInvested = u.investments.reduce((s, inv) => s + inv.amount, 0);
      const activeInvestments = u.investments.filter(inv => inv.isActive);
      return {
        id: u.id,
        username: u.username,
        email: u.email,
        fullName: u.fullName,
        balance: u.balance,
        isActive: u.isActive,
        createdAt: u.createdAt,
        totalDeposited,
        totalInvested,
        activeInvestmentsCount: activeInvestments.length,
        depositCount: approvedDeposits.length,
      };
    });

    return NextResponse.json({
      user: {
        username: fullUser.username,
        email: fullUser.email,
        fullName: fullUser.fullName,
        balance: fullUser.balance,
        commissionRate: fullUser.agentCommissionRate,
        referralCode: fullUser.referralCode,
      },
      stats: {
        totalCommissionEarned,
        referredUsersCount,
        activeReferrals,
        totalDepositsFromReferrals,
        totalInvestmentsFromReferrals,
      },
      referrals: enrichedReferrals,
      commissionHistory: fullUser.activities,
    });
  } catch (error) {
    console.error('Agent dashboard error:', error);
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
