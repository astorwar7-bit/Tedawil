import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSettings, logActivity } from '@/lib/helpers';

// Automated daily profit distribution - called by cron
const CRON_SECRET = process.env.CRON_SECRET || 'tedawulai_cron_secret_2024';

export async function GET(request: NextRequest) {
  try {
    // Verify cron secret header
    const cronSecret = request.headers.get('x-cron-secret');
    if (cronSecret !== CRON_SECRET) {
      console.error('[Cron] Unauthorized profit distribution attempt');
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const settings = await getSettings();
    const REFERRAL_L1_RATE = settings.referralBonusRate / 100;
    const REFERRAL_L2_RATE = settings.referralLevel2Rate / 100;
    const MONTHLY_CAP = settings.monthlyCommissionCap || 0; // 0 = unlimited

    const now = new Date();

    // Calculate month start for commission cap
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    // Pre-fetch all referrer chain data (to avoid N+1 queries)
    const activeInvestments = await db.investment.findMany({
      where: {
        isActive: true,
        endDate: { gt: now },
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            balance: true,
            referredBy: true,
          },
        },
      },
    });

    if (activeInvestments.length === 0) {
      return NextResponse.json({
        success: true, distributed: 0, totalAmount: 0, referralBonuses: 0,
        message: 'لا توجد استثمارات نشطة',
      });
    }

    let totalDistributed = 0;
    let referralBonuses = 0;

    const profitRecords: { userId: string; investmentId: string; amount: number; rate: number; type: string }[] = [];
    const userBalanceUpdates: Record<string, number> = {};
    const investmentProfitUpdates: Record<string, number> = {};

    const referralRecords: { userId: string; amount: number; rate: number; type: string; referredByUsername: string }[] = [];

    for (const investment of activeInvestments) {
      const profit = investment.amount * (investment.dailyRate / 100);

      profitRecords.push({
        userId: investment.userId,
        investmentId: investment.id,
        amount: profit,
        rate: investment.dailyRate,
        type: 'investment',
      });

      userBalanceUpdates[investment.userId] = (userBalanceUpdates[investment.userId] || 0) + profit;
      investmentProfitUpdates[investment.id] = (investmentProfitUpdates[investment.id] || 0) + profit;
      totalDistributed += profit;

      // Level 1 referral bonus
      if (investment.user.referredBy) {
        const l1Bonus = profit * REFERRAL_L1_RATE;

        // Check monthly cap for Level 1 referrer
        let cappedL1Bonus = l1Bonus;
        if (MONTHLY_CAP > 0) {
          const currentMonthTotal = await db.dailyProfit.aggregate({
            where: {
              userId: investment.user.referredBy,
              type: { in: ['referral', 'referral_level2', 'referral_signup', 'agent_commission'] },
              date: { gte: monthStart },
            },
            _sum: { amount: true },
          });

          const alreadyEarned = currentMonthTotal._sum.amount || 0;
          const remaining = MONTHLY_CAP - alreadyEarned;

          if (remaining <= 0) {
            cappedL1Bonus = 0;
          } else if (l1Bonus > remaining) {
            cappedL1Bonus = remaining;
          }
        }

        if (cappedL1Bonus > 0) {
          referralBonuses += cappedL1Bonus;
          userBalanceUpdates[investment.user.referredBy] =
            (userBalanceUpdates[investment.user.referredBy] || 0) + cappedL1Bonus;

          referralRecords.push({
            userId: investment.user.referredBy,
            amount: cappedL1Bonus,
            rate: REFERRAL_L1_RATE * 100,
            type: 'referral',
            referredByUsername: investment.user.username,
          });
        }

        // Level 2 referral: check if Level 1 referrer was also referred
        if (REFERRAL_L2_RATE > 0) {
          const l1Referrer = await db.user.findUnique({
            where: { id: investment.user.referredBy },
            select: { referredBy: true },
          });

          if (l1Referrer?.referredBy) {
            const l2Bonus = profit * REFERRAL_L2_RATE;

            // Check monthly cap for Level 2 referrer
            let cappedL2Bonus = l2Bonus;
            if (MONTHLY_CAP > 0) {
              const currentMonthTotal2 = await db.dailyProfit.aggregate({
                where: {
                  userId: l1Referrer.referredBy,
                  type: { in: ['referral', 'referral_level2', 'referral_signup', 'agent_commission'] },
                  date: { gte: monthStart },
                },
                _sum: { amount: true },
              });

              const alreadyEarned2 = currentMonthTotal2._sum.amount || 0;
              const remaining2 = MONTHLY_CAP - alreadyEarned2;

              if (remaining2 <= 0) {
                cappedL2Bonus = 0;
              } else if (l2Bonus > remaining2) {
                cappedL2Bonus = remaining2;
              }
            }

            if (cappedL2Bonus > 0) {
              referralBonuses += cappedL2Bonus;
              userBalanceUpdates[l1Referrer.referredBy] =
                (userBalanceUpdates[l1Referrer.referredBy] || 0) + cappedL2Bonus;

              referralRecords.push({
                userId: l1Referrer.referredBy,
                amount: cappedL2Bonus,
                rate: REFERRAL_L2_RATE * 100,
                type: 'referral_level2',
                referredByUsername: investment.user.username,
              });
            }
          }
        }
      }
    }

    // Execute all database operations atomically
    await db.$transaction(async (tx) => {
      for (const record of profitRecords) {
        await tx.dailyProfit.create({
          data: {
            userId: record.userId,
            investmentId: record.investmentId,
            amount: record.amount,
            type: record.type,
            rate: record.rate,
          },
        });
      }

      for (const record of referralRecords) {
        await tx.dailyProfit.create({
          data: {
            userId: record.userId,
            amount: record.amount,
            type: record.type,
            rate: record.rate,
          },
        });

        const isLevel2 = record.type === 'referral_level2';
        await tx.notification.create({
          data: {
            userId: record.userId,
            title: isLevel2 ? 'عمولة إحالة - المستوى الثاني' : 'مكافأة إحالة',
            message: isLevel2
              ? `حصلت على عمولة $${record.amount.toFixed(2)} من المستوى الثاني بسبب استثمار المستخدم ${record.referredByUsername}`
              : `حصلت على مكافأة إحالة $${record.amount.toFixed(2)} من استثمار المستخدم ${record.referredByUsername}`,
            type: 'referral',
          },
        });
      }

      for (const [userId, amount] of Object.entries(userBalanceUpdates)) {
        await tx.user.update({
          where: { id: userId },
          data: { balance: { increment: amount } },
        });

        const investmentProfit = profitRecords.filter(r => r.userId === userId).reduce((s, r) => s + r.amount, 0);
        if (investmentProfit > 0) {
          await tx.userActivity.create({
            data: {
              userId,
              action: 'DAILY_PROFIT',
              details: `أرباح يومية من الاستثمارات: $${investmentProfit.toFixed(2)}`,
              amount: investmentProfit,
            },
          });
        }

        const referralProfit = referralRecords.filter(r => r.userId === userId).reduce((s, r) => s + r.amount, 0);
        if (referralProfit > 0) {
          await tx.userActivity.create({
            data: {
              userId,
              action: 'REFERRAL_PROFIT',
              details: `عمولة إحالات يومية: $${referralProfit.toFixed(2)}`,
              amount: referralProfit,
            },
          });
        }
      }

      for (const [investmentId, profit] of Object.entries(investmentProfitUpdates)) {
        await tx.investment.update({
          where: { id: investmentId },
          data: { actualProfit: { increment: profit } },
        });
      }
    });

    await logActivity(
      'system_cron',
      'CRON_DISTRIBUTE_PROFITS',
      `تم توزيع أرباح يومية: $${totalDistributed.toFixed(2)} لـ ${activeInvestments.length} مستثمر. مكافآت إحالة: $${referralBonuses.toFixed(2)}`
    );

    return NextResponse.json({
      success: true,
      distributed: activeInvestments.length,
      totalAmount: Math.round(totalDistributed * 100) / 100,
      referralBonuses: Math.round(referralBonuses * 100) / 100,
      message: `تم توزيع الأرباح بنجاح لـ ${activeInvestments.length} مستثمر`,
    });
  } catch (error) {
    console.error('[Cron] Profit distribution error:', error);
    return NextResponse.json({ success: false, error: 'حدث خطأ أثناء توزيع الأرباح' }, { status: 500 });
  }
}
