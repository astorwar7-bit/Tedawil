import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings, sendRealtimeNotification } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const status = searchParams.get('status') || '';

    const where: Record<string, unknown> = { userId: user.userId };
    if (status === 'active') where.isActive = true;
    if (status === 'completed') where.isActive = false;

    const [investments, total] = await Promise.all([
      db.investment.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: { plan: { select: { name: true, nameEn: true, icon: true, color: true } } },
      }),
      db.investment.count({ where }),
    ]);

    return NextResponse.json({ investments, total, pages: Math.ceil(total / limit) });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const fullUser = await db.user.findUnique({ where: { id: user.userId } });
    if (!fullUser) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

    // Agent check: agents cannot invest
    if (fullUser.isAgent) {
      return NextResponse.json({ error: 'الوكلاء لا يمكنهم الاستثمار' }, { status: 403 });
    }

    const body = await request.json();
    const { amount, couponCode, planId } = body;

    if (!amount || amount < 100) {
      return NextResponse.json({ error: 'الحد الأدنى للاستثمار هو $100' }, { status: 400 });
    }

    const settings = await getSettings();
    let dailyRate = settings.minDailyRate;
    let duration = 30;

    if (planId) {
      const plan = await db.investmentPlan.findUnique({ where: { id: planId } });
      if (!plan || !plan.isActive) {
        return NextResponse.json({ error: 'خطة الاستثمار غير موجودة أو غير نشطة' }, { status: 400 });
      }
      if (amount < plan.minAmount) {
        return NextResponse.json({ error: `الحد الأدنى لخطة "${plan.name}" هو $${plan.minAmount.toLocaleString()}` }, { status: 400 });
      }
      if (plan.maxAmount > 0 && amount > plan.maxAmount) {
        return NextResponse.json({ error: `الحد الأقصى لخطة "${plan.name}" هو $${plan.maxAmount.toLocaleString()}` }, { status: 400 });
      }
      dailyRate = plan.dailyRate;
      duration = plan.duration;
    } else {
      if (amount < settings.minDeposit) {
        return NextResponse.json({ error: `الحد الأدنى للاستثمار هو $${settings.minDeposit}` }, { status: 400 });
      }
    }

    if (fullUser.balance < amount) {
      return NextResponse.json({ error: 'رصيدك غير كافي' }, { status: 400 });
    }

    let finalAmount = amount;
    let couponId: string | undefined;
    let couponDiscountAmount = 0;

    if (couponCode) {
      const coupon = await db.coupon.findUnique({ where: { code: couponCode.toUpperCase() } });
      if (!coupon || !coupon.isActive) return NextResponse.json({ error: 'كوبون غير صالح' }, { status: 400 });
      if (coupon.expiresAt && coupon.expiresAt < new Date()) return NextResponse.json({ error: 'انتهت صلاحية الكوبون' }, { status: 400 });
      if (coupon.usedCount >= coupon.maxUses) return NextResponse.json({ error: 'تم استخدام الكوبون بالحد الأقصى' }, { status: 400 });

      // Check per-user usage limit
      const userUsageCount = await db.couponUsage.count({
        where: { couponId: coupon.id, userId: user.userId },
      });
      if (coupon.maxUsesPerUser > 0 && userUsageCount >= coupon.maxUsesPerUser) {
        return NextResponse.json({ error: `لقد استخدمت هذا الكوبون الحد الأقصى المسموح (${coupon.maxUsesPerUser} مرة)` }, { status: 400 });
      }

      // Check minimum investment for coupon
      if (coupon.minInvestment > 0 && amount < coupon.minInvestment) {
        return NextResponse.json({ error: `الحد الأدنى لاستخدام هذا الكوبون هو $${coupon.minInvestment.toLocaleString()}` }, { status: 400 });
      }

      if (coupon.type === 'fixed') {
        couponDiscountAmount = coupon.discount;
        finalAmount = amount - coupon.discount;
      } else {
        couponDiscountAmount = amount * coupon.discount / 100;
        finalAmount = amount - couponDiscountAmount;
      }

      if (finalAmount <= 0) {
        return NextResponse.json({ error: 'مبلغ الخصم أكبر من مبلغ الاستثمار' }, { status: 400 });
      }

      couponId = coupon.id;
      await db.$transaction([
        db.coupon.update({ where: { id: coupon.id }, data: { usedCount: { increment: 1 } } }),
        db.couponUsage.create({ data: { couponId: coupon.id, userId: user.userId } }),
      ]);

      // Notify user about coupon usage
      await sendRealtimeNotification(
        user.userId,
        'تم تطبيق كوبون الخصم',
        `تم خصم $${Math.round(couponDiscountAmount * 100) / 100} ${coupon.type === 'percentage' ? `(${coupon.discount}%)` : '(مبلغ ثابت)'} من استثمارك`,
        'success'
      );
    }

    const startDate = new Date();
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + duration);
    const expectedProfit = finalAmount * (dailyRate / 100) * duration;

    let planName = 'خطة افتراضية';
    if (planId) {
      const planData = await db.investmentPlan.findUnique({ where: { id: planId }, select: { name: true } });
      if (planData) planName = planData.name;
    }

    await db.$transaction([
      db.user.update({ where: { id: user.userId }, data: { balance: { decrement: finalAmount } } }),
      db.investment.create({
        data: {
          userId: user.userId,
          planId: planId || undefined,
          amount: finalAmount,
          dailyRate,
          startDate,
          endDate,
          expectedProfit,
          couponId,
        },
      }),
      db.userActivity.create({
        data: {
          userId: user.userId,
          action: 'INVESTMENT_CREATE',
          details: `استثمار جديد في ${planName}: $${finalAmount.toFixed(2)} بمعدل ${dailyRate}% يومياً`,
          amount: -finalAmount,
        },
      }),
    ]);

    // Notify about investment creation
    await sendRealtimeNotification(
      user.userId,
      'تم إنشاء استثمار جديد',
      `تم استثمار $${Math.round(finalAmount * 100) / 100} بمعدل ${dailyRate}% يومياً لمدة ${duration} يوم${couponDiscountAmount > 0 ? ` (بعد خصم كوبون $${Math.round(couponDiscountAmount * 100) / 100})` : ''}`,
      'investment'
    );

    return NextResponse.json({ message: 'تم إنشاء الاستثمار بنجاح' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
