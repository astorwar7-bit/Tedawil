import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '15');
    const type = searchParams.get('type') || '';

    const where: Record<string, unknown> = { userId: user.userId };
    if (type) where.type = type;

    const [profits, total, totalProfits] = await Promise.all([
      db.dailyProfit.findMany({
        where, orderBy: { date: 'desc' },
        skip: (page - 1) * limit, take: limit,
      }),
      db.dailyProfit.count({ where }),
      db.dailyProfit.aggregate({ where: { userId: user.userId }, _sum: { amount: true } }),
    ]);

    return NextResponse.json({ profits, total, pages: Math.ceil(total / limit), totalProfits: totalProfits._sum.amount || 0 });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
