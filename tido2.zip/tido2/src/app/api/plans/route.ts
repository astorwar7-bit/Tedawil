import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

const DEFAULT_PLANS = [
  {
    name: 'الخطة البرونزية',
    nameEn: 'Bronze',
    minAmount: 100,
    maxAmount: 999,
    dailyRate: 1.2,
    duration: 30,
    icon: '🥉',
    color: '#CD7F32',
    sortOrder: 1,
    description: 'مثالية للمستثمرين المبتدئين، ابدأ رحلتك الاستثمارية بمبلغ صغير وأرباح يومية مضمونة.',
  },
  {
    name: 'الخطة الفضية',
    nameEn: 'Silver',
    minAmount: 1000,
    maxAmount: 4999,
    dailyRate: 1.8,
    duration: 60,
    icon: '🥈',
    color: '#C0C0C0',
    sortOrder: 2,
    description: 'للمستثمرين ذوي الخبرة، استمتع بنسبة ربح أعلى ومدة استثمار أطول.',
  },
  {
    name: 'الخطة الذهبية',
    nameEn: 'Gold',
    minAmount: 5000,
    maxAmount: 19999,
    dailyRate: 2.5,
    duration: 90,
    icon: '🥇',
    color: '#FFD700',
    sortOrder: 3,
    description: 'الخطة المفضلة للمستثمرين المحترفين، عوائد استثنائية على المدى المتوسط.',
  },
  {
    name: 'الخطة الماسية',
    nameEn: 'Diamond',
    minAmount: 20000,
    maxAmount: 0,
    dailyRate: 3.5,
    duration: 120,
    icon: '💎',
    color: '#B9F2FF',
    sortOrder: 4,
    description: 'الخطة الملكية للمستثمرين الكبار، أعلى نسبة ربح يومية بدون حد أقصى.',
  },
];

async function seedPlans() {
  const existing = await db.investmentPlan.count();
  if (existing === 0) {
    await db.investmentPlan.createMany({ data: DEFAULT_PLANS });
  }
}

export async function GET() {
  try {
    await seedPlans();

    const plans = await db.investmentPlan.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
      include: {
        _count: {
          select: { investments: true },
        },
      },
    });

    return NextResponse.json({ plans });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
