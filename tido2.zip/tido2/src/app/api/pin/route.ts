import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { hashPassword, comparePassword } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const pin = await db.userPin.findUnique({ where: { userId: user.userId } });

    return NextResponse.json({
      hasPin: !!pin?.pinHash,
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { action, pin, currentPin } = body;

    if (!pin || !/^\d{4}$/.test(pin)) {
      return NextResponse.json({ error: 'رمز PIN يجب أن يكون 4 أرقام' }, { status: 400 });
    }

    const existingPin = await db.userPin.findUnique({ where: { userId: user.userId } });

    if (action === 'set') {
      if (existingPin?.pinHash) {
        return NextResponse.json({ error: 'لديك بالفعل رمز PIN. استخدم تغيير الرمز' }, { status: 400 });
      }

      const pinHash = await hashPassword(pin);
      await db.userPin.create({
        data: { userId: user.userId, pinHash },
      });

      await db.userActivity.create({
        data: { userId: user.userId, action: 'pin_set', details: 'إنشاء رمز PIN' },
      });

      return NextResponse.json({ message: 'تم إنشاء رمز PIN بنجاح' });
    }

    if (action === 'change') {
      if (!existingPin?.pinHash) {
        return NextResponse.json({ error: 'ليس لديك رمز PIN. قم بإنشاء واحد أولاً' }, { status: 400 });
      }

      if (!currentPin) {
        return NextResponse.json({ error: 'يرجى إدخال الرمز الحالي' }, { status: 400 });
      }

      const isValid = await comparePassword(currentPin, existingPin.pinHash);
      if (!isValid) {
        return NextResponse.json({ error: 'الرمز الحالي غير صحيح' }, { status: 400 });
      }

      const pinHash = await hashPassword(pin);
      await db.userPin.update({
        where: { userId: user.userId },
        data: { pinHash },
      });

      await db.userActivity.create({
        data: { userId: user.userId, action: 'pin_change', details: 'تغيير رمز PIN' },
      });

      return NextResponse.json({ message: 'تم تغيير رمز PIN بنجاح' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
