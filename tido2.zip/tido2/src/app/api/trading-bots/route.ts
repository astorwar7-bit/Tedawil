import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

const MAX_SUBSCRIPTIONS = 3;

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const tab = searchParams.get('tab') || 'marketplace';

    const activeBots = await db.botSubscription.findMany({
      where: { userId: user.userId, isActive: true },
    });

    const subscribedIds = new Set(activeBots.map(b => b.botId));

    if (tab === 'active') {
      return NextResponse.json({ activeBots, totalProfit: activeBots.reduce((s, b) => s + b.profit, 0) });
    }

    // Read bots from database (managed by admin)
    const dbBots = await db.tradingBot.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });

    const bots = dbBots.map(b => ({
      id: b.id,
      name: b.name,
      botName: b.name,
      strategy: b.strategy,
      description: b.description,
      dailyReturn: b.dailyReturn,
      riskLevel: b.riskLevel,
      minBalance: b.minBalance,
      icon: b.icon,
      color: b.color,
      subscribers: b.subscribers,
      isSubscribed: subscribedIds.has(b.id),
    }));

    return NextResponse.json({ bots, activeBots, maxSubscriptions: MAX_SUBSCRIPTIONS });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { action, botId } = body;

    if (action === 'subscribe') {
      const activeCount = await db.botSubscription.count({
        where: { userId: user.userId, isActive: true },
      });
      if (activeCount >= MAX_SUBSCRIPTIONS) {
        return NextResponse.json({ error: `يمكنك الاشتراك في ${MAX_SUBSCRIPTIONS} بوتات فقط` }, { status: 400 });
      }

      const bot = await db.tradingBot.findUnique({ where: { id: botId } });
      if (!bot || !bot.isActive) return NextResponse.json({ error: 'البوت غير موجود أو غير متاح' }, { status: 404 });

      const userData = await db.user.findUnique({ where: { id: user.userId }, select: { balance: true } });
      if (!userData || userData.balance < bot.minBalance) {
        return NextResponse.json({ error: `رصيدك غير كافٍ. الحد الأدنى: $${bot.minBalance}` }, { status: 400 });
      }

      const existing = await db.botSubscription.findFirst({ where: { userId: user.userId, botId } });
      if (existing) {
        if (existing.isActive) return NextResponse.json({ error: 'أنت مشترك بالفعل' }, { status: 400 });
        await db.botSubscription.update({ where: { id: existing.id }, data: { isActive: true } });
      } else {
        await db.botSubscription.create({
          data: {
            userId: user.userId, botId: bot.id, botName: bot.name,
            strategy: bot.strategy, dailyReturn: bot.dailyReturn,
            riskLevel: bot.riskLevel, minBalance: bot.minBalance,
          },
        });
      }

      await db.tradingBot.update({ where: { id: botId }, data: { subscribers: { increment: 1 } } });
      await db.userActivity.create({ data: { userId: user.userId, action: 'bot_subscribe', details: `الاشتراك في بوت ${bot.name}` } });

      return NextResponse.json({ message: `تم الاشتراك في ${bot.name} بنجاح` });
    }

    if (action === 'unsubscribe') {
      const sub = await db.botSubscription.findFirst({ where: { userId: user.userId, botId, isActive: true } });
      if (sub) {
        await db.botSubscription.update({ where: { id: sub.id }, data: { isActive: false } });
        await db.tradingBot.update({ where: { id: botId }, data: { subscribers: { decrement: 1 } } });
      }
      const bot = await db.tradingBot.findUnique({ where: { id: botId } });
      await db.userActivity.create({ data: { userId: user.userId, action: 'bot_unsubscribe', details: `إلغاء الاشتراك في بوت ${bot?.name || botId}` } });
      return NextResponse.json({ message: 'تم إلغاء الاشتراك' });
    }

    return NextResponse.json({ error: 'إجراء غير صالح' }, { status: 400 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'معرف غير صالح' }, { status: 400 });
    await db.botSubscription.deleteMany({ where: { id, userId: user.userId } });
    return NextResponse.json({ message: 'تم الحذف بنجاح' });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
