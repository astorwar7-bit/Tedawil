import { NextResponse } from 'next/server';
import { getSettings } from '@/lib/helpers';

export async function GET() {
  try {
    const settings = await getSettings();
    return NextResponse.json({
      platformName: settings.platformName,
      platformNameEn: settings.platformNameEn,
      platformDesc: settings.platformDesc,
      platformLogo: settings.platformLogo,
      mainWalletAddress: settings.mainWalletAddress,
      minDeposit: settings.minDeposit,
      minWithdraw: settings.minWithdraw,
      referralBonusRate: settings.referralBonusRate,
      referralFixedBonus: settings.referralFixedBonus,
      welcomeBonus: settings.welcomeBonus,
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
