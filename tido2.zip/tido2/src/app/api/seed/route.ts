import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, generateReferralCode } from '@/lib/auth';

export async function POST() {
  try {
    const adminExists = await db.user.findFirst({ where: { isAdmin: true } });
    if (adminExists) {
      return NextResponse.json({ message: 'المدير موجود بالفعل', user: { username: adminExists.username } });
    }

    const hashedPassword = await hashPassword(process.env.ADMIN_PASSWORD || 'Admin123456');
    const admin = await db.user.create({
      data: {
        username: process.env.ADMIN_USERNAME || 'tedawilai_admin',
        fullName: 'مدير تداولاي',
        email: process.env.ADMIN_EMAIL || 'admin@tedawilai.com',
        password: hashedPassword,
        isAdmin: true,
        isActive: true,
        referralCode: generateReferralCode(),
      },
    });

    // Create default settings
    const settingsExist = await db.setting.findFirst();
    if (!settingsExist) {
      await db.setting.create({
        data: {
          platformName: 'Tedawilai',
          platformDesc: 'منصة استثمار رقمية متكاملة - تداولاي',
          mainWalletAddress: '',
          minDeposit: 100,
          minWithdraw: 10,
          referralBonusRate: 5,
          minDailyRate: 1.2,
          maxDailyRate: 1.7,
        },
      });
    }

    return NextResponse.json({ message: 'تم إنشاء المدير بنجاح', user: { username: admin.username, email: admin.email } });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ أثناء إنشاء المدير';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
