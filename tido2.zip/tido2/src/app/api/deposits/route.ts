import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings } from '@/lib/helpers';
import { parsePagination } from '@/lib/utils';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const { page, limit } = parsePagination(searchParams);
    const status = searchParams.get('status') || '';

    const where: Record<string, unknown> = { userId: user.userId };
    if (status) where.status = status;

    const [deposits, total] = await Promise.all([
      db.deposit.findMany({
        where, orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit, take: limit,
      }),
      db.deposit.count({ where }),
    ]);

    const stats = await db.deposit.aggregate({
      where: { userId: user.userId },
      _sum: { amount: true },
      _count: true,
    });

    const pendingSum = await db.deposit.aggregate({
      where: { userId: user.userId, status: 'pending' },
      _sum: { amount: true },
    });
    const approvedSum = await db.deposit.aggregate({
      where: { userId: user.userId, status: 'approved' },
      _sum: { amount: true },
    });

    return NextResponse.json({
      deposits,
      total,
      pages: Math.ceil(total / limit),
      stats: {
        total: stats._sum.amount || 0,
        count: stats._count,
        pending: pendingSum._sum.amount || 0,
        approved: approvedSum._sum.amount || 0,
      },
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { amount, method, txHash, screenshot } = body;

    if (!amount || !method) {
      return NextResponse.json({ error: 'يرجى إدخال المبلغ وطريقة الدفع' }, { status: 400 });
    }

    const validMethods = ['USDT_TRC20', 'USDT_ERC20', 'BANK'];
    if (!validMethods.includes(method)) {
      return NextResponse.json({ error: 'طريقة الدفع غير صالحة' }, { status: 400 });
    }

    const settings = await getSettings();
    if (amount < settings.minDeposit) {
      return NextResponse.json({ error: `الحد الأدنى للإيداع هو $${settings.minDeposit}` }, { status: 400 });
    }

    await db.deposit.create({
      data: {
        userId: user.userId,
        amount: parseFloat(amount),
        method,
        txHash: txHash || '',
        screenshot: screenshot || '',
        status: 'pending',
      },
    });

    await db.userActivity.create({
      data: {
        userId: user.userId,
        action: 'deposit_request',
        details: `طلب إيداع $${amount} عبر ${method}`,
        amount: parseFloat(amount),
      },
    });

    return NextResponse.json({ message: 'تم تقديم طلب الإيداع بنجاح. سيتم مراجعته قريباً.' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
