import { NextRequest } from 'next/server';
import { getRequestUser } from '@/lib/middleware';
import { addConnection } from '@/lib/sse';

const HEARTBEAT_INTERVAL = 30_000; // 30 seconds

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  const user = await getRequestUser(request);
  if (!user) {
    return new Response('Unauthorized', { status: 401 });
  }

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      // Send initial connection confirmation
      const connectPayload = `event: connected\ndata: ${JSON.stringify({ userId: user.userId, timestamp: Date.now() })}\n\n`;
      controller.enqueue(encoder.encode(connectPayload));

      // Register this connection so notifications can be pushed to it
      const cleanup = addConnection(user.userId, controller);

      // Heartbeat to keep the connection alive
      const heartbeatTimer = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`: heartbeat\n\n`));
        } catch {
          clearInterval(heartbeatTimer);
          cleanup();
        }
      }, HEARTBEAT_INTERVAL);

      // Clean up when the client disconnects
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeatTimer);
        cleanup();
        try {
          controller.close();
        } catch {
          // Controller already closed
        }
      });
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no', // Disable nginx buffering (if behind proxy)
    },
  });
}
