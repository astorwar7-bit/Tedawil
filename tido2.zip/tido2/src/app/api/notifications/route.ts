import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');

    const [notifications, total, unreadCount] = await Promise.all([
      db.notification.findMany({
        where: { userId: user.userId },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.notification.count({ where: { userId: user.userId } }),
      db.notification.count({ where: { userId: user.userId, isRead: false } }),
    ]);

    return NextResponse.json({ notifications, total, unreadCount, pages: Math.ceil(total / limit) });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { id } = body;
    if (!id) return NextResponse.json({ error: 'معرف الإشعار مطلوب' }, { status: 400 });

    await db.notification.update({
      where: { id, userId: user.userId },
      data: { isRead: true },
    });

    return NextResponse.json({ message: 'تم تحديث الإشعار' });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
