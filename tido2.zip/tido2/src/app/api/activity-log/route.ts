import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const action = searchParams.get('action') || '';

    const where: Record<string, unknown> = { userId: user.userId };
    if (action) where.action = action;

    const [activities, total] = await Promise.all([
      db.userActivity.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.userActivity.count({ where }),
    ]);

    const actionTypes = await db.userActivity.findMany({
      where: { userId: user.userId },
      select: { action: true },
      distinct: ['action'],
    });

    return NextResponse.json({
      activities,
      total,
      pages: Math.ceil(total / limit),
      actionTypes: actionTypes.map(a => a.action),
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
