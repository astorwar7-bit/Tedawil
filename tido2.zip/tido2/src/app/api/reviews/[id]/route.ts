import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح. يرجى تسجيل الدخول.' }, { status: 401 });

    const { id } = await params;

    const review = await db.review.findUnique({ where: { id } });
    if (!review) return NextResponse.json({ error: 'التقييم غير موجود' }, { status: 404 });

    if (review.userId !== user.userId) {
      return NextResponse.json({ error: 'ليس لديك صلاحية حذف هذا التقييم' }, { status: 403 });
    }

    await db.review.delete({ where: { id } });

    return NextResponse.json({ message: 'تم حذف التقييم بنجاح' });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
