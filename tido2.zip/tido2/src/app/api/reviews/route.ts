import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const planId = searchParams.get('planId') || '';
    const botId = searchParams.get('botId') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');

    const where: Record<string, unknown> = {};
    if (planId) where.planId = planId;
    if (botId) where.botId = botId;

    const [reviews, total] = await Promise.all([
      db.review.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          user: {
            select: { id: true, username: true, fullName: true, avatar: true },
          },
        },
      }),
      db.review.count({ where }),
    ]);

    const avgRating = total > 0
      ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
      : 0;

    return NextResponse.json({
      reviews,
      total,
      pages: Math.ceil(total / limit),
      avgRating: Math.round(avgRating * 10) / 10,
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح. يرجى تسجيل الدخول.' }, { status: 401 });

    const body = await request.json();
    const { rating, comment, planId, botId } = body;

    if (!rating || rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'التقييم يجب أن يكون بين 1 و 5' }, { status: 400 });
    }

    if (!planId && !botId) {
      return NextResponse.json({ error: 'يجب تحديد خطة استثمار أو بوت تداول' }, { status: 400 });
    }

    // Check for existing review
    const existingReview = await db.review.findFirst({
      where: {
        userId: user.userId,
        ...(planId ? { planId } : {}),
        ...(botId ? { botId } : {}),
      },
    });

    if (existingReview) {
      return NextResponse.json({ error: 'لقد أضفت تقييماً مسبقاً' }, { status: 400 });
    }

    const review = await db.review.create({
      data: {
        userId: user.userId,
        rating,
        comment: comment || '',
        planId: planId || null,
        botId: botId || null,
      },
      include: {
        user: {
          select: { id: true, username: true, fullName: true, avatar: true },
        },
      },
    });

    return NextResponse.json({ review, message: 'تم إضافة التقييم بنجاح' }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
