import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const kyc = await db.kYC.findUnique({
      where: { userId: user.userId },
    });

    return NextResponse.json({
      kyc: kyc || { status: 'not_submitted', idFront: '', idBack: '', selfie: '' },
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const existing = await db.kYC.findUnique({ where: { userId: user.userId } });
    if (existing && (existing.status === 'verified' || existing.status === 'pending')) {
      return NextResponse.json({ error: 'طلبك قيد المراجعة أو تم التحقق بالفعل' }, { status: 400 });
    }

    const body = await request.json();
    const { idFront, idBack, selfie } = body;

    if (!idFront || !idBack || !selfie) {
      return NextResponse.json({ error: 'يرجى رفع جميع المستندات المطلوبة' }, { status: 400 });
    }

    if (existing) {
      await db.kYC.update({
        where: { userId: user.userId },
        data: { idFront, idBack, selfie, status: 'pending', rejectReason: '' },
      });
    } else {
      await db.kYC.create({
        data: { userId: user.userId, idFront, idBack, selfie, status: 'pending' },
      });
    }

    await db.userActivity.create({
      data: { userId: user.userId, action: 'kyc_submit', details: 'تقديم طلب التحقق من الهوية' },
    });

    return NextResponse.json({ message: 'تم تقديم طلب التحقق بنجاح. سيتم مراجعته خلال 24-48 ساعة.' });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'حدث خطأ';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
