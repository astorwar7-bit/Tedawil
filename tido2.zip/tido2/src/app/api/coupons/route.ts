import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';

export async function POST(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const body = await request.json();
    const { code, amount } = body;

    if (!code || !amount || amount <= 0) {
      return NextResponse.json({ error: 'الكود والمبلغ مطلوبان' }, { status: 400 });
    }

    const coupon = await db.coupon.findUnique({
      where: { code: code.toUpperCase() },
    });

    if (!coupon) return NextResponse.json({ error: 'كوبون غير صالح' }, { status: 400 });
    if (!coupon.isActive) return NextResponse.json({ error: 'هذا الكوبون غير نشط' }, { status: 400 });
    if (coupon.expiresAt && coupon.expiresAt < new Date()) return NextResponse.json({ error: 'انتهت صلاحية هذا الكوبون' }, { status: 400 });
    if (coupon.usedCount >= coupon.maxUses) return NextResponse.json({ error: 'تم استخدام الكوبون بالحد الأقصى' }, { status: 400 });

    // Check per-user usage limit
    const userUsageCount = await db.couponUsage.count({
      where: { couponId: coupon.id, userId: user.userId },
    });
    if (coupon.maxUsesPerUser > 0 && userUsageCount >= coupon.maxUsesPerUser) {
      return NextResponse.json({ error: `لقد استخدمت هذا الكوبون ${coupon.maxUsesPerUser} مرة/مرات بالفعل. الحد الأقصى لكل مستخدم هو ${coupon.maxUsesPerUser}` }, { status: 400 });
    }

    // Check minimum investment amount for coupon
    if (coupon.minInvestment > 0 && amount < coupon.minInvestment) {
      return NextResponse.json({ error: `الحد الأدنى لاستخدام هذا الكوبون هو $${coupon.minInvestment.toLocaleString()}` }, { status: 400 });
    }

    let discountAmount = 0;
    let finalAmount = amount;

    if (coupon.type === 'fixed') {
      discountAmount = coupon.discount;
      finalAmount = amount - coupon.discount;
    } else {
      discountAmount = amount * coupon.discount / 100;
      finalAmount = amount - discountAmount;
    }

    if (finalAmount <= 0) {
      return NextResponse.json({ error: 'مبلغ الخصم أكبر من مبلغ الاستثمار' }, { status: 400 });
    }

    return NextResponse.json({
      valid: true,
      coupon: {
        id: coupon.id,
        code: coupon.code,
        type: coupon.type,
        discount: coupon.discount,
        discountAmount: Math.round(discountAmount * 100) / 100,
        originalAmount: amount,
        finalAmount: Math.round(finalAmount * 100) / 100,
        remainingUses: coupon.maxUses - coupon.usedCount,
        userRemainingUses: coupon.maxUsesPerUser > 0 ? coupon.maxUsesPerUser - userUsageCount : -1,
        expiresAt: coupon.expiresAt,
      },
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
