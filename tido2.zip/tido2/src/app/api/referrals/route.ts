import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getRequestUser } from '@/lib/middleware';
import { getSettings } from '@/lib/helpers';

export async function GET(request: NextRequest) {
  try {
    const user = await getRequestUser(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    const fullUser = await db.user.findUnique({ where: { id: user.userId } });
    if (!fullUser) return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 });

    const referredUsers = await db.user.findMany({
      where: { referredBy: user.userId },
      select: { id: true, username: true, fullName: true, createdAt: true },
    });

    // Get actual referral earnings from DailyProfit records
    const signupBonuses = await db.dailyProfit.findMany({
      where: { userId: user.userId, type: 'referral_signup' },
      select: { amount: true, date: true },
    });

    const dailyReferralProfits = await db.dailyProfit.findMany({
      where: { userId: user.userId, type: 'referral' },
      select: { amount: true, date: true },
    });

    const totalSignupBonuses = signupBonuses.reduce((sum, p) => sum + p.amount, 0);
    const totalDailyReferral = dailyReferralProfits.reduce((sum, p) => sum + p.amount, 0);
    const totalReferralEarnings = totalSignupBonuses + totalDailyReferral;

    // Today's referral earnings
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todaySignupBonuses = signupBonuses.filter(p => new Date(p.date) >= today).reduce((sum, p) => sum + p.amount, 0);
    const todayReferralProfits = dailyReferralProfits.filter(p => new Date(p.date) >= today).reduce((sum, p) => sum + p.amount, 0);
    const todayReferralEarnings = todaySignupBonuses + todayReferralProfits;

    const settings = await getSettings();

    return NextResponse.json({
      referralCode: fullUser.referralCode,
      referralLink: `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/register?ref=${fullUser.referralCode}`,
      totalReferred: referredUsers.length,
      totalReferralEarnings,
      totalSignupBonuses,
      totalDailyReferral,
      todayReferralEarnings,
      referralBonusRate: settings.referralBonusRate || 5,
      referralFixedBonus: settings.referralFixedBonus || 5,
      referredUsers,
    });
  } catch {
    return NextResponse.json({ error: 'حدث خطأ' }, { status: 500 });
  }
}
