'use client';

import { useEffect, useState, useCallback, useRef } from 'react';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
}

interface UseRealtimeNotificationsReturn {
  notifications: Notification[];
  unreadCount: number;
  isConnected: boolean;
  markAsRead: (id: string) => Promise<void>;
  markAllRead: () => Promise<void>;
  refresh: () => Promise<void>;
}

const POLL_INTERVAL = 30_000; // 30 seconds
const MAX_NOTIFICATIONS = 10;

export function useRealtimeNotifications(): UseRealtimeNotificationsReturn {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isConnected, setIsConnected] = useState(false);
  const lastFetchedIdRef = useRef<string | null>(null);
  const isInitialLoadRef = useRef(true);
  const mountedRef = useRef(true);
  const pollIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);
  const sseFailedRef = useRef(false);

  const fetchNotifications = useCallback(async (isInitial = false) => {
    try {
      const res = await fetch(`/api/notifications?limit=${MAX_NOTIFICATIONS}`);
      if (!res.ok) return;

      const data = await res.json();
      if (!mountedRef.current) return;

      const fetchedNotifications: Notification[] = data.notifications || [];
      const fetchedUnreadCount: number = data.unreadCount || 0;

      // Smart deduplication: only update state if we have new data
      const newLastId = fetchedNotifications[0]?.id || null;
      const prevLastId = lastFetchedIdRef.current;

      if (isInitial || prevLastId !== newLastId) {
        setNotifications(fetchedNotifications);
        lastFetchedIdRef.current = newLastId;
      }

      // Always update unread count (can change via mark-as-read actions)
      setUnreadCount(fetchedUnreadCount);

      if (!isInitial) {
        setIsConnected(true);
      }
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
      if (!isInitial) {
        setIsConnected(false);
      }
    }
  }, []);

  // Mark a single notification as read
  const markAsRead = useCallback(async (id: string) => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });

      if (!res.ok) return;

      if (mountedRef.current) {
        // Optimistically update local state
        setNotifications((prev) =>
          prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
        );
        setUnreadCount((prev) => Math.max(0, prev - 1));
      }
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  }, []);

  // Mark all notifications as read
  const markAllRead = useCallback(async () => {
    try {
      const res = await fetch('/api/notifications/mark-all', {
        method: 'PUT',
      });

      if (!res.ok) return;

      if (mountedRef.current) {
        // Optimistically update local state
        setNotifications((prev) =>
          prev.map((n) => ({ ...n, isRead: true }))
        );
        setUnreadCount(0);
      }
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
    }
  }, []);

  // Start polling as fallback
  const startPolling = useCallback(() => {
    if (pollIntervalRef.current) return; // Already polling
    pollIntervalRef.current = setInterval(async () => {
      await fetchNotifications(false);
    }, POLL_INTERVAL);
  }, [fetchNotifications]);

  // Stop polling
  const stopPolling = useCallback(() => {
    if (pollIntervalRef.current) {
      clearInterval(pollIntervalRef.current);
      pollIntervalRef.current = null;
    }
  }, []);

  // Start SSE connection
  const startSSE = useCallback(() => {
    if (eventSourceRef.current) return;

    const es = new EventSource('/api/notifications/stream');
    eventSourceRef.current = es;

    es.addEventListener('connected', () => {
      if (mountedRef.current) {
        setIsConnected(true);
        sseFailedRef.current = false;
        // Stop polling when SSE is connected
        stopPolling();
      }
    });

    es.addEventListener('notification', (event) => {
      try {
        const notification: Notification = JSON.parse(event.data);
        if (!mountedRef.current) return;

        // Prepend the new notification to the list
        setNotifications((prev) => {
          // Avoid duplicates
          if (prev.some((n) => n.id === notification.id)) return prev;
          return [notification, ...prev].slice(0, MAX_NOTIFICATIONS);
        });

        // Increment unread count if not already read
        if (!notification.isRead) {
          setUnreadCount((prev) => prev + 1);
        }
      } catch {
        console.error('Failed to parse SSE notification:', event.data);
      }
    });

    es.onerror = () => {
      if (!mountedRef.current) return;
      console.warn('SSE connection error, falling back to polling');
      setIsConnected(false);
      sseFailedRef.current = true;

      // Close this EventSource and start polling
      es.close();
      eventSourceRef.current = null;
      startPolling();
    };
  }, [stopPolling, startPolling]);

  // Initial load + SSE setup
  useEffect(() => {
    mountedRef.current = true;

    const init = async () => {
      if (isInitialLoadRef.current) {
        // First load: fetch immediately
        await fetchNotifications(true);
        isInitialLoadRef.current = false;
        setIsConnected(true);
      }

      // Start polling as baseline (SSE will stop it if it connects)
      startPolling();

      // Attempt SSE connection
      // EventSource auto-reconnects natively, but we also have a polling safety net
      if (!sseFailedRef.current) {
        startSSE();
      }
    };

    init();

    return () => {
      mountedRef.current = false;
      stopPolling();
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
    };
  }, [fetchNotifications, startPolling, startSSE, stopPolling]);

  // Listen for tab visibility changes to refresh on tab focus
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && mountedRef.current) {
        fetchNotifications(false);
        // Re-attempt SSE if it failed before
        if (sseFailedRef.current && !eventSourceRef.current) {
          sseFailedRef.current = false;
          startSSE();
        }
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [fetchNotifications, startSSE]);

  return {
    notifications,
    unreadCount,
    isConnected,
    markAsRead,
    markAllRead,
    refresh: () => fetchNotifications(false),
  };
}
