'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { useEffect, useState } from 'react';
import {
  LayoutDashboard, Wallet, TrendingUp, ArrowDownToLine, ArrowUpFromLine, Users,
  Megaphone, User, LogOut, X, Copy, Bot, Trophy, UsersRound, Shield, Lock,
  Bell, ScrollText, Landmark, Gem, Headphones, FileCheck, Settings,
  CreditCard, ArrowRightLeft, ChevronDown, ChevronUp
} from 'lucide-react';

interface NavSection {
  title: string;
  items: { href: string; label: string; icon: typeof LayoutDashboard }[];
}

const userSections: NavSection[] = [
  {
    title: 'الرئيسية',
    items: [
      { href: '/dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
    ],
  },
  {
    title: 'الاستثمار',
    items: [
      { href: '/plans', label: 'خطط الاستثمار', icon: Gem },
      { href: '/investments', label: 'استثماراتي', icon: TrendingUp },
      { href: '/profits', label: 'الأرباح', icon: Wallet },
    ],
  },
  {
    title: 'المحفظة',
    items: [
      { href: '/deposits', label: 'الإيداع', icon: ArrowDownToLine },
      { href: '/withdrawals', label: 'السحب', icon: ArrowUpFromLine },
      { href: '/activity-log', label: 'سجل المعاملات', icon: ArrowRightLeft },
    ],
  },
  {
    title: 'الأدوات',
    items: [
      { href: '/copy-trading', label: 'نسخ التداول', icon: Copy },
      { href: '/trading-bots', label: 'روبوتات التداول', icon: Bot },
      { href: '/leaderboard', label: 'لوحة المتصدرين', icon: Trophy },
      { href: '/team-competition', label: 'منافسة الفرق', icon: UsersRound },
    ],
  },
  {
    title: 'الحساب',
    items: [
      { href: '/referrals', label: 'الإحالات', icon: Users },
      { href: '/kyc', label: 'التوثيق', icon: Shield },
      { href: '/pin', label: 'رمز PIN', icon: Lock },
      { href: '/notifications', label: 'الإشعارات', icon: Bell },
      { href: '/ads', label: 'الإعلانات', icon: Megaphone },
      { href: '/support', label: 'الدعم الفني', icon: Headphones },
      { href: '/profile', label: 'الملف الشخصي', icon: User },
    ],
  },
];

interface AdminNavSection {
  title: string;
  items: { href: string; label: string; icon: typeof LayoutDashboard }[];
}

const adminSections: AdminNavSection[] = [
  {
    title: 'نظرة عامة',
    items: [
      { href: '/admin/dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
      { href: '/admin/settings', label: 'الإعدادات', icon: Settings },
    ],
  },
  {
    title: 'إدارة المستخدمين',
    items: [
      { href: '/admin/users', label: 'المستخدمين', icon: Users },
      { href: '/admin/kyc', label: 'التوثيق (KYC)', icon: Shield },
      { href: '/admin/referrals', label: 'الإحالات', icon: Users },
      { href: '/admin/agents', label: 'الوكلاء', icon: Users },
    ],
  },
  {
    title: 'المعاملات المالية',
    items: [
      { href: '/admin/deposits', label: 'الإيداعات', icon: CreditCard },
      { href: '/admin/withdrawals', label: 'طلبات السحب', icon: ArrowDownToLine },
      { href: '/admin/rates', label: 'إدارة النسب', icon: TrendingUp },
    ],
  },
  {
    title: 'المنصة',
    items: [
      { href: '/admin/plans', label: 'خطط الاستثمار', icon: Gem },
      { href: '/admin/trading-bots', label: 'بوتات التداول', icon: Bot },
      { href: '/admin/coupons', label: 'الكوبونات', icon: CreditCard },
      { href: '/admin/ads', label: 'الإعلانات', icon: Megaphone },
    ],
  },
  {
    title: 'التواصل والتحليل',
    items: [
      { href: '/admin/notifications', label: 'إشعارات جماعية', icon: Bell },
      { href: '/admin/support', label: 'تذاكر الدعم', icon: Headphones },
      { href: '/admin/reports', label: 'التقارير', icon: TrendingUp },
      { href: '/admin/activity-log', label: 'سجل العمليات', icon: ScrollText },
    ],
  },
];

function SectionLabel({ label }: { label: string }) {
  return (
    <div className="px-4 pt-4 pb-1.5">
      <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 select-none">
        {label}
      </span>
    </div>
  );
}

export function UserSidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = usePathname();
  const { logout } = useAuth();
  const [unreadNotifs, setUnreadNotifs] = useState(false);
  const [openTickets, setOpenTickets] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchBadges = async () => {
      try {
        const [nRes, sRes] = await Promise.all([
          fetch('/api/notifications?limit=1').catch(() => null),
          fetch('/api/support?limit=1').catch(() => null),
        ]);
        if (nRes?.ok) {
          const nData = await nRes.json();
          const hasUnread = (nData.notifications || []).some((n: { isRead: boolean }) => !n.isRead);
          setUnreadNotifs(hasUnread || (nData.unreadCount || 0) > 0);
        }
        if (sRes?.ok) {
          const sData = await sRes.json();
          const pendingCount = (sData.tickets || []).filter((t: { status: string }) => t.status === 'open' || t.status === 'pending').length;
          setOpenTickets(pendingCount > 0);
        }
      } catch { /* silent fail */ }
    };
    fetchBadges();
    const interval = setInterval(fetchBadges, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = async () => {
    await logout();
    onClose();
  };

  const hasBadge = (href: string) => {
    if (href === '/notifications') return unreadNotifs;
    if (href === '/support') return openTickets;
    return false;
  };

  const toggleSection = (title: string) => {
    setCollapsedSections(prev => {
      const next = new Set(prev);
      if (next.has(title)) next.delete(title);
      else next.add(title);
      return next;
    });
  };

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm" onClick={onClose} />}
      <aside className={`fixed top-0 right-0 h-full w-64 bg-[#0D1117] border-l border-[#2A3040]/50 z-50 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        {/* Sidebar header with gradient */}
        <div className="relative overflow-hidden p-4 border-b border-[#2A3040]/50">
          <div className="absolute inset-0 bg-gradient-to-l from-[#2ECC71]/5 to-transparent pointer-events-none" />
          <div className="relative flex items-center justify-between">
            <Link href="/dashboard" className="flex items-center gap-2.5 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-bold text-sm shadow-lg shadow-[#2ECC71]/20 group-hover:shadow-[#2ECC71]/40 transition-shadow">T</div>
              <span className="gradient-text-animated font-bold text-lg">تداولاي</span>
            </Link>
            <button onClick={onClose} className="lg:hidden text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-[#1A1F2E]"><X size={20} /></button>
          </div>
        </div>
        <nav className="overflow-y-auto max-h-[calc(100vh-140px)] scrollbar-thin">
          {userSections.map((section) => {
            const isCollapsed = collapsedSections.has(section.title);
            const hasActiveItem = section.items.some(item => pathname === item.href);
            const isSingle = section.items.length === 1;

            return (
              <div key={section.title}>
                {!isSingle && (
                  <button
                    onClick={() => toggleSection(section.title)}
                    className="w-full px-4 pt-4 pb-1.5 flex items-center justify-between group select-none"
                  >
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 group-hover:text-gray-400 transition-colors">
                      {section.title}
                    </span>
                    {isCollapsed ? <ChevronUp size={12} className="text-gray-600" /> : <ChevronDown size={12} className="text-gray-600" />}
                  </button>
                )}
                {!isCollapsed && (
                  <div className="px-2 space-y-0.5">
                    {section.items.map(item => {
                      const isActive = pathname === item.href;
                      const showBadge = hasBadge(item.href);
                      return (
                        <Link
                          key={item.href}
                          href={item.href}
                          onClick={onClose}
                          className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all text-[13px] relative ${
                            isActive
                              ? 'bg-[#2ECC71]/10 text-[#2ECC71] font-medium neon-emerald'
                              : 'text-gray-400 hover:bg-[#1A1F2E] hover:text-white'
                          }`}
                        >
                          <item.icon size={17} className={isActive ? 'text-[#2ECC71]' : 'text-gray-500'} />
                          <span>{item.label}</span>
                          {showBadge && (
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-[#0D1117]" />
                          )}
                          {isActive && (
                            <span className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-full bg-[#2ECC71]" />
                          )}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>
        {/* Gradient divider */}
        <div className="gradient-divider mx-4 my-2" />
        {/* Logout */}
        <div className="p-3">
          <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm w-full text-red-400/70 hover:text-red-400 hover:bg-red-500/10 transition-all card-lift">
            <LogOut size={17} />
            تسجيل الخروج
          </button>
        </div>
      </aside>
    </>
  );
}

export function AdminSidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = usePathname();
  const { logout } = useAuth();
  const [pendingTickets, setPendingTickets] = useState(false);
  const [pendingKYC, setPendingKYC] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchBadges = async () => {
      try {
        const [sRes, kRes] = await Promise.all([
          fetch('/api/support?limit=1').catch(() => null),
          fetch('/api/admin/kyc?status=pending&limit=1').catch(() => null),
        ]);
        if (sRes?.ok) {
          const sData = await sRes.json();
          const openCount = (sData.tickets || []).filter((t: { status: string }) => t.status === 'open' || t.status === 'pending').length;
          setPendingTickets(openCount > 0);
        }
        if (kRes?.ok) {
          const kData = await kRes.json();
          setPendingKYC((kData.stats?.pending || 0) > 0);
        }
      } catch { /* silent fail */ }
    };
    fetchBadges();
    const interval = setInterval(fetchBadges, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = async () => {
    await logout();
    onClose();
  };

  const hasBadge = (href: string) => {
    if (href === '/admin/support') return pendingTickets;
    if (href === '/admin/kyc') return pendingKYC;
    return false;
  };

  const toggleSection = (title: string) => {
    setCollapsedSections(prev => {
      const next = new Set(prev);
      if (next.has(title)) next.delete(title);
      else next.add(title);
      return next;
    });
  };

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm" onClick={onClose} />}
      <aside className={`fixed top-0 right-0 h-full w-64 bg-[#0A0C10] border-l border-[#2A3040]/50 z-50 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        {/* Sidebar header with gradient */}
        <div className="relative overflow-hidden p-4 border-b border-[#2A3040]/50">
          <div className="absolute inset-0 bg-gradient-to-l from-[#FFD700]/5 to-transparent pointer-events-none" />
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-bold text-sm shadow-lg shadow-[#FFD700]/20">T</div>
              <div>
                <span className="gradient-text-animated font-bold text-sm">تداولاي</span>
                <p className="text-[10px] text-gray-500">لوحة الإدارة</p>
              </div>
            </div>
            <button onClick={onClose} className="lg:hidden text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-[#1A1F2E]"><X size={20} /></button>
          </div>
        </div>
        <nav className="overflow-y-auto max-h-[calc(100vh-140px)] scrollbar-thin">
          {adminSections.map((section) => {
            const isCollapsed = collapsedSections.has(section.title);
            const hasActiveItem = section.items.some(item => pathname === item.href);

            return (
              <div key={section.title}>
                <button
                  onClick={() => toggleSection(section.title)}
                  className="w-full px-4 pt-4 pb-1.5 flex items-center justify-between group select-none"
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 group-hover:text-gray-400 transition-colors">
                    {section.title}
                  </span>
                  {isCollapsed ? <ChevronUp size={12} className="text-gray-600" /> : <ChevronDown size={12} className="text-gray-600" />}
                </button>
                {!isCollapsed && (
                  <div className="px-2 space-y-0.5">
                    {section.items.map(item => {
                      const isActive = pathname === item.href;
                      const showBadge = hasBadge(item.href);
                      return (
                        <Link
                          key={item.href}
                          href={item.href}
                          onClick={onClose}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-xs relative ${
                            isActive
                              ? 'bg-[#FFD700]/10 text-[#FFD700] font-medium neon-gold'
                              : 'text-gray-400 hover:bg-[#1A1F2E] hover:text-white'
                          }`}
                        >
                          <item.icon size={16} className={isActive ? 'text-[#FFD700]' : 'text-gray-500'} />
                          <span>{item.label}</span>
                          {showBadge && (
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-[#0A0C10]" />
                          )}
                          {isActive && (
                            <span className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-5 rounded-full bg-[#FFD700]" />
                          )}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>
        <div className="gradient-divider mx-4 my-2" />
        <div className="p-3">
          <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs w-full text-red-400/70 hover:text-red-400 hover:bg-red-500/10 transition-all card-lift">
            <LogOut size={16} />
            تسجيل الخروج
          </button>
        </div>
      </aside>
    </>
  );
}
