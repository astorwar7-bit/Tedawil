'use client';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  size?: number;
  interactive?: boolean;
  onRate?: (rating: number) => void;
}

export default function StarRating({ rating, size = 14, interactive = false, onRate }: StarRatingProps) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={!interactive}
          onClick={() => interactive && onRate?.(star)}
          className={`${interactive ? 'cursor-pointer hover:scale-110 transition-transform' : 'cursor-default'}`}
          aria-label={`${star} نجوم`}
        >
          <Star
            size={size}
            className={`transition-colors ${
              star <= rating
                ? 'fill-[#FFD700] text-[#FFD700]'
                : 'fill-[#2A3040] text-[#2A3040]'
            }`}
          />
        </button>
      ))}
    </div>
  );
}
