'use client';

import { useState, useEffect, useRef, useMemo } from 'react';
import {
  Bell,
  CheckCheck,
  TrendingUp,
  AlertTriangle,
  Gift,
  Info,
  DollarSign,
  Shield,
  Megaphone,
  X,
  ArrowLeft,
  Clock,
} from 'lucide-react';
import { useRealtimeNotifications, type Notification } from '@/hooks/useRealtimeNotifications';

// Map notification types to icons and colors
function getNotificationStyle(type: string): {
  icon: React.ReactNode;
  bg: string;
  border: string;
  iconColor: string;
} {
  switch (type) {
    case 'profit':
      return {
        icon: <TrendingUp size={16} />,
        bg: 'bg-emerald-500/10',
        border: 'border-emerald-500/20',
        iconColor: 'text-emerald-400',
      };
    case 'warning':
    case 'alert':
      return {
        icon: <AlertTriangle size={16} />,
        bg: 'bg-amber-500/10',
        border: 'border-amber-500/20',
        iconColor: 'text-amber-400',
      };
    case 'coupon':
    case 'bonus':
      return {
        icon: <Gift size={16} />,
        bg: 'bg-purple-500/10',
        border: 'border-purple-500/20',
        iconColor: 'text-purple-400',
      };
    case 'deposit':
    case 'withdrawal':
      return {
        icon: <DollarSign size={16} />,
        bg: 'bg-blue-500/10',
        border: 'border-blue-500/20',
        iconColor: 'text-blue-400',
      };
    case 'security':
      return {
        icon: <Shield size={16} />,
        bg: 'bg-red-500/10',
        border: 'border-red-500/20',
        iconColor: 'text-red-400',
      };
    case 'announcement':
      return {
        icon: <Megaphone size={16} />,
        bg: 'bg-gold/10',
        border: 'border-gold/20',
        iconColor: 'text-gold',
      };
    default:
      return {
        icon: <Info size={16} />,
        bg: 'bg-gray-500/10',
        border: 'border-gray-500/20',
        iconColor: 'text-gray-400',
      };
  }
}

// Relative time formatter in Arabic
function formatTimeAgo(dateStr: string): string {
  const now = Date.now();
  const date = new Date(dateStr).getTime();
  const diffMs = now - date;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);
  const diffWeek = Math.floor(diffDay / 7);

  if (diffSec < 60) return 'الآن';
  if (diffMin < 60) return `منذ ${diffMin} دقيقة`;
  if (diffHour < 24) return `منذ ${diffHour} ساعة`;
  if (diffDay < 7) return `منذ ${diffDay} يوم`;
  if (diffWeek < 4) return `منذ ${diffWeek} أسبوع`;
  return new Date(dateStr).toLocaleDateString('ar-EG');
}

// Single notification item
function NotificationItem({
  notification,
  onMarkRead,
}: {
  notification: Notification;
  onMarkRead: (id: string) => void;
}) {
  const style = useMemo(() => getNotificationStyle(notification.type), [notification.type]);

  return (
    <button
      onClick={() => {
        if (!notification.isRead) {
          onMarkRead(notification.id);
        }
      }}
      className={`w-full flex items-start gap-3 p-3 rounded-xl text-right transition-all duration-200 group
        ${notification.isRead
          ? 'opacity-70 hover:opacity-90 hover:bg-white/[0.04]'
          : 'bg-white/[0.03] hover:bg-white/[0.06]'
        }`}
    >
      {/* Unread indicator dot */}
      <div className="flex-shrink-0 pt-1.5">
        {!notification.isRead && (
          <div className="w-2 h-2 rounded-full bg-gold animate-pulse" />
        )}
      </div>

      {/* Icon */}
      <div
        className={`flex-shrink-0 w-9 h-9 rounded-lg ${style.bg} border ${style.border} flex items-center justify-center ${style.iconColor}`}
      >
        {style.icon}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <p
          className={`text-sm font-medium truncate leading-relaxed ${
            notification.isRead ? 'text-gray-400' : 'text-white'
          }`}
        >
          {notification.title}
        </p>
        <p className="text-xs text-gray-400 mt-0.5 line-clamp-2 leading-relaxed">
          {notification.message}
        </p>
        <div className="flex items-center gap-1 mt-1.5">
          <Clock size={10} className="text-gray-500" />
          <span className="text-[10px] text-gray-500">
            {formatTimeAgo(notification.createdAt)}
          </span>
        </div>
      </div>
    </button>
  );
}

// Main NotificationBell component
export function NotificationBell() {
  const {
    notifications,
    unreadCount,
    isConnected,
    markAsRead,
    markAllRead,
  } = useRealtimeNotifications();

  const [isOpen, setIsOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        panelRef.current &&
        !panelRef.current.contains(e.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  // Auto-mark all as read when dropdown opens
  useEffect(() => {
    if (isOpen && unreadCount > 0) {
      markAllRead();
    }
  }, [isOpen]);

  // Close dropdown on route change
  useEffect(() => {
    const handleRouteChange = () => setIsOpen(false);
    window.addEventListener('popstate', handleRouteChange);
    return () => window.removeEventListener('popstate', handleRouteChange);
  }, []);

  const handleMarkAllRead = async () => {
    await markAllRead();
  };

  return (
    <div className="relative">
      {/* Bell button */}
      <button
        ref={buttonRef}
        onClick={() => setIsOpen(!isOpen)}
        className={`relative p-2 rounded-xl transition-all duration-300 group ${
          isOpen
            ? 'bg-white/[0.06] text-gold'
            : 'hover:bg-white/[0.04] text-gray-400 hover:text-gray-200'
        }`}
        aria-label="الإشعارات"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <Bell
          size={20}
          className={`transition-transform duration-300 ${isOpen ? 'scale-110' : ''} ${
            isOpen ? 'text-gold' : 'group-hover:text-gold/80'
          }`}
        />
        {/* Connection status indicator */}
        {isConnected && (
          <div className="absolute -bottom-0.5 right-1/2 translate-x-1/2 w-1 h-1 rounded-full bg-emerald-400" />
        )}
        {/* Unread badge */}
        {unreadCount > 0 && (
          <span className="absolute -top-0.5 -left-0.5 min-w-5 h-5 px-1 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold pulse-badge shadow-lg shadow-red-500/20">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown panel */}
      {isOpen && (
        <div
          ref={panelRef}
          className="absolute left-0 sm:left-auto sm:right-0 top-full mt-3 w-[calc(100vw-2rem)] sm:w-80 sm:w-96 max-w-[calc(100vw-2rem)] z-50 animate-scaleIn overflow-hidden rounded-xl shadow-2xl shadow-black/60 border border-[#2A3040]"
          style={{ background: 'rgba(26, 31, 46, 0.97)', backdropFilter: 'blur(20px)', transformOrigin: 'top left' }}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-[#2A3040]/50">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold/20 to-emerald-500/20 border border-gold/10 flex items-center justify-center">
                <Bell size={15} className="text-gold" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-100">الإشعارات</h3>
                <p className="text-[10px] text-gray-500">
                  {unreadCount > 0
                    ? `${unreadCount} إشعار غير مقروء`
                    : 'لا توجد إشعارات جديدة'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              {unreadCount > 0 && (
                <button
                  onClick={handleMarkAllRead}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-medium text-gold hover:bg-gold/10 transition-colors"
                  title="تحديد الكل كمقروء"
                >
                  <CheckCheck size={13} />
                  <span className="hidden sm:inline">قراءة الكل</span>
                </button>
              )}
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 rounded-lg text-gray-500 hover:text-gray-300 hover:bg-white/[0.04] transition-colors"
              >
                <X size={14} />
              </button>
            </div>
          </div>

          {/* Notification list */}
          <div className="max-h-80 overflow-y-auto scrollbar-thin">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-4">
                <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-[#2A3040]/50 flex items-center justify-center mb-3">
                  <Bell size={24} className="text-gray-600" />
                </div>
                <p className="text-sm text-gray-500 font-medium">لا توجد إشعارات</p>
                <p className="text-xs text-gray-600 mt-1">
                  ستتلقى إشعارات هنا عند حدوث أحداث جديدة
                </p>
              </div>
            ) : (
              <div className="p-2 space-y-0.5">
                {notifications.map((notification) => (
                  <NotificationItem
                    key={notification.id}
                    notification={notification}
                    onMarkRead={markAsRead}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="border-t border-[#2A3040]/50 p-2">
              <a
                href="/notifications"
                onClick={() => setIsOpen(false)}
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg text-xs font-medium text-gray-400 hover:text-gold hover:bg-gold/[0.05] transition-all"
              >
                <span>عرض جميع الإشعارات</span>
                <ArrowLeft size={13} className="rotate-180" />
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
