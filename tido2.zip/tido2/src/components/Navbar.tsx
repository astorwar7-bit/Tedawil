'use client';
import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Bell, Menu, LogOut, User, Settings, ChevronDown, X, Wallet } from 'lucide-react';
import { NotificationBell } from '@/components/NotificationBell';
import { useRealtimeNotifications } from '@/hooks/useRealtimeNotifications';

export function Navbar({ onMenuClick, isAdmin, isAgent }: { onMenuClick: () => void; isAdmin?: boolean; isAgent?: boolean }) {
  const { user, logout } = useAuth();
  const [dropdown, setDropdown] = useState(false);
  const [hamburgerOpen, setHamburgerOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const mobileSheetRef = useRef<HTMLDivElement>(null);
  const { unreadCount } = useRealtimeNotifications();

  // Close dropdown on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdown(false);
      }
      if (mobileSheetRef.current && !mobileSheetRef.current.contains(e.target as Node)) {
        setDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('touchstart', handleClick as unknown as EventListener);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('touchstart', handleClick as unknown as EventListener);
    };
  }, []);

  // Close dropdown on escape key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setDropdown(false);
    };
    document.addEventListener('keydown', handleEsc);
    return () => document.removeEventListener('keydown', handleEsc);
  }, []);

  const handleLogout = () => {
    setDropdown(false);
    setHamburgerOpen(false);
    logout();
  };

  return (
    <>
      <header className="sticky top-0 z-30 bg-[#0A0F0D]/90 backdrop-blur-2xl border-b border-[#2A3040]/40">
        <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 sm:py-3">
          {/* Left section: hamburger + logo */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Animated hamburger button */}
            <button
              onClick={() => { setHamburgerOpen(!hamburgerOpen); onMenuClick(); }}
              className="lg:hidden touch-target relative w-11 h-11 flex items-center justify-center text-gray-400 hover:text-white rounded-xl hover:bg-[#1A1F2E] transition-all active:scale-95"
              aria-label="فتح القائمة"
            >
              <div className="flex flex-col gap-1.5 items-center justify-center w-5 h-5">
                <span className={`block h-[2px] w-5 bg-current rounded-full transition-all duration-300 ${hamburgerOpen ? 'rotate-45 translate-y-[7px]' : ''}`} />
                <span className={`block h-[2px] w-5 bg-current rounded-full transition-all duration-300 ${hamburgerOpen ? 'opacity-0 scale-0' : ''}`} />
                <span className={`block h-[2px] w-5 bg-current rounded-full transition-all duration-300 ${hamburgerOpen ? '-rotate-45 -translate-y-[7px]' : ''}`} />
              </div>
            </button>
            {!isAdmin && !isAgent && (
              <a href="/dashboard" className="flex items-center gap-2 lg:hidden">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-bold text-sm shadow-lg shadow-[#FFD700]/20">
                  T
                </div>
              </a>
            )}
            {isAgent && (
              <a href="/agent-dashboard" className="flex items-center gap-2 lg:hidden">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-bold text-sm shadow-lg shadow-[#FFD700]/20">
                  T
                </div>
              </a>
            )}
          </div>

          {/* Swipe hint text - only visible on first visit (hidden by default, shown briefly) */}
          {/* We add a subtle swipe icon hint on the hamburger side */}
          <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-gray-500/50 pointer-events-none select-none">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="opacity-60">
              <path d="M15 18l-6-6 6-6" />
            </svg>
            <span>اسحب للقائمة</span>
          </div>

          {/* Center: Balance display for agents */}
          {(isAgent || !isAdmin) && user && (
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#FFD700]/[0.06] border border-[#FFD700]/15">
              <Wallet size={14} className="text-[#FFD700]" />
              <span className="text-[#FFD700] font-bold text-sm" dir="ltr">${(user.balance || 0).toLocaleString('en', { minimumFractionDigits: 2 })}</span>
            </div>
          )}

          {/* Right section: notifications + user */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {user && (
              <>
                {/* Notification bell - real-time dropdown */}
                <NotificationBell />

                {/* Desktop user dropdown */}
                <div className="relative hidden sm:block" ref={dropdownRef}>
                  <button
                    onClick={() => setDropdown(!dropdown)}
                    className="flex items-center gap-2 text-sm text-gray-300 hover:text-white transition-all touch-target rounded-xl hover:bg-[#1A1F2E]/50 active:scale-95 px-1"
                  >
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 border-2 border-[#2A3040] flex items-center justify-center text-[#FFD700] font-bold text-xs hover:border-[#FFD700]/30 transition-all">
                      {user.username?.[0]?.toUpperCase()}
                    </div>
                    <span className="hidden md:block">{user.fullName || user.username}</span>
                    <ChevronDown size={14} className={`transition-transform duration-300 ${dropdown ? 'rotate-180' : ''}`} />
                  </button>
                  {dropdown && (
                    <div className="absolute left-0 mt-2 w-56 glass-card py-1 z-50 animate-fadeIn" style={{ transform: 'none' }}>
                      {/* User info header */}
                      <div className="px-4 py-3 border-b border-[#2A3040]/50">
                        <p className="text-sm font-semibold text-white">{user.fullName || user.username}</p>
                        <p className="text-xs text-gray-400 mt-0.5">{user.email}</p>
                      </div>
                      <a href="/profile" onClick={() => setDropdown(false)} className="flex items-center gap-2.5 px-4 py-3 text-sm text-gray-300 hover:bg-[#2A3040]/50 hover:text-white transition-colors">
                        <User size={16} className="text-gray-400" /> الملف الشخصي
                      </a>
                      <a href={isAdmin ? '/admin/settings' : isAgent ? '/agent-dashboard/profile' : '/profile'} onClick={() => setDropdown(false)} className="flex items-center gap-2.5 px-4 py-3 text-sm text-gray-300 hover:bg-[#2A3040]/50 hover:text-white transition-colors">
                        <Settings size={16} className="text-gray-400" /> الإعدادات
                      </a>
                      <div className="gradient-divider my-1" />
                      <button onClick={handleLogout} className="w-full flex items-center gap-2.5 px-4 py-3 text-sm text-red-400/80 hover:bg-red-500/10 hover:text-red-400 transition-colors">
                        <LogOut size={16} /> تسجيل الخروج
                      </button>
                    </div>
                  )}
                </div>

                {/* Mobile user avatar button (opens bottom sheet) */}
                <button
                  onClick={() => setDropdown(!dropdown)}
                  className="sm:hidden relative touch-target w-11 h-11 flex items-center justify-center rounded-xl hover:bg-[#1A1F2E] active:scale-95 transition-all"
                  aria-label="القائمة الشخصية"
                >
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 border-2 border-[#2A3040] flex items-center justify-center text-[#FFD700] font-bold text-xs">
                    {user.username?.[0]?.toUpperCase()}
                  </div>
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Mobile bottom sheet for user dropdown */}
      {dropdown && user && (
        <>
          {/* Backdrop */}
          <div
            className="sm:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-50 animate-fadeIn"
            onClick={() => setDropdown(false)}
          />
          {/* Sheet panel */}
          <div
            ref={mobileSheetRef}
            className="sm:hidden fixed bottom-0 left-0 right-0 z-50 animate-slide-up"
            style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
          >
            <div className="bg-[#12161F] rounded-t-3xl border-t border-[#2A3040]/50 shadow-2xl">
              {/* Drag handle */}
              <div className="flex justify-center pt-3 pb-2">
                <div className="w-10 h-1 rounded-full bg-gray-600" />
              </div>

              {/* User info */}
              <div className="px-5 pb-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#FFD700]/20 to-[#2ECC71]/20 border-2 border-[#FFD700]/20 flex items-center justify-center text-[#FFD700] font-bold text-lg">
                  {user.username?.[0]?.toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{user.fullName || user.username}</p>
                  <p className="text-xs text-gray-400 truncate">{user.email}</p>
                </div>
                <button onClick={() => setDropdown(false)} className="touch-target w-8 h-8 flex items-center justify-center rounded-full hover:bg-[#2A3040]/50 text-gray-400">
                  <X size={18} />
                </button>
              </div>

              <div className="gradient-divider mx-5" />

              {/* Menu items */}
              <div className="px-3 py-2">
                <a
                  href="/profile"
                  onClick={() => setDropdown(false)}
                  className="flex items-center gap-3 px-3 py-3.5 text-sm text-gray-200 hover:bg-[#2A3040]/40 rounded-2xl transition-colors touch-target active:bg-[#2A3040]/60"
                >
                  <div className="w-9 h-9 rounded-xl bg-[#1A1F2E] flex items-center justify-center">
                    <User size={18} className="text-[#FFD700]" />
                  </div>
                  الملف الشخصي
                </a>
                <a
                  href={isAdmin ? '/admin/settings' : '/profile'}
                  onClick={() => setDropdown(false)}
                  className="flex items-center gap-3 px-3 py-3.5 text-sm text-gray-200 hover:bg-[#2A3040]/40 rounded-2xl transition-colors touch-target active:bg-[#2A3040]/60"
                >
                  <div className="w-9 h-9 rounded-xl bg-[#1A1F2E] flex items-center justify-center">
                    <Settings size={18} className="text-gray-400" />
                  </div>
                  الإعدادات
                </a>
                <a
                  href="/notifications"
                  onClick={() => setDropdown(false)}
                  className="flex items-center gap-3 px-3 py-3.5 text-sm text-gray-200 hover:bg-[#2A3040]/40 rounded-2xl transition-colors touch-target active:bg-[#2A3040]/60 relative"
                >
                  <div className="w-9 h-9 rounded-xl bg-[#1A1F2E] flex items-center justify-center relative">
                    <Bell size={18} className="text-gray-400" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </span>
                    )}
                  </div>
                  الإشعارات
                  {unreadCount > 0 && <span className="mr-auto text-xs text-[#FFD700] font-medium">{unreadCount} جديد</span>}
                </a>
              </div>

              <div className="gradient-divider mx-5" />

              {/* Logout */}
              <div className="px-3 pb-3 pt-2">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-3 py-3.5 text-sm text-red-400 hover:bg-red-500/10 rounded-2xl transition-colors touch-target active:bg-red-500/20"
                >
                  <div className="w-9 h-9 rounded-xl bg-red-500/10 flex items-center justify-center">
                    <LogOut size={18} className="text-red-400" />
                  </div>
                  تسجيل الخروج
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}
