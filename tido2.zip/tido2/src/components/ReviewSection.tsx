'use client';
import { useEffect, useState } from 'react';
import { MessageSquarePlus, ChevronDown, ChevronUp, Trash2, Send } from 'lucide-react';
import { useToast } from '@/contexts/ToastContext';
import StarRating from './StarRating';

interface ReviewUser {
  id: string;
  username: string;
  fullName: string;
  avatar: string;
}

interface Review {
  id: string;
  rating: number;
  comment: string;
  createdAt: string;
  user: ReviewUser;
  userId: string;
}

interface ReviewSectionProps {
  itemId: string;
  itemType: 'plan' | 'bot';
}

export default function ReviewSection({ itemId, itemType }: ReviewSectionProps) {
  const { showToast } = useToast();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [avgRating, setAvgRating] = useState(0);
  const [totalReviews, setTotalReviews] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [currentUserId, setCurrentUserId] = useState('');

  const fetchReviews = async (pageNum: number = 1) => {
    setLoading(true);
    try {
      const paramKey = itemType === 'plan' ? 'planId' : 'botId';
      const res = await fetch(`/api/reviews?${paramKey}=${itemId}&page=${pageNum}&limit=5`);
      const data = await res.json();
      setReviews(data.reviews || []);
      setTotalReviews(data.total || 0);
      setAvgRating(data.avgRating || 0);
      setTotalPages(data.pages || 0);
      setPage(pageNum);
    } catch {
      showToast('حدث خطأ أثناء تحميل التقييمات', 'error');
    }
    setLoading(false);
  };

  const fetchCurrentUser = async () => {
    try {
      const res = await fetch('/api/auth/me');
      if (res.ok) {
        const data = await res.json();
        setCurrentUserId(data.user?.id || '');
      }
    } catch {
      // Not logged in
    }
  };

  useEffect(() => {
    fetchCurrentUser();
  }, []);

  useEffect(() => {
    if (expanded) {
      fetchReviews(1);
    }
  }, [expanded, itemId]);

  const handleSubmit = async () => {
    if (rating === 0) {
      showToast('يرجى اختيار التقييم', 'error');
      return;
    }
    setSubmitting(true);
    try {
      const body: Record<string, unknown> = {
        rating,
        comment,
        ...(itemType === 'plan' ? { planId: itemId } : { botId: itemId }),
      };
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('tedawilai_token')}`,
        },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error, 'error');
        setSubmitting(false);
        return;
      }
      showToast(data.message || 'تم إضافة التقييم بنجاح');
      setRating(0);
      setComment('');
      setShowForm(false);
      fetchReviews(1);
    } catch {
      showToast('حدث خطأ', 'error');
    }
    setSubmitting(false);
  };

  const handleDelete = async (reviewId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا التقييم؟')) return;
    try {
      const res = await fetch(`/api/reviews/${reviewId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${localStorage.getItem('tedawilai_token')}` },
      });
      const data = await res.json();
      if (!res.ok) {
        showToast(data.error, 'error');
        return;
      }
      showToast(data.message || 'تم حذف التقييم');
      fetchReviews(page);
    } catch {
      showToast('حدث خطأ', 'error');
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    if (diffDays === 0) return 'اليوم';
    if (diffDays === 1) return 'أمس';
    if (diffDays < 7) return `منذ ${diffDays} أيام`;
    if (diffDays < 30) return `منذ ${Math.floor(diffDays / 7)} أسابيع`;
    return `منذ ${Math.floor(diffDays / 30)} أشهر`;
  };

  return (
    <div className="border-t border-[#2A3040]/50 pt-3 mt-1">
      {/* Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between py-2 group"
      >
        <div className="flex items-center gap-2">
          <MessageSquarePlus size={14} className="text-[#FFD700]" />
          <span className="text-xs font-medium text-gray-300">المراجعات</span>
          {totalReviews > 0 && (
            <div className="flex items-center gap-1.5">
              <StarRating rating={Math.round(avgRating)} size={12} />
              <span className="text-[10px] text-gray-500">
                {avgRating} ({totalReviews})
              </span>
            </div>
          )}
        </div>
        {expanded ? (
          <ChevronUp size={14} className="text-gray-500 group-hover:text-gray-300 transition-colors" />
        ) : (
          <ChevronDown size={14} className="text-gray-500 group-hover:text-gray-300 transition-colors" />
        )}
      </button>

      {/* Expanded Reviews */}
      {expanded && (
        <div className="animate-fadeIn space-y-3">
          {/* Add Review Button / Form */}
          {!showForm && currentUserId && (
            <button
              onClick={() => setShowForm(true)}
              className="w-full py-2.5 rounded-xl bg-[#1A1F2E] border border-[#2A3040] hover:border-[#FFD700]/30 text-xs text-gray-400 hover:text-[#FFD700] transition-all flex items-center justify-center gap-2"
            >
              <MessageSquarePlus size={14} />
              أضف تقييمك
            </button>
          )}

          {showForm && (
            <div className="glass-card p-3 space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">أضف تقييمك</span>
                <button
                  onClick={() => { setShowForm(false); setRating(0); setComment(''); }}
                  className="text-gray-500 hover:text-gray-300 text-xs"
                >
                  إلغاء
                </button>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-400">التقييم:</span>
                <StarRating rating={rating} size={18} interactive onRate={setRating} />
              </div>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="شاركنا رأيك..."
                className="w-full bg-[#12161F] border border-[#2A3040] rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-[#FFD700]/50 resize-none"
                rows={2}
              />
              <button
                onClick={handleSubmit}
                disabled={submitting || rating === 0}
                className="btn-ripple px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all disabled:opacity-50 bg-[#FFD700]/10 border border-[#FFD700]/30 text-[#FFD700] hover:bg-[#FFD700]/20"
              >
                {submitting ? (
                  <div className="w-4 h-4 border-2 border-[#FFD700]/30 border-t-[#FFD700] rounded-full animate-spin" />
                ) : (
                  <Send size={12} />
                )}
                إرسال التقييم
              </button>
            </div>
          )}

          {/* Reviews List */}
          {loading ? (
            <div className="space-y-2">
              {[1, 2].map((i) => (
                <div key={i} className="bg-[#12161F] rounded-lg p-3 animate-pulse">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-full bg-[#2A3040]" />
                    <div className="h-3 w-20 bg-[#2A3040] rounded" />
                  </div>
                  <div className="h-2 w-full bg-[#2A3040] rounded" />
                </div>
              ))}
            </div>
          ) : reviews.length === 0 ? (
            <div className="text-center py-4">
              <MessageSquarePlus size={24} className="text-gray-600 mx-auto mb-2" />
              <p className="text-xs text-gray-500">لا توجد تقييمات بعد</p>
              <p className="text-[10px] text-gray-600">كن أول من يضيف تقييماً</p>
            </div>
          ) : (
            <>
              <div className="space-y-2 max-h-64 overflow-y-auto custom-scrollbar">
                {reviews.map((review) => (
                  <div
                    key={review.id}
                    className="bg-[#12161F] rounded-lg p-3 border border-[#2A3040]/50 hover:border-[#2A3040] transition-colors"
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[9px] font-bold text-[#0A0F0D]">
                          {review.user.fullName?.charAt(0) || review.user.username.charAt(0)}
                        </div>
                        <div>
                          <span className="text-xs font-medium text-white">
                            {review.user.fullName || review.user.username}
                          </span>
                          <span className="text-[10px] text-gray-600 mr-2">
                            {formatDate(review.createdAt)}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <StarRating rating={review.rating} size={10} />
                        {review.userId === currentUserId && (
                          <button
                            onClick={() => handleDelete(review.id)}
                            className="text-gray-600 hover:text-red-400 transition-colors mr-1"
                            aria-label="حذف التقييم"
                          >
                            <Trash2 size={10} />
                          </button>
                        )}
                      </div>
                    </div>
                    {review.comment && (
                      <p className="text-xs text-gray-400 leading-relaxed">{review.comment}</p>
                    )}
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 pt-1">
                  <button
                    onClick={() => fetchReviews(page - 1)}
                    disabled={page <= 1}
                    className="px-2.5 py-1 rounded-lg bg-[#1A1F2E] border border-[#2A3040] text-[10px] text-gray-400 hover:text-white disabled:opacity-30 transition-all"
                  >
                    السابق
                  </button>
                  <span className="text-[10px] text-gray-500">{page} / {totalPages}</span>
                  <button
                    onClick={() => fetchReviews(page + 1)}
                    disabled={page >= totalPages}
                    className="px-2.5 py-1 rounded-lg bg-[#1A1F2E] border border-[#2A3040] text-[10px] text-gray-400 hover:text-white disabled:opacity-30 transition-all"
                  >
                    التالي
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
