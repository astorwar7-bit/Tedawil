'use client';
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Navbar } from '@/components/Navbar';
import { UserSidebar } from '@/components/Sidebar';
import { useRouter } from 'next/navigation';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Gem, Bell, Wallet, User, ArrowRightLeft } from 'lucide-react';

const bottomNavItems = [
  { href: '/dashboard', icon: LayoutDashboard, label: 'الرئيسية' },
  { href: '/plans', icon: Gem, label: 'الخطط' },
  { href: '/notifications', icon: Bell, label: 'إشعارات', isCenter: true },
  { href: '/activity-log', icon: ArrowRightLeft, label: 'المعاملات' },
  { href: '/profile', icon: User, label: 'حسابي' },
];

export default function DashLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (!loading && !user) router.push('/');
    if (!loading && user?.isAdmin) router.push('/admin/dashboard');
    if (!loading && user?.isAgent) router.push('/agent-dashboard');
  }, [user, loading, router]);

  // Fetch unread notifications count for the center bell badge
  useEffect(() => {
    const fetchUnread = async () => {
      try {
        const res = await fetch('/api/notifications?limit=1');
        if (res.ok) {
          const data = await res.json();
          setUnreadCount(data.unreadCount || 0);
        }
      } catch {}
    };
    if (user) {
      fetchUnread();
      const interval = setInterval(fetchUnread, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#0A0F0D]"><div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>;
  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex overflow-x-hidden">
      <UserSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-h-screen">
        <Navbar onMenuClick={() => setSidebarOpen(true)} />
        <main className="flex-1 p-3 sm:p-4 md:p-6 overflow-x-hidden">{children}</main>

        {/* Mobile bottom navigation with glass effect */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 safe-bottom">
          {/* Glass background */}
          <div className="absolute inset-0 bg-[#0D1117]/85 backdrop-blur-2xl border-t border-[#2A3040]/40" />
          {/* Safe area spacer */}
          <div style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
            <div className="relative flex justify-around items-end px-1 pt-2 pb-2">
              {bottomNavItems.map((item) => {
                const isActive = pathname === item.href || (item.href !== '/dashboard' && pathname?.startsWith(item.href));

                if (item.isCenter) {
                  return (
                    <a
                      key={item.href}
                      href={item.href}
                      className="flex flex-col items-center justify-end touch-target"
                      style={{ minWidth: 52 }}
                    >
                      <span className={`text-[10px] font-medium mb-1 transition-colors ${isActive ? 'text-[#FFD700]' : 'text-gray-400'}`}>
                        {item.label}
                      </span>
                      {/* Raised center button */}
                      <div className="nav-center-btn">
                        <item.icon size={22} strokeWidth={2.5} />
                        {unreadCount > 0 && (
                          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center pulse-badge border-2 border-[#0D1117]">
                            {unreadCount > 9 ? '9+' : unreadCount}
                          </span>
                        )}
                      </div>
                    </a>
                  );
                }

                return (
                  <a
                    key={item.href}
                    href={item.href}
                    className="flex flex-col items-center justify-center relative touch-target rounded-2xl transition-all"
                    style={{ minWidth: 52, minHeight: 52 }}
                  >
                    {/* Active indicator bar */}
                    {isActive && (
                      <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-1 rounded-full bg-gradient-to-r from-[#FFD700] to-[#2ECC71] nav-active-indicator shadow-lg shadow-[#FFD700]/20" />
                    )}
                    {/* Active glow background */}
                    <div className={`absolute inset-0 rounded-2xl transition-opacity ${isActive ? 'opacity-100' : 'opacity-0'}`}
                      style={{
                        background: 'radial-gradient(circle at center, rgba(255, 215, 0, 0.08) 0%, transparent 70%)',
                      }}
                    />
                    <item.icon
                      size={22}
                      strokeWidth={isActive ? 2.5 : 1.8}
                      className={`relative z-10 transition-all ${isActive ? 'text-[#FFD700]' : 'text-gray-400'}`}
                    />
                    <span className={`text-[10px] font-medium relative z-10 mt-0.5 transition-colors ${isActive ? 'text-[#FFD700]' : 'text-gray-400'}`}>
                      {item.label}
                    </span>
                  </a>
                );
              })}
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}
