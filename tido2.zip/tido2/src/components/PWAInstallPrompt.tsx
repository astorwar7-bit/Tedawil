'use client';
import { useEffect, useState } from 'react';
import { Download, X } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const t = localStorage.getItem('pwa_install_dismissed');
    if (t) {
      const diff = (Date.now() - new Date(t).getTime()) / (1000 * 60 * 60);
      if (diff < 48) return;
      setDismissed(false);
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      if (!dismissed) setTimeout(() => setShowPrompt(true), 3000);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, [dismissed]);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setShowPrompt(false);
    } catch { /* ignore */ }
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    setDismissed(true);
    localStorage.setItem('pwa_install_dismissed', new Date().toISOString());
  };

  if (!showPrompt || !deferredPrompt) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:w-96 z-[100] animate-slide-up">
      <div className="bg-[#1A1F2E] border border-[#FFD700]/30 rounded-2xl p-4 shadow-2xl shadow-black/50">
        <button onClick={handleDismiss} className="absolute top-3 left-3 text-gray-500 hover:text-white p-1 rounded-lg hover:bg-[#2A3040] transition-colors">
          <X size={16} />
        </button>
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center flex-shrink-0">
            <Download size={22} className="text-[#0A0F0D]" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-sm">تثبيت تداول AI</p>
            <p className="text-gray-400 text-xs mt-0.5 leading-relaxed">أضف التطبيق إلى شاشتك الرئيسية لتجربة أسرع وأفضل</p>
          </div>
        </div>
        <div className="flex gap-2 mt-3">
          <button onClick={handleInstall} className="flex-1 py-2.5 rounded-xl text-xs font-bold btn-premium-gold">تثبيت التطبيق</button>
          <button onClick={handleDismiss} className="px-4 py-2.5 rounded-xl text-xs font-medium bg-[#12161F] text-gray-400 border border-[#2A3040] hover:bg-[#2A3040] transition-colors">لاحقاً</button>
        </div>
      </div>
    </div>
  );
}
