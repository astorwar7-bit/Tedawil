'use client';
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Navbar } from '@/components/Navbar';
import { useRouter } from 'next/navigation';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Users, Bell, User, ArrowRightLeft, Headphones, LogOut, X, Copy, ChevronDown, ChevronUp, ArrowDownToLine } from 'lucide-react';
import Link from 'next/link';

interface AgentNavItem {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
}

const agentNavItems: { title: string; items: AgentNavItem[] }[] = [
  {
    title: 'الرئيسية',
    items: [
      { href: '/agent-dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
    ],
  },
  {
    title: 'العمليات',
    items: [
      { href: '/agent-dashboard/deposits', label: 'إيداع للعملاء', icon: ArrowDownToLine },
      { href: '/agent-dashboard/referrals', label: 'الإحالات', icon: Users },
      { href: '/agent-dashboard/activity-log', label: 'المعاملات', icon: ArrowRightLeft },
    ],
  },
  {
    title: 'الحساب',
    items: [
      { href: '/agent-dashboard/notifications', label: 'الإشعارات', icon: Bell },
      { href: '/agent-dashboard/support', label: 'الدعم', icon: Headphones },
      { href: '/agent-dashboard/profile', label: 'الملف الشخصي', icon: User },
    ],
  },
];

function AgentSidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const pathname = usePathname();
  const { logout } = useAuth();
  const [unreadNotifs, setUnreadNotifs] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchBadges = async () => {
      try {
        const nRes = await fetch('/api/notifications?limit=1').catch(() => null);
        if (nRes?.ok) {
          const nData = await nRes.json();
          setUnreadNotifs((nData.unreadCount || 0) > 0 || (nData.notifications || []).some((n: { isRead: boolean }) => !n.isRead));
        }
      } catch {}
    };
    fetchBadges();
    const interval = setInterval(fetchBadges, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = async () => { await logout(); onClose(); };
  const toggleSection = (title: string) => {
    setCollapsedSections(prev => { const next = new Set(prev); if (next.has(title)) next.delete(title); else next.add(title); return next; });
  };

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm" onClick={onClose} />}
      <aside className={`fixed top-0 right-0 h-full w-64 bg-[#0D1117] border-l border-[#2A3040]/50 z-50 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="relative overflow-hidden p-4 border-b border-[#2A3040]/50">
          <div className="absolute inset-0 bg-gradient-to-l from-[#FFD700]/5 to-transparent pointer-events-none" />
          <div className="relative flex items-center justify-between">
            <Link href="/agent-dashboard" className="flex items-center gap-2.5 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#FFD700] to-[#2ECC71] flex items-center justify-center text-[#0A0F0D] font-bold text-sm shadow-lg shadow-[#FFD700]/20 group-hover:shadow-[#FFD700]/40 transition-shadow">T</div>
              <div>
                <span className="gradient-text-animated font-bold text-lg">تداولاي</span>
                <p className="text-[10px] text-[#FFD700]/60">لوحة الوكيل</p>
              </div>
            </Link>
            <button onClick={onClose} className="lg:hidden text-gray-400 hover:text-white transition-colors p-1 rounded-lg hover:bg-[#1A1F2E]"><X size={20} /></button>
          </div>
        </div>
        <nav className="overflow-y-auto max-h-[calc(100vh-140px)] scrollbar-thin">
          {agentNavItems.map((section) => {
            const isCollapsed = collapsedSections.has(section.title);
            const isSingle = section.items.length === 1;
            return (
              <div key={section.title}>
                {!isSingle && (
                  <button onClick={() => toggleSection(section.title)} className="w-full px-4 pt-4 pb-1.5 flex items-center justify-between group select-none">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 group-hover:text-gray-400 transition-colors">{section.title}</span>
                    {isCollapsed ? <ChevronUp size={12} className="text-gray-600" /> : <ChevronDown size={12} className="text-gray-600" />}
                  </button>
                )}
                {!isCollapsed && (
                  <div className="px-2 space-y-0.5">
                    {section.items.map(item => {
                      const isActive = pathname === item.href;
                      return (
                        <Link key={item.href} href={item.href} onClick={onClose}
                          className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all text-[13px] relative ${
                            isActive ? 'bg-[#FFD700]/10 text-[#FFD700] font-medium neon-gold' : 'text-gray-400 hover:bg-[#1A1F2E] hover:text-white'
                          }`}>
                          <item.icon size={17} className={isActive ? 'text-[#FFD700]' : 'text-gray-500'} />
                          <span>{item.label}</span>
                          {item.href === '/agent-dashboard/notifications' && unreadNotifs && (
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-[#0D1117]" />
                          )}
                          {isActive && <span className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-full bg-[#FFD700]" />}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>
        <div className="gradient-divider mx-4 my-2" />
        <div className="p-3">
          <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm w-full text-red-400/70 hover:text-red-400 hover:bg-red-500/10 transition-all card-lift">
            <LogOut size={17} />
            تسجيل الخروج
          </button>
        </div>
      </aside>
    </>
  );
}

const bottomNavItems = [
  { href: '/agent-dashboard', icon: LayoutDashboard, label: 'الرئيسية' },
  { href: '/agent-dashboard/referrals', icon: Users, label: 'الإحالات' },
  { href: '/agent-dashboard/notifications', icon: Bell, label: 'إشعارات', isCenter: true },
  { href: '/agent-dashboard/activity-log', icon: ArrowRightLeft, label: 'المعاملات' },
  { href: '/agent-dashboard/profile', icon: User, label: 'حسابي' },
];

export default function AgentDashLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const pathname = usePathname();

  useEffect(() => {
    const fetchUnread = async () => {
      try {
        const res = await fetch('/api/notifications?limit=1');
        if (res.ok) { const data = await res.json(); setUnreadCount(data.unreadCount || 0); }
      } catch {}
    };
    if (user) { fetchUnread(); const interval = setInterval(fetchUnread, 30000); return () => clearInterval(interval); }
  }, [user]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#0A0F0D]"><div className="w-8 h-8 border-2 border-[#FFD700] border-t-transparent rounded-full animate-spin" /></div>;
  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#0A0F0D] flex">
      <AgentSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-h-screen">
        <Navbar onMenuClick={() => setSidebarOpen(true)} isAgent />
        <main className="flex-1 p-4 md:p-6">{children}</main>
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 safe-bottom">
          <div className="absolute inset-0 bg-[#0D1117]/85 backdrop-blur-2xl border-t border-[#2A3040]/40" />
          <div style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
            <div className="relative flex justify-around items-end px-1 pt-2 pb-2">
              {bottomNavItems.map((item) => {
                const isActive = pathname === item.href || (item.href !== '/agent-dashboard' && pathname?.startsWith(item.href));
                if (item.isCenter) {
                  return (
                    <a key={item.href} href={item.href} className="flex flex-col items-center justify-end" style={{ minWidth: 52 }}>
                      <span className={`text-[10px] font-medium mb-1 transition-colors ${isActive ? 'text-[#FFD700]' : 'text-gray-400'}`}>{item.label}</span>
                      <div className="nav-center-btn">
                        <item.icon size={22} strokeWidth={2.5} />
                        {unreadCount > 0 && (
                          <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center pulse-badge border-2 border-[#0D1117]">
                            {unreadCount > 9 ? '9+' : unreadCount}
                          </span>
                        )}
                      </div>
                    </a>
                  );
                }
                return (
                  <a key={item.href} href={item.href} className="flex flex-col items-center justify-center relative rounded-2xl transition-all" style={{ minWidth: 52, minHeight: 52 }}>
                    {isActive && <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-1 rounded-full bg-gradient-to-r from-[#FFD700] to-[#2ECC71] nav-active-indicator shadow-lg shadow-[#FFD700]/20" />}
                    <div className={`absolute inset-0 rounded-2xl transition-opacity ${isActive ? 'opacity-100' : 'opacity-0'}`} style={{ background: 'radial-gradient(circle at center, rgba(255, 215, 0, 0.08) 0%, transparent 70%)' }} />
                    <item.icon size={22} strokeWidth={isActive ? 2.5 : 1.8} className={`relative z-10 transition-all ${isActive ? 'text-[#FFD700]' : 'text-gray-400'}`} />
                    <span className={`text-[10px] font-medium relative z-10 mt-0.5 transition-colors ${isActive ? 'text-[#FFD700]' : 'text-gray-400'}`}>{item.label}</span>
                  </a>
                );
              })}
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
}
