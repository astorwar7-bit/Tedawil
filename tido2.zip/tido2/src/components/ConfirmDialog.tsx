'use client';
import { useEffect, useRef } from 'react';
import { AlertTriangle, Info, AlertCircle, X } from 'lucide-react';

interface Props {
  open: boolean;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  onCancel: () => void;
  variant?: 'danger' | 'warning' | 'info';
}

export default function ConfirmDialog({
  open,
  title,
  message,
  confirmText = 'تأكيد',
  cancelText = 'إلغاء',
  onConfirm,
  onCancel,
  variant = 'warning',
}: Props) {
  const confirmRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (open) {
      confirmRef.current?.focus();
    }
  }, [open]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCancel();
    };
    if (open) window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [open, onCancel]);

  if (!open) return null;

  const variantConfig = {
    danger: {
      icon: AlertCircle,
      iconColor: 'text-red-400',
      iconBg: 'bg-red-500/10 border-red-500/20',
      confirmBtn: 'bg-red-500 hover:bg-red-600 text-white',
    },
    warning: {
      icon: AlertTriangle,
      iconColor: 'text-[#FFD700]',
      iconBg: 'bg-[#FFD700]/10 border-[#FFD700]/20',
      confirmBtn: 'btn-premium-gold',
    },
    info: {
      icon: Info,
      iconColor: 'text-[#2ECC71]',
      iconBg: 'bg-[#2ECC71]/10 border-[#2ECC71]/20',
      confirmBtn: 'bg-[#2ECC71] hover:bg-[#25A25A] text-white',
    },
  };

  const config = variantConfig[variant];
  const IconComp = config.icon;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onCancel} />
      <div
        className="relative w-full max-w-sm glass-card p-6 animate-scaleIn border border-[#2A3040]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-dialog-title"
      >
        <button
          onClick={onCancel}
          className="absolute top-3 left-3 text-gray-500 hover:text-gray-300 transition-colors p-1 rounded-lg hover:bg-[#1A1F2E]"
          aria-label="إغلاق"
        >
          <X size={18} />
        </button>

        <div className={`w-14 h-14 mx-auto mb-4 rounded-2xl ${config.iconBg} border flex items-center justify-center`}>
          <IconComp size={28} className={config.iconColor} />
        </div>

        <h3 id="confirm-dialog-title" className="text-white font-bold text-lg text-center mb-2">
          {title}
        </h3>
        <p className="text-gray-400 text-sm text-center leading-relaxed mb-6">
          {message}
        </p>

        <div className="flex gap-3">
          <button
            ref={confirmRef}
            onClick={onConfirm}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${config.confirmBtn}`}
          >
            {confirmText}
          </button>
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 rounded-xl text-sm font-medium text-gray-400 hover:text-white hover:bg-[#1A1F2E] transition-all border border-[#2A3040]"
          >
            {cancelText}
          </button>
        </div>
      </div>
    </div>
  );
}
