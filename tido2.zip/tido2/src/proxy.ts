import { NextRequest, NextResponse } from 'next/server';

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Skip proxy for static files, API routes, public pages
  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    pathname.startsWith('/favicon') ||
    pathname.startsWith('/images') ||
    pathname === '/' ||
    pathname === '/register' ||
    pathname.includes('.') // static files like .js, .css, .png, etc.
  ) {
    return NextResponse.next();
  }

  // Check for token in cookie (tedawilai_token or token) or Authorization header
  const cookieToken =
    request.cookies.get('tedawilai_token')?.value ||
    request.cookies.get('token')?.value;
  const authHeader = request.headers.get('authorization');
  const bearerToken = authHeader?.startsWith('Bearer ')
    ? authHeader.split(' ')[1]
    : null;

  const hasToken = !!(cookieToken || bearerToken);

  // Protect dashboard routes
  if (pathname.startsWith('/dashboard')) {
    if (!hasToken) {
      const loginUrl = new URL('/', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }
  }

  // Protect agent dashboard routes
  if (pathname.startsWith('/agent-dashboard')) {
    if (!hasToken) {
      const loginUrl = new URL('/', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }
  }

  // Protect admin routes
  if (pathname.startsWith('/admin')) {
    if (!hasToken) {
      const loginUrl = new URL('/', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|images/).*)'],
};
