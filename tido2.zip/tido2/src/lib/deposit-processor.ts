import { db } from '@/lib/db';
import { sendRealtimeNotification } from '@/lib/helpers';

/**
 * Process an approved deposit — handles balance credit, referral bonuses,
 * agent commissions, and Level 2 referral commissions.
 * Used by both admin approval and agent auto-approval.
 */
export async function processApprovedDeposit(depositId: string) {
  const deposit = await db.deposit.findUnique({
    where: { id: depositId },
    include: { user: true },
  });

  if (!deposit) throw new Error('الإيداع غير موجود');
  if (deposit.status !== 'pending') throw new Error('تم معالجة هذا الإيداع مسبقاً');

  await db.$transaction(async (tx) => {
    // 1. Mark deposit as approved and credit user balance
    await tx.deposit.update({
      where: { id: depositId },
      data: { status: 'approved' },
    });

    await tx.user.update({
      where: { id: deposit.userId },
      data: { balance: { increment: deposit.amount } },
    });

    await sendRealtimeNotification(
      deposit.userId,
      'تم قبول الإيداع',
      `تم قبول إيداعك بقيمة $${deposit.amount.toFixed(2)} وإضافته إلى رصيدك.`,
      'success'
    );

    await tx.userActivity.create({
      data: {
        userId: deposit.userId,
        action: 'DEPOSIT_APPROVED',
        details: `تم قبول إيداع $${deposit.amount.toFixed(2)} بطريقة ${deposit.method}`,
        amount: deposit.amount,
      },
    });

    // 2. Referral signup bonus (Level 1) — only on FIRST deposit
    if (deposit.user.referredBy && !deposit.user.referralBonusGiven) {
      const settings = await tx.setting.findFirst();
      const referralFixedBonus = settings?.referralFixedBonus || 0;

      if (referralFixedBonus > 0) {
        // Credit the Level 1 referrer
        await tx.user.update({
          where: { id: deposit.user.referredBy },
          data: { balance: { increment: referralFixedBonus } },
        });

        await tx.dailyProfit.create({
          data: {
            userId: deposit.user.referredBy,
            amount: referralFixedBonus,
            type: 'referral_signup',
            rate: 0,
          },
        });

        await tx.user.update({
          where: { id: deposit.userId },
          data: { referralBonusGiven: true },
        });

        await tx.notification.create({
          data: {
            userId: deposit.user.referredBy,
            title: 'مكافأة إحالة جديدة!',
            message: `حصلت على مكافأة $${referralFixedBonus.toFixed(2)} بفضل إيداع ${deposit.user.username} الأول.`,
            type: 'referral',
          },
        });

        await tx.notification.create({
          data: {
            userId: deposit.userId,
            title: 'تم تفعيل كود الإحالة',
            message: `تم إيداعك الأول بنجاح! حصل المُحيل على مكافأة $${referralFixedBonus.toFixed(2)} بفضل كود الإحالة.`,
            type: 'referral',
          },
        });

        await tx.userActivity.create({
          data: {
            userId: deposit.user.referredBy,
            action: 'REFERRAL_BONUS',
            details: `مكافأة إحالة: $${referralFixedBonus.toFixed(2)} بسبب إيداع ${deposit.user.username} الأول`,
            amount: referralFixedBonus,
          },
        });

        // Level 2 referral bonus: check if the Level 1 referrer was also referred
        const level1Referrer = await tx.user.findUnique({
          where: { id: deposit.user.referredBy },
          select: { referredBy: true, username: true },
        });

        if (level1Referrer?.referredBy) {
          const settings2 = await tx.setting.findFirst();
          const level2Rate = settings2?.referralLevel2Rate || 0;
          const level2Bonus = referralFixedBonus * (level2Rate / 100);

          if (level2Bonus > 0) {
            await tx.user.update({
              where: { id: level1Referrer.referredBy },
              data: { balance: { increment: level2Bonus } },
            });

            await tx.dailyProfit.create({
              data: {
                userId: level1Referrer.referredBy,
                amount: level2Bonus,
                type: 'referral_level2',
                rate: level2Rate,
              },
            });

            await tx.notification.create({
              data: {
                userId: level1Referrer.referredBy,
                title: 'عمولة إحالة من المستوى الثاني',
                message: `حصلت على عمولة $${level2Bonus.toFixed(2)} من إحالة المستوى الثاني بسبب تسجيل ${deposit.user.username}.`,
                type: 'referral',
              },
            });
          }
        }
      }
    }

    // 3. Agent commission (if referrer is an agent)
    if (deposit.user.referredBy) {
      const referrer = await tx.user.findUnique({
        where: { id: deposit.user.referredBy },
        select: { id: true, isAgent: true, agentCommissionRate: true, username: true },
      });

      if (referrer && referrer.isAgent && referrer.agentCommissionRate > 0) {
        const commission = deposit.amount * (referrer.agentCommissionRate / 100);

        await tx.user.update({
          where: { id: referrer.id },
          data: { balance: { increment: commission } },
        });

        await tx.dailyProfit.create({
          data: {
            userId: referrer.id,
            amount: commission,
            type: 'agent_commission',
            rate: referrer.agentCommissionRate,
          },
        });

        await tx.userActivity.create({
          data: {
            userId: referrer.id,
            action: 'AGENT_COMMISSION',
            details: `عمولة وكيل من إيداع ${deposit.user.username}: $${commission.toFixed(2)} (${referrer.agentCommissionRate}% من $${deposit.amount.toFixed(2)})`,
            amount: commission,
          },
        });

        await tx.notification.create({
          data: {
            userId: referrer.id,
            title: 'عمولة جديدة من إحالتك',
            message: `حصلت على عمولة $${commission.toFixed(2)} من إيداع ${deposit.user.username} بقيمة $${deposit.amount.toFixed(2)} (نسبة ${referrer.agentCommissionRate}%)`,
            type: 'referral',
          },
        });
      }
    }
  });
}
