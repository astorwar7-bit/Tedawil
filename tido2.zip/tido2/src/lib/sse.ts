/**
 * Server-Sent Events (SSE) connection manager.
 * Stores active SSE connections per userId in-memory.
 * Works within a single Next.js process — suitable for this project's scale.
 */

interface SSEConnection {
  controller: ReadableStreamDefaultController;
  createdAt: number;
}

// Map of userId -> Set of active connections (multiple tabs per user)
const connections = new Map<string, Set<SSEConnection>>();

/**
 * Register a new SSE connection for a user.
 * Returns a cleanup function to remove the connection when closed.
 */
export function addConnection(
  userId: string,
  controller: ReadableStreamDefaultController
): () => void {
  const conn: SSEConnection = { controller, createdAt: Date.now() };

  if (!connections.has(userId)) {
    connections.set(userId, new Set());
  }
  connections.get(userId)!.add(conn);

  // Return cleanup function
  return () => {
    const userConns = connections.get(userId);
    if (userConns) {
      userConns.delete(conn);
      if (userConns.size === 0) {
        connections.delete(userId);
      }
    }
  };
}

/**
 * Push a notification to all active SSE connections for a given user.
 * The data is serialized as JSON and sent as an SSE "notification" event.
 */
export function sendNotificationToUser(
  userId: string,
  notification: {
    id: string;
    title: string;
    message: string;
    type: string;
    isRead: boolean;
    createdAt: string;
  }
) {
  const userConns = connections.get(userId);
  if (!userConns || userConns.size === 0) return;

  const data = JSON.stringify(notification);
  const payload = `event: notification\ndata: ${data}\n\n`;

  const dead: SSEConnection[] = [];

  for (const conn of userConns) {
    try {
      const encoder = new TextEncoder();
      conn.controller.enqueue(encoder.encode(payload));
    } catch {
      // Controller is closed — mark for removal
      dead.push(conn);
    }
  }

  // Clean up dead connections
  for (const conn of dead) {
    userConns.delete(conn);
  }
  if (userConns.size === 0) {
    connections.delete(userId);
  }
}

/**
 * Get the number of active connections (useful for debugging).
 */
export function getActiveConnectionCount(): number {
  let total = 0;
  for (const conns of connections.values()) {
    total += conns.size;
  }
  return total;
}
