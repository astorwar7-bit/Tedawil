import { db } from '@/lib/db';
import { sendNotificationToUser } from '@/lib/sse';

export async function sendRealtimeNotification(
  userId: string,
  title: string,
  message: string,
  type: string
) {
  const notification = await db.notification.create({
    data: { userId, title, message, type },
  });

  sendNotificationToUser(userId, {
    id: notification.id,
    title: notification.title,
    message: notification.message,
    type: notification.type,
    isRead: notification.isRead,
    createdAt: notification.createdAt.toISOString(),
  });

  return notification;
}

export async function getSettings() {
  let settings = await db.setting.findFirst();
  if (!settings) {
    settings = await db.setting.create({
      data: {
        platformName: 'تداول AI',
        platformNameEn: 'Tadawul AI',
        platformDesc: 'منصة استثمار رقمية متكاملة',
        mainWalletAddress: '',
        minDeposit: 100,
        minWithdraw: 10,
        referralBonusRate: 5,
        minDailyRate: 1.2,
        maxDailyRate: 1.7,
        welcomeBonus: 10,
      },
    });
  }
  return settings;
}

export async function logActivity(adminName: string, actionType: string, details: string, ipAddress: string = '') {
  await db.activityLog.create({
    data: { adminName, actionType, details, ipAddress },
  });
}
