/**
 * ====================================
 * تداول AI - Database Setup Script
 * Ready for deployment with Node.js
 * ====================================
 *
 * Usage:
 *   node setup-database.js          # Initialize fresh database with seed data
 *   node setup-database.js --reset   # Reset database (drops and recreates)
 *
 * Requirements:
 *   - Node.js 18+
 *   - Run from project root: /home/z/my-project/
 */

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function hashPassword(password) {
  return bcrypt.hash(password, 12);
}

async function main() {
  const isReset = process.argv.includes('--reset');

  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║   Tadawul AI - Database Setup                  ║');
  console.log('║   تداول AI - تهيئة قاعدة البيانات               ║');
  console.log('╚══════════════════════════════════════════════════╝\n');

  if (isReset) {
    console.log('⚠️  Reset mode: This will DELETE all existing data!\n');
  }

  // 1. Create Settings
  console.log('📋 Step 1/5: Creating platform settings...');
  const settings = await prisma.setting.upsert({
    where: { id: 'default' },
    update: {},
    create: {
      id: 'default',
      platformName: 'تداول AI',
      platformNameEn: 'Tadawul AI',
      platformDesc: 'منصة استثمار رقمية متكاملة - تداول AI',
      platformLogo: '',
      mainWalletAddress: '',
      minDeposit: 100,
      minWithdraw: 10,
      referralBonusRate: 5,
      minDailyRate: 1.2,
      maxDailyRate: 1.7,
      welcomeBonus: 10,
    },
  });
  console.log('   ✅ Settings created:', settings.platformNameEn);

  // 2. Create Admin User
  console.log('\n👤 Step 2/5: Creating admin user...');
  const adminPassword = await hashPassword('Admin123456');
  const admin = await prisma.user.upsert({
    where: { username: 'tedawilai_admin' },
    update: {},
    create: {
      username: 'tedawilai_admin',
      fullName: 'مدير المنصة',
      email: 'admin@tadawulai.com',
      phone: '+966500000000',
      password: adminPassword,
      isAdmin: true,
      isActive: true,
      balance: 0,
      avatar: '',
      referralCode: 'ADMIN001',
    },
  });
  console.log('   ✅ Admin user created:', admin.username);

  // 3. Create Investment Plans
  console.log('\n📊 Step 3/5: Creating investment plans...');
  const plans = [
    {
      name: 'البرونزي',
      nameEn: 'Bronze',
      minAmount: 100,
      maxAmount: 999,
      dailyRate: 1.2,
      duration: 30,
      icon: '🥉',
      color: '#CD7F32',
      isActive: true,
      sortOrder: 1,
      description: 'خطة للمبتدئين - استثمار آمن ومضمون بنسبة ثابتة يومياً',
    },
    {
      name: 'الفضي',
      nameEn: 'Silver',
      minAmount: 1000,
      maxAmount: 4999,
      dailyRate: 1.5,
      duration: 30,
      icon: '🥈',
      color: '#C0C0C0',
      isActive: true,
      sortOrder: 2,
      description: 'خطة متقدمة بعوائد أعلى - مناسبة للمستثمرين ذوي الخبرة',
    },
    {
      name: 'الذهبي',
      nameEn: 'Gold',
      minAmount: 5000,
      maxAmount: 19999,
      dailyRate: 2.0,
      duration: 45,
      icon: '🥇',
      color: '#FFD700',
      isActive: true,
      sortOrder: 3,
      description: 'خطة ذهبية بمزايا حصرية - عوائد مميزة ومدة أطول',
    },
    {
      name: 'الماسي',
      nameEn: 'Diamond',
      minAmount: 20000,
      maxAmount: 0,
      dailyRate: 3.5,
      duration: 60,
      icon: '💎',
      color: '#3498DB',
      isActive: true,
      sortOrder: 4,
      description: 'خطة الماس الحصرية - أعلى عوائد مع مميزات VIP كاملة',
    },
  ];

  for (const plan of plans) {
    const existing = await prisma.investmentPlan.findFirst({ where: { nameEn: plan.nameEn } });
    if (!existing) {
      await prisma.investmentPlan.create({ data: plan });
      console.log(`   ✅ Plan created: ${plan.nameEn} ($${plan.minAmount} - ${plan.dailyRate}%)`);
    } else {
      console.log(`   ⏭️  Plan exists: ${plan.nameEn}`);
    }
  }

  // 4. Create Trading Bots
  console.log('\n🤖 Step 4/5: Creating trading bots...');
  const bots = [
    {
      name: 'Bot Alpha',
      description: 'بوت تداول ذكي يعتمد على تحليل الاتجاهات العامة مع إدارة مخاطر محكمة',
      strategy: 'Trend Following + Risk Management',
      dailyReturn: 1.5,
      riskLevel: 'منخفض',
      minBalance: 500,
      icon: '🤖',
      color: '#2ECC71',
      isActive: true,
      sortOrder: 1,
    },
    {
      name: 'Bot Pro',
      description: 'بوت احترافي للمتداولين ذوي الخبرة - استراتيجيات متقدمة ومتنوعة',
      strategy: 'Multi-Strategy Scalping',
      dailyReturn: 2.5,
      riskLevel: 'متوسط',
      minBalance: 2000,
      icon: '⚡',
      color: '#FFD700',
      isActive: true,
      sortOrder: 2,
    },
    {
      name: 'Bot Elite',
      description: 'بوت النخبة - أعلى عوائد مع تحليل ذكاء اصطناعي متقدم',
      strategy: 'AI-Powered Grid Trading',
      dailyReturn: 4.0,
      riskLevel: 'عالي',
      minBalance: 10000,
      icon: '🔥',
      color: '#E74C3C',
      isActive: true,
      sortOrder: 3,
    },
  ];

  for (const bot of bots) {
    const existing = await prisma.tradingBot.findFirst({ where: { name: bot.name } });
    if (!existing) {
      await prisma.tradingBot.create({ data: bot });
      console.log(`   ✅ Bot created: ${bot.name} (${bot.dailyReturn}%/day)`);
    } else {
      console.log(`   ⏭️  Bot exists: ${bot.name}`);
    }
  }

  // 5. Create Sample Coupons
  console.log('\n🎫 Step 5/5: Creating sample coupons...');
  const coupons = [
    {
      code: 'WELCOME2024',
      discount: 10,
      type: 'percentage',
      maxUses: 1000,
      maxUsesPerUser: 1,
      minInvestment: 0,
      expiresAt: new Date('2026-12-31'),
      isActive: true,
    },
    {
      code: 'LAUNCH50',
      discount: 50,
      type: 'fixed',
      maxUses: 500,
      maxUsesPerUser: 1,
      minInvestment: 200,
      expiresAt: new Date('2026-06-30'),
      isActive: true,
    },
    {
      code: 'VIP20',
      discount: 20,
      type: 'percentage',
      maxUses: 100,
      maxUsesPerUser: 1,
      minInvestment: 5000,
      expiresAt: new Date('2026-12-31'),
      isActive: true,
    },
  ];

  for (const coupon of coupons) {
    const existing = await prisma.coupon.findUnique({ where: { code: coupon.code } });
    if (!existing) {
      await prisma.coupon.create({ data: coupon });
      console.log(`   ✅ Coupon created: ${coupon.code} (${coupon.type === 'fixed' ? '$' + coupon.discount : coupon.discount + '%'})`);
    } else {
      console.log(`   ⏭️  Coupon exists: ${coupon.code}`);
    }
  }

  // Summary
  const userCount = await prisma.user.count();
  const planCount = await prisma.investmentPlan.count();
  const botCount = await prisma.tradingBot.count();
  const couponCount = await prisma.coupon.count();

  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║   Setup Complete!                            ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log(`║   Users:        ${String(userCount).padEnd(33)}║`);
  console.log(`║   Plans:        ${String(planCount).padEnd(33)}║`);
  console.log(`║   Bots:         ${String(botCount).padEnd(33)}║`);
  console.log(`║   Coupons:      ${String(couponCount).padEnd(33)}║`);
  console.log('╠══════════════════════════════════════════════════╣');
  console.log('║   Admin Login:                               ║');
  console.log('║   Username: tedawilai_admin                  ║');
  console.log('║   Password: Admin123456                      ║');
  console.log('╚══════════════════════════════════════════════════╝\n');
}

main()
  .catch((e) => {
    console.error('❌ Error:', e.message);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
