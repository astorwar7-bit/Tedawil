# Task 1-5: Enhanced Coupon System

## Summary
Enhanced the coupon system to support both percentage-based and fixed-amount discount types across the full stack.

## Changes Made

### 1. Prisma Schema (`prisma/schema.prisma`)
- Added `type String @default("percentage")` field to the Coupon model
- Supports "percentage" or "fixed" coupon types

### 2. New Coupon Validation API (`src/app/api/coupons/route.ts`)
- Created POST endpoint for validating coupon codes before investment
- Validates: coupon exists, is active, not expired, not maxed out
- Calculates discount amount based on type (fixed vs percentage)
- Returns original amount, discount amount, and final amount for preview

### 3. Admin Coupons API (`src/app/api/admin/coupons/route.ts`)
- Updated POST to accept `type` field with validation
- Percentage: discount must be 0-100
- Fixed: discount must be > 0
- Updated GET to include investment count stats
- Updated PUT to handle type changes
- Activity logging includes type information

### 4. Investment API (`src/app/api/investments/route.ts`)
- Updated coupon handling to check `coupon.type`
- `fixed`: `finalAmount = amount - coupon.discount`
- `percentage`: `finalAmount = amount - (amount * coupon.discount / 100)`
- Added `finalAmount > 0` validation

### 5. Admin Coupons Page (`src/app/(admin)/admin/coupons/page.tsx`)
- Added stats cards (total, active, inactive coupons)
- Added type column to table with colored badges
- Added usage progress bar per coupon
- Added investment count column
- Added type selector (percentage/fixed) in create/edit modal
- Dynamic discount label based on selected type
- Live discount preview showing example calculation
- Improved modal with cancel button

### 6. Plans Page (`src/app/(dashboard)/plans/page.tsx`)
- Added coupon validation with "تطبيق" (Apply) button
- Shows loading state during validation
- Displays coupon details after successful validation (type, discount, final amount, remaining uses)
- Error messages for invalid/expired/maxed coupons
- Investment summary showing original amount, discount, final amount, and expected profit
- Automatically re-validates coupon when investment amount changes
- Option to remove applied coupon
