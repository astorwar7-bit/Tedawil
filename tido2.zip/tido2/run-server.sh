#!/bin/bash
cd /home/z/my-project
while true; do
  node .next/standalone/server.js -p 3000 -H 0.0.0.0
  echo "Server died, restarting in 2s..."
  sleep 2
done
