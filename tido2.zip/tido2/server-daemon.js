const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');

function start() {
  const srv = spawn('node', ['.next/standalone/server.js'], {
    env: { ...process.env, PORT: '3000', HOSTNAME: '0.0.0.0', NODE_ENV: 'production' },
    stdio: ['ignore', fs.openSync('server.log', 'a'), fs.openSync('server.log', 'a')],
  });
  srv.on('exit', () => setTimeout(start, 2000));
  srv.on('error', () => setTimeout(start, 2000));
  console.log('Started PID:', srv.pid);
}

start();
